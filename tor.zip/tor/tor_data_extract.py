import pandas as pd
from bs4 import BeautifulSoup

def extract_tor_node_list(html_file):
    print("\n"+"+"*20+"Scrapping in Process"+"+"*20)

    with open(html_file, 'r', encoding='utf-8') as file:
        soup = BeautifulSoup(file, 'html.parser')

    hidden_div = soup.find('div', {'style': 'display: none'})

    if hidden_div:
        # decode contents gives plain text
        div_content = hidden_div.decode_contents()
        start_marker = "<!-- __BEGIN_TOR_NODE_LIST__ //-->"
        end_marker = "<!-- __END_TOR_NODE_LIST__ //-->"
        
        # find start index from where to start fetching the data till end index 
        start_index = div_content.find(start_marker)
        end_index = div_content.find(end_marker)
        
        # fetch the data and skips <!-- __BEGIN_TOR_NODE_LIST__ //--> and <!-- __END_TOR_NODE_LIST__ //-->
        if start_index != -1 and end_index != -1:
            tor_node_data = div_content[start_index + len(start_marker):end_index].strip()
            rows = tor_node_data.splitlines()

            # data cleaning 
            cleaned_rows = []
            uncleaned_rows = []
            for row in rows:
                cleaned_row = row.replace('<br/>', '').split('|', 7)  
                if len(cleaned_row) == 8:
                    cleaned_rows.append(cleaned_row)
                else:
                    print(f"Skipped row due to column mismatch: {row}")
                    uncleaned_rows.append(row)
            return cleaned_rows,uncleaned_rows
    return [],[]

if __name__ == "__main__":
    html_file = 'march8.html'
    clean_data,uncleaned_data = extract_tor_node_list(html_file)
   
    if clean_data:
        column_headers = ['ip', 'name', 'onion_port', 'directory_port', 'flags', 'uptime', 'tor_version', 'email']
        df1 = pd.DataFrame(clean_data, columns=column_headers)
        df1.to_csv('tor_data_cleaned.csv', index=False, encoding='utf-8')
        print("\n"+"-"*35)
        print("TOR data successfully written")
        print("-"*35)

    else:
        print("No valid TOR Node data found in the HTML file.")
