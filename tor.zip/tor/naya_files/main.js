var	eMail = "\x08\x0B\x0A\x0F\x55\x1B\x6D\x00\x01\x65\x43\x2C";
var	emKey = 'enJk4uCmdK6GxUDvF3pWgQkJvHy8WHja';

// global variables
var	menuOpen = false;
var	loggedIn = false;
var	loginUser = '';
var	sessionId = '';
var	asn = 0;

function doXor(text, key) {
	return Array.from(text, (c, i) => String.fromCharCode(c.charCodeAt() ^ key.charCodeAt(i % key.length))).join('');
}

function getEmail() {
	return doXor(eMail, emKey);
}

function showIcon(name, show, tooltip) {
	if (tooltip != '')
		$('#tt-' + name).html(tooltip);
	if (show)
		$('#icon-' + name).css('color', 'rgba(255, 255, 255, 0.9)');
	else
		$('#icon-' + name).css('color', 'rgba(255, 255, 255, 0.25)');
}

function showHideLoginFeatures() {
	if (loggedIn) {
		showIcon('loggedin', true, 'Logged in as: ' + loginUser);
		$('.loggedin').css('visibility', 'visible');
		$('.loginonly').removeClass('hideitem');
		$('.logoutonly').addClass('hideitem');
	} else {
		showIcon('loggedin', false, 'Not logged in');
		$('.loggedin').css('visibility', 'hidden');
		$('.loginonly').addClass('hideitem');
		$('.logoutonly').removeClass('hideitem');
	}
}

function toggleMenu() {
	if (!menuOpen) {
		menuOpen = true;
		$('.menubar').addClass('showitem');
		$('.menubar-footer').html('&#9650; &nbsp; MENU &nbsp; &#9650;');
	} else {
		menuOpen = false;
		$('.menubar').removeClass('showitem');
		$('.menubar-footer').html('&#9660; &nbsp; MENU &nbsp; &#9660;');
	}
}

function showLogin() {
	// first close the menu bar
	if (menuOpen)
		toggleMenu();
	// ignore if already logged in
	if (loggedIn)
		return false;
	// now hide all items
	$('.wrapper').addClass('blur-filter');
	// show login box
	$('.loginbox').css('visibility', 'visible');
	// move focus to username box
	$('#loginUser').focus();
	$('#loginUser').select();
}

function closeLogin() {
	$('.wrapper').removeClass('blur-filter');
	$('.loginbox').css('visibility', 'hidden');
}

function doLogin() {
	var loginUsername = $('#loginUser').val();
	var loginPass = $('#loginPass').val();
	var login2FA = $('#login2FA').val();
	// try to login
	$.post('login.php', {
		user: loginUsername,
		pass: loginPass,
		twofa: login2FA
	}, function(data) {
		var errno = data['errno'];
		var errmsg = data['error'];
		if (errno != '' && errno != '0') {
			// error
			$('#login-err').text('#' + errno + ': ' + errmsg);
			$('.loginbox-err').css('visibility', 'visible');
			// show for a few seconds
			setTimeout(function(){
				$('.loginbox-err').css('visibility', 'hidden');
				$('#login-err').text('');
			}, 3000);
			return true;
		} else {
			// success
			sessionId = data['sid'];
			// activate the menu items
			loggedIn = true;
			loginUser = loginUsername;
			showHideLoginFeatures();
			closeLogin();
			return true;
		}
	}, "json");
}

function doLogout() {
	if (!loggedIn)
		return false;
	// try to logout
	$.post('logout.php', {
		sid: sessionId
	}, function(data) {
		var resp = data['response'];
		if (resp == 'success') {
			// deactivate the menu items
			loggedIn = false;
			sessionId = '';
			showHideLoginFeatures();
			return true;
		}
	}, "json");
}

function getClientInfo() {
	// get visitor info
	if ($('#ci-ip4').html() == '-')
		$.getJSON('https://ipv4.dan.me.uk/info.php?ip', function(data) {
			$('#ci-ip4').html(data['ip']);
		});
	if ($('#ci-ip6').html() == '-')
		$.getJSON('https://ipv6.dan.me.uk/info.php?ip', function(data) {
			$('#ci-ip6').html(data['ip']);
		});
	$.getJSON('/info.php', function(data) {
		asn = data['asn'];
		$('#ni-db').html(data['db-node']);
		$('#ni-web').html(data['web-node']);
		$('#ci-isp').html('AS' + data['asn'] + ': ' + data['isp'] + ' [' + data['iso'] + ']');
		$('#ci-ssl').html(data['ssl-keysize'] + '-bit ' + data['ssl-proto'] + ' [' + data['ssl-cipher'] + ']');
		$('#ci-proto').html(data['protocol']);
		if (data['ip'].includes(':')) {
			$('#ci-ip46').html('IPv6');
			$('.ci-marker6').html('&#9989;');
			$('.ci-v4v6').css('display', 'inline-flex');
		} else {
			$('#ci-ip46').html('IPv4');
			$('.ci-marker4').html('&#9989;');
			$('.ci-v4v6').css('display', 'inline-flex');
		}
		if (data['protocol'] == 'HTTP/2.0')
			showIcon('http2', true, 'HTTP/2.0 protocol detected');
		if (data['is_pv']) {
			if (data['tornode'])
				showIcon('proxyvpn', true, 'TOR node detected');
			else
				showIcon('proxyvpn', true, 'Anonymous Proxy/VPN detected');
		}
		if (data['logged-in']) {
			loggedIn = true;
			loginUser = data['login-user'];
		} else {
			loggedIn = false;
			loginUser = '';
		}
		// update login features
		showHideLoginFeatures();
	});
};

$(document).ready(function() {
	showHideLoginFeatures();

	$(document).on('click', 'a', function(e) {
		var id = $(this).data('id');
		switch (id) {
			default:
				break;
			case 'login':
				showLogin();
				break;
			case 'logout':
				doLogout();
				break;
			case 'menu':
				toggleMenu();
				break;
		}
	});
	$(document).on('click', 'button', function(e) {
		var id = $(this).data('id');
		switch (id) {
			default:
				break;
			case 'loginbtn':
				doLogin();
				break;
		}
	});
	// handle keys
	$(document).on('keydown', function(e) {
		if (e.key === 'Escape') {
			if (menuOpen)
				toggleMenu();
			closeLogin();
		} else if (e.key === 'Enter') {
			var loginVis = $('.loginbox').css('visibility');
			if (loginVis != 'hidden') {
				document.getElementById("loginbtn").click();
			}
		}
	});
	// handle other clicks
	$('#login-x').click(function() {
		closeLogin();
	});
	$('#gallery-image-i').click(function() {
		if ($('.gallery-image-info').css('display') == 'none')
			$('.gallery-image-info').css('display', 'grid');
		else
			$('.gallery-image-info').css('display', 'none');
	});
	$('#gallery-image-x').click(function() {
		$('.wrapper').removeClass('blur-filter');
		$('#gallery-image').css('visibility', 'hidden');
	});
	$('#icon-email').click(function() {
		var emvis = $('.emailme').css('visibility');
		if (emvis == 'visible') {
			$('.emailme').css('visibility', 'hidden');
		} else {
			var email = getEmail();
			$('#email').html('<a href="mailto:' + email + '">' + email + '</a>');
			$('.emailme').css('visibility', 'visible');
		}
	});
	$('#icon-pgpkey').click(function() {
		$('#content-box').load('pgp.asc', function( response, status, xhr ) {
			if (status == 'success') {
				document.title = 'Secure E-mail and File Transfer - PGP';
				$('#content-title').html('Secure E-mail and File Transfer - PGP');
				$('#content-box').html('<div class="cb-box" style="width: fit-content; min-width: fit-content;"><span>Secure PGP Key</span>\
<p><br />Please use the PGP key below to send secure email to me.<br /><br />\
Alternatively, you can download it at <a href="pgp.asc">pgp.asc</a><br /><br />\
<pre>' + response + '</pre></div>');
			}
		});
	});
});

// only get client info once entire page is loaded
$(window).on('load', function() {
	showIcon('email', true, '');
	$('#icon-email').css('cursor', 'pointer');
	$('#icon-pgpkey').css('cursor', 'pointer');
	showIcon('pgpkey', true, '');
	showIcon('http2', false, 'HTTP/1.x protocol detected');
	showIcon('proxyvpn', false, 'No anonymous proxy/VPN detected');
	getClientInfo();
	// update client info every minute so sessions don't timeout while on page
	setInterval(getClientInfo, 50000);

	// used for code blocks in blog
	const blogspans = document.querySelectorAll('.codecopy');
	Array.from(blogspans).forEach(span => {
		span.addEventListener('click', event => {
			const copytext = event.target.parentElement.innerText.slice(0, -5);
			navigator.clipboard.writeText(copytext);
			event.target.innerText = 'Copied';
			setTimeout(function() { event.target.innerText = ' Copy '; }, 2000);
		});
	});
});

function setContentTitle(title) {
	$('#content-title').html(title);
}

