import time
import tarantool
import pandas as pd

connection = tarantool.connect('192.168.1.134', 3302)
tor_name = ''
tor_onion_port = ''
tor_directory_port = ''
tor_flags = ''
tor_uptime = ''
tor_version = ''
tor_email = ''
is_tor_detected = 'no'

# def insert_batch(df,connection):

#     tuples = [tuple(x) for x in df.to_records(index=False)]
#     connection.call("batch_insert", ('tor_details',tuples))
#     print("successfull insert") 
# try:
#     df = pd.read_csv('tor.csv',index_col=False)
# except Exception as e:
#     print("Error reading file:", e)
# df = df.astype(str)
# df['email'] = df['email'].replace('nan','')
# df['directory_port'] = df['directory_port'].replace('0.0','0')
# print(df.dtypes)
# print(df.head(10))
# ip_to_dict_space = connection.space('tor_details')
# insert_batch(df,connection)  

# def test(destination_ip_address):
#     for idx,dest_ip in enumerate(destination_ip_address):
#         # result = connection.call('fetch_tor_data', 'tor_details', str('100.15.73.71'))
#         result = connection.call('fetch_tor_data', 'tor_details', str(dest_ip))

#         if result:  
#             data = result[0]  
#             print(data)
#             if data:  
#                 data_dict = data[0]  
                
#                 tor_name = str(data_dict.get('name', '')).replace("[","").replace("]","").replace("'","").upper()
#                 tor_onion_port = str(data_dict.get('onion_port', '')).replace("[","").replace("]","").replace("'","")
#                 tor_directory_port = str(data_dict.get('directory_port', '')).replace("[","").replace("]","").replace("'","") if data_dict.get('directory_port') != '0' else 'UNKNOWN'
#                 tor_flags = str(data_dict.get('flags', '')).replace("[","").replace("]","").replace("'","")
#                 tor_uptime = str(data_dict.get('uptime', '')).replace("[","").replace("]","").replace("'","").upper()
#                 tor_version = str(data_dict.get('tor_version', '')).replace("[","").replace("]","").replace("'","").upper()
#                 email_value = data_dict.get('email', '')
#                 tor_email = (
#                     str(email_value).replace("[", "").replace("]", "").replace("'", "").upper()
#                     if email_value and email_value.lower() != 'nan' and email_value.strip()
#                     else 'UNKNOWN'
#                 )
#                 is_tor_detected = 'yes'

#                 print(f"Name: {tor_name}")
#                 print(f"Onion Port: {tor_onion_port}")
#                 print(f"Directory Port: {tor_directory_port}")
#                 print(f"Flags: {tor_flags}")
#                 print(f"Uptime: {tor_uptime}")
#                 print(f"Tor Version: {tor_version}")
#                 print(f"Email: {tor_email}")
#             else:
#                 print("No data found.",idx)

# df = pd.read_csv('unique.csv')
# unique_dest_ip = df['destination_ip']
# test(unique_dest_ip)

result = connection.call('fetch_tor_data', 'tor_details', str('104.152.209.217'))
if result:  
    data = result[0]  
    print(data)
    if data:  
        tor_name = str(data.get('name', '')).replace("[","").replace("]","").replace("'","").upper()
        tor_onion_port = str(data.get('onion_port', '')).replace("[","").replace("]","").replace("'","")
        tor_directory_port = str(data.get('directory_port', '')).replace("[","").replace("]","").replace("'","") if data.get('directory_port') != '0' else 'UNKNOWN'
        tor_flags = str(data.get('flags', '')).replace("[","").replace("]","").replace("'","")
        tor_uptime = str(data.get('uptime', '')).replace("[","").replace("]","").replace("'","").upper()
        tor_version = str(data.get('tor_version', '')).replace("[","").replace("]","").replace("'","").upper()
        email_value = data.get('email', '')
        tor_email = (
            str(email_value).replace("[", "").replace("]", "").replace("'", "").upper()
            if email_value and email_value.lower() != 'nan' and email_value.strip()
            else 'UNKNOWN'
        )
        is_tor_detected = 'yes'

        print(f"Name: {tor_name}")
        print(f"Onion Port: {tor_onion_port}")
        print(f"Directory Port: {tor_directory_port}")
        print(f"Flags: {tor_flags}")
        print(f"Uptime: {tor_uptime}")
        print(f"Tor Version: {tor_version}")
        print(f"Email: {tor_email}")
    else:
        print("No data found.")
