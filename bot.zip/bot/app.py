from flask import Flask, render_template, request, jsonify
import os
from chatbot import get_response  

app = Flask(__name__, template_folder=os.getcwd()) 

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get', methods=['POST'])
def get_bot_response():
    try:
        user_input = request.form.get('user_input') or request.json.get('user_input')
        if not user_input:
            return jsonify({'response': "Invalid input!"}), 400
        
        bot_response = get_response(user_input)
        print(bot_response)  
        return jsonify({'response': bot_response})
    except Exception as e:
        return jsonify({'response': f"Error: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True)