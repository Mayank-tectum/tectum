from groq import Groq

API_KEY = "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"
client = Groq(api_key=API_KEY)

def get_response(prompt):

    completion = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {"role": "user", "content": prompt}
        ] ,
        temperature=1,
        max_tokens=5000,
        max_completion_tokens=1024,
        top_p=1,
        stream=True
    )

    response_text = ""

    for chunk in completion:
        content = chunk.choices[0].delta.content or ""
        response_text += content  

    return response_text