// Selecting element to view chat
var chatBotSession = document.querySelector( ".chatBot .chatBody .chatSession" )

// Selecting trigger elements of conversation
var chatBotSendButton = document.querySelector( ".chatBot .chatForm #sendButton" )
var chatBotTextArea = document.querySelector( ".chatBot .chatForm #chatTextBox" )

// Default values for replies
var chatBotBlankMessageReply = "Type something!"
var chatBotReply = "{{ reply }}"

// Collecting user input
var inputMessage = ""

var typeOfContainer = ""

// Function to open ChatBot
chatBotSendButton.addEventListener("click", (event)=> {
    event.preventDefault()
    if( validateMessage() ){
        inputMessage    = chatBotTextArea.value
        typeOfContainer = "message"
        createContainer( typeOfContainer )
        fetch("/get", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ user_input: inputMessage })
        })
        .then(response => response.json())
        .then(data => {
            chatBotReply = data.response; 
            typeOfContainer = "reply";
            createContainer(typeOfContainer);
        })
        .catch(error => {
            console.error("Error:", error);
            chatBotReply = "Error connecting to chatbot!";
            typeOfContainer = "reply";
            createContainer(typeOfContainer);
        });
        
    }
    else{        
        typeOfContainer = "error";
        createContainer( typeOfContainer )
    }
    chatBotTextArea.value = ""
    chatBotTextArea.focus()
})

function formatBotResponse(response) {
    // Replace new lines with <br> for proper spacing
    response = response.replace(/\n/g, "<br>");

    // Format code blocks (```python ... ```)
    response = response.replace(/```(.*?)```/gs, function(match, code) {
        return `<pre><code>${code}</code></pre>`;
    });

    // Format inline code (`code`)
    response = response.replace(/`(.*?)`/g, function(match, code) {
        return `<code>${code}</code>`;
    });

    return response;
}

function createContainer( typeOfContainer ) {
    var containerID = ""
    var textClass   = ""
    switch( typeOfContainer ) {
        case "message"      :
            // This would create a message container for user's message
            containerID = "messageContainer"
            textClass   = "message"
            break;
        case "reply"        :
        case "error"        :
            // This would create a reply container for bot's reply
            containerID = "replyContainer"
            textClass   = "reply"
            break;
        
    }

    // Creating container
    var newContainer = document.createElement( "div" )
    newContainer.setAttribute( "class" , "container" )
    if( containerID == "messageContainer" )
        newContainer.setAttribute( "id" , "messageContainer" )
    if( containerID == "replyContainer" )
        newContainer.setAttribute( "id" , "replyContainer" )
    chatBotSession.appendChild( newContainer )

    switch( textClass ) {
        case "message"  :
            var allMessageContainers = document.querySelectorAll("#messageContainer")
            var lastMessageContainer = allMessageContainers[ allMessageContainers.length - 1 ]
            var newMessage = document.createElement( "p" )
            newMessage.setAttribute( "class" , "message animateChat" )
            newMessage.innerHTML = inputMessage
            lastMessageContainer.appendChild( newMessage )
            lastMessageContainer.scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"})
            break
        case "reply"    :
            var allReplyContainers = document.querySelectorAll( "#replyContainer" )    
            var lastReplyContainer = allReplyContainers[ allReplyContainers.length - 1 ]
            var newReply = document.createElement( "p" )
            newReply.setAttribute( "class" , "reply animateChat accentColor" )
            switch( typeOfContainer ){
                case "reply":
                    newReply.innerHTML = formatBotResponse(chatBotReply);
                    break;
            
                case "error"        :
                    newReply.innerHTML = chatBotBlankMessageReply
                    break
            }
            setTimeout(function (){
                lastReplyContainer.appendChild( newReply )
                lastReplyContainer.scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"})
            }, 10)            
            break
        default         :
            console.log("Error in conversation")
    }
}

function initiateConversation() {
    chatBotSession.innerHTML = ""
    typeOfContainer = "initialize"
    createContainer( typeOfContainer )
}