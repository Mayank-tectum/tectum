# import maxminddb
# import csv
# # ------------- code to extract application data from MMDB --------------
# def extract_ip(network):
#     """Extracts the IP address from the network field."""
#     return str(network).split('/')[0]

# def process_mmdb_to_csv(mmdb_path, output_csv, chunk_size=25000):
#     """Processes the MMDB file in chunks and writes only the metadata fields to a CSV."""
#     print("Processing MMDB to CSV...")
#     try:
#         with maxminddb.Reader(mmdb_path) as reader:
#             batch = []
#             count = 0
#             header_written = False  # Track if the header is written

#             for network, metadata in reader:
#                 ip_address = extract_ip(network)
#                 # Include only metadata fields in the record
#                 record = {key: metadata.get(key, '') for key in metadata.keys()}
#                 record['ip_address'] = ip_address  # Add the IP address
                
#                 batch.append(record)
#                 count += 1

#                 if len(batch) >= chunk_size:
#                     write_to_csv(output_csv, batch, mode='a', write_header=not header_written)
#                     header_written = True
#                     batch.clear()

#             if batch:  # Write remaining records
#                 write_to_csv(output_csv, batch, mode='a', write_header=not header_written)

#             print(f"Processed {count} records and saved them to {output_csv}")

#     except FileNotFoundError:
#         print(f"Error: The file at `{mmdb_path}` was not found.")
#     except maxminddb.InvalidDatabaseError:
#         print("Error: The database file is invalid or corrupted.")
#     except Exception as e:
#         print(f"An unexpected error occurred: {e}")

# def write_to_csv(output_csv, data, mode='w', write_header=True):
#     """Writes a list of dictionaries to a CSV file."""
#     with open(output_csv, mode, newline='', encoding='utf-8') as csvfile:
#         # Extract headers from the first dictionary in the batch
#         fieldnames = data[0].keys() if data else []
#         writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
#         if write_header:
#             writer.writeheader()
        
#         writer.writerows(data)

# # Input and output file paths
# mmdb_path = "/home/tectum18/Desktop/Mayank/new_MMDB/mmdb_file/new_final_ip.mmdb"
# output_csv = "/home/tectum18/Desktop/Mayank/new_MMDB/mmdb_file/output1.csv"

# # Process MMDB file and create CSV
# process_mmdb_to_csv(mmdb_path, output_csv, chunk_size=5000)
# print("CSV creation complete.")


# ------------ code to read data in chunks from mmdb -------------
# import maxminddb

# def read_first_n_records(mmdb_path, n=10):
#     """Reads and prints the first `n` records from a MaxMind DB file in their raw format."""
#     try:
#         with maxminddb.Reader(mmdb_path) as reader:
#             records = []
#             count = 0
#             for network, metadata in reader:
#                 if count >= n:
#                     break
#                 # Store the record as a tuple
#                 records.append((network, metadata))
#                 count += 1
                
#             # Print the first 10 records
#             for i, (network, metadata) in enumerate(records, start=1):
#                 print(f"Record {i}:")
#                 print(f"  Network: {network}")
#                 print(f"  Metadata: {metadata}")
#                 print("-" * 40)

#     except FileNotFoundError:
#         print(f"Error: The file at `{mmdb_path}` was not found.")
#     except maxminddb.InvalidDatabaseError:
#         print("Error: The database file is invalid or corrupted.")
#     except Exception as e:
#         print(f"An unexpected error occurred: {e}")

# # Example usage
# mmdb_path = "/home/tectum18/Desktop/Mayank/new_MMDB/mmdb_file/new_23_jan.mmdb"

# # Read and print the first 10 records
# read_first_n_records(mmdb_path, n=1000)



# -------------- code to extract vpn data from MMDB ---------------------
# import maxminddb
# import csv

# def extract_ip(network):
#     """Extracts the IP address from the network field."""
#     return str(network).split('/')[0]

# def process_mmdb_to_csv(mmdb_path, output_csv, chunk_size=5000):
#     """
#     Processes the MMDB file in chunks and writes the required fields to a CSV.

#     Args:
#         mmdb_path (str): Path to the MMDB file.
#         output_csv (str): Path to the output CSV file.
#         chunk_size (int): Number of records to process per chunk.
#     """
#     try:
#         with maxminddb.Reader(mmdb_path) as reader:
#             batch = []
#             count = 0

#             for network, metadata in reader:
#                 ip_address = extract_ip(network)
#                 vpn_name = metadata.get('app_name', '')   
                
#                 batch.append({'ip_address': ip_address, 'vpn_name': vpn_name})
#                 count += 1

#                 if len(batch) >= chunk_size:
#                     write_to_csv(output_csv, batch, mode='a') 
#                     batch.clear() 

#             if batch:
#                 write_to_csv(output_csv, batch, mode='a')

#             print(f"Processed {count} records and saved them to {output_csv}")

#     except FileNotFoundError:
#         print(f"Error: The file at `{mmdb_path}` was not found.")
#     except maxminddb.InvalidDatabaseError:
#         print("Error: The database file is invalid or corrupted.")
#     except Exception as e:
#         print(f"An unexpected error occurred: {e}")

# def write_to_csv(output_csv, data, mode='w'):
#     """
#     Writes a list of dictionaries to a CSV file.

#     Args:
#         output_csv (str): Path to the CSV file.
#         data (list): List of dictionaries to write.
#         mode (str): File mode ('w' for write, 'a' for append).
#     """
#     with open(output_csv, mode, newline='', encoding='utf-8') as csvfile:
#         writer = csv.DictWriter(csvfile, fieldnames=['ip_address', 'vpn_name'])
#         if mode == 'w': 
#             writer.writeheader()
#         writer.writerows(data)

# mmdb_path = "/home/tectum18/Desktop/Mayank/new_MMDB/mmdb_file/new_23_jan.mmdb"
# output_csv = "/home/tectum18/Desktop/Mayank/new_MMDB/mmdb_file/new_23_jan.csv"

# process_mmdb_to_csv(mmdb_path, output_csv, chunk_size=5000)



import maxminddb

def read_first_n_records(mmdb_path, n=10):
    """Reads and prints the first `n` records from a MaxMind DB file in their raw format."""
    try:
        with maxminddb.Reader(mmdb_path) as reader:
            records = []
            count = 0
            for network, metadata in reader:
                if count >= n:
                    break
                records.append((network, metadata))
                count += 1
                
            for i, (network, metadata) in enumerate(records, start=1):
                print(f"Record {i}:")
                print(f"  Network: {network}")
                print(f"  Metadata: {metadata}")
                print("-" * 40)

    except FileNotFoundError:
        print(f"Error: The file at `{mmdb_path}` was not found.")
    except maxminddb.InvalidDatabaseError:
        print("Error: The database file is invalid or corrupted.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Example usage
mmdb_path = "/home/tectum18/Desktop/Mayank/new_MMDB/mmdb_file/vpn_data_netify.mmdb"
read_first_n_records(mmdb_path, n=100000)