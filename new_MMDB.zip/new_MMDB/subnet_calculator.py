import csv
import ipaddress


# Function to determine the class of an IP address and its subnet mask, and to generate CIDR notation
def determine_ip_class_and_mask(ip):
    try:
        # Validate the IP address
        ip_obj = ipaddress.ip_address(ip)
        first_octet = ip_obj.packed[0]  # Get the first octet

        if 1 <= first_octet <= 126:
            return "Class A", "255.0.0.0", "/8"
        elif 128 <= first_octet <= 191:
            return "Class B", "255.255.0.0", "/16"
        elif 192 <= first_octet <= 223:
            return "Class C", "255.255.255.0", "/24"
        elif 224 <= first_octet <= 239:
            return "Class D", "N/A (Multicast)", "N/A (Multicast)"
        elif 240 <= first_octet <= 255:
            return "Class E", "N/A (Reserved)", "N/A (Reserved)"
        else:
            return "Unknown", "N/A", "N/A"
    except ValueError:
        # Handle the case where the input is not a valid IP address
        print(f"Invalid IP address: {ip}")
        return "Invalid IP", "N/A", "N/A"

def process_and_generate_output_csv(input_file_path, output_file_path):
    with open(input_file_path, mode="r") as infile:
        csv_reader = csv.DictReader(infile)
        output_data = [["Vpn_Name", "Start_IP", "Subnet_Mask", "CIDR_Notation"]]

        for row in csv_reader:
            vpn_name = row["Vpn_Name"]
            start_ip = row["Start_IP"]

            ip_class, subnet_mask, cidr_notation = determine_ip_class_and_mask(start_ip)

            # Create the CIDR notation using the IP address and the subnet mask
            if ip_class not in ["Class D", "Class E", "Unknown"]:
                cidr = f"{start_ip}{cidr_notation}"
            else:
                cidr = "N/A"

            # Add the results to the output data
            output_data.append([vpn_name, start_ip, subnet_mask, cidr])

        # Write the output data to a new CSV file
        with open(output_file_path, mode="w", newline="", encoding="utf-8") as outfile:
            writer = csv.writer(outfile)
            writer.writerows(output_data)


input_csv_path = "new_vpn.csv"  
output_csv_path = "subnet.csv"

process_and_generate_output_csv(input_csv_path, output_csv_path)
print(f"Output CSV has been generated: {output_csv_path}")
