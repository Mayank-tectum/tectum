# import pandas as pd

# def convert_xlsx_to_csv(input_file, output_file):
#     df = pd.read_excel(input_file, engine="openpyxl")

#     df.to_csv(output_file, index=False)


# # Example usage
# input_xlsx = "formated.xlsx"
# output_csv = "output_file.csv"
# convert_xlsx_to_csv(input_xlsx, output_csv)
import pandas as pd
from netaddr import IPSet,IPAddress
from mmdb_writer import MMDBWriter

# Define the path for the output MMDB file
output_mmdb_path = "output.mmdb"

# Read the CSV file
input_csv_path = "rem_duplicate.csv"  # Replace with the path to your CSV file
data = pd.read_csv(input_csv_path)

# Initialize the MMDBWriter
writer = MMDBWriter()

# Iterate over the rows in the CSV and add data to the writer
ip_data = []
for index, row in data.iterrows():
    vpn_name = row["Vpn_Name"]
    start_ip = row["Start_IP"]
    end_ip = row["End_Range"]

    try:
        # Create an IP range using the start and end IP
        network = f"{start_ip}-{end_ip}"

        # Convert the IP range to an IPSet
        # ip_set = IPSet(network)

        # Metadata to be stored
        metadata = {
            "hosting": "true",
            "network": f"{start_ip}-{end_ip}",
            "port": "",
            "proxy": "",
            "relay": "",
            "service": vpn_name,
            "tor": "true",  # Adjust as needed
            "vpn": "",
        }
        ip_address = IPAddress(start_ip)
        ip_data.append((ip_address, metadata))

        # Insert the network and metadata into the MMDB
        # writer.insert_network(ip_set, metadata)

    except Exception as e:
        print(f"Error processing row {index}: {e}")

for ip, metadata in ip_data:
        ip_set = IPSet([ip])
        writer.insert_network(ip_set, metadata)

# Write the data to the MMDB file
writer.to_db_file(output_mmdb_path)

print(f"MMDB file '{output_mmdb_path}' has been created successfully.")
# Write the data to the MMDB file
# writer.to_db_file(output_mmdb_path)

# print(f"MMDB file '{output_mmdb_path}' has been created successfully.")
