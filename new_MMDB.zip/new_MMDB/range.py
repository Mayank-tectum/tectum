# import netaddr

# startip = "104.16.0.0"
# endip = "104.31.255.255"
# cidrs = netaddr.iprange_to_cidrs(startip, endip)
# print(cidrs)


# import netaddr

# # Given CIDR notation
# cidr = "95.179.197.66/8"

# # Create an IP network object
# network = netaddr.IPNetwork(cidr)

# # Get the start and end IP addresses
# start_ip = network.network
# end_ip = network.broadcast

# print(f"Start IP: {start_ip}")
# print(f"End IP: {end_ip}")

# import ipaddress
# import csv


# def calculate_ip_range(cidr_notation):
#     # Convert the CIDR notation to an ip_network object
#     network = ipaddress.ip_network(cidr_notation, strict=False)

#     # Get the network start and end addresses
#     start_ip = network.network_address
#     end_ip = network.broadcast_address

#     return start_ip, end_ip


# def process_and_generate_output_csv(input_file_path, output_file_path):
#     with open(input_file_path, mode="r") as infile:
#         csv_reader = csv.DictReader(infile)
#         output_data = [
#             ["Vpn_Name", "Start_IP", "Subnet_Mask", "CIDR_Notation", "IP_Range"]
#         ]

#         for row in csv_reader:
#             vpn_name = row["Vpn_Name"]
#             start_ip = row["Start_IP"]
#             subnet_mask = row["Subnet_Mask"]
#             cidr_notation = row["CIDR_Notation"]

#             # Calculate the IP range based on the CIDR notation
#             start_ip_range, end_ip_range = calculate_ip_range(cidr_notation)

#             # Add the results to the output data
#             output_data.append(
#                 [
#                     vpn_name,
#                     start_ip,
#                     subnet_mask,
#                     cidr_notation,
#                     f"{start_ip_range} - {end_ip_range}",
#                 ]
#             )

#         # Write the output data to a new CSV file
#         with open(output_file_path, mode="w", newline="", encoding="utf-8") as outfile:
#             writer = csv.writer(outfile)
#             writer.writerows(output_data)


# # Path to the input CSV file and the output CSV file
# input_csv_path = "subnet.csv"  # Replace with your input file path
# output_csv_path = "ip_ranges.csv"

# # Process the input CSV and generate the output CSV with IP ranges
# process_and_generate_output_csv(input_csv_path, output_csv_path)

# print(f"IP range results have been written to {output_csv_path}")

import csv
import netaddr
import ipaddress

def calculate_ip_range(cidr):
    try:
        # Validate the CIDR notation
        network = netaddr.IPNetwork(cidr)

        start_ip = network.network
        end_ip = network.broadcast

        return start_ip, end_ip
    except (netaddr.core.AddrFormatError, ValueError) as e:
        print(f"Error processing CIDR '{cidr}': {e}")
        return None, None  # Return None for invalid CIDR

def process_csv(input_csv, output_csv):
    with open(input_csv, mode="r") as infile:
        csv_reader = csv.DictReader(infile)

        output_data = [csv_reader.fieldnames + ["Start_Range", "End_Range"]]

        for row in csv_reader:
            cidr_notation = row["CIDR_Notation"]
            start_ip, end_ip = calculate_ip_range(cidr_notation)

            if start_ip is None or end_ip is None:
                # If the IP range could not be calculated, append N/A
                output_data.append(list(row.values()) + ["N/A", "N/A"])
            else:
                output_data.append(list(row.values()) + [str(start_ip), str(end_ip)])

        with open(output_csv, mode="w", newline="", encoding="utf-8") as outfile:
            writer = csv.writer(outfile)
            writer.writerows(output_data)

input_csv_path = "subnet.csv"
output_csv_path = "new_vpn_ip_with_ranges.csv"

# Process the CSV and generate the output
process_csv(input_csv_path, output_csv_path)

print(f"Start and end IP ranges have been added and saved to {output_csv_path}")