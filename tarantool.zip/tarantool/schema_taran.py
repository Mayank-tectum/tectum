# box.schema.space.create('ip_to_dict', {
#     engine = 'vinyl',  -- Use vinyl engine for better performance with large datasets
#     format = {
#         {name = 'destination_ip_address', type = 'string'},
#         {name = 'hosted_domain_name', type = 'string'},
#         {name = 'company_name', type = 'string'},
#         {name = 'company_domain', type = 'string'},
#         {name = 'company_type', type = 'string'},
#         {name = 'company_asn', type = 'string'},
#         {name = 'vpn_hosting', type = 'string'},
#         {name = 'vpn_proxy', type = 'string'},
#         {name = 'vpn_tor', type = 'string'},
#         {name = 'is_vpn', type = 'string'},
#         {name = 'vpn_is_relay', type = 'string'},
#         {name = 'vpn_name', type = 'string'},
#         {name = 'app_name', type = 'string'},
#         {name = 'app_category', type = 'string'},
#         {name = 'app_logo', type = 'string'},
#         {name = 'app_source_country', type = 'string'},
#         {name = 'app_domain', type = 'string'},
#         {name = 'ip_city', type = 'string'},
#         {name = 'ip_country', type = 'string'},
#         {name = 'ip_lat', type = 'string'},
#         {name = 'ip_long', type = 'string'},
#         {name = 'service_provider_detail', type = 'string'},
#         {name = 'ip_state_name', type = 'string'},
#         {name = 'ip_district_name', type = 'string'},
#         {name = 'ip_continent_name', type = 'string'},
#         {name = 'ip_connection_type', type = 'string'},
#         {name = 'ip_lat_long', type = 'string'},
#         {name = 'app_ip_type', type = 'string'},
#         {name = 'tor_name', type = 'string'},
#         {name = 'tor_onion_port', type = 'string'},
#         {name = 'tor_directory_port', type = 'string'},
#         {name = 'tor_flags', type = 'string'},
#         {name = 'tor_uptime', type = 'string'},
#         {name = 'tor_version', type = 'string'},
#         {name = 'tor_email', type = 'string'},
#         {name = 'is_tor_detected', type = 'string'}
#     }
# })

# box.space.ip_to_dict:create_index('primary', { type = 'tree', parts = {1, 'string'} })  -- Use 'destination_ip_address' as primary key



# lua script for batch processing
# function batch_insert(space_name, data)
#                > local space = box.space[space_name]
#                > for _, tuple in ipairs(data) do
#                >   space:put(tuple)
#                > end
#                > end



# function fetch_tor_data(space_name, target_ip)
#     local space = box.space[space_name]
#     local result = {}
#     local column_names = {'ip_address', 'name', 'onion_port', 'directory_port', 'flags', 'uptime', 'tor_version', 'email'}
#     local rows = space:select({target_ip})

   
#     for _, tuple in ipairs(rows) do
#         local row_data = {}
#         for i, column_name in ipairs(column_names) do
#             row_data[column_name] = tuple[i]
#         end
#         table.insert(result, row_data)
#     end
    
#     return result
# end


# box.schema.space.create('tor_details', {
#     format = {
#         {name = 'ip_address', type = 'string'},
#         {name = 'name', type = 'string'},
#         {name = 'onion_port', type = 'string'},
#         {name = 'directory_port', type = 'string'},
#         {name = 'flags', type = 'string'},
#         {name = 'uptime', type = 'string'},  
#         {name = 'tor_version', type = 'string'},
#         {name = 'email', type = 'string'}   
#     }
# })
# box.space.tor_details:create_index('primary', { type = 'tree', parts = {1, 'string'} })




# function fetch_data_in_batches(ips, connection)
#     local batch_size = 1000
#     local matched_ips = {}
#     local not_found_ips = {}

#     for i = 1, #ips, batch_size do
#         local batch = {}
#         for j = i, math.min(i + batch_size - 1, #ips) do
#             local ip = ips[j]
#             if ip and type(ip) == "string" and ip ~= "nan" then
#                 table.insert(batch, {ip})
#             end
#         end

#         for _, ip_tuple in ipairs(batch) do
#             local ip = ip_tuple[1]
#             local result, err = connection:space('ip_to_dict'):select(ip_tuple)

#             if not result then
#                 table.insert(not_found_ips, ip)
#             else
#                 for _, record in ipairs(result) do
#                     matched_ips[record[1]] = {table.unpack(record, 2)}  -- Save only values, not the IP
#                 end
#             end
#         end
#     end

#     return matched_ips, not_found_ips
# end
