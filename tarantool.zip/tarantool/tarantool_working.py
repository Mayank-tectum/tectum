import pandas as pd
import tarantool
import time

connection = tarantool.connect('192.168.1.134', 3301)

connection.eval("""
if not box.space.ip_to_dict then
    box.schema.space.create('ip_to_dict')
    box.space.ip_to_dict:create_index('primary', { type = 'hash', parts = {1, 'str'} })
end
""")

def insert_in_batches(space_name, df, batch_size):
    for i in range(0, len(df), batch_size):
        batch = df.iloc[i:i + batch_size]  
        insert_batch(space_name, batch)

def insert_batch(space, batch):
    data_batch = []
    for row in batch.itertuples(index=False):
        destination_ip = str(row.destination_ip_address) if pd.notna(row.destination_ip_address) else ''

        data = (
            destination_ip, row.hosted_domain_name or '', row.company_name or '',
            row.company_domain or '', row.company_type or '', row.company_asn or '',
            row.vpn_hosting or '', row.vpn_proxy or '', row.vpn_tor or '',
            row.is_vpn or '', row.vpn_is_relay or '', row.vpn_name or '',
            row.app_name or '', row.app_category or '', row.app_logo or '',
            row.app_source_country or '', row.app_domain or '', row.ip_city or '',
            str(row.ip_country) or '', str(row.ip_lat) or '', str(row.ip_long) or '',
            row.service_provider_detail or '', row.ip_state_name or '',
            row.ip_district_name or '', row.ip_continent_name or '', row.ip_connection_type or '',
            row.ip_lat_long or '', row.app_ip_type or '', row.tor_name or '',
            row.tor_onion_port or '', row.tor_directory_port or '', row.tor_flags or '',
            row.tor_uptime or '', row.tor_version or '', row.tor_email or '', row.is_tor_detected or ''
        )
        data_batch.append(data)
        # try:
        #     space.insert(data)
        # except Exception as e:
        #     print(e)
    connection.call('batch_insert', ('ip_to_dict', data_batch))


df = pd.read_csv('one_lakh.csv', low_memory=False)
df = df.fillna('')  
ip_to_dict_space = connection.space('ip_to_dict')

start_time = time.time()
insert_in_batches(ip_to_dict_space, df, batch_size=10000)  

print("Total time taken to insert records into Tarantool: ", time.time() - start_time)
connection.close()
print("Data successfully inserted.")
