import tarantool

import time


start_time = time.time()
connection = tarantool.connect('192.168.1.134', 3301)

# data = [
#     '185.2.227.186',
#     '176.59.16.92',
#     '45.149.27.132',
#     '1.0.22.3'
# ]

# not_found = []
# found = []

# for ip in data:
#     try:
#         # Query the database with the IP address as a string
#         result = connection.space('ip_to_dict').select(ip)
#         if result:
#             found.append(ip)
#             print(result)
#         else:
#             not_found.append(ip)
#     except tarantool.error.DatabaseError as e:
#         print(f"Error querying IP {ip}: {e}")
#         not_found.append(ip)

# print("Not found:", not_found)
# print("Found:", found)
# to fetch specific data 
result = connection.space('ip_to_dict').select(('31.8.105.27',))
print(result)

# limit = 400
# data = []
# all_data = connection.space('ip_to_dict').select(limit=limit)
# for row in all_data:
#     data.append(row)



print(f"Total time taken to export from Tarantool: {time.time() - start_time:.2f}")
connection.close()

# connection.call('get_data_from_tt',('tor_details',ip))
# which calls 
# function get_data_from_tt(space_name, ip)
# local space = box.space[space_name]
