# import csv
# import tarantool

# connection = tarantool.connect('192.168.1.134', 3301)  

# connection.eval("""
# -- Create the space 'ip_to_dict' if it doesn't exist
# if not box.space.ip_to_dict then
#     box.schema.space.create('ip_to_dict')
#     -- Create a primary index on the first field, assuming it is 'destination_ip_address'
#     box.space.ip_to_dict:create_index('primary', { type = 'hash', parts = {1, 'str'} })
# end
# """)

# with open('ip_to_dict.csv', 'r') as file:
#     csv_reader = csv.DictReader(file)
#     ip_to_dict_space = connection.space('ip_to_dict')

#     for row in csv_reader:
#         try:
#             tor_uptime = float(row['tor_uptime']) if row['tor_uptime'] else 0.0
#         except ValueError:
#             tor_uptime = 0.0  
        
#         data = (
#             row['destination_ip_address'],
#             row['hosted_domain_name'],
#             row['company_name'],
#             row['company_domain'],
#             row['company_type'],
#             row['company_asn'],
#             row['vpn_hosting'],
#             row['vpn_proxy'],
#             row['vpn_tor'],
#             row['is_vpn'],
#             row['vpn_is_relay'],
#             row['vpn_name'],
#             row['app_name'],
#             row['app_category'],
#             row['app_logo'],
#             row['app_source_country'],
#             row['app_domain'],
#             row['ip_city'],
#             row['ip_country'],
#             float(row['ip_lat']) if row['ip_lat'] else 0.0,
#             float(row['ip_long']) if row['ip_long'] else 0.0,
#             row['service_provider_detail'],
#             row['ip_state_name'],
#             row['ip_district_name'],
#             row['ip_continent_name'],
#             row['ip_connection_type'],
#             row['ip_lat_long'],
#             row['app_ip_type'],
#             row['tor_name'],
#             row['tor_onion_port'],
#             row['tor_directory_port'],
#             row['tor_flags'],
#             tor_uptime,  
#             row['tor_version'],
#             row['tor_email'],
#             row['is_tor_detected']
#         )
#         ip_to_dict_space.replace(data)

# connection.close()

# print("CSV data has been inserted into Tarantool!")

# connection = tarantool.connect('192.168.1.134', 3301)  
# ip_to_dict_space = connection.space('ip_to_dict') 

# data_tuples = [tuple(row) for row in mapper_dict_with_raw.to_numpy()]

# try:
#     # Insert multiple records in bulk 
#     ip_to_dict_space.replace(data_tuples)
#     print(f"Inserted {len(data_tuples)} records successfully.")
# except Exception as e:
#     print(f"Error inserting records: {e}")

# import pandas as pd
# import tarantool
# import time

# start_time = time.time()
# connection = tarantool.connect('192.168.1.134', 3301)

# connection.eval("""
# if not box.space.ip_to_dict then
#     box.schema.space.create('ip_to_dict')
#     box.space.ip_to_dict:create_index('primary', { type = 'hash', parts = {1, 'str'} })
# end
# """)

# df = pd.read_csv('generated_data.csv')
# ip_to_dict_space = connection.space('ip_to_dict')


# for index, row in df.iterrows():
#     destination_ip = str(row['destination_ip_address']) if pd.notna(row['destination_ip_address']) else ''

#     data = (
#         destination_ip,  
#         row['hosted_domain_name'] or '',
#         row['company_name'] or '',
#         row['company_domain'] or '',
#         row['company_type'] or '',
#         row['company_asn'] or '',
#         row['vpn_hosting'] or '',
#         row['vpn_proxy'] or '',
#         row['vpn_tor'] or '',
#         row['is_vpn'] or '',
#         row['vpn_is_relay'] or '',
#         row['vpn_name'] or '',
#         row['app_name'] or '',
#         row['app_category'] or '',
#         row['app_logo'] or '',
#         row['app_source_country'] or '',
#         row['app_domain'] or '',
#         row['ip_city'] or '',
#         row['ip_country'] or '',
#         float(row['ip_lat']) if pd.notna(row['ip_lat']) else 0.0,
#         float(row['ip_long']) if pd.notna(row['ip_long']) else 0.0,
#         row['service_provider_detail'] or '',
#         row['ip_state_name'] or '',
#         row['ip_district_name'] or '',
#         row['ip_continent_name'] or '',
#         row['ip_connection_type'] or '',
#         row['ip_lat_long'] or '',
#         row['app_ip_type'] or '',
#         row['tor_name'] or '',
#         row['tor_onion_port'] or '',
#         row['tor_directory_port'] or '',
#         row['tor_flags'] or '',
#         float(row['tor_uptime']) if pd.notna(row['tor_uptime']) else 0.0,
#         row['tor_version'] or '',
#         row['tor_email'] or '',
#         row['is_tor_detected'] or ''
#     )
#     ip_to_dict_space.replace(data)

# connection.close()
# print("total time taken to insert 100000 in tarantool: ",time.time()-start_time)
# print(f"data successfully inserted.")