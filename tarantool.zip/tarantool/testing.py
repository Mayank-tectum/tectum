# # import pandas as pd
# # import tarantool
# # import time

# # count = 0

# # start_time = time.time()

# # count += 1
# # if count ==1:
# #     connection = tarantool.connect('192.168.1.134', 3301)

# #     connection.eval("""
# #     if not box.space.ip_to_dict then
# #         box.schema.space.create('ip_to_dict')
# #         box.space.ip_to_dict:create_index('primary', { type = 'hash', parts = {1, 'str'} })
# #     end
# #     """)

# # def read_in_chunks(file_path, chunk_size):
# #     return pd.read_csv(file_path, chunksize=chunk_size)

# # # def process_lat_long(value):
# # #     if pd.notna(value):
# # #         try:
# # #             return float(value)
# # #         except ValueError:
# # #             return str(value)
# # #     return ''

# # def insert_batch(space, batch):
# #     for row in batch.itertuples(index=False):
# #         destination_ip = str(row.destination_ip_address) if pd.notna(row.destination_ip_address) else ''

# #         data = (
# #             destination_ip, row.hosted_domain_name or '', row.company_name or '',
# #             row.company_domain or '', row.company_type or '', row.company_asn or '',
# #             row.vpn_hosting or '', row.vpn_proxy or '', row.vpn_tor or '',
# #             row.is_vpn or '', row.vpn_is_relay or '', row.vpn_name or '',
# #             row.app_name or '', row.app_category or '', row.app_logo or '',
# #             row.app_source_country or '', row.app_domain or '', row.ip_city or '',
# #             row.ip_country or '', row.ip_lat, row.ip_long,
# #             row.service_provider_detail or '', row.ip_state_name or '',
# #             row.ip_district_name or '', row.ip_continent_name or '', row.ip_connection_type or '',
# #             row.ip_lat_long or '', row.app_ip_type or '', row.tor_name or '',
# #             row.tor_onion_port or '', row.tor_directory_port or '', row.tor_flags or '',
# #             row.tor_uptime or '', row.tor_version or '', row.tor_email or '', row.is_tor_detected or ''
# #         )
# #         try:
# #             space.insert(data)
# #         except Exception as e:
# #             print(e)

# # chunk_size = 10000  
# # df = pd.read_csv('one_lakh.csv')
# # ip_to_dict_space = connection.space('ip_to_dict')

# # # Process each chunk
# # for chunk in read_in_chunks(file_path, chunk_size):
# #     insert_batch(ip_to_dict_space, chunk)

# # connection.close()

# # # Print total time taken
# # print("Total time taken to insert records into Tarantool: ", time.time() - start_time)
# # print("Data successfully inserted.")
# import pandas as pd
# import tarantool
# import time

# # Tarantool connection
# connection = tarantool.connect('192.168.1.134', 3301)

# connection.eval("""
# if not box.space.ip_to_dict then
#     box.schema.space.create('ip_to_dict')
#     box.space.ip_to_dict:create_index('primary', { type = 'hash', parts = {1, 'str'} })
# end
# """)

# def insert_in_batches(space_name, df, batch_size=1000):
#     for i in range(0, len(df), batch_size):
#         batch = df.iloc[i:i + batch_size]  #
#         insert_batch(space_name, batch)

# def insert_batch(space, batch):
#     for row in batch.itertuples(index=False):
#         destination_ip = str(row.destination_ip_address) if pd.notna(row.destination_ip_address) else ''

#         data = (
#             destination_ip, row.hosted_domain_name or '', row.company_name or '',
#             row.company_domain or '', row.company_type or '', row.company_asn or '',
#             row.vpn_hosting or '', row.vpn_proxy or '', row.vpn_tor or '',
#             row.is_vpn or '', row.vpn_is_relay or '', row.vpn_name or '',
#             row.app_name or '', row.app_category or '', row.app_logo or '',
#             row.app_source_country or '', row.app_domain or '', row.ip_city or '',
#             row.ip_country or '', str(row.ip_lat) or '', str(row.ip_long) or '',
#             row.service_provider_detail or '', row.ip_state_name or '',
#             row.ip_district_name or '', row.ip_continent_name or '', row.ip_connection_type or '',
#             row.ip_lat_long or '', row.app_ip_type or '', row.tor_name or '',
#             row.tor_onion_port or '', row.tor_directory_port or '', row.tor_flags or '',
#             row.tor_uptime or '', row.tor_version or '', row.tor_email or '', row.is_tor_detected or ''
#         )
#         try:
#             space.insert(data)
#         except Exception as e:
#             print(e)

# df = pd.read_csv('one_lakh.csv', low_memory=False)
# df = df.fillna('')  
# ip_to_dict_space = connection.space('ip_to_dict')

# start_time = time.time()
# insert_in_batches(ip_to_dict_space, df, batch_size=10000)  
# print("Total time taken to insert records into Tarantool: ", time.time() - start_time)

# connection.close()

# print("Data successfully inserted.")

# key: 2404:6800:4002:081C:0000:0000:0000:2002- value ['', 'Google International, LLC', '', 'business', 'AS15169', '', '', '', '', '', '', 'GOOGLE', 'BUSINESS', '', '', '', 'SYDNEY', 'AUSTRALIA', '-33.8688', '151.209', 'GOOGLE INTERNATIONAL, LLC GOOGLE LLC GOOGLE LLC SYDNEY SYDNEY NEW SOUTH WALES AUSTRALIA -33.8688 151.209', 'NEW SOUTH WALES', 'SYDNEY', 'OCEANIA', 'Corporate', '-33.8688~~~151.209', 'HOSTED', '', '', '', '', '', '', '', 'no'] key: 2404:6800:4002:0813:0000:0000:0000:200A- value ['', 'Google International, LLC', '', 'business', 'AS15169', '', '', '', '', '', '', 'GOOGLE', 'BUSINESS', '', '', '', 'SYDNEY', 'AUSTRALIA', '-33.8688', '151.209', 'GOOGLE INTERNATIONAL, LLC GOOGLE LLC GOOGLE LLC SYDNEY SYDNEY NEW SOUTH WALES AUSTRALIA -33.8688 151.209', 'NEW SOUTH WALES', 'SYDNEY', 'OCEANIA', 'Corporate', '-33.8688~~~151.209', 'HOSTED', '', '', '', '', '', '', '', 'no'] key: 2A03:2880:F244:01CA:FACE:B00C:0000:43FE- value ['', 'Meta Platforms Ireland Limited', '', 'hosting', 'AS32934', '', '', '', '', '', '', 'META', 'SOCIAL MEDIA', '', '', '', 'DUBLIN (BALLSBRIDGE)', 'IRELAND', '53.3289', '-6.23018', 'META PLATFORMS IRELAND LIMITED FACEBOOK, INC. FACEBOOK, INC. DUBLIN (BALLSBRIDGE) DUBLIN CITY LEINSTER IRELAND 53.3289 -6.23018', 'LEINSTER', 'DUBLIN CITY', 'EUROPE', 'Corporate', '53.3289~~~-6.23018', 'MULTIPRODUCT', '', '', '', '', '', '', '', 'no'] key: 2405:0200:1604:0000:0000:0000:17C8:D80B- value ['', 'Reliance Jio Infocomm Limited', '', 'cellular', 'AS55836', '', '', '', '', '', '', 'JIO', 'ISP/TELCO', '', '', '', 'NAVI MUMBAI (RELIANCE CORPORATE PARK)', 'INDIA', '19.136', '73.0039', 'RELIANCE JIO INFOCOMM LIMITED RELIANCE JIO INFOCOMM LIMITED RELIANCE JIO INFOCOMM LIMITED NAVI MUMBAI (RELIANCE CORPORATE PARK) THANE MAHARASHTRA INDIA 19.136 73.0039', 'MAHARASHTRA', 'THANE', 'ASIA', 'Cellular', '19.136~~~73.0039', 'HOSTED', '', '', '', '', '', '', '', 'no'] key: 2A03:2880:F144:0181:FACE:B00C:0000:25DE- value ['', 'Meta Platforms Ireland Limited', '', 'hosting', 'AS32934', '', '', '', '', '', '', 'META', 'SOCIAL MEDIA', '', '', '', 'DUBLIN (BALLSBRIDGE)', 'IRELAND', '53.3289', '-6.23018', 'META PLATFORMS IRELAND LIMITED FACEBOOK, INC. FACEBOOK, INC. DUBLIN (BALLSBRIDGE) DUBLIN CITY LEINSTER IRELAND 53.3289 -6.23018', 'LEINSTER', 'DUBLIN CITY', 'EUROPE', 'Corporate', '53.3289~~~-6.23018', 'MULTIPRODUCT', '', '', '', '', '', '', '', 'no'] key: 2404:6800:4002:081B:0000:0000:0000:2002- value ['', 'Google International, LLC', '', 'business', 'AS15169', '', '', '', '', '', '', 'GOOGLE', 'BUSINESS', '', '', '', 'SYDNEY', 'AUSTRALIA', '-33.8688', '151.209', 'GOOGLE INTERNATIONAL, LLC GOOGLE LLC GOOGLE LLC SYDNEY SYDNEY NEW SOUTH WALES AUSTRALIA -33.8688 151.209', 'NEW SOUTH WALES', 'SYDNEY', 'OCEANIA', 'Corporate', '-33.8688~~~151.209', 'HOSTED', '', '', '', '', '', '', '', 'no'] key: 2404:6800:4002:0824:0000:0000:0000:2002- value ['', 'Google International, LLC', '', 'business', 'AS15169', '', '', '', '', '', '', 'GOOGLE', 'BUSINESS', '', '', '', 'SYDNEY', 'AUSTRALIA', '-33.8688', '151.209', 'GOOGLE INTERNATIONAL, LLC GOOGLE LLC GOOGLE LLC SYDNEY SYDNEY NEW SOUTH WALES AUSTRALIA -33.8688 151.209', 'NEW SOUTH WALES', 'SYDNEY', 'OCEANIA', 'Corporate', '-33.8688~~~151.209', 'HOSTED', '', '', '', '', '', '', '', 'no'] key: 2404:6800:4002:0824:0000:0000:0000:2003- value ['', 'Google International, LLC', '', 'business', 'AS15169', '', '', '', '', '', '', 'GOOGLE', 'BUSINESS', '', '', '', 'SYDNEY', 'AUSTRALIA', '-33.8688', '151.209', 'GOOGLE INTERNATIONAL, LLC GOOGLE LLC GOOGLE LLC SYDNEY SYDNEY NEW SOUTH WALES AUSTRALIA -33.8688 151.209', 'NEW SOUTH WALES', 'SYDNEY', 'OCEANIA', 'Corporate', '-33.8688~~~151.209', 'DEDICATED', '', '', '', '', '', '', '', 'no'] key: 185.2.227.186- value ['', '"KCell" JSC', '', 'business', 'AS29355', '', '', '', '', '', '', '', '', '', '', '', 'ALMATY (BOSTANDYK DISTRICT)', 'KAZAKHSTAN', '43.2273', '76.9212', '"KCELL" JSC KCELL JSC KCELL JSC ALMATY (BOSTANDYK DISTRICT) ALMATY (BOSTANDYK DISTRICT) ALMATY KAZAKHSTAN 43.2273 76.9212', 'ALMATY', 'ALMATY (BOSTANDYK DISTRICT)', 'ASIA', 'Corporate', '43.2273~~~76.9212', '', '', '', '', '', '', '', '', 'no'] key: 176.59.16.92- value ['', 'Tele2 Russia IP Network', '', 'cellular', 'AS15378', '', '', '', '', '', '', '', '', '', '', '', 'ST PETERSBURG', 'RUSSIA', '59.9386', '30.3141', 'TELE2 RUSSIA IP NETWORK TELE2 RUSSIA IP NETWORK T2 MOBILE LLC ST PETERSBURG ST PETERSBURG ST.-PETERSBURG RUSSIA 59.9386 30.3141', 'ST.-PETERSBURG', 'ST PETERSBURG', 'EUROPE', 'Cellular', '59.9386~~~30.3141', '', '', '', '', '', '', '', '', 'no']