 # batch_data = []
                    # tarantool_time = time.time()
                    # for ip in unique_destination_ip_address:
                    #     try:
                    #         ip_data = ip_to_dict(ip, ip_to_dict_session, reader, reader_vpn, app_reader)
                    #         batch_data.append((ip, ip_data))  
                    #         if len(batch_data) >= batch_size:
                    #             insert_batch_with_ip(ip_to_dict_space,batch_data,connection)
                    #             batch_data = []

                    #     except Exception as e:
                    #         print(f"Error processing IP {ip}: {e}")

                    # if batch_data:
                    #     insert_batch_with_ip(ip_to_dict_space,batch_data,connection)
                    # print(f"tarantool insert time: {time.time()-tarantool_time}")

                    # mapping_df = pd.DataFrame.from_dict(ip_to_dict_mapping_dict_destination, orient='index',columns=['hosted_domain_name','company_name','company_domain','company_type','company_asn','vpn_hosting','vpn_proxy','vpn_tor','is_vpn','vpn_is_relay','vpn_name','app_name','app_category','app_logo','app_source_country','app_domain','ip_city','ip_country','ip_lat','ip_long','service_provider_detail','ip_state_name','ip_district_name','ip_continent_name','ip_connection_type','ip_lat_long','app_ip_type','tor_name','tor_onion_port','tor_directory_port','tor_flags','tor_uptime','tor_version','tor_email','is_tor_detected'])
                    # mapping_df.reset_index(inplace=True)
                    # mapping_df.rename(columns={'index': 'destination_ip_address'}, inplace=True)

                    # ip_to_dict_space = connection.space('ip_to_dict')
                    # data = ip_to_dict_space.select()  
                    # columns = [
                    #     'destination_ip_address', 'hosted_domain_name', 'company_name', 'company_domain',
                    #     'company_type', 'company_asn', 'vpn_hosting', 'vpn_proxy', 'vpn_tor', 'is_vpn',
                    #     'vpn_is_relay', 'vpn_name', 'app_name', 'app_category', 'app_logo', 'app_source_country',
                    #     'app_domain', 'ip_city', 'ip_country', 'ip_lat', 'ip_long', 'service_provider_detail',
                    #     'ip_state_name', 'ip_district_name', 'ip_continent_name', 'ip_connection_type',
                    #     'ip_lat_long', 'app_ip_type', 'tor_name', 'tor_onion_port', 'tor_directory_port',
                    #     'tor_flags', 'tor_uptime', 'tor_version', 'tor_email', 'is_tor_detected'
                    # ]
                    # mapping_df_time = time.time()
                    # mapping_df = pd.DataFrame(data, columns=columns)
                    # print(f"mapping_df_time: {time.time()-mapping_df_time}")    
                    # print("time taken ip_to_dict:",time.time()-start_time)



# def insert_batch_with_ip(space, batch,connection):

#     """
#     Inserts the processed IP data directly into the Tarantool space.
    
#     Parameters:
#         space: The Tarantool space object.
#         ip_address: The IP address to be inserted.
#         ip_data: A list of values corresponding to the schema fields.
#     """
#     data_batch= []
#     for ip, ip_data in batch:
#         try:
#             if not isinstance(ip_data, list):
#                 raise ValueError("ip_data should be a list.")
            
#             data = (
#                     str(ip), str(ip_data[0] if len(ip_data) > 0 else ''), str(ip_data[1] if len(ip_data) > 1 else ''), 
#                     str(ip_data[2] if len(ip_data) > 2 else ''), ip_data[3] if len(ip_data) > 3 else '', ip_data[4] if len(ip_data) > 4 else '', 
#                     ip_data[5] if len(ip_data) > 5 else '', ip_data[6] if len(ip_data) > 6 else '', ip_data[7] if len(ip_data) > 7 else '', 
#                     ip_data[8] if len(ip_data) > 8 else '', ip_data[9] if len(ip_data) > 9 else '', ip_data[10] if len(ip_data) > 10 else '', 
#                     ip_data[11] if len(ip_data) > 11 else '', ip_data[12] if len(ip_data) > 12 else '', ip_data[13] if len(ip_data) > 13 else '', 
#                     ip_data[14] if len(ip_data) > 14 else '', ip_data[15] if len(ip_data) > 15 else '', ip_data[16] if len(ip_data) > 16 else '', 
#                     ip_data[17] if len(ip_data) > 17 else '', str(ip_data[18] if len(ip_data) > 18 else ''), str(ip_data[19] if len(ip_data) > 19 else ''), 
#                     ip_data[20] if len(ip_data) > 20 else '', ip_data[21] if len(ip_data) > 21 else '', ip_data[22] if len(ip_data) > 22 else '', 
#                     ip_data[23] if len(ip_data) > 23 else '', ip_data[24] if len(ip_data) > 24 else '', ip_data[25] if len(ip_data) > 25 else '', 
#                     ip_data[26] if len(ip_data) > 26 else '', ip_data[27] if len(ip_data) > 27 else '', ip_data[28] if len(ip_data) > 28 else '', 
#                     ip_data[29] if len(ip_data) > 29 else '', ip_data[30] if len(ip_data) > 30 else '', ip_data[31] if len(ip_data) > 31 else '', 
#                     ip_data[32] if len(ip_data) > 32 else '', ip_data[33] if len(ip_data) > 33 else '', ip_data[34] if len(ip_data) >= 34 else '')
#             data_batch.append(data)        
#         except Exception as e:
#             print(f"Error inserting IP {ip_address}: {e}")

#     connection.call('batch_insert', ('ip_to_dict', data_batch))




# for_time = time.time()
                        # records = ip_to_dict_space.select(limit=1)                          
                        # if not records:
                        #     tarantool_time = time.time()
                        #     insert_in_batches(ip_to_dict_space,mapping_df,batch_size,connection)
                        #     print(f"tarantool insert time: {time.time()-tarantool_time}")
                        # else:
                        #     drop_duplicate_time = time.time()
                        #     if 'Destination IP Address' in df.columns:
                        #         unique_ips = df['Destination IP Address'].drop_duplicates().to_list()
                        #     elif 'Destination_IP4' in df.columns:
                        #         unique_ips = df['Destination_IP4'].drop_duplicates().to_list()
                                
                        #     print("lenght of unique destination ip:",len(unique_ips))
                        #     matched_ips,not_matched_ips=fetch_data_in_batches(unique_ips,connection)
                        #     not_matched_ips = [ip[0] for ip in not_matched_ips]
                        #     print(f"length of matched_ips: {len(matched_ips)}")
                        #     print(f"length of unmatched_ips: {len(not_matched_ips)}")
                        #     print(f"drop_duplicate_time: {time.time()-drop_duplicate_time}")

                        # if len(not_matched_ips) > 0:
                        #     new_ips_data = {val: ip_to_dict(val,ip_to_dict_session,reader,reader_vpn,app_reader) for val in not_matched_ips}
                        #     new_ip_df = pd.DataFrame.from_dict(new_ips_data, orient='index',columns=['hosted_domain_name','company_name','company_domain','company_type','company_asn','vpn_hosting','vpn_proxy','vpn_tor','is_vpn','vpn_is_relay','vpn_name','app_name','app_category','app_logo','app_source_country','app_domain','ip_city','ip_country','ip_lat','ip_long','service_provider_detail','ip_state_name','ip_district_name','ip_continent_name','ip_connection_type','ip_lat_long','app_ip_type','tor_name','tor_onion_port','tor_directory_port','tor_flags','tor_uptime','tor_version','tor_email','is_tor_detected'])
                        #     print(new_ip_df.head())
                        #     new_ip_df.reset_index(inplace=True)
                        #     new_ip_df.rename(columns={'index': 'destination_ip_address'}, inplace=True)
                        #     insert_in_batches(ip_to_dict_space,new_ip_df,batch_size,connection)
                        #     print("new ips inserted successfull.")
                        # # matched_df = matched_df.merge(new_ip_df, on='destination_ip_address', how='left')

                        # columns = [
                        #             'destination_ip_address', 'hosted_domain_name', 'company_name', 'company_domain',
                        #             'company_type', 'company_asn', 'vpn_hosting', 'vpn_proxy', 'vpn_tor', 'is_vpn',
                        #             'vpn_is_relay', 'vpn_name', 'app_name', 'app_category', 'app_logo', 'app_source_country',
                        #             'app_domain', 'ip_city', 'ip_country', 'ip_lat', 'ip_long', 'service_provider_detail',
                        #             'ip_state_name', 'ip_district_name', 'ip_continent_name', 'ip_connection_type',
                        #             'ip_lat_long', 'app_ip_type', 'tor_name', 'tor_onion_port', 'tor_directory_port',
                        #             'tor_flags', 'tor_uptime', 'tor_version', 'tor_email', 'is_tor_detected'
                        #                 ]
                        
                        # if len(matched_ips) != 0 and len(not_matched_ips) != 0:
                        #     matched_df = pd.DataFrame(matched_ips, columns=columns)
                        #     new_ip_df = new_ip_df.merge(matched_df,on='destination_ip_address', how='left')
                        #     matched_ips = []
                        #     not_matched_ips = []