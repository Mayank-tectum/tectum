import json
import clickhouse_connect
import pandas as pd

table = 'tower_test_dis'
json_file= open('database.config','r').read()

def clickhouse_connection():    

    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    
    client = clickhouse_connect.get_client(
            host=database['click_house_node1'],
            port=database['click_house_port'],
            user=database['click_house_username'],
            password=database['click_house_password'],
            database=database['click_house_database'],
        )
    return client

client = clickhouse_connection()

df = pd.read_csv('data/rep1.csv', encoding='utf-8')
df[['Latitude', 'Longitude']]=df['First CGI Lat/Long'].str.split('/',expand=True)
df.columns = df.columns.str.strip()
df = df[['First CGI','Latitude','Longitude']]
df = df.rename(columns={'Latitude': 'tower_latitude','Longitude': 'tower_longitude','First CGI':'tower_cgi'})

df['by_telecom'] = '0' 
df['created_at'] = '0'
df['file_name'] = None
df['range'] = '0.0'
df['signal_strength'] = '0.0'
df['t_status'] = '1'
df['tower_azimuth'] = '0.0'
df['tower_district'] = None
df['tower_height'] = None
# df['lat_long'] = [(0.0, 0.0)] * len(df)
df['tower_location']= None
df['tower_network_type'] = None
df['tower_operator'] =None
df['tower_pincode'] =None
df['tower_site_name'] =None
df['tower_state'] = None
df['tower_town'] = None
df['updated_at'] = '0'

# df = df[sorted(df.columns)].astype(str)
# client.insert(table, df.to_records(index=False).tolist(),column_names=list(df.columns))
# print("successfull inserted:",len(df))
