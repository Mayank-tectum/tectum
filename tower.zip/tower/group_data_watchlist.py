import json
import clickhouse_connect
import pandas as pd
import hashlib
import requests

def clickhouse_connection():    

    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    
    client = clickhouse_connect.get_client(
            host=database['click_house_node1'],
            port=database['click_house_port'],
            user=database['click_house_username'],
            password=database['click_house_password'],
            database=database['click_house_database'],
        )
    return client

client = clickhouse_connection()

hash_value = ''

#-------------- add new group ------------------
def add_new_group_watchlist():
    base_url = "http://192.168.1.64:3000/api/group/add"
    url = f"{base_url}"
    
    payload = {
        "group_name": "Targets"  
    }
    response = requests.post(url, json=payload)
    print(response.json())
    if response.status_code == 200:
        print("Group added successfully!")
    else:
        print(f"Failed to add group. Status code: {response.status_code}")

    base_url = "http://192.168.1.64:3000/api/group/list"
    url = f"{base_url}"
    try:
        response = requests.post(url)
        if response.status_code == 200:
            data = response.json()
            if data and "message" in data and "data" in data["message"]:
                groups = data["message"]["data"]
                if isinstance(groups, list):
                    for group in groups:
                        if group.get("group_name") == "TARGETS":
                            hash_value = group.get("group_name_hash")
                            if hash_value:
                                return hash_value 
                            else:
                                print("Hash value not found for group 'Targets'.")
                            break
                        else:
                            print("Group not found.")
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")     

hash_value = add_new_group_watchlist()

def create_hash(row,entity_type):
    group_data_str = 'Targets' + str(row['NAME']) + str(entity_type) + str(row[entity_type])
    return hashlib.sha256(group_data_str.encode()).hexdigest()

def check_if_member_exists(client, entity_type, group_name_hash, entity_value):

    query = f"""
        SELECT COUNT(*) 
        FROM group_data
        WHERE entity_type = '{entity_type}' 
        AND group_name_hash = '{group_name_hash}' 
        AND entity_value = '{entity_value}'
    """
    result = client.query(query)
    if result.result_rows:
        count = result.result_rows[0][0]  
        return count > 0 
    else:
        return False

def insert_target_member(df, hash_value, client):

    # Normalize column names for consistency
    df.columns = df.columns.str.strip().str.upper().str.replace(" ", "_")
    entity_type = ''
    member_df = pd.DataFrame()

    # Determine the entity type based on which column is available, and assign the corresponding 'entity_value'
    if 'NUMBER' in df.columns:
        entity_type = 'NUMBER'
        member_df['entity_value'] = df['NUMBER']
        member_df['phone_no'] = df['NUMBER']

    elif 'IP' in df.columns:
        entity_type = 'Ip'
        member_df['entity_value'] = df['IP']
        member_df['ip'] = df['IP']

    elif 'IMEI' in df.columns:
        entity_type = 'IMEI'
        member_df['entity_value'] = df['IMEI']
        member_df['imei_no'] = df['IMEI']

    elif 'IMSI' in df.columns:
        entity_type = 'IMSI'
        member_df['entity_value'] = df['IMSI']
        member_df['imsi_no'] = df['IMSI']

    elif 'CELL_ID' in df.columns:
        entity_type = 'CELL ID'
        member_df['entity_value'] = df['CELL_ID']

    elif 'PINCODE' in df.columns:
        entity_type = 'Pincode'
        member_df['entity_value'] = df['PINCODE']

    elif 'LAT_LONG' in df.columns:
        entity_type = 'Lat Long'
        member_df['entity_value'] = df['LAT_LONG']

    if member_df.empty:
        print("Invalid file: No valid data found.")
        return
    
    # Generate a hash for each row in the DataFrame based on the entity type
    member_df['group_data_hash'] = df.apply(create_hash, axis=1, entity_type=entity_type)
    member_df['entity_type'] = str(entity_type)
    member_df['tags'] = df['TAGS'] if 'TAGS' in df.columns else ''
    member_df['source'] = df['SOURCE'] if 'SOURCE' in df.columns else ''
    member_df['remarks'] = df['REMARKS'] if 'REMARKS' in df.columns else ''
    member_df['date'] = df['DATE'] if 'DATE' in df.columns else ''
    member_df['group_name_hash'] = str(hash_value)
    member_df['group_name'] = 'Targets'
    member_df['target_name'] = df['NAME'] if 'NAME' in df.columns else '' 

    member_df = member_df[sorted(member_df.columns)].astype(str)

    records_to_insert = []
    for _, row in member_df.iterrows():
        if not check_if_member_exists(client, entity_type, hash_value, row['entity_value']):
            records_to_insert.append(row)
    new_member_df = pd.DataFrame(records_to_insert)

    if not new_member_df.empty:
        client.insert('group_data', new_member_df.to_records(index=False).tolist(), column_names=list(new_member_df.columns))
        print(f"Successfully inserted {len(new_member_df)} new rows.")
    else:
        print("No new data to insert.")

def process_excel_file(file_path, hash_value, client):
    sheets = pd.read_excel(file_path, sheet_name=None)
    
    for sheet_name, df in sheets.items():
        print(f"Processing sheet: {sheet_name}")
        try:
            insert_target_member(df, hash_value, client)
            
        except Exception as e:
            print(f"Error processing sheet {sheet_name}: {e}")

file_path = 'Sample_Watch_List.xlsx'
process_excel_file(file_path, hash_value, client)
