import json
import clickhouse_connect
import pandas as pd

table = 'p_tower_test'
json_file= open('database.config','r').read()

def clickhouse_connection():    

    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    
    client = clickhouse_connect.get_client(
            host=database['click_house_node1'],
            port=database['click_house_port'],
            user=database['click_house_username'],
            password=database['click_house_password'],
            database=database['click_house_database'],
        )
    return client

client = clickhouse_connection()


df = pd.read_csv('/home/tectum18/Desktop/tower_data/mela cell_id_data/vi/B_rest_prayagraj.csv', encoding='utf-8')
df.columns = df.columns.str.strip()

# VI = 1
# df = df[['CGI','Latitude','Longitude','Site Name']]
# df = df.rename(columns={'CGI':'tower_cgi','Latitude': 'tower_latitude', 'Longitude': 'tower_longitude','Site Name':'tower_site_name'})

# VI = 2
# df = df[['CGI','Latitude','Longitude','City/town']]
# df = df.rename(columns={'CGI':'tower_cgi','Latitude': 'tower_latitude', 'Longitude': 'tower_longitude','City/town':'tower_state'})

# VI = 3
# df = df[['CGI','Latitude','Longitude']]
# df = df.rename(columns={'CGI':'tower_cgi','Latitude': 'tower_latitude', 'Longitude': 'tower_longitude'})

# df['tower_location'] = df['tower_location'].replace('\n', ' ', regex=True)
df['tower_cgi'] = df['tower_cgi'].str.replace('-', '', regex=False)
# df['tower_site_name'] = df['tower_site_name'].str.upper()

df['by_telecom'] = '0' 
df['created_at'] = '0'
df['file_name'] = None
df['range'] = '0.0'
df['signal_strength'] = '0.0'
df['t_status'] = '1'
df['tower_azimuth'] = '0.0'
df['tower_district'] = None
df['tower_height'] = None
# df['lat_long'] = [(0.0, 0.0)] * len(df)
# df['tower_location']= 'MELA_AREA'
df['tower_location']= 'ROF_PRAYAGRAJ'
df['tower_network_type'] = ''
df['tower_operator'] ='VI'
df['tower_pincode'] =None
df['tower_site_name'] =None
df['tower_state'] = None
df['tower_town'] = None
df['updated_at'] = '0'
print(df.head(2))


df = df[sorted(df.columns)].astype(str)
client.insert(table, df.to_records(index=False).tolist(),column_names=list(df.columns))
print("successfull inserted:",len(df))

