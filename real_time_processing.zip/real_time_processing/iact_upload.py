# IACT/PACT UPLOAD
# Author: Sresht
# Date: 25th Oct 2023

# IACT UPLOAD
# Changed By: Arvind
# Date: 27-12-2023
# Import necessary libraries/modules at the beginning of your script.
import logging
import pathlib
import MySQLdb
import json
import os
import sys
import subprocess
import re
import hashlib
import mmap
import magic
import mimetypes
import pandas as pd
import numpy as np
import zipfile
from bs4 import BeautifulSoup
import warnings
import shutil
import openpyxl,xlrd,csv


# turn warning off for pandas
warnings.filterwarnings('ignore')

# supported compressed files
SUPPORTED_COMPRESSED = ['zip', 'gz', 'tar', 'bz2', '7z', 'rar']

# supported pcap files
SUPPORTED_PCAP = ['pcap', 'pcapng']

# supported single files
SUPPORTED_SINGLE = ['csv', 'text', 'xlsx', 'xls', 'html']

# db connection
def ipdr_conn():
    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    return MySQLdb.connect(
        host=database['database_url'],
        port=database['database_port'],  # Replace with your desired port number
        user=database['database_user'],
        passwd=database['database_password'],
        db=database['database_name']
    )

# get all mappers
# def get_all_mappers():
#     conn = ipdr_conn()
#     df = pd.read_sql('SELECT mn.mapper_name, mn.date_format,mt.mapper_type_name, mo.operator_name, mo.country_name, md.database_col, md.format_col FROM mapper_database md JOIN mapper_names mn ON mn.mapper_name_id = md.mapper_name_id JOIN mapper_types mt ON mn.mapper_type_id = mt.mapper_type_id JOIN mapper_operators mo ON mn.mapper_operator_id = mo.operator_id', conn)
#     conn.close()
#     return df


def get_all_mappers():
    conn = ipdr_conn()
    df1 = pd.read_sql('SELECT mn.mapper_name, mn.date_format,mt.mapper_type_name as model_type, mo.operator_name as telecom_name, mo.country_name as mapper_country_name, md.database_col, md.format_col FROM mapper_database md JOIN mapper_names mn ON mn.mapper_name_id = md.mapper_name_id JOIN mapper_types mt ON mn.mapper_type_id = mt.mapper_type_id JOIN mapper_operators mo ON mn.mapper_operator_id = mo.operator_id', conn)
    conn.close()
    df2 = df1.pivot_table(index=['mapper_name', 'date_format', 'model_type', 'telecom_name', 'mapper_country_name'],
                        columns='database_col', values='format_col', aggfunc='first').reset_index()
    df2.columns.name = None
    df2 = df2.rename_axis(columns=None).reset_index()
    df2 = df2.fillna('')
    exclude_cols = ['index','mapper_name', 'date_format', 'model_type', 'telecom_name', 'mapper_country_name']
    df3 = df2.copy()
    df3['dict_values'] = df2.apply(lambda row: {col: row[col] for col in row.index if col not in exclude_cols and row[col]!=''}, axis=1)

    df3['match_values'] = df2.apply(lambda row: [item.upper().strip() for sublist in [item.split('#####') if '#####' in item else [item] for item in list(set(row.drop(exclude_cols).tolist()))] for item in sublist if item != ''], axis=1)

    new_col = ['mapper_name', 'date_format', 'model_type', 'telecom_name', 'mapper_country_name','dict_values','match_values']
    df4 = df3[new_col]
    # df4.to_csv('all_mapper.csv')
    return df4

# mapper df


# get header and category
def get_header_category(file_dict,file_format):
    limit = 20
    print(file_dict)
    header, header_position = [], None
    
    if file_format in ['csv','txt']:
        with open(file_dict['file_path'], 'r') as sf:
            for line_num,line in enumerate(sf, 1):
                row = line.split(',')
                row = [item for item in row if item!='']
                if len(line)>95 and len(row) > 10:
                    header, header_position = [item.strip() for item in row], line_num
                    break
                limit -= 1
                if not limit:
                    break
    elif file_format in ['xls', 'xlsx','xlsb']:
        source_df = pd.read_excel(file_dict['file_path'],sheet_name=0, header=None, engine='xlrd' if file_format=='xls' else 'openpyxl')
        for _, row in source_df.iterrows():
            row_list = row.tolist()
            # print(row_list,'=======================')
            nan_count = row_list.count(np.nan)
            if nan_count == 0:
                header, header_position = row_list, _
                break
            limit -= 1
            if not limit:
                break
    elif file_format == 'html':
        with open(file_dict['file_path'], 'r') as hf:
            try:
                soup = BeautifulSoup(hf, "html.parser")
                tables = soup.find_all('table')
                first_row = tables[0].find('tr')
                header = [(header.text).strip()for header in first_row.find_all('td')]
                header_position = 0
            except:
                header, header_position = [], None
      

        
    return [item for item in header if item], header_position

def getStatus(file_dict, model_type,file_format,MAPPER_DF):
    status, mapper_name, service_provider, file_type, header_position,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper = None, None, None, None, None,'','',{},None
    keywords = ['Calling (A) Party Number', 'Target /A PARTY NUMBER', 'GPRS Report', 'BTS location'] # not applicable cdr
    try:
        def is_file_empty(file_path, data):
            res = False
            if os.path.getsize(file_path) == 0:
                return True
            if data.isspace():
                return True
            data_line = [line for line in file_content.splitlines() if line]
            comma_line = 0
            for line in data_line:
                comma_count = line.count(',')
                x_count = line.count('|')
                if comma_count >= 8 or x_count >= 8:
                    comma_line += 1
                if comma_line > 1:
                    return False
            if comma_line ==1:
                return True
            return res
        
        def read_raw_file_in_mb(file_path, mb_size):
            chunk_size_bytes = 1024 * 1024
            bytes_read = 0
            binary = b''

            with open(file_path, 'rb') as file:
                while bytes_read < mb_size * chunk_size_bytes:
                    data = file.read(chunk_size_bytes)
                    if not data:
                        break
                    binary += data#.decode('utf-8')
                    bytes_read += len(data)
            return binary
        
        def read_data_file_in_mb(file_path, mb_size):
            chunk_size_bytes = 1024 * 1024
            bytes_read = 0
            d = ''
            with open(file_path, 'rb') as file:
                while bytes_read < mb_size * chunk_size_bytes:
                    data = file.read(chunk_size_bytes)
                    if not data:
                        break
                    d += data.decode('utf-8')
                    bytes_read += len(data)
            return d
        
        def get_details(file_dict,model_type,file_format,MAPPER_DF):
            header_length, header_list, header_position, mapper_name, telecom_name, model_type, uploadStatus, date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper = 0, [], None, None, None, model_type, None,None,None,{},None
            try:
                header_list, header_position = get_header_category(file_dict,file_format)
                if header_list:
                    
                    MAPPER_DF = MAPPER_DF[MAPPER_DF['model_type'] == model_type]   
                    # MAPPER_DF.to_csv('all_mappers.csv',index=None)                 
                    header_list  =[header.upper().strip() for header in header_list]
                    mapper_found = False
                    not_found_mapper_data_list = []
                    not_found_mapper_name_list = []
                    for index,items in MAPPER_DF.iterrows():
                        if sorted(list(set(items['match_values'])))==sorted(list(set(header_list))):
                            print('mapper_name',items['mapper_name'])
                            mapper_name = items['mapper_name']
                            telecom_name  = items['telecom_name']
                            mapper_country_name  = items['mapper_country_name']
                            date_format  = items['date_format']
                            mapper_dict_with_raw = items['dict_values']
                            mapper_found = True
                            break
                        else:
                           
                            match_values_in_mapper  = list(set(items['match_values']) - set(header_list))
                            match_values_out_mapper = list(set(header_list)-set(items['match_values']))
                            added_mapper_data = match_values_in_mapper+match_values_out_mapper
                            
                            not_found_mapper_data_list.append(list(set(added_mapper_data)))
                            not_found_mapper_name_list.append(items['mapper_name'])
                    if mapper_found == True:
                        uploadStatus = 0
                    else:
                        top_not_found_mapper_data = min(not_found_mapper_data_list, key=len)
                        not_found_mapper_index = not_found_mapper_data_list.index(top_not_found_mapper_data)
                        top_not_found_mapper= {'mapper_name':not_found_mapper_name_list[not_found_mapper_index],'mapper_cols':top_not_found_mapper_data}
                        # print(top_not_found_mapper)
                        # print('-------------------------------------------============')
                        uploadStatus  = 9
                else:
                     uploadStatus  = 5
            except Exception as err:
                logging.error(f'Error in get_details() - {str(err)}', exc_info=True)
                pass
            return header_list, header_position, mapper_name, telecom_name, uploadStatus,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        
        header, header_position, mapper_name, service_provider, status,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper = get_details(file_dict,model_type,file_format,MAPPER_DF)
        header_length = len(header)
        if status is not None:
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        
        raw_data = read_raw_file_in_mb(file_dict['file_path'], 10)    
        if b'\x00' in raw_data or any(char < 32 and char not in [9, 10, 13] for char in raw_data):
            # print(f"{file_path}: Invalid file - File is binary or encoded")
            status = 8
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        
        file_content = read_data_file_in_mb(file_dict['file_path'], 10)
        
        # print(file_dict)
        if is_file_empty(file_path, file_content):
            # print(f"{file_path}: File Is Empty")
            status = 5
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        elif model_type =='ipdr' and any(keyword in file_content for keyword in keywords):
            # print(f"{file_path}: Invalid file, Format is gprsdata")
            status = 6
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        elif model_type =='ipdr' and file_content.lower().find('destination') == -1 and file_content.lower().find('Destination') == -1: # not applicable cdr
        # elif file_content.lower().find('destination') == -1 and file_content.lower().find('Destination') == -1: # not applicable cdr
            # print(f"{file_path}: Invalid file, Destination IP not found")
            status = 7
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        elif "E+11" in file_content or "E+12" in file_content or "E+13" in file_content or "E+14" in file_content or "E+15" in file_content or "E+16" in file_content or "E+17" in file_content or "E+18" in file_content or file_content in "E+19":
            # print(f"{file_path}: File is opened in Excel 1")
            status = 4
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        elif model_type =='ipdr' and "-----------------" in file_content: # # not applicable cdr
            # print(f"{file_path}: File is opened in Excel 1")
            status = 4
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        elif re.search(r'E\+[0-9]{2,}', file_content):
            # print(f"{file_path}: File is opened in Excel 1")
            status = 4
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
        else:
            # print('Completed')
            status = 0
            return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
    except Exception as err:
        logging.error(f"Error inside getStatus" , exc_info=True)
        status = 3
        return status, mapper_name, service_provider, model_type, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper
    # return status, mapper_name, service_provider, file_type, header_position, header_length


# bulk insert to table file_meta_details
def meta_bulk_injest(rows):
    # print(rows)
    insert_query = """
    INSERT INTO ipdr_data.files_meta_details (
        file_id,
        name,
        request_id,
        input_type,
        Input_value,
        start_date,
        end_date,
        total_records,
        case_id,
        file_hash,
        telecom_name,
        path,
        uploadStatus,
        pcap_phone_no,
        pcap_public_ip_address,
        file_type,
        file_format,
        mapper_name,
        header_position,
        header_length,
        date_format,
        mapper_country_name,
        mapper_dict_with_raw,
        top_not_found_mapper
    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
    """
    # print(insert_query)
    conn = ipdr_conn()
    cur = conn.cursor()
    cur.executemany(insert_query, rows)
    conn.commit()
    cur.close()
    conn.close()


def generic_injest(model_type,injest_type, data_dict, case_id, pcap_phone_no, pcap_public_ip_address, file_format,MAPPER_DF=None,telecom_name_cdr=None):
    rows = []
    file_id = 0
    request_id = 0
    input_type = ''
    Input_value = ''
    start_date = ''
    end_date = ''
    total_records = 0
    case_id = case_id
    date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper = '','',{},{}
    if model_type == 'gprs':        
        if isinstance(data_dict, dict):
            data_dict = data_dict.values()
        for item in data_dict:            
            name = os.path.basename(item['file_path'])                        
            file_hash = item['file_hash']
            file_format ='gprsdata'
            telecom_name = 'pcap'
            path = os.path.dirname(item['file_path'])
            if injest_type == 'insert':
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper = 0, None, telecom_name, 'gprs', None, None,None,{},{}
                
                MAPPER_DF = MAPPER_DF[MAPPER_DF['model_type'] == 'gprs']   
                
                mapper_found = False                
                for index,items in MAPPER_DF.iterrows():
                    print('mapper_name',items['mapper_name'])
                    mapper_name = items['mapper_name']
                    telecom_name  = items['telecom_name']
                    mapper_country_name  = items['mapper_country_name']
                    date_format  = items['date_format']
                    mapper_dict_with_raw = items['dict_values']
                    header_length = len(items['dict_values'].keys())
                    header_position = 1
                    mapper_found = True
                    break                           
                if mapper_found == True:
                    uploadStatus = 0
                else:
                    uploadStatus  = 9

                
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)                 
            elif injest_type == 'update':
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = -2, None, telecom_name, None, None, None

                MAPPER_DF = MAPPER_DF[MAPPER_DF['model_type'] == 'gprs']   
                mapper_found = False                
                for index,items in MAPPER_DF.iterrows():
                    print('mapper_name',items['mapper_name'])
                    mapper_name = items['mapper_name']
                    telecom_name  = items['telecom_name']
                    mapper_country_name  = items['mapper_country_name']
                    date_format  = items['date_format']
                    mapper_dict_with_raw = items['dict_values']
                    header_length = len(items['dict_values'].keys())
                    header_position = 1
                    mapper_found = True
                    break                   
                if mapper_found == True:
                    uploadStatus = -2
                else:
                    uploadStatus  = 9
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
            elif injest_type == 'failed':
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 12, None, telecom_name, None, None, None
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
            else:
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 11, None, telecom_name, None, None, None       
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
    
    elif model_type == 'pcap':        
        if isinstance(data_dict, dict):
            data_dict = data_dict.values()
        for item in data_dict:            
            shutil.move(item['file_path'],item['file_path'].replace(' ','_'))
            item['file_path'] = item['file_path'].replace(' ','_')
            name = os.path.basename(item['file_path'])            
            file_hash = item['file_hash']
            file_format ='pcap'
            telecom_name = 'pcap'
            path = os.path.dirname(item['file_path'])
            if injest_type == 'insert':
                temp_file_format = item['file_format']
                if temp_file_format in ['pcapng','pcap']:
                    file_format =temp_file_format
                    pcap_phone_no = get_pcap_phone_no_gprs(name)
                    if pcap_phone_no !='':                        
                        uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper = 0, None, None, 'pcap', None, None,None,{},{}
                        MAPPER_DF = MAPPER_DF[MAPPER_DF['model_type'] == 'pcap']   
                        # MAPPER_DF.to_csv('all_mappers.csv',index=None)
                        mapper_found = False                
                        for index,items in MAPPER_DF.iterrows():                            
                            print('mapper_name',items['mapper_name'])
                            mapper_name = items['mapper_name']
                            telecom_name  = items['telecom_name']
                            mapper_country_name  = items['mapper_country_name']
                            date_format  = items['date_format']
                            mapper_dict_with_raw = items['dict_values']
                            header_length = len(items['dict_values'].keys())
                            header_position = 1
                            mapper_found = True
                            break                    
                        if mapper_found == True:
                            uploadStatus = 0
                        else:
                            uploadStatus  = 9
                        row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                        rows.append(row)                 
                    else:
                        uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = -2, None, 'pcap', None, None, None
                        MAPPER_DF = MAPPER_DF[MAPPER_DF['model_type'] == 'pcap']   
                        mapper_found = False                
                        for index,items in MAPPER_DF.iterrows():
                            print('mapper_name',items['mapper_name'])
                            mapper_name = items['mapper_name']
                            telecom_name  = items['telecom_name']
                            mapper_country_name  = items['mapper_country_name']
                            date_format  = items['date_format']
                            mapper_dict_with_raw = items['dict_values']
                            header_length = len(items['dict_values'].keys())
                            header_position = 1
                            mapper_found = True
                            break                  
                        if mapper_found == True:
                            uploadStatus = -2
                        else:
                            uploadStatus  = 9
                        row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                        rows.append(row)
                else:
                    uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 12, None, 'pcap', None, None, None
                    row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                    rows.append(row)
            elif injest_type=='failed':
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 12, None, 'pcap', None, None, None
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
            else:
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 11, None, 'pcap', None, None, None       
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length,date_format,mapper_country_name,mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
    elif model_type == 'cdr':
        if isinstance(data_dict, dict):
            data_dict = data_dict.values()
        for item in data_dict:
            name = os.path.basename(item['file_path'])            
            file_hash = item['file_hash']
            path = os.path.dirname(item['file_path'])            
            file_format =item['file_format']
            # operator_list=['AIRTEL','BSNL','JIO','VODA']
            # telecom_name = ''  
            # if 'AIRTEL' in path:
            #     telecom_name_cdr= 'AIRTEL'
            # elif 'BSNL' in path:
            #     telecom_name_cdr= 'BSNL'
            # elif 'JIO' in path:
            #     telecom_name_cdr= 'JIO'
            # elif 'VODA' in path:
            #     telecom_name_cdr='VI'
            # else:
            #     telecom_name_cdr='GENERAL'
            
            if injest_type =='failed':                
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 12, None, telecom_name_cdr, None, None, None
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
            elif injest_type =='duplicate':
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 11, None, telecom_name_cdr, None, None, None    
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
            elif injest_type  == 'insert':
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper = getStatus(item, model_type,file_format,MAPPER_DF)
                if uploadStatus is None:
                    if header_position is not None:
                        if not mapper_name:
                            uploadStatus = 9
                    else:
                        uploadStatus = 12
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name_cdr, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper)
                # print(row)
                rows.append(row)
    else:
        if isinstance(data_dict, dict):
            data_dict = data_dict.values()
        for item in data_dict:
            name = os.path.basename(item['file_path'])            
            file_hash = item['file_hash']
            path = os.path.dirname(item['file_path'])            
            file_format =item['file_format']
            telecom_name = ''            
            if injest_type =='failed':                
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 12, None, model_type, None, None, None
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
            elif injest_type =='duplicate':
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 11, None, model_type, None, None, None    
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper)
                rows.append(row)
            elif injest_type  == 'insert':
                uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper = getStatus(item, model_type,file_format,MAPPER_DF)
                if uploadStatus is None:
                    if header_position is not None:
                        if not mapper_name:
                            uploadStatus = 9
                    else:
                        uploadStatus = 12
                row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper)
                # print(row)
                rows.append(row)
    if rows:
        meta_bulk_injest(rows)

# check if files already exists in db using hashes
def check_exists_new(datas, case_id):
    exists, new = {}, {}
    hash_list = list(datas.keys())
    sql_query = "SELECT file_hash FROM ipdr_data.files_meta_details WHERE case_id="+case_id+" AND file_hash IN (%s)"
    conn = ipdr_conn()
    cur = conn.cursor()
    enquiry_string =', '.join(map(lambda x: '%s', hash_list))
    sql_enquiry = sql_query % (enquiry_string)
    cur.execute(sql_enquiry, hash_list)
    exists_hash = [item[0] for item in cur.fetchall()]
    cur.close()
    conn.close()
    new_hash = list(set(hash_list) - set(exists_hash))
    exists = {h1:datas[h1] for h1 in exists_hash}
    new = {h2:datas[h2] for h2 in new_hash}
    return exists, new

# get sha256 hash of a file by mb
def get_sha256_hash_by_mb(file_path, mb_to_read):
    chunk_size_bytes = 1024 * 1024
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as file:
        bytes_read = 0
        while bytes_read < mb_to_read * chunk_size_bytes:
            data = file.read(chunk_size_bytes)
            if not data:
                break
            sha256.update(data)
            bytes_read += len(data)
    return sha256.hexdigest()

# get sha256 hash of a file
def get_sha256_hash(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as file:
        try:
            with mmap.mmap(file.fileno(), 0, access=mmap.ACCESS_READ) as mmapped_file:
                sha256.update(mmapped_file)
        except:
            sha256.update(file.read())
    return sha256.hexdigest()

# get file size in mb
def get_file_size_mb(file_path):
    file_size_bytes = os.path.getsize(file_path)
    file_size_mb = file_size_bytes / (1024 * 1024)
    return file_size_mb


# generate hash
def generate_hash(file_paths,model_type):
    mb_to_read = 10
    datas = {}
    dup_datas = []
    if not isinstance(file_paths, list):
        file_paths = [file_paths]
    for file_path in file_paths:
        ext = os.path.splitext(file_path)[1].replace('.', '')
        if ext not in ['ini']:
            s_mb = get_file_size_mb(file_path)
            if s_mb <= 10:
                hash = get_sha256_hash(file_path)
            else:
                hash = get_sha256_hash_by_mb(file_path, mb_to_read)
            print(mime_to_type(file_path,model_type,os.path.splitext(file_path)[1].replace('.', '')),'===========================',file_path)
            if hash not in datas:
                datas[hash] = {'file_path': file_path, 'file_hash': hash, 'file_format': mime_to_type(file_path,model_type,os.path.splitext(file_path)[1].replace('.', '')), 'file_extension': os.path.splitext(file_path)[1].replace('.', '')}
            else:
                dup_datas.append({'file_path': file_path, 'file_hash': hash, 'file_format': mime_to_type(file_path,model_type,os.path.splitext(file_path)[1].replace('.', '')), 'file_extension': os.path.splitext(file_path)[1].replace('.', '')})
    return datas, dup_datas

# def spliting_csv_from_excel(file_path,file_extension):
#     csv_list = []
#     sheet_names = []
#     # file_extension = file_path.split('.')[-1]
#     output_file_name = os.path.basename(file_path).split('.')[0]
#     output_file_path = os.path.dirname(file_path)
#     # print(f"[+]file extension in spliting csv {file_extension}")
#     # file_extension = mime_to_type(file_path,model_type,file_extension)
#     if file_extension == 'xlsx':
#         workbook = openpyxl.load_workbook(file_path)
#         sheet_names = workbook.sheetnames
#     elif file_extension == 'xls':
#         try:
#             workbook = xlrd.open_workbook(file_path)
#             sheet_names = workbook.sheet_names()
#         except Exception as e :
#             print(f'[+] xls workbook error as:  {str(e)}')
#     # print(f'[+] xls workbook {file_path} have Sheet name {sheet_names}')
#     if len(sheet_names) > 1:
        
#         for sheet_name in sheet_names:
#             if file_extension == 'xlsx':
#                 sheet = workbook[sheet_name]
#                 data = sheet.values
#             elif file_extension == 'xls':
#                 sheet = workbook.sheet_by_name(sheet_name)
#                 data = [sheet.row_values(i) for i in range(sheet.nrows)]
#             # print(f"")
#             csv_file_path = os.path.join(output_file_path, f"{output_file_name}_{sheet_name}.csv")
#             # print(f"[+] csv names: {csv_file_path}")
#             with open(csv_file_path, 'w', newline='') as csv_file:
#                 csv_writer = csv.writer(csv_file)
#                 csv_writer.writerows(data)
#             csv_list.append(csv_file_path)

#             print(f"CSV file created for sheet '{sheet_name}': {csv_file_path}")
#     else:
#         print("Only one sheet found. No CSV files created.")
#     return csv_list


def spliting_csv_from_excel(file_path, file_extension, output_path):
    csv_list = []
    sheet_names = []
    output_file_name = os.path.basename(file_path).split('.')[0]
    output_file_path = os.path.dirname(output_path)

    try:
        if file_extension == 'xlsx':
            workbook = openpyxl.load_workbook(file_path)
            sheet_names = workbook.sheetnames
        elif file_extension == 'xls':
            workbook = xlrd.open_workbook(file_path)
            sheet_names = workbook.sheet_names()
        else:
            raise ValueError(f"Unsupported file extension: {file_extension}")
    except Exception as e:
        print(f"[+] Error loading workbook '{file_path}': {str(e)}")
        return csv_list

    if len(sheet_names) > 1:
        for sheet_name in sheet_names:
            try:
                if file_extension == 'xlsx':
                    sheet = workbook[sheet_name]
                    data = sheet.values
                elif file_extension == 'xls':
                    sheet = workbook.sheet_by_name(sheet_name)
                    data = [sheet.row_values(i) for i in range(sheet.nrows)]
                else:
                    continue
                
                csv_file_path = os.path.join(output_file_path, f"{output_file_name}_{sheet_name}.csv")
                with open(csv_file_path, 'w', newline='') as csv_file:
                    csv_writer = csv.writer(csv_file)
                    csv_writer.writerows(data)
                csv_list.append(csv_file_path)
                print(f"CSV file created for sheet '{sheet_name}': {csv_file_path}")
            except Exception as e:
                print(f"[+] Error processing sheet '{sheet_name}': {str(e)}")
    else:
        print("Only one sheet found. No CSV files created.")
    
    return csv_list

# get file paths from a dir
def get_all_file_path(path,file_extension, output_path):
    
    result = []
    for root, dirs, files in os.walk(path):
        for filename in files:
            file_path = os.path.join(root, filename)
            file_extension = str(pathlib.Path(file_path).suffix).replace('.','')
            # print(f"[!] file_path: {file_path} {file_extension}")
            csv_list = []
            if file_extension in ['xls','xlsx']:
                # print(f"[+] file_details: {filename}\n")
                csv_list = spliting_csv_from_excel(file_path,file_extension, output_path)
                if len(csv_list)!=0:
                    result = result+csv_list
                else:result.append(file_path)
            else:
                result.append(file_path)
    return result

def get_pcap_phone_no_gprs(output):
    pcap_phone_no = ''
    pattern = r'91\d{10}'
    try:
        matches = re.findall(pattern, output)
        if matches:
            pcap_phone_no=matches[0]
            print(matches[0])
    except:
        pass
    return pcap_phone_no

# validate gprs 
def is_gprsdata(output):
    result = False
    print(output)
    
    if '_ZPKT.txt' in output or 'G-UNKNOWN' in output or 'G-DNS' in output:
        result = True
    return result

# nested unzipper    
def unzip_nested_zip(file_path,model_type, output_path):    
    def get_zip(path):
        res = []
        for root, dirs, files in os.walk(path):
            for filename in files:
                fpath = os.path.join(root, filename)
                if mime_to_type(fpath,model_type,filename.split('.')[-1]) in SUPPORTED_COMPRESSED:
                    ext = os.path.splitext(fpath)[-1][1:].lower()
                    if ext not in SUPPORTED_SINGLE and ext not in SUPPORTED_PCAP and ext in SUPPORTED_COMPRESSED:
                        res.append([root, filename])
        return res
    
    extract_dir = output_path # os.path.splitext(file_path)[0]
    os.makedirs(extract_dir, exist_ok=True)
    subprocess.call(['7z', 'x', f'-o{extract_dir}', '-aoa', file_path, '-y', '-bso0', '-bsp0'])
    mal_zip = []
    while True:
        zips = get_zip(extract_dir)
        for item in mal_zip:
            if item in zips:
                zips.remove(item)
        if zips:
            for zip in zips:
                if not is_encrypted(os.path.join(zip[0], zip[1])):
                    try:
                        command = ['7z', 'x', f'-o{extract_dir}', '-aoa', os.path.join(zip[0], zip[1]), '-y', '-bso0', '-bsp0']
                        subprocess.call(command)
                        os.remove(os.path.join(zip[0], zip[1]))
                    except Exception as err:
                        logging.error('unzip error - (unzip_nested_zip) -', err)
                else:
                    if zip not in mal_zip:
                        mal_zip.append(zip)
        else:
            break
    return extract_dir

def is_encrypted(file_path):
    zf = zipfile.ZipFile(file_path)
    for zinfo in zf.infolist():
        is_encrypted = zinfo.flag_bits & 0x1 
        if is_encrypted:
            return True
    return False

# get compressed listing without decompression
def get_compressed_list(file_path):
    return subprocess.run(['7z', 'l', '-ba', file_path], capture_output=True, text=True).stdout

def is_really_xlsx(file_path):
    try:
        with zipfile.ZipFile(file_path, 'r') as zip_file:
            required_files = {'[Content_Types].xml', 'xl/workbook.xml'}
            zip_file_contents = set(zip_file.namelist())
            return required_files.issubset(zip_file_contents)
    except zipfile.BadZipFile:
        return False

# mimetype to filetype mapper
def mime_to_type(file_path,model_type,file_ext):
    res = ''
    mimetype =  magic.from_file(file_path, mime=True)
    # print(mimetype, file_ext)
    if model_type in ['pcap','gprs']:
        d = {
            'application/vnd.tcpdump.pcap': 'pcap',
            'application/x-pcap': 'pcap',            
            'application/vnd.tcpdump.pcapng': 'pcapng',           
            'application/x-zip-compressed': 'zip',
            'application/zip': 'zip',
            'application/gzip': 'gz',
            'application/x-tar': 'tar',
            'application/x-bzip2': 'bz2',
            'application/x-7z-compressed': '7z',
            'application/x-rar-compressed': 'rar',
            'inode/blockdevice': 'zip'
        }
    else:
        d = {
            
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
            'application/vnd.ms-excel': 'xls',            
            'application/vnd.ms-excel.sheet.binary.macroEnabled.12':'xlsb',
            'text/html': 'html',
            'text/plain': 'csv',
            'text/csv': 'csv',
            'application/csv': 'csv',
            'application/x-zip-compressed': 'zip',
            'application/zip': 'zip',
            'application/gzip': 'gz',
            'application/x-tar': 'tar',
            'application/x-bzip2': 'bz2',
            'application/x-7z-compressed': '7z',
            'application/x-rar-compressed': 'rar'
        }
    if file_ext == 'csv' and mimetype == 'application/octet-stream':
        res = 'csv'
        return res
    elif file_ext == 'xls' and mimetype == 'application/octet-stream':
        res = 'xls'
        return res
    elif file_ext == 'xlsx' and mimetype == 'application/octet-stream':
        res = 'xlsx'
        return res
    elif file_ext == 'xlsx' and is_really_xlsx(file_path):
        res = 'xlsx'
        return res
    elif file_ext == 'xlsb' and mimetype == 'application/octet-stream':
        res = 'xlsb' 
        return res  
    elif file_ext == 'pcap' and mimetype in ['application/octet-stream','application/vnd.tcpdump.pcap']:
        res = 'pcap'
        return res
    elif file_ext == 'pcapng' and mimetype in ['application/octet-stream','application/vnd.tcpdump.pcap']:
        res = 'pcapng'   
        return res
    elif file_ext == 'ini' and mimetype == 'text/plain':
        res = ''  
        return res
    elif mimetype in d:
        # print('\n[i] mimetype:',d[mimetype])
        res = d[mimetype]
        return res


def main_function(file_path, case_id, model_type, output_path,telecom_name_cdr=None):
    ''' Main function to process the file.
        Args:
            file_path: path of the file to be processed.
            case_id: case id of the file.
            model_type: model(ipdr, cdr, gprs, pcap, pcapng, csv, etc) type of the file.
    '''
    
    #  log_dir_path: path of the log directory in public folder.
    log_dir_path = os.getcwd()+"/public"

    # check and create log directory
    if not os.path.exists(log_dir_path):
        os.makedirs(log_dir_path)

    print(os.path.join(log_dir_path, "uploader.log"))
    logging.basicConfig(filename=os.path.join(log_dir_path, f"uploader.log"), level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logging.info(f"Started processing for {file_path}")
    
    # get dataframe of all mappers
    MAPPER_DF = get_all_mappers()

    if model_type == 'gprs':
        ext = os.path.splitext(file_path)[1].replace('.', '')
        ft = mime_to_type(file_path,model_type,ext)
        # print('[+] filetype:',ft)
        
        if ft in SUPPORTED_COMPRESSED and ext in SUPPORTED_COMPRESSED:
            logging.info(f"Supported compressed file detected")

            hashes, _ = generate_hash(file_path,model_type)
            logging.info(f"Unique file count = {len(hashes)}")
            if hashes:
                logging.info(f"Initiating files Database Validation")
                hash_already_exists, new_hashes = check_exists_new(hashes, case_id)
                if new_hashes:
                    output = get_compressed_list(file_path)
                    if is_gprsdata(output):
                        pcap_phone_no = get_pcap_phone_no_gprs(output)
                        print(pcap_phone_no,'===============')
                        if pcap_phone_no =='':
                            generic_injest('gprs','update', new_hashes, case_id, '', '',ft,MAPPER_DF)
                        else:    
                            pcap_public_ip_address = ''
                            generic_injest('gprs','insert', new_hashes, case_id, pcap_phone_no, pcap_public_ip_address,ft,MAPPER_DF)
                    else:
                        generic_injest('gprs','failed', new_hashes, case_id, '', '','')                
                if hash_already_exists:
                        generic_injest('gprs','duplicate', hash_already_exists, case_id, '', '','')
    elif model_type == 'pcap':
        print('\n[=> Enter model condition]',model_type)
        ext = os.path.splitext(file_path)[1].replace('.', '')
        ft = mime_to_type(file_path,model_type,ext)
        # print('\n[+] file type:',ft)
        is_process = False
        if ft in SUPPORTED_COMPRESSED and ext in SUPPORTED_COMPRESSED:
            extract_dir = unzip_nested_zip(file_path,model_type)
            file_paths = get_all_file_path(extract_dir,ft)
            is_process = True
        elif ft in SUPPORTED_PCAP:
            file_paths = [file_path]
            is_process = True
        else:
            file_paths = [file_path]
            hashes, duplicate_hashes = generate_hash(file_paths,model_type)
            generic_injest('pcap','failed', hashes, case_id, '', '','')
            
        if is_process == True:
            hashes, duplicate_hashes = generate_hash(file_paths,model_type)
            if hashes:                
                hash_already_exists, new_hashes = check_exists_new(hashes, case_id)                
                if new_hashes:
                    generic_injest('pcap','insert', new_hashes, case_id, '', '',ft,MAPPER_DF)
                if hash_already_exists:
                    generic_injest('pcap','duplicate', hash_already_exists, case_id, '', '','')
            if duplicate_hashes:
                generic_injest('pcap','duplicate', duplicate_hashes, case_id, '', '','')
    else:
        print('\n[=> Enter model else condition]',model_type)
        ext = os.path.splitext(file_path)[1].replace('.', '')
        ft = mime_to_type(file_path,model_type,ext)
        # print(f"[+] ft Details {ft}")
        is_process = False
        if ft in SUPPORTED_COMPRESSED and ext in SUPPORTED_COMPRESSED:
            extract_dir = unzip_nested_zip(file_path,model_type, output_path)
            # print(f"[!] Extract_dir: {extract_dir}")
            file_paths = get_all_file_path(extract_dir,ft, output_path)
            # print("[+] File paths: ",file_paths)
            # print(f"[+] ft Details {ft}")
            is_process = True
        elif ft in ['xls','xlsx']:
            csv_list = spliting_csv_from_excel(file_path,ft)
            if len(csv_list)!=0:
                file_paths = csv_list
                is_process = True
            else:
                file_paths = [file_path]
                is_process = True
        elif ft in SUPPORTED_SINGLE:
            file_paths = [file_path]
            is_process = True
        else:
            file_paths = [file_path]
            hashes, duplicate_hashes = generate_hash(file_paths,model_type)
            generic_injest(model_type,'failed', hashes, case_id, '', '','',telecom_name_cdr=telecom_name_cdr)
        if is_process == True:
            hashes, duplicate_hashes = generate_hash(file_paths,model_type)
            # print(f"[+] Hash Details: {hashes}, \n\nDuplicate hshes {duplicate_hashes}")
            if hashes:                
                hash_already_exists, new_hashes = check_exists_new(hashes, case_id)                
                if new_hashes:
                    generic_injest(model_type,'insert', new_hashes, case_id, '', '',ft,MAPPER_DF,telecom_name_cdr=telecom_name_cdr)
                if hash_already_exists:
                    generic_injest(model_type,'duplicate', hash_already_exists, case_id, '', '','',telecom_name_cdr=telecom_name_cdr)
            if duplicate_hashes:
                generic_injest(model_type,'duplicate', duplicate_hashes, case_id, '', '','',telecom_name_cdr=telecom_name_cdr)
    

# Check if the script is the main program being run (not imported as a module).
if __name__ == '__main__':
    # Take values from the arguments
    
    if len(sys.argv) >= 3:
        file_path = sys.argv[1]
        case_id  = sys.argv[2]
        model_type = sys.argv[3]
        print('[+] Model type', model_type)
        output_path = sys.argv[4]
        # pcap_public_ip_address = sys.argv[5]
        
        main_function(file_path, case_id, model_type, output_path,telecom_name_cdr=None)
    else:
        print('use command - ')
        print(f'{os.path.basename(sys.argv[0])} <full-zip-file-path> <case-id> <model_type>')
        print('sample command - ')
        print(f'{os.path.basename(sys.argv[0])} /dir/test.zip 420 cdr')
