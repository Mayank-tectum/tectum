
import mysql.connector
from config_loader import load_config
config = load_config()  
DB_CONFIG = config['database']
import time

def insert_new_agent(agent_id):
    """ Insert new agent details into the database if they don't exist """
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    query = """
        INSERT INTO agent_status (agent_id, status, uptime)
        VALUES (%s, 'idle', NOW())
    """
    cursor.execute(query, (agent_id,))
    conn.commit()
    cursor.close()
    conn.close()

def initialize_agents(agent_ids):
    """ Initialize agents in the agent_status table """
    for agent_id in agent_ids:
        # Check if agent already exists
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)
        query = "SELECT * FROM agent_status WHERE agent_id = %s"
        cursor.execute(query, (agent_id,))
        agent = cursor.fetchone()
        
        if not agent:
            # If agent does not exist, insert a new agent record
            insert_new_agent(agent_id)
            print(f"Agent {agent_id} has been added to the system.")
        else:
            print(f"Agent {agent_id} already exists in the system.")
        
        cursor.close()
        conn.close()

if __name__ == "__main__":
    agent_ids = [1]  
    initialize_agents(agent_ids)
