# from msilib.schema import File
import os
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import mysql.connector
from datetime import datetime
from config_loader import load_config
from iact_upload import main_function

config = load_config()
DB_CONFIG = config['database']
CASE_CONFIG = config['case_details']
PATH_CONFIG = config['data_path']

def insert_file_meta(file_name, file_path, file_size, file_type):
    """Insert file metadata into the database."""
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    query = """
        INSERT INTO files_meta_details (name, path, file_type, status)
        VALUES (%s, %s, %s, %s)
    """
    cursor.execute(query, (file_name, file_path,  file_type, 'new'))
    conn.commit()
    cursor.close()
    conn.close()

class FileEventHandler(FileSystemEventHandler):
    """Event handler for folder monitoring."""

    def on_created(self, event):
        if not event.is_directory:
            file_name = os.path.basename(event.src_path)
            file_path = os.path.abspath(event.src_path)
            directory_path = os.path.dirname(file_path)

            directories = file_path.strip(os.sep).split(os.sep)
            file_type= 'ipdr'
            if 'cdr' in directories:
                file_type= 'cdr'
            if 'AIRTEL' in directories:
                telecom_name= 'AIRTEL'
            elif 'BSNL' in directories:
                telecom_name= 'BSNL'
            elif 'JIO' in directories:
                telecom_name= 'JIO'
            elif 'VODA' in directories:
                telecom_name='VI'
            else:
                telecom_name='GENERAL'
            last_folder_name = os.path.basename(directory_path)
            file_size = os.path.getsize(file_path)
            # file_type = os.path.splitext(file_name)[-1].lower()
            print(f"New file detected: {file_name, file_size, file_type,last_folder_name}")
            # insert_file_meta(file_name, file_path, file_size, file_type)
            ''' uploader function to upload the file. input details from config file: case id, model type, unzip path
            '''
            unzip_path = os.path.join(PATH_CONFIG['input_folder'],PATH_CONFIG['output_folder']+last_folder_name,file_name.split('.')[0])
            main_function(file_path, str(CASE_CONFIG['case_id']), file_type, unzip_path,telecom_name_cdr=telecom_name)

def start_monitoring(folder_path):
    """Start monitoring the folder for new files."""
    
    event_handler = FileEventHandler()
    observer = Observer()

    for directory in folder_path:
        observer.schedule(event_handler, directory, recursive=True)

    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

if __name__ == "__main__":
    folder_to_monitor_cdr = os.path.join(PATH_CONFIG['input_folder'], CASE_CONFIG['model_type_cdr'])
    folder_to_monitor_ipdr = os.path.join(PATH_CONFIG['input_folder'], CASE_CONFIG['model_type_ipdr'])
    directories_to_monitor = [folder_to_monitor_cdr, folder_to_monitor_ipdr]
    start_monitoring(directories_to_monitor)
