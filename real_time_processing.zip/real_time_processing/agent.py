import time
import mysql.connector
from config_loader import load_config
config =load_config()
DB_CONFIG = config['database']

def fetch_assigned_files(agent_id):
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    query = """
        SELECT * FROM files_meta_details
        WHERE locked_by = %s AND status = 'processing'
    """
    cursor.execute(query, (agent_id,))
    files = cursor.fetchall()
    cursor.close()
    conn.close()
    return files

def update_file_status(file_id, status):
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    query = """
        UPDATE files_meta_details
        SET status = %s, updated_at = NOW()
        WHERE id = %s
    """
    cursor.execute(query, (status, file_id))
    conn.commit()
    cursor.close()
    conn.close()

def update_agent_status(agent_id, status=None, increment_file_count=False):
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    if increment_file_count:
        query = """
            UPDATE agent_status
            SET file_processed_count = file_processed_count + 1, last_updated = NOW()
            WHERE agent_id = %s
        """
        cursor.execute(query, (agent_id,))
    elif status:
        query = """
            UPDATE agent_status
            SET status = %s, last_updated = NOW()
            WHERE agent_id = %s
        """
        cursor.execute(query, (status, agent_id))
    conn.commit()
    cursor.close()
    conn.close()

def process_file(file):
    print(f"Processing file: {file['ID']}")
    time.sleep(2)  # Simulate processing time
    return "completed"

def agent_function(agent_id):
    update_agent_status(agent_id, status="idle")
    while True:
        assigned_files = fetch_assigned_files(agent_id)
        if assigned_files:
            update_agent_status(agent_id, status="busy")
            for file in assigned_files:
                try:
                    status = process_file(file)
                    update_file_status(file["ID"], status)
                    update_agent_status(agent_id, increment_file_count=True)
                except Exception as e:
                    update_file_status(file["ID"], "error")
        else:
            update_agent_status(agent_id, status="idle")
        time.sleep(5)

if __name__ == "__main__":
    agent_id =  int(input("Enter agent ID: "))
    agent_function(agent_id)
