from json import load
import time
import mysql.connector
from mysql.connector import Error
from config_loader import load_config
config = load_config()
DB_CONFIG = config['database']

def fetch_new_files():
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)
    query = """
        SELECT * FROM files_meta_details
        WHERE status = 'new' and uploadStatus = 0
        ORDER BY priority DESC, created_at ASC
    """
    cursor.execute(query)
    files = cursor.fetchall()
    cursor.close()
    conn.close()
    return files

def fetch_idle_agent():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True, buffered=True)  

        query = """
            SELECT * FROM agent_status
            WHERE status = 'idle'
            ORDER BY last_updated ASC
        """
        cursor.execute(query)
        agent = cursor.fetchone()  
        return agent  
    except Error as e:
        print(f"Error fetching idle agent: {e}")
        return None  
    finally:
        cursor.close()
        conn.close()

def assign_file_to_agent(file_id, agent_id):
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    query = """
        UPDATE files_meta_details
        SET  status = 'assigned', assigned_to = %s, locked_by = %s, updated_at = NOW()
        WHERE ID = %s
    """
    cursor.execute(query, (agent_id,agent_id, file_id))
    conn.commit()
    

    query = """
        UPDATE agent_status
        SET status = 'busy', last_updated = NOW()
        WHERE agent_id = %s
    """
    cursor.execute(query, (agent_id,))
    conn.commit()
    cursor.close()
    conn.close()

def manager_function():
    while True:
        new_files = fetch_new_files()
        for file in new_files:
            idle_agent = fetch_idle_agent()
            if idle_agent:
                assign_file_to_agent(file["ID"], idle_agent["agent_id"])
                print(f"Assigned file {file['name']} to agent {idle_agent['agent_id']}")
            #else:
             #   print("No idle agent available. Retrying later.")
        
        time.sleep(5)

if __name__ == "__main__":
    manager_function()
