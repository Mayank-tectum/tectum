import redis
import traceback
import json
import polars as pl
# import pdb

json_file = open('redis.config','r').read()
database = json.loads(json_file) 

def redis_conn():
    try:
        client = redis.Redis(
                    host=database['REDIS_HOST'],
                    port=database['REDIS_PORT'],
                    password=database['REDIS_PASSWORD'],
                    decode_responses=True
                    )
        print("connected successfully.")
        return client
    except Exception :
        print(f"failed to establish redis connection:{traceback.print_exc()}")

def redis_insert(redis:str): 
    df = pl.scan_csv('filtered_output1.csv').unique(subset=['Destination IP Address'],keep='first').collect(streaming = True)
    rows = df.to_dicts()
    flat_dict = {f"row:{i}": json.dumps(row) for i, row in enumerate(rows)}
    redis.hmset("unique_destination_ip", flat_dict) 
    print("successfully inserted data.") 

def search_ip_in_redis(r, hash_key, ip_list):
    my_ip_set = set(ip_list)
    matching_rows = []
    cursor = 0

    # pdb.set_trace()
    while True:
        cursor, data = r.hscan(hash_key, cursor, count=1000)
        for key, value in data.items():
            # Convert Redis bytes to string 
            if isinstance(value, bytes):
                value = value.decode('utf-8')

            try:
                row = json.loads(value)
            except json.JSONDecodeError:
                continue

            # Extract the destination IP
            dest_ip = row.get('Destination IP Address')
            if dest_ip and dest_ip in my_ip_set:
                matching_rows.append(row)

        if cursor == 0:
            break

    return matching_rows

if __name__ == "__main__":

    client = redis_conn()
    print(client)
    # redis_insert(client)
    # ip_list = ["192.168.0.133", "192.168.0.146"]
    # matching_rows = search_ip_in_redis(client, "unique_destination_ip", ip_list)
    # print("Matching row keys:", matching_rows)