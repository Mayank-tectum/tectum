import pandas as pd

df = pd.read_csv("new_vpn_ip_with_ranges.csv", header=None)

df.columns = [
    "Vpn_Name",
    "Start_IP",
    "Subnet_Mask",
    "CIDR_Notation",
    "Start_Range",
    "End_Range",
]

duplicates = df[df.duplicated(subset="Start_IP", keep="first")]

for index, row in duplicates.iterrows():
    print(f"IP: {row['Start_IP']}, VPN Name: {row['Vpn_Name']}")

df = df.drop_duplicates(subset="Start_IP", keep="first")
df.to_csv("rem_duplicate.csv", index=False)
