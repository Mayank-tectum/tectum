import pandas as pd
from netaddr import IPSet,IPAddress
from mmdb_writer import MMDBWriter

output_mmdb_path = "vpn_data_netify.mmdb"
input_csv_path = "cleaned_vpn_ip_with_ranges.csv"  
data = pd.read_csv(input_csv_path)

writer = MMDBWriter(ip_version=6, ipv4_compatible=True)

ip_data = []
for index, row in data.iterrows():
    vpn_name = row["vpn_name"]
    start_ip = row["start_ip"]
    end_ip = row["end_ip"]

    try:
        # Create an IP range using the start and end IP
        network = f"{start_ip}-{end_ip}"

        # Convert the IP range to an IPSet
        # ip_set = IPSet(network)

        # Metadata to be stored
        metadata = {
            "hosting": "true",
            "network": f"{start_ip}-{end_ip}",
            "port": "",
            "proxy": "",
            "relay": "",
            "service": vpn_name,
            "tor": "", 
            "vpn": "true",
        }
        ip_address = IPAddress(start_ip)
        ip_data.append((ip_address, metadata))

        # Insert the network and metadata into the MMDB
        # writer.insert_network(ip_set, metadata)

    except Exception as e:
        print(f"Error processing row {index}: {e}")

for ip, metadata in ip_data:
        ip_set = IPSet([ip])
        writer.insert_network(ip_set, metadata)

# Write the data to the MMDB file
writer.to_db_file(output_mmdb_path)
print(f"MMDB file '{output_mmdb_path}' has been created successfully.")
