import pandas as pd

# Load the CSV file into a DataFrame
df = pd.read_csv('new_vpn_ip_with_ranges1.csv')

# Remove records where 'app_cidr' is NaN or empty
df = df[df['app_cidr'].notna() & (df['app_cidr'] != '')]

# Keep only the specified columns: 'ip_address', 'vpn_name', 'start_ip', 'end_ip'
df = df[['ip_address', 'vpn_name', 'start_ip', 'end_ip']]

# Save the cleaned DataFrame to a new CSV file
df.to_csv('cleaned_vpn_ip_with_ranges1.csv', index=False)

print("Records with missing 'app_cidr' have been removed and only specified columns are kept.")