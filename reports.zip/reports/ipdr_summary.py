# IPDR SUMMARY
# Author: Sresht
# Date: 30th Oct 2023

# Import necessary libraries/modules at the beginning of your script.
import logging
import pandas as pd
import numpy as np
import sys
import os
import datetime
import pysolr
import time
import json,base64,requests



class CustomAuth(requests.auth.AuthBase):
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def __call__(self, r):
        # Add your custom authentication logic here
        auth_string = f'{self.username}:{self.password}'.encode('utf-8')
        auth_bytes = base64.b64encode(auth_string)
        auth_header = f'Basic {auth_bytes.decode("utf-8")}'
        r.headers['Authorization'] = auth_header
        return r

def fetch_pysolr_data(core_name, param_dict, filter, add_solr_query, fl=None, ext_param_dict=None):
    query = []
    if 'case_id' in param_dict:
        if param_dict['case_id']:
            query.append(f"case_id:{param_dict['case_id']}")
    if 'phone_no' in param_dict:
        if param_dict['phone_no']:    
            query.append(f"phone_no:{param_dict['phone_no']}")
    if 'imei' in param_dict:
        if param_dict['imei']:
            query.append(f"imei_no:{param_dict['imei']}")
    if 'imsi' in param_dict:
        if param_dict['imsi']:
            query.append(f"imsi_no:{param_dict['imsi']}")
    if 'start_date_time' in param_dict:
        if param_dict['start_date_time'] and 'end_date_time' in param_dict:
            query.append(f"start_date_time:[{param_dict['start_date_time']} TO {param_dict['end_date_time']}]")
    # if 'end_date_time' in param_dict:
    #     if param_dict['end_date_time']:
    #         query.append(f"start_date_time:[* TO {param_dict['end_date_time']}]")
    if 'sourceIp' in param_dict:
        if param_dict['sourceIp']:
            if param_dict['sourceIp'] != 'all':
                query.append(" OR ".join(f'source_ip_address:"{ip}"' for ip in param_dict['sourceIp'].split(',')))
            else:
                query.append(f"source_ip_address:*")
    if 'publicIp' in param_dict:
        if param_dict['publicIp']:
            if param_dict['publicIp'] != 'all':
                query.append(" OR ".join(f'public_ip_address:"{ip}"' for ip in param_dict['publicIp'].split(',')))
            else:
                query.append(f"public_ip_address:*")
    if 'destination_ip_address' in param_dict:
        if param_dict['destination_ip_address']:
            if param_dict['destination_ip_address'] != 'all':
                query.append(" OR ".join(f'destination_ip_address:"{ip}"' for ip in param_dict['destination_ip_address'].split(',')))
            else:
                query.append(f"destination_ip_address:*")
    if ext_param_dict:
        query.append(ext_param_dict)
    query.extend(filter)
    solr_query = {
        'q': '*:*'
    }
    if fl:
        solr_query.update({'fl': fl})

    if query:
        solr_query.update({'fq': query})

    if add_solr_query:
        solr_query.update(add_solr_query)
    # print(solr_query)
    # solr_query.update({'rows': 100000})
    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    auth = CustomAuth(database['SOLR_USERNAME'], database['SOLR_PASSWORD'])
    solr = pysolr.Solr(f"{database['solr_server']}:{database['solr_port']}/solr/{core_name}",auth=auth)
    response_object = solr.search(**solr_query)
    return response_object

def voip(d):
    count = 0
    core_name = 'ipdr_details'
    voip_data_count = fetch_pysolr_data(core_name, d,['b_party_table_status:yes AND -is_tor_detected:yes AND -service_provider_detail:UNKNOWN AND -service_provider_detail:unknown'], {
        'rows': 10
    })
    count = voip_data_count.hits
    return count

def domain(d):
    count = 0
    core_name = 'ipdr_details'
    response_json = fetch_pysolr_data(core_name, d, ['hosted_domain_name:*'], {
        'rows': 10
    })
    count = response_json.hits
    return count

# def apk_ipa(d):
#     count = 0
#     top_5_apps = []
#     core_name = 'ipdr_details'
#     response_json = fetch_pysolr_data(core_name, d, ['app_name:*'], {'rows': 1})
#     apk_ipa_data = fetch_pysolr_data(core_name, d, ['app_name:*'], {'rows': response_json.hits})

#     apk_ipa_df = solr_to_df(apk_ipa_data)
#     if 'app_name' in apk_ipa_df.columns:
#         top_apk_ipa = apk_ipa_df['app_name'].value_counts()
#         top_5_apps = top_apk_ipa[:5].reset_index()
#         top_5_apps.columns = ['Value', 'Count']
#         top_5_apps = top_5_apps['Value'].tolist()
#         apk_ipa_df = apk_ipa_df.drop_duplicates(subset=['app_name'])
#         count = len(apk_ipa_df)
#     return count, top_5_apps

def apk_ipa(d, chunk_size=1000):
    count = 0
    top_5_apps = []
    core_name = 'ipdr_details'
    params = {'rows': chunk_size}  # Set the chunk size for each request
    start = 0  # Initialize the start index

    while True:
        # Fetch data in chunks
        apk_ipa_data = fetch_pysolr_data(core_name, d, ['app_name:*'], params)
        apk_ipa_df = solr_to_df(apk_ipa_data)

        if 'app_name' in apk_ipa_df.columns:
            top_apk_ipa = apk_ipa_df['app_name'].value_counts()
            top_5_apps.extend(top_apk_ipa[:5].index.tolist())
            count += len(apk_ipa_df.drop_duplicates(subset=['app_name']))

        # Increment the start index for the next chunk
        start += chunk_size
        params['start'] = start

        # Break the loop if all data has been fetched
        if start >= count:
            break
    return count, top_5_apps



# def vpn(d):
#     count = 0
#     core_name = 'ipdr_details'
#     response_json = fetch_pysolr_data(core_name, d, ['vpn_name:*'], {
#         'rows': 1
#     },"",', (((is_vpn:true or vpn_tor:true) , -destination_port:(90 OR 91 OR 92 OR 93 OR 94 OR 95 OR 96 OR 97 OR 98 OR 99 OR 443 OR 500 OR 4500 OR 6881 OR 6882 OR 6883 OR 600 OR 4600 OR 1390 OR 3390 OR 1723 OR 1194 OR 1701 OR 51820 OR 53133) ) OR (-destination_port(90 OR 91 OR 92 OR 93 OR 94 OR 95 OR 96 OR 97 OR 98 OR 99 OR 500 OR 4500 OR 6881 OR 6882 OR 6883 OR 600 OR 4600 OR 1390 OR 3390 OR 1723 OR 1194 OR 1701 OR 51820 OR 53133) , ip_country:India)) , -ip_country:India')

#     vpn_data = fetch_pysolr_data(core_name, d, ['vpn_name:*'], {
#         'rows': response_json.hits
#     },"",', (((is_vpn:true or vpn_tor:true) , -destination_port:(90 OR 91 OR 92 OR 93 OR 94 OR 95 OR 96 OR 97 OR 98 OR 99 OR 443 OR 500 OR 4500 OR 6881 OR 6882 OR 6883 OR 600 OR 4600 OR 1390 OR 3390 OR 1723 OR 1194 OR 1701 OR 51820 OR 53133) ) OR (-destination_port(90 OR 91 OR 92 OR 93 OR 94 OR 95 OR 96 OR 97 OR 98 OR 99 OR 500 OR 4500 OR 6881 OR 6882 OR 6883 OR 600 OR 4600 OR 1390 OR 3390 OR 1723 OR 1194 OR 1701 OR 51820 OR 53133) , ip_country:India)) , -ip_country:India')
#     vpn_df = solr_to_df(vpn_data)
#     vpn_df = vpn_df.drop_duplicates(subset=['vpn_name'])
#     count = len(vpn_df)
#     return count
def vpn(d, chunk_size=1000):
    count = 0
    core_name = 'ipdr_details'
    start = 0
    vpn_data = []
    
    while True:
        # Fetch data in chunks
        chunk_data = fetch_pysolr_data(core_name, d, ['vpn_name:*'], {
            'rows': chunk_size,
            'start': start
        },"",', (((is_vpn:true or vpn_tor:true) , -destination_port:(90 OR 91 OR 92 OR 93 OR 94 OR 95 OR 96 OR 97 OR 98 OR 99 OR 443 OR 500 OR 4500 OR 6881 OR 6882 OR 6883 OR 600 OR 4600 OR 1390 OR 3390 OR 1723 OR 1194 OR 1701 OR 51820 OR 53133) ) OR (-destination_port(90 OR 91 OR 92 OR 93 OR 94 OR 95 OR 96 OR 97 OR 98 OR 99 OR 500 OR 4500 OR 6881 OR 6882 OR 6883 OR 600 OR 4600 OR 1390 OR 3390 OR 1723 OR 1194 OR 1701 OR 51820 OR 53133) , ip_country:INDIA)) , -ip_country:INDIA')
        
        # Append chunk data to the result list
        vpn_data.extend(chunk_data)
        
        # Update start index for the next chunk
        start += chunk_size
        
        # Break the loop if all data has been fetched
        if len(chunk_data) < chunk_size:
            break

    # Convert the result to a DataFrame
    vpn_df = solr_to_df(vpn_data)
    
    # Drop duplicate rows based on 'vpn_name' column
    vpn_df = vpn_df.drop_duplicates(subset=['vpn_name'])
    
    # Get the count of unique VPNs
    count = len(vpn_df)
    return count


def imei(d):
    # count = 0
    # core_name = 'ipdr_details'
    # imei_data = fetch_pysolr_data(core_name, d, ['imei_no:* AND -imei_no:0'], {'rows':100000000})
    # imei_df = solr_to_df(imei_data)
    # imei_df = imei_df.drop_duplicates(subset=['imei_no'])
    # count = len(imei_df)
    # return count
    count = 0
    core_name = 'ipdr_details'
    response_json = fetch_pysolr_data(core_name, d, ['imei_no:* AND -imei_no:0'], {
        'rows': 10
    })
    count = response_json.hits
    return count

def country(d):
    count = 0
    country_list = []
    country_data =  fetch_pysolr_data('ipdr_details', d, ['ip_country:* AND -ip_country:unknown AND -ip_country:UNKNOWN'], {
        'group': 'true',
        'group.field': 'ip_country',
        'group.limit': 1
    })
    if country_data.grouped['ip_country']['groups']:
        country_list = [item['groupValue'] for item in country_data.grouped['ip_country']['groups']]
        count = len(country_list)
    relevant = ['Pakistan', 'China', 'Afganistan', 'Bangladesh', 'Sri Lanka']
    for country in relevant:
        if country in country_list:
            country_list.remove(country)
            country_list = [country] + country_list
    return count, country_list

def solr_to_df(solr_response):
    docs = [doc for doc in solr_response]
    df = pd.DataFrame(docs)
    return df

def stats(counts):
    data = {}
    data['TOTAL B-PARTY CALLS'] = counts['voip_count'] if 'voip_count' in counts else 0
    data['TOTAL APPLICATIONS'] = counts['app_count'] if 'app_count' in counts else 0
    data['TOTAL DOMAINS'] = counts['domain_count'] if 'domain_count' in counts else 0
    data['TOTAL VPN'] = counts['vpn_count'] if 'vpn_count' in counts else 0
    data['TOTAL COUNTRIES'] = counts['country_count'] if 'country_count' in counts else 0
    data['TOTAL DEVICES'] = counts['imei_count'] if 'imei_count' in counts else 0
    return data

def recent(d):
    res_imei = ''
    res_imsi = ''
    res_cell_id = ''
    res_activity = ''
    recent_imei = fetch_pysolr_data('ipdr_details', d, ['imei_no:* AND -imei_no:0'], {
        'sort': 'start_date_time desc',
        'rows': 1
    })
    recent_imsi = fetch_pysolr_data('ipdr_details', d, ['imsi_no:* AND -imsi_no:0'], {
        'sort': 'start_date_time desc',
        'rows': 1
    })
    recent_cell_id = fetch_pysolr_data('ipdr_details', d, ['cell_id:* AND -cell_id:0'], {
        'sort': 'start_date_time desc',
        'rows': 1
    })
    recent_activity = fetch_pysolr_data('ipdr_details', d, ['b_party_table_status:yes AND -is_tor_detected:yes AND -service_provider_detail:UNKNOWN AND -service_provider_detail:unknown'], {
        'sort': 'start_date_time desc',
        'rows': 1
    })
    if recent_imei:
        if recent_imei.docs[0]['imei_no']:
            res_imei = f"recent imei was <span id='summary_main'>{recent_imei.docs[0]['imei_no']}</span>, "
    if recent_imsi:
        if recent_imsi.docs[0]['imsi_no']:
            res_imsi = f"recent imsi was <span id='summary_main'>{recent_imsi.docs[0]['imsi_no']}</span>, "
    if recent_cell_id:
        if recent_cell_id.docs[0]['cell_id']:
            res_cell_id = f"recent cell-id was <span id='summary_main'>{recent_cell_id.docs[0]['cell_id']}</span>. "
    if recent_activity:
        recent_activity = recent_activity.docs[0]
        if recent_activity['phone_no'] and recent_activity['destination_ip_address'] and recent_activity['start_date_time']:
            res_activity = f"Target <span id='summary_main'>{recent_activity['phone_no']}</span> has made last call to <span id='summary_main'>{recent_activity['destination_ip_address']}</span> bparty IP on <span id='summary_main'>{datetime.datetime.fromtimestamp(recent_activity['start_date_time']).strftime('%Y-%m-%d %H:%M:%S')}</span>. "
    if res_imei or res_imsi or res_cell_id:
        return "Target's " + res_imei + res_imsi + res_cell_id, res_activity
    else:
        return "", res_activity


def info(d, data, country_list, top_5_apps, recent_imei_imsi_cell_id, recent_activity):
    def report_summary_builder(d, data, country_list, recent_imei_imsi_cell_id, recent_activity):
        dd_list = []
        if d['phone_no']:
            dd_list.append("Target with mobile number <span id='summary_main'>{0}</span> is :-".format(d['phone_no']))
        if data['TOTAL DEVICES']:
            dd_list.append("Using <span id='summary_main'>{0}</span> phone(s) for connection(s)".format(data['TOTAL DEVICES']))
        elif (('imei' in d) and d['imei']):
            dd_list.append("Using IMEI as <span id='summary_main'>{0}</span>".format(d['imei']))
        elif (('imsi' in d) and d['imsi']):
            dd_list.append("Using IMSI <span id='summary_main'>{0}</span>".format(d['imsi']))
        elif (('publicIp' in d) and d['publicIp']):
            dd_list.append("Using public IPs <span id='summary_main'>{0}</span>".format(d['publicIp']))
        elif (('sourceIp' in d) and d['sourceIp']):
            dd_list.append("Using source IPs <span id='summary_main'>{0}</span>".format(d['sourceIp']))
        elif (('destinationIp' in d) and d['destinationIp']):
            dd_list.append("Using destination IPs <span id='summary_main'>{0}</span>".format(d['destinationIp']))

        if data['TOTAL VPN']:
            dd_list.append("Using <span id='summary_main'>{0}</span> VPN Applications for connections".format(data['TOTAL VPN']))
        platform_names = []#[item for item in platform_names if 'unk' not in item]
        if platform_names:
            dd_list.append("Using platforms <span id='summary_main'>{0}</span> for making calls".format(data['TOTAL VPN']))
        # add None validation by VJ    
        countries = [item for item in country_list if item is not None and 'unk' not in item]
        if countries:
            dd_list.append("Calls is connected to various countries including <span id='summary_main'>{0}</span>".format(", ".join(countries[:5])))
        if data['TOTAL APPLICATIONS']:
            dd_list.append("Using <span id='summary_main'>{0}</span> mobile applications including applications like <span id='summary_main'>{1}</span>".format(data['TOTAL APPLICATIONS'], ', '.join(top_5_apps).replace('[', '').replace(']', '')))
        if recent_imei_imsi_cell_id:
            dd_list.append(recent_imei_imsi_cell_id)
        if recent_activity:
            dd_list.append(recent_activity)
        return dd_list

    if d['start_date_time']!=0 and d['end_date_time']!=0:
        start_date_time  = datetime.datetime.utcfromtimestamp(int(d['start_date_time']))
        # add some offsets in seconds 
        start_date_time = start_date_time + datetime.timedelta(seconds=19800)
        start_date_time = start_date_time.strftime("%d-%m-%Y %H:%M:%S %p")
        
        end_date_time = datetime.datetime.utcfromtimestamp(int(d['end_date_time']))
        # add some offsets in seconds 
        end_date_time = end_date_time + datetime.timedelta(seconds=19800)
        end_date_time = end_date_time.strftime("%d-%m-%Y %H:%M:%S %p")
        d['start_date_time'] = start_date_time
        d['end_date_time'] = end_date_time
    else:
        start_date_time = "-"
        end_date_time = "-"
        d['start_date_time'] = start_date_time
        d['end_date_time'] = end_date_time

    rs_list = report_summary_builder(d, data, country_list, recent_imei_imsi_cell_id, recent_activity)
    
    # d['summary'] = ' '.join(rs_list)
    # df = pd.DataFrame([d])
    # print(df)
    for line in rs_list:
        print(line)
    return rs_list
        

# Define functions or classes (if applicable) to encapsulate your code logically.
def main_function(script_name, case_id, mobile_number, start_date_time, end_date_time, log_dir_path):
    # Your code for the main functionality of the script goes here.
    # Check if the file exists
    # Configure the logging settings
    logging.basicConfig(filename=os.path.join(log_dir_path, f"{script_name.split('.')[0]}.log"), level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    d = {
        "case_id": case_id,
        "phone_no": mobile_number,
        "start_date_time": int(start_date_time),
        "end_date_time": int(end_date_time)
    }
    # curr_time = time.time()
    voip_count = voip(d)
    # curr_time1 = time.time()
    # print("voip time --")
    # print(curr_time1 - curr_time)
    
    domain_count = domain(d)
    # curr_time2 = time.time()
    # print("domain time --")
    # print(curr_time2 - curr_time1)
    
    app_count, top_5_apps = apk_ipa(d)
    # curr_time3 = time.time()
    # print("apk_ipa time --")
    # print(curr_time3 - curr_time2)

    vpn_count = vpn(d)
    # curr_time4 = time.time()
    # print("vpn time --")
    # print(curr_time4 - curr_time3)

    imei_count = imei(d)
    # curr_time5 = time.time()
    # print("imei time --")
    # print(curr_time5 - curr_time4)

    country_count, country_list = country(d)
    # curr_time6 = time.time()
    # print("country time --")
    # print(curr_time6 - curr_time5)


    counts = {'voip_count': voip_count, 'domain_count': domain_count, 'app_count': app_count, 'vpn_count': vpn_count, 'imei_count': imei_count, 'country_count': country_count}
    data = stats(counts)
    recent_imei_imsi_cell_id, recent_activity = recent(d)
    summary=info(d, data, country_list, top_5_apps, recent_imei_imsi_cell_id, recent_activity)
    logging.info(f"Execution complete for {mobile_number}")
    return summary
   

# Check if the script is the main program being run (not imported as a module).
if __name__ == "__main__":
    # Take values from the arguments
    args = sys.argv
    # Validate the arguments
    if len(args) >= 6:
        # Get the excel path from the arguments
        case_id = args[1]
        mobile_number = args[2]
        start_date_time = args[3]
        end_date_time = args[4]
        log_dir_path = args[5]
        # Call the main function to execute the script's primary logic.
        main_function(args[0], case_id, mobile_number, start_date_time, end_date_time, log_dir_path)
    else:
        # Console the sample command
        print("Sample command :-")
        print(f"{args[0]} <case-id> <mobile-number> <start-date-time-int> <end-date-time-int> <log-dir-path>")