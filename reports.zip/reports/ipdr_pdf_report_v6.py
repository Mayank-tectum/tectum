import warnings

import clickhouse_connect
warnings.filterwarnings('ignore')
from ctypes import alignment
from matplotlib.pyplot import pie
from reportlab.platypus import SimpleDocTemplate, Image, Table, TableStyle
from reportlab.rl_config import defaultPageSize
from reportlab.lib.colors import Color, HexColor, transparent, white
from reportlab.lib.units import inch, cm
from reportlab.platypus import SimpleDocTemplate, Image, PageBreak
from reportlab.lib import colors
from reportlab.platypus import *
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.platypus import SimpleDocTemplate, Image, Table, TableStyle
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import HorizontalBarChart, VerticalBarChart
import os, sys, datetime
# import pyodbc
import textwrap
import pandas as pd
import hashlib,json
import numpy as np
import random
import pysolr
import MySQLdb, requests,base64
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import LETTER
import re
import logging

import ipdr_summary

current_directory = os.getcwd()
save_directory = os.path.join(current_directory, 'public', 'reports')


class CustomAuth(requests.auth.AuthBase):
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def __call__(self, r):
        # Add your custom authentication logic here
        auth_string = f'{self.username}:{self.password}'.encode('utf-8')
        auth_bytes = base64.b64encode(auth_string)
        auth_header = f'Basic {auth_bytes.decode("utf-8")}'
        r.headers['Authorization'] = auth_header
        return r
    

json_file= open('database.config','r').read()
database = json.loads(json_file)

client = clickhouse_connect.get_client(
        host=database['click_house_node1'],
        port=database['click_house_port'],
        user=database['click_house_username'],
        password=database['click_house_password'],
        database=database['click_house_database'],
    )
  

def ipdr_conn():
    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    return MySQLdb.connect(
        host=database['database_url'],
        port=database['database_port'],  # Replace with your desired port number
        user=database['database_user'],
        password=database['database_password'],
        database=database['database_name']        
    )
    # return pyodbc.connect(
    #     'Driver='+database['database_driver']+';'
    #     'Server='+database['database_url']+';'
    #     'Database='+database['database_name']+';'
    #     'UID='+database['database_user']+';'
    #     'PWD='+database['database_password']+';'
    #     'TrustServerCertificate=yes;'
    #     )

def fetch_clickhouse_data(table_name, param_dict, filter_conditions, extra_query=None, fields=None, limit=None):
    print('table_name:',table_name)
    query_conditions = []
    if 'case_id' in param_dict and param_dict['case_id']:
        query_conditions.append(f"case_id = '{param_dict['case_id']}'")

    if 'phone_no' in param_dict and param_dict['phone_no']: 
        phone_numbers = ','.join(f"'{phone}'" for phone in str(param_dict['phone_no']).split(','))
        query_conditions.append(f"phone_no IN ({phone_numbers})")

    if 'imei' in param_dict and param_dict['imei']:
        imeis = ','.join(f"'{imei}'" for imei in param_dict['imei'].split(','))
        query_conditions.append(f"imei_no IN ({imeis})")

    if 'imsi' in param_dict and param_dict['imsi']:
        imsis = ','.join(f"'{imsi}'" for imsi in param_dict['imsi'].split(','))
        query_conditions.append(f"imsi_no IN ({imsis})")

    if 'start_date_time' in param_dict and param_dict['start_date_time']:
        query_conditions.append(f"start_date_time >= '{param_dict['start_date_time']}'")

    if 'end_date_time' in param_dict and param_dict['end_date_time']:
        query_conditions.append(f"end_date_time <= '{param_dict['end_date_time']}'")

    if 'sourceIp' in param_dict and param_dict['sourceIp']:
        if param_dict['sourceIp'] != 'all':
            ips = ','.join(f"'{ip}'" for ip in param_dict['sourceIp'].split(','))
            query_conditions.append(f"source_ip_address IN ({ips})")
        else:
            query_conditions.append("source_ip_address IS NOT NULL")

    if 'publicIp' in param_dict and param_dict['publicIp']:
        if param_dict['publicIp'] != 'all':
            ips = ','.join(f"'{ip}'" for ip in param_dict['publicIp'].split(','))
            query_conditions.append(f"public_ip_address IN ({ips})")
        else:
            query_conditions.append("public_ip_address IS NOT NULL")

    if 'destination_ip_address' in param_dict and param_dict['destination_ip_address']:
        if param_dict['destination_ip_address'] != 'all':
            ips = ','.join(f"'{ip}'" for ip in param_dict['destination_ip_address'].split(','))
            query_conditions.append(f"destination_ip_address IN ({ips})")
        else:
            query_conditions.append("destination_ip_address IS NOT NULL")

    if 'cell_id' in param_dict and param_dict['cell_id']:
        cell_ids = ','.join(f"'{cell_id}'" for cell_id in param_dict['cell_id'].split(','))
        query_conditions.append(f"cell_id IN ({cell_ids})")

    if filter_conditions:
        query_conditions.append(f"({' AND '.join(filter_conditions)})")

    select_clause = ", ".join(fields) if fields else "*"
    where_clause = " AND ".join(query_conditions) if query_conditions else "1"

    sql_query = f"SELECT {select_clause} FROM {table_name} WHERE {where_clause}"
    if extra_query:
        sql_query += f" {extra_query}"
    if limit:
        sql_query += f"LIMIT {limit}"
    print("sql_query:",sql_query)
        

    result = client.query(sql_query)
    data = [dict(zip(result.column_names, row)) for row in result.result_rows]    
    print("data:",data)

    return data

# def fetch_pysolr_data(core_name, param_dict, filter, add_solr_query, fl=None, ext_param_dict=None,rows=None,raw_query = None):
#     query = []
#     if 'case_id' in param_dict:
#         if param_dict['case_id']:
#             query.append(f"case_id:{param_dict['case_id']}")
#     if 'phone_no' in param_dict:
#         if param_dict['phone_no']:    
#             query.append(" OR ".join(f'phone_no:"{phone_no}"' for phone_no in str(param_dict['phone_no']).split(',')))
#     if 'imei' in param_dict:
#         if param_dict['imei']:
#             query.append(" OR ".join(f'imei_no:"{imei}"' for imei in param_dict['imei'].split(',')))
#     if 'imsi' in param_dict:
#         if param_dict['imsi']:
#             query.append(" OR ".join(f'imsi_no:"{imsi}"' for imsi in param_dict['imsi'].split(',')))
#     if 'start_date_time' in param_dict:
#         if param_dict['start_date_time']:
#             query.append(f"start_date_time:[{param_dict['start_date_time']} TO *]")
#     if 'end_date_time' in param_dict:
#         if param_dict['end_date_time']:
#             query.append(f"start_date_time:[* TO {param_dict['end_date_time']}]")
#     if 'sourceIp' in param_dict:
#         if param_dict['sourceIp']:
#             if param_dict['sourceIp'] != 'all':
#                 # query.append(f"source_ip_address:({' OR '.join(param_dict['sourceIp'].split(','))})")
#                 query.append(" OR ".join(f'source_ip_address:"{ip}"' for ip in param_dict['sourceIp'].split(',')))
#             else:
#                 query.append(f"source_ip_address:*")
#     if 'publicIp' in param_dict:
#         if param_dict['publicIp']:
#             if param_dict['publicIp'] != 'all':
#                 # query.append(f"public_ip_address:({' OR '.join(param_dict['publicIp'].split(','))})")
#                 query.append(" OR ".join(f'public_ip_address:"{ip}"' for ip in param_dict['publicIp'].split(',')))
#             else:
#                 query.append(f"public_ip_address:*")
#     if 'destination_ip_address' in param_dict:
#         if param_dict['destination_ip_address']:
#             if param_dict['destination_ip_address'] != 'all':
#                 # query.append(f"destination_ip_address:({' OR '.join(param_dict['destination_ip_address'].split(','))})")
#                 query.append(" OR ".join(f'destination_ip_address:"{ip}"' for ip in param_dict['destination_ip_address'].split(',')))
#             else:
#                 query.append(f"destination_ip_address:*")
#     if 'cell_id' in param_dict:
#         if param_dict['cell_id']:
#             query.append(" OR ".join(f'cell_id:"{cell_id}"' for cell_id in param_dict['cell_id'].split(',')))

#     if ext_param_dict:
#         query.append(ext_param_dict)
#     query.extend(filter)
#     solr_query = {
#         'q': '*:*'
#     }
#     if fl:
#         solr_query.update({'fl': fl})
#     if query:
#         solr_query.update({'fq': query})

#     if add_solr_query:
#         solr_query.update(add_solr_query)
#     if rows:
#         solr_query.update({'rows': rows})
#     else:
#         solr_query.update({'rows': 100000})
    
#     # print(solr_query)
#     # print("+++++++++++++++++++++++++++++++++++++")
#     json_file= open('database.config','r').read()
#     database = json.loads(json_file)
#     auth = CustomAuth(database['SOLR_USERNAME'], database['SOLR_PASSWORD'])
#     solr = pysolr.Solr(f"{database['solr_server']}:{database['solr_port']}/solr/{core_name}",auth=auth)
#     response_object = solr.search(**solr_query)
#     # for result in response_object:
#     #     print(result)
#     #     break
#     #     print("#####################")
#     return response_object


def update_progress(report_id,status,file_name):
    conn  = ipdr_conn()
    cursor = conn.cursor()
    update_report_query = f"UPDATE reports SET status={status}, report_name='{file_name}' where report_id={report_id}"
    cursor.execute(update_report_query)
    conn.commit()
    conn.close()


def reports_mssql_table(report_id):
    res = {}
    conn = ipdr_conn()
    sql = f"SELECT case_id,phone_no,start_date_time,end_date_time,status,imei,imsi,publicIp,sourceIp,destination_ip_address,cell_id FROM reports where report_id={report_id};"# AND report_type=0 AND status IN (0, 1, 3);"
    df_reports = pd.read_sql(sql, conn)
    if len(df_reports)>0:
        res = df_reports.to_dict('records')[0]
    return res


def first_page():
    now = datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    d = str(now)
    PAGE_HEIGHT=defaultPageSize[1]
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='Right', alignment=TA_RIGHT))
    s = Spacer(1, 12)
    p = PageBreak() 
    logo = Image(os.path.join(os.getcwd(), 'report_files','blue1.png'), width=21*cm, height=6*cm)
    Version = Paragraph("<font size=16 >Version 5.6</font>", styles["Right"])
    Date = Paragraph(d, styles["Right"])
    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    Title = Paragraph(f"<font color='#295cad' size=100 >{database['ipdr_report_name']}</font>", styles["Right"])
    s = Spacer(1, 13)
    Line1 = Paragraph(f"<font size=30>{database['ipdr_report_tagline']}</font>", styles["Right"])
    first_story = [logo, Version, s, Date, s, s, s, s, s, s, s, s, s, s, s, s, Title, s, s, s, s, s, s, s, s, Line1, s, p]
    return first_story 

def stats(counts, d,phone_no):
    data = {}
    data['TOTAL B-PARTY CALLS'] = counts['voip_count'] if 'voip_count' in counts else 0
    data['TOTAL APPLICATIONS'] = counts['app_count'] if 'app_count' in counts else 0
    data['TOTAL DOMAINS'] = counts['domain_count'] if 'domain_count' in counts else 0
    data['TOTAL VPN'] = counts['vpn_count'] if 'vpn_count' in counts else 0
    data['TOTAL COUNTRIES'] = counts['country_count'] if 'country_count' in counts else 0
    data['TOTAL DEVICES'] = counts['imei_count'] if 'imei_count' in counts else 0
    #data['TOTAL APK/IPA'] = d['app_count']
    data_res = data.copy()
    data2 = {key:data[key] for key in data if data[key] != 0}
    third_story = []
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='th1', alignment=TA_CENTER))
    styles.add(ParagraphStyle(name='th2', alignment=TA_LEFT))
    styles.add(ParagraphStyle(name='Line1', alignment=TA_CENTER, fontSize=20, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line2', alignment=TA_CENTER, fontSize=12, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line3', alignment=TA_CENTER, fontSize=9, textColor= HexColor('#333333')))
    #story.append(s)
    styles.add(ParagraphStyle(name='Right', alignment=TA_RIGHT))
    s = Spacer(1, 12)
    s = Spacer(1, 12)
    def bar_graph_ipdr(columns, values):
        drawing = Drawing(400, 200)
        clist = ['#cb277e','#7ecb27','#27cb74','#7427cb','#e33826','#f47b20','#fcc111','#f9ee4b','#2e9646','#01562f','#1c78be','#1d3863','#7a4fa0']

        data = [
            values,
            ]

        names = columns


        bc = VerticalBarChart()
        bc.x = 0
        bc.y = 50
        bc.height = 200
        bc.width = 400
        bc.data = data
        #bc.bars[0].fillColor = HexColor('#295cad')
        for i in range(len(columns)):
            bc.bars[(0, i)].fillColor = HexColor(random.choice(clist))
        bc.strokeColor = colors.black
        bc.valueAxis.valueMin = 0
        bc.valueAxis.valueMax = float(max(values)) + (float(max(values)) * 0.1)
        bc.valueAxis.valueStep = float(max(values)/10)
        bc.categoryAxis.labels.boxAnchor = 'ne'
        bc.categoryAxis.labels.dx = 8
        bc.categoryAxis.labels.fontName = 'Helvetica'
        bc.categoryAxis.labels.dy = -2
        bc.categoryAxis.labels.angle = 30
        bc.categoryAxis.categoryNames = names
        bc.barLabels.fontName = "Helvetica"
        bc.barLabels.fontSize = 5
        bc.barLabels.fillColor = HexColor('#000000')
        bc.barLabelFormat = '%d'
        bc.barLabels.nudge = 15
        bc.categoryAxis.labels.fontSize = 5
        bc.valueAxis.labels.fontSize    = 5
        drawing.add(bc)
        return drawing
    
    if data2:
        columns, values = list(data2.keys()), list(data2.values())
        bar0 = bar_graph_ipdr(columns, values)
        bar0.hAlign = 'CENTER'
        table0 = [[Paragraph(f"<font color=white><b>IPDR SUMMARY (Vertical Bar Chart) ({phone_no})</b></font>", styles["th1"]),''],
            [bar0,'']]
        t0 = Table(table0, [3.7*inch]*2, (0.7*cm,11*cm))
        t0.setStyle(
            TableStyle(
                [
                    ('SPAN',(0,0),(1,0)),
                    ('SPAN',(0,1),(1,1)),
                    ('BACKGROUND', (0, 0), (1, 0), HexColor('#295cad')),
                    ('TEXTCOLOR',(0,0),(1,0), colors.white),
                    ('BOX', (0,0), (1,1), 0.15, HexColor('#295cad')),
                    ('ALIGN',(0,0),(1,0),'CENTER'),
                    ('ALIGN',(0,1),(1,1),'CENTER'),
                ]
            )
        )
        third_story.extend([s,t0])

        table2=[
            [Paragraph(f"<font color=white><b>IPDR SUMMARY (Table) ({phone_no})</b></font>", styles["th1"]), ''],
        ]
        for k in data_res:
            table2.append([k, data_res[k]])   
        t1 = Table(table2, colWidths=[3.8*inch,3.8*inch])
        t1.setStyle(TableStyle([('SPAN',(0,0),(1,0)),
                                ('BACKGROUND', (0,0),(1,0), HexColor('#295cad')),
                                #('TEXTCOLOR',(0,1),(3,0), colors.white),
                                ('BACKGROUND', (0, 1), (1, 1), HexColor('#e1e1e1')),
                                ('BACKGROUND', (0, 3), (1, 3), HexColor('#e1e1e1')),
                                ('BACKGROUND', (0, 5), (1, 5), HexColor('#e1e1e1')),
                                ('BOX', (0,0), (1,(len(table2)-1)), 0.15, HexColor('#ababab')),
                                ('ALIGN',(0,0),(1,(len(table2)-1)),'LEFT'),
                                ]))
        third_story.extend([s,s,s,s,s, t1, s, PageBreak()])
    return data, third_story

def create_table(title, columns, column_widths, data, note_status=True):
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='th1', alignment=TA_CENTER))
    styles.add(ParagraphStyle(name='th2', alignment=TA_LEFT))
    styles.add(ParagraphStyle(name='Line1', alignment=TA_CENTER, fontSize=20, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line2', alignment=TA_CENTER, fontSize=12, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line3', alignment=TA_CENTER, fontSize=9, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='tt', alignment=TA_CENTER, fontSize=6))
    styles.add(ParagraphStyle(name='note', alignment=TA_RIGHT, fontSize=7, textColor=HexColor('#7F7F7F')))
    styles.add(ParagraphStyle(name='Right', alignment=TA_RIGHT))
    # note = Paragraph("(Note -Top 1000 rows displayed. For viewing more rows please create a CSV report.)" if note_status else '', style=styles["note"])
    s = Spacer(1, 12)

    rows = [
        [Paragraph(f"<font color=white><b>{title}</b></font>", styles["th1"])] + ['' for i in range(len(columns)-1)],
        [Paragraph(column, styles['tt']) for column in columns]
    ]
    if data:
        for row in data:
            new_row = [Paragraph(str(value), styles['tt']) for value in row]
            rows.append(new_row)
            
        t = Table(rows, colWidths=[width*cm for width in column_widths])
        t.setStyle(TableStyle([('SPAN',(0,0),(-1,0)),
                                ('BACKGROUND', (0,0),(8,0), HexColor('#295cad')),
                                #('TEXTCOLOR',(0,1),(3,0), colors.white),
                                ('BACKGROUND', (0, 1), (8, 1), HexColor('#e1e1e1')),
                                # ('BACKGROUND', (0, 5), (1, 5), HexColor('#e1e1e1')),
                                ('INNERGRID', (0,0), (-1,-1), 0.25, HexColor('#295cad')),
                                ('BOX', (0,0), (8,(len(rows)-1)), 0.25, HexColor('#ababab')),
                                ('ALIGN',(0,0),(8,(len(rows)-1)),'LEFT'),
                                ]))
        return_value = [s, t, s, PageBreak()]
    else:
        t = Table(rows, colWidths=[width*cm for width in column_widths])
        t.setStyle(TableStyle([('SPAN',(0,0),(-1,0)),
                                ('BACKGROUND', (0,0),(8,0), HexColor('#295cad')),
                                #('TEXTCOLOR',(0,1),(3,0), colors.white),
                                ('BACKGROUND', (0, 1), (8, 1), HexColor('#ffffff')),
                                # ('BACKGROUND', (0, 5), (1, 5), HexColor('#e1e1e1')),
                                ('INNERGRID', (0,0), (-1,-1), 0.25, HexColor('#ffffff')),
                                ('BOX', (0,0), (8,(len(rows)-1)), 0.25, HexColor('#ffffff')),
                                ('ALIGN',(0,0),(8,(len(rows)-1)),'LEFT'),
                                ]))
        return_value = [s, t, s]
    
    return return_value



def create_table_cluster(title, columns, column_widths, data, total_members, family_name, note_status=True):
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='th1', alignment=TA_CENTER))
    styles.add(ParagraphStyle(name='th2', alignment=TA_LEFT))
    styles.add(ParagraphStyle(name='Line1', alignment=TA_CENTER, fontSize=20, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line2', alignment=TA_CENTER, fontSize=12, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line3', alignment=TA_CENTER, fontSize=12, textColor= HexColor('#333333')))

    styles.add(ParagraphStyle(name='tt', alignment=TA_CENTER, fontSize=6))
    styles.add(ParagraphStyle(name='note', alignment=TA_RIGHT, fontSize=7, textColor=HexColor('#7F7F7F')))
    styles.add(ParagraphStyle(name='Right', alignment=TA_RIGHT))
    # note = Paragraph("(Note -Top 1000 rows displayed. For viewing more rows please create a CSV report.)" if note_status else '', style=styles["note"])
    s = Spacer(1, 12)

    if total_members:
        rows = [
            [Paragraph(f"<font color=white><b>{title}<nbsp>{total_members}</b></font>", styles["th2"])] + ['' for i in range(len(columns)-1)],
            # [Paragraph(f"<para align=left spaceb=3><font color=white><b>{total_members}</b></font></para>")],
            [Paragraph(column, styles['tt']) for column in columns]
            ]
    else:
        rows = [
            [Paragraph(f"<font color=white><b>{title}</b></font>", styles["th1"])] + ['' for i in range(len(columns)-1)],
            [Paragraph(column, styles['tt']) for column in columns]
            ]
    
    if data:
        for row in data:
            new_row = [Paragraph(str(value), styles['tt']) for value in row]
            rows.append(new_row)
            
    t = Table(rows, colWidths=[width*cm for width in column_widths]) 
    t.setStyle(TableStyle([('SPAN',(0,0),(-1,0)),
                        ('BACKGROUND', (0,0),(8,0), HexColor('#295cad')),
                        #('TEXTCOLOR',(0,1),(3,0), colors.white),
                        ('BACKGROUND', (0, 1), (8, 1), HexColor('#e1e1e1')),
                        # ('BACKGROUND', (0, 5), (1, 5), HexColor('#e1e1e1')),
                        ('INNERGRID', (0,0), (-1,-1), 0.25, HexColor('#295cad')),
                        ('BOX', (0,0), (8,(len(rows)-1)), 0.25, HexColor('#ababab')),
                        ('ALIGN',(0,0),(8,(len(rows)-1)),'LEFT'),
                        ]))       
    return [s, t, s] #, PageBreak()


def junk_clean(data):
    pattern = r'\\X0D\\X0A\s*|\\X09|&#X(?:28|29|2F);'
    if isinstance(data, list):
        if len(data) > 1:
            data = ','.join(data)
        else:
            data = data[0]
    cleaned_data = re.sub(pattern, '', str(data))
    return cleaned_data

'''Converting input d value to json data for api'''
def d_to_json_data_mapper_for_count(d_value,extra_key_dict=None):
    json_input = {'caseId': 0, 'startDate': '', 'endDate': '', 'imei': [], 'imsi': [], 'mobile': [], 'state': [], 'pincode': '','b_party_mobile': [], 'cell_id': [], 'towerLocation': '', 'country': [], "publicIp":[], "sourceIPs":[], "destinationIPs":[]}
    json_input['caseId'] = d_value['case_id']
    json_input['startDate'] = d_value['start_date_time']
    json_input['endDate'] = d_value['end_date_time']
    json_input['imei'] = str(d_value['imei']).split(',') if d_value['imei'] else []
    json_input['imsi'] = str(d_value['imsi']).split(',') if d_value['imsi'] else []
    json_input['mobile'] = str(d_value['phone_no']).split(',') if d_value['phone_no'] else []
    json_input['publicIp'] = str(d_value['publicIp']).split(',') if d_value['publicIp'] else []
    json_input['sourceIPs'] = str(d_value['sourceIp']).split(',') if d_value['sourceIp'] else []
    json_input['destinationIPs'] = str(d_value['destination_ip_address']).split(',') if d_value['destination_ip_address'] else []
    json_input['cell_id'] = str(d_value['cell_id']).split(',') if d_value['cell_id'] else []

    if extra_key_dict:
        json_input.update(extra_key_dict)
    # json_input['mobile'] = str(json_input['phone_no'][0]).split(',')   
    clean_json = json.dumps(json_input, indent=2)
    return clean_json

'''Converting input d value to json data for api'''
def d_to_json_data_mapper(d_value,rows_to_show, extra_key_dict=None):
    json_input = {'caseId': 0, 'startDate': '', 'endDate': '', 'imei': [], 'imsi': [], 'mobile': [], 'state': [], 'pincode': '', 'limit': rows_to_show, 'offset': 0, 'b_party_mobile': [], 'cell_id': [], 'towerLocation': '', 'country': [], "publicIp":[], "sourceIPs":[], "destinationIPs":[]}
    json_input['caseId'] = d_value['case_id']
    json_input['startDate'] = d_value['start_date_time']
    json_input['endDate'] = d_value['end_date_time']
    json_input['imei'] = str(d_value['imei']).split(',') if d_value['imei'] else []
    json_input['imsi'] = str(d_value['imsi']).split(',') if d_value['imsi'] else []
    json_input['mobile'] = str(d_value['phone_no']).split(',') if d_value['phone_no'] else []
    json_input['publicIp'] = str(d_value['publicIp']).split(',') if d_value['publicIp'] else []
    json_input['sourceIPs'] = str(d_value['sourceIp']).split(',') if d_value['sourceIp'] else []
    json_input['destinationIPs'] = str(d_value['destination_ip_address']).split(',') if d_value['destination_ip_address'] else []
    json_input['cell_id'] = str(d_value['cell_id']).split(',') if d_value['cell_id'] else []

    if extra_key_dict:
        json_input.update(extra_key_dict)
    # json_input['mobile'] = str(json_input['phone_no'][0]).split(',')   
    clean_json = json.dumps(json_input, indent=2)
    return clean_json

'''Generalised function to call API request'''
def api_call_fun(url,data,token):
    headers = {
        'Accept':'*/*',
        'Accept-Encoding':'gzip, deflate, br',
        'Authorization': token,
        'Connection':'keep-alive',
        'Content-Type':'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    }
    # Updating API url with configured details
    json_file= open('database.config','r').read()
    confg_details = json.loads(json_file)
    url = url.replace('http://localhost:3000',str(confg_details['server_url'])+':'+str(confg_details['server_port']))
    
    # making request to the apiF
    response = requests.post(url,data=data,headers=headers,timeout=30,verify=False)
    print('\n[i] API ', url, response.status_code)
    print("url:",url)
    print("data:",data)
    print("headers:",headers)
    if response.status_code == 200:   
        response_data = response.json()
        if isinstance(response_data['result'], list):
            clean_data = response_data['result']
            return clean_data

        key = next((k for k in ['data', 'result','results', 'final_result', 'suspectedGroupData','case_info_arr'] if k in response_data['result']), None)
        if not key:
            logging.error('No valid key found in the result')
            return
        try:
            response_data = response.json()

            clean_data = response_data['result'].get(key, [])
        except Exception as e:
            print('Enter Exception for',response_data['result'].keys(), e)
                  
        return clean_data
    else:
        print('[Error]: API request/response is not valid', response.status_code)
        clean_data = []
        return clean_data

def common_connection(d,jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/location/commonConnections'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    correlation_data = api_call_fun(url,body_payload,jwt_token)
    if correlation_data:
        print('[+] Total record(common_connection): ',len(correlation_data))    
        title = "COMMON CONNECTION"
        columns = ['SR NO.','PHONE NO','PUBLIC IP','DESTINATION IP','PROTOCOL NAME','SERVICE PROVIDER']
        column_widths = [2,2.5,2.5,2.5,2.5,7]
        data = []
        sr = 0 
        for row in correlation_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(str(row['phone_no'] if 'phone_no' in row else 'N/A'))
            temper.append(str(row['public_ip_address']) if 'public_ip_address' in row else 'N/A')
            temper.append(str(row['destination_ip_address']) if 'destination_ip_address' in row else 'N/A')
            temper.append(str(row['protocol_name']) if 'protocol_name' in row else 'N/A')
            temper.append(str(row['service_provider_detail']) if 'service_provider_detail' in row else 'N/A')
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story

def apk_ipa_correlation_graph(d,jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/correlated/getApkIpaCorelationNodesTable'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    correlation_data = api_call_fun(url,body_payload,jwt_token)
    if correlation_data:
        print('[+] Total record(apk_ipa_correlation_graph): ',len(correlation_data))    
        title = "APK/IPA CORRELATION"
        columns = ['SR NO.','APP NAME','PHONE NO']
        column_widths = [3,8,8]
        data = []
        sr = 0 
        for row in correlation_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(str(row['app_name'] if 'app_name' in row else 'N/A'))
            temper.append(str(row['phone_no']) if 'phone_no' in row else 'N/A')
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story

def destination_correlation_graph(d,jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/correlated/getDestinationCorelationNodesTable'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    correlation_data = api_call_fun(url,body_payload,jwt_token)
    if correlation_data:
        print('[+] Total record(destination_correlation_graph): ',len(correlation_data))    
        title = "DESTINATION CORRELATION"
        columns = ['SR NO.','PHONE NO','DESTINATION IP']
        column_widths = [3,8,8]
        data = []
        sr = 0 
        for row in correlation_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(str(row['phone_no']) if 'phone_no' in row else 'N/A')
            temper.append(str(row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'))
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story


def p_to_p_correlation_graph(d,jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/getVoipCorelationNodesTable'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    print('[+] Total record(body_payload): ',body_payload)    

    correlation_data = api_call_fun(url,body_payload,jwt_token)
    if correlation_data:
        print('[+] Total record(p_to_p_correlation_graph): ',len(correlation_data))    
        title = "P2P CORRELATION"
        columns = ['SR NO.','A PARTY','B PARTY','DURATION (min)','PUBLIC IPADDRESS','PUBLIC IP PORT']
        column_widths = [2,3.5,3.5,3,4,3]
        data = []
        sr = 0 
        for row in correlation_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(str(row['a_party']) if 'a_party' in row else 'N/A')
            temper.append(str(row['b_party'] if 'b_party' in row else 'N/A'))
            temper.append("{:.2f}".format(float(row['session_duration'])/60) if 'session_duration' in row else 'N/A')
            temper.append(str(row['public_ip_address'] if 'public_ip_address' in row else 'N/A'))
            temper.append(str(row['public_ip_port'] if 'public_ip_port' in row else 'N/A'))
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story


def vpn_bparty_list(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/BPartyVpnData'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Vpn Bparty: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "VPN BPARTY LIST"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','APP NAME','DESTINATION IP','COUNTRY','START TIME','END TIME','DURATION (min)']
            column_widths = [2,3,3,2,3,2,2,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no} [{public_ip}/{public_port}]")
                    temper.append(row['vpn_name'] if 'vpn_name' in row else 'N/A')
                    temper.append(row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A')
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['session_duration'])/60) if 'session_duration' in row else 'NA')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR VPN BPARTY LIST: {e}")
                    logging.exception(f"[!] ERROR VPN BPARTY LIST: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def vpn_call_correlation(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/vpnCorrelatedData'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    body_payload=json.loads(body_payload)
    del body_payload['startDate']
    del body_payload['endDate']
    body_payload = json.dumps(body_payload, indent=2)
    correlation_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total correlation calls : ',len(correlation_data))    
    if correlation_data:
        title = "VOIP CALL CORRELATION"
        columns = ['SR NO.','A PARTY','B PARTY','VPN LIST','IP MATCHED','FREQUENCY']
        column_widths = [2.5,3,3,4,4,2.5]
        data = []
        sr = 0 
        for row in correlation_data:
            sr += 1
            temper = []
            try:
                temper.append(str(sr))
                temper.append(str(row['aparty']) if 'aparty' in row else 'N/A')
                temper.append(str(row['bparty'] if 'bparty' in row else 'N/A'))
                temper.append(str(row['vpn_name'] if 'vpn_name' in row else 'N/A'))
                temper.append(str(row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'))
                temper.append(str(row['total_count'] if 'total_count' in row else 'N/A'))
                data.append(temper)
            except Exception as e:
                print(f"[!] ERROR in  VOIP CALL CORRELATION: {e}")
                logging.exception(f"[!] ERROR in  VOIP CALL CORRELATION: {e} \n [i] Error data: {row}\n")
        story.extend(create_table(title, columns, column_widths, data))
    return story

def mobile_phones(d, jwt_token,tab,rows_to_show):
    story = []
    data = []
    sr = 0
    if tab=='INDIVIDUAL':
        title = "TABLE OF MOBILE PHONES" 
    else:
        title= "TABLE OF MOBILE BRAND" 
    # title = "TABLE OF MOBILE PHONES" 

    columns = ['SR.NO.','PHONE NO','IMEI','PHONE NAME','MODEL NAME','PHONE BRAND','PHONE TYPE']
    column_widths = [2,2.5,3,2.5,3,3,3]
    url = 'http://localhost:3000/api/case/getImei'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total MOBILE PHONES records: ',len(response_data))
    for item in response_data:
        item['phone_type'] = 'Smart Phone' if item['is_basic'] == 'no' else 'Basic Phone'
    if response_data:
        for row in response_data:
            sr += 1
            temper = []
            try:
                temper.append(str(sr))
                temper.append((str(row['phone_no'])) if 'phone_no' in row else 'N/A')
                temper.append((str(row['imei_no'])) if 'imei_no' in row else 'N/A')
                temper.append((str(row['phone_name'])) if 'phone_name' in row else 'N/A')
                temper.append((str(row['phone_model'])) if 'phone_model' in row else 'N/A')
                temper.append((str(row['phone_brand'])) if 'phone_brand' in row else 'N/A')
                temper.append((str(row['phone_type'])) if 'phone_type' in row else 'N/A')
                data.append(temper)
            except Exception as e:
                print(f"[!] ERROR in  MOBILE PHONES: {e}")
                logging.exception(f"[!] ERROR in  MOBILE PHONES: {e} \n [i] Error data: {row}\n")
        story.extend(create_table(title, columns, column_widths, data))
    return story

'''Phone Change'''
def phone_change(d, jwt_token,rows_to_show):
    story = []
    data = []
    sr = 0
    title = "TABLE OF PHONE CHANGES" 
    columns = ['SR.NO.','PHONE NO','OLD PHONE IMEI','NEW PHONE IMEI']
    column_widths = [2,5.5,5.5,5.5]
    url = 'http://localhost:3000/api/cdr/isPhoneChanged'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total phone change: ',len(response_data))

    if response_data:
        for row in response_data:
            sr += 1
            temper = []
            try:
                temper.append(str(sr))
                temper.append((str(row['phone_no'])) if 'phone_no' in row else 'N/A')
                temper.append((str(row['off_imei_no'])) if 'off_imei_no' in row else 'N/A')
                temper.append((str(row['on_imei_no'])) if 'on_imei_no' in row else 'N/A')
                data.append(temper)
            except Exception as e:
                print(f"[!] ERROR in phone change: {e}")
                logging.exception(f"[!] ERROR in phone change: {e} \n [i] Error data: {row}\n")
        story.extend(create_table(title, columns, column_widths, data))
    return story


'''tower movement'''
def tower_movement(d, jwt_token,rows_to_show):
    story = []
    data = []
    sr = 0
    title = "TABLE OF TOWER MOVEMENTS" 
    columns = ['SR.NO.','START CELL ID','START DATE TIME','START TOWER LOCATION','END DATE TIME','END TOWER LOCATION']
    column_widths = [1.5,2.5,3,4.5,3,5]
    url = 'http://localhost:3000/api/case/towerLocationMovements'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total tower movements location: ',len(response_data))
    if response_data:
        for row in response_data:
            sr += 1
            temper = []
            try:
                temper.append(str(sr))
                temper.append((str(row['start_cell_id'])) if 'start_cell_id' in row else 'N/A')
                temper.append((str(datetime.datetime.fromtimestamp(int(row['cell_id_start_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))) if 'cell_id_start_date_time' in row else 'N/A')
                temper.append((str(junk_clean(row['start_tower_location']))) if 'start_tower_location' in row else 'N/A')
                temper.append((str(datetime.datetime.fromtimestamp(int(row['cell_id_end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))) if 'cell_id_end_date_time' in row else 'N/A')
                temper.append((str(junk_clean(row['end_tower_location']))) if 'end_tower_location' in row else 'N/A')
                data.append(temper)
            except Exception as e:
                print(f"[!] ERROR in tower movements location: {e}")
                logging.exception(f"[!] ERROR in tower movements location: {e} \n [i] Error data: {row}\n")
        story.extend(create_table(title, columns, column_widths, data))
    return story

'''visited Rail/Bus/Airport'''
def visited_transport(d, jwt_token,rows_to_show):
    story = []
    data = []
    sr = 0
    title = "TABLE OF VISITED RAIL/BUS/AIRPORT" 
    columns = ['SR.NO.','CELL_ID','LOCATION','CATEGORY','PHONE','ADDRESS']
    column_widths = [1.5,3,3,3,3,6]
    url = 'http://localhost:3000/api/cluster/visitedTransport'
    body_payload = d_to_json_data_mapper(d,rows_to_show, {"distance":""})
    response_data = api_call_fun(url,body_payload,jwt_token)

    print('[+] Total visited transport(rail/bus/airport): ',len(response_data))
    if response_data:
        for row in response_data:
            for locations in row['nearby_loc']:
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append(str(row['data']['start_cell_id']))
                    temper.append((str(junk_clean(locations['title']))) if 'title' in locations else 'N/A')
                    temper.append((str(locations['categories'])) if "categories" in locations else 'N/A')
                    temper.append((str(locations['phone'])) if 'phone' in locations else 'N/A')
                    temper.append((str(junk_clean(locations['address']))) if 'address' in locations else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR in visited transport(rail/bus/airport): {e}")
                    logging.exception(f"[!] ERROR in visited transport(rail/bus/airport): {e} \n [i] Error data: {row}\n")
        story.extend(create_table(title, columns, column_widths, data))
    return story
            

'''Important travel routes'''
def important_travel_routes(d,rows_to_show):
    story = []
    data = []
    sr = 0
    d2_for_custom = d.copy() 
    d2_for_custom['cell_id_start_date_time'] = d2_for_custom['start_date_time']
    d2_for_custom['cell_id_end_date_time'] = d2_for_custom['end_date_time']
    d2_for_custom.pop('start_date_time')
    d2_for_custom.pop('end_date_time')
    
    title = "TABLE OF IMPORTANT TRAVEL ROUTES"
    columns = ['SR.NO.','PHONE NO','START LOCATION','END LOCATION','START DATE TIME','END DATE TIME']
    column_widths = [1.5,2,5,5,2.5,2.5]
    table_name = 'important_travel_routes'
    filter_conditions = [
        "end_tower_latitude IS NOT NULL",
        "end_tower_longitude IS NOT NULL",
        "start_tower_latitude IS NOT NULL",
        "start_tower_longitude IS NOT NULL"
        ]
    # travel_routes  = fetch_pysolr_data(core_name , d2_for_custom, ['end_tower_latitude:*','end_tower_longitude:*','start_tower_latitude:*','start_tower_longitude:*'],'',fl='',rows=rows_to_show)
    travel_routes = fetch_clickhouse_data(table_name,d2_for_custom,filter_conditions=filter_conditions,fields=None,limit=rows_to_show)

    if travel_routes:
        # story.append(PageBreak())
        print('[+] important travel routes count: ',len(travel_routes))
        for rows in travel_routes:
            sr += 1
            temper = []
            try:
                temper.append(str(sr))
                temper.append((str(rows['phone_no'])) if 'phone_no' in rows else 'N/A')
                temper.append(junk_clean(rows['start_tower_district']) if 'start_tower_district' in rows else 'N/A')
                temper.append(junk_clean(rows['end_tower_district']) if 'end_tower_district' in rows else 'N/A')
                temper.append(str(datetime.datetime.fromtimestamp(int(rows['cell_id_start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'cell_id_start_date_time' in rows else 'N/A')
                temper.append(str(datetime.datetime.fromtimestamp(int(rows['cell_id_end_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'cell_id_end_date_time' in rows else 'N/A')
                data.append(temper)
            except Exception as e:
                print(f"[!] ERROR in important travel routes: {e}")
                logging.exception(f"[!] ERROR in important travel routes: {e} \n Error data: {rows}")
        story.extend(create_table(title, columns, column_widths, data))
    return story

'''No network/vacuum Analysis'''
def no_network_analysis(d, jwt_token,tab,rows_to_show):
    story = []
    data = []
    sr = 0
    if tab=='INDIVIDUAL':
        title = "TABLE OF NO NETWORK ANALYSIS" 
    else:
        title= "TABLE OF VACUUM ANALYSIS" 
    # phone_no,off_time,off_imei_no,off_imsi_no,on_time,on_imei_no,on_imsi_no,duration
    # title = "TABLE OF NO NETWORK ANALYSIS" 
    columns = ['SR.NO.','PHONE NO','PHONE OFF TIME','OFF TIME IMEI','OFF TIME IMSI','PHONE ON TIME', 'ON TIME IMEI', 'ON TIME IMSI','DURATION(min)']
    column_widths = [1.5,2,2.25,2.25,2.25,2.25,2.25,2.25,2]
    url = 'http://localhost:3000/api/tower/towerLocationInactivePeriod'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total rec of no network analysis: ',len(response_data))
    if response_data:
        # story.append(PageBreak())
        for row in response_data:
            sr += 1
            temper = []
            try:
                temper.append(str(sr))
                temper.append((str(row['phone_no'])) if 'phone_no' in row else 'N/A')
                temper.append((str(datetime.datetime.fromtimestamp(int(row['off_time'])).strftime("%d-%m-%Y %H:%M:%S"))) if 'off_time' in row else 'N/A')
                temper.append((str(row['off_imei_no'])) if 'off_imei_no' in row else 'N/A')
                temper.append((str(row['off_imsi_no'])) if 'off_imsi_no' in row else 'N/A')
                temper.append((str(datetime.datetime.fromtimestamp(int(row['on_time'])).strftime("%d-%m-%Y %H:%M:%S"))) if 'on_time' in row else 'N/A')
                temper.append((str(row['on_imei_no'])) if 'on_imei_no' in row else 'N/A')
                temper.append((str(row['on_imsi_no'])) if 'on_imsi_no' in row else 'N/A')
                # temper.append((str(row['vaccume_duration'])) if 'vaccume_duration' in row else 'N/A')
                temper.append("{:.2f}".format(float(row['vaccume_duration'])/60) if 'vaccume_duration' in row else 'N/A')
                data.append(temper)
            except Exception as e:
                print(f"[!] ERROR in No network analysis: {e}")
                logging.exception(f"[!] ERROR in No network analysis: {e} \n [i] Error data: {row}\n")
        story.extend(create_table(title, columns, column_widths, data))
    return story

'''District wise top 3 Locations'''
def district_location(d,rows_to_show):
    story = []    
    pb=False

    # removing extra keys and value from input dict "d"
    query = {'case_id':d['case_id'], 'phone_no': d['phone_no']}
    rem_key =['start_date_time','end_date_time','imei','imsi', 'publicIp', 'sourceIp', 'destination_ip_address', 'report_id', 'start_end_time','phone_no']
    # for key in rem_key:
    #     d.pop(key, None)
        
    table_name = 'u_district_wise_location_dis'
    # imei_data  = fetch_pysolr_data(core_name, query, '','',fl='',rows=rows_to_show)
    imei_data = fetch_clickhouse_data(table_name, d, filter_conditions='', extra_query='', fields=['district_name', 'location_dict_encode'], limit=rows_to_show )

    print('[+] Top 3 district location count: ',len(imei_data))
    if imei_data:
        pb=True
        # story.append(PageBreak())
        title = "TOP 3 DISTRICT WISE LOCATIONS"
        columns = ['SR.NO.','DISTRICT','CELL ID','COUNT', 'LOCATION']
        column_widths = [1.5,2,2.5,2,11]
        
        '''Creation of header before table start'''
        story.extend(create_table(title, ['','','','',''], [1.5,2,2.5,2,11], '', note_status=False))
        for rows in imei_data:
            sr = 0
            data = []
            # decode base64 data for location
            try:
                decoded_data_list  = base64.b64decode(rows['location_dict_encode']).decode("utf-8")
                # decoded_data_list  = base64.b64decode(rows['location_dict_encode']).decode("ascii")

            except Exception as e:
                print(f"[!] ERROR: {e}")
                # print(f"[+] Cash Withdrawl exception {base64.b64decode(row['near_by_atm'][0])}") 
                logging.exception(f"[+] district location exception {base64.b64decode(rows['near_by_atm'][0])}")
            decoded_data_list_temp = decoded_data_list.replace('nan','0')
            all_decoded_data = eval(decoded_data_list_temp)
            # adding the data to create table 
            for decoded_data in all_decoded_data:
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append(str(junk_clean(decoded_data['tower_district'])) if 'tower_district' in decoded_data else 'N/A')
                    temper.append(str(decoded_data['cell_id']) if 'cell_id' in decoded_data else 'N/A')
                    temper.append(str(decoded_data['count']) if 'count' in decoded_data else 'N/A')
                    temper.append(str(junk_clean(decoded_data['tower_location'])) if 'tower_location' in decoded_data else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR in District wise location: {e}")
                    logging.exception(f"[!] ERROR in District wise location: {e} \n [i] Error data: {decoded_data}\n")
            story.extend(create_table_cluster(junk_clean(rows['district_name']), columns, column_widths, data,'',''))
    return  story, pb


def betting_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/bettingApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Betting Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "BETTING APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Betting Application: {e}")
                    logging.exception(f"[!] ERROR Betting Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story



def games_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/gameApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Games Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "GAMES APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Games Application: {e}")
                    logging.exception(f"[!] ERROR Games Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def remote_desktop_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/remoteDesktopApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Remote Desktop Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "REMOTE DESKTOP APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Remote Desktop Application: {e}")
                    logging.exception(f"[!] ERROR Remote Desktop Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def file_sharing_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/fileSharingApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total File Sharing Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "FILE SHARING APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR File Sharing Application: {e}")
                    logging.exception(f"[!] ERROR File Sharing Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def shopping_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/shoppingApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Shopping Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "SHOPPING APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Shopping Application: {e}")
                    logging.exception(f"[!] ERROR Shopping Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story


def mail_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/mailApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Mail Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "MAIL APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Mail Application: {e}")
                    logging.exception(f"[!] ERROR Mail Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def govt_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/governmentApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Government Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "GOVERNMENT APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Government Application: {e}")
                    logging.exception(f"[!] ERROR Government Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story


def wallet_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/walletApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Wallet Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "WALLET APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Wallet Application: {e}")
                    logging.exception(f"[!] ERROR Wallet Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def streaming_media_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/streamingMediaApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Streaming Meadia Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "STREAMING MEDIA APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Streaming Meadia Application: {e}")
                    logging.exception(f"[!] ERROR Streaming Meadia Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def news_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/app/newsApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total News Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "NEWS APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER','APPLICATION NAME']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no}[{public_ip}/{public_port}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if 'apk_ipa_total_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR News Application: {e}")
                    logging.exception(f"[!] ERROR News Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story


def drone_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/droneApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Drone Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "DRONE APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER [PUBLIC IP/PORT]','DRONE APP','DESTINATION IP/PORT','COUNTRY','START TIME','END TIME','DURATION (min)','SERVICE PROVIDER']
            column_widths = [1.5,2,2,2,2,2,2,2,3.5]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    phone_no=row['phone_no'] if 'phone_no' in row else 'N/A'
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{phone_no} [{public_ip}/{public_port}]")
                    droneApp=row['droneApp'] if 'droneApp' in row else 'N/A'
                    hosted_domain_name=row['hosted_domain_name'] if 'hosted_domain_name' in row else 'N/A'
                    temper.append(f"{droneApp} [{hosted_domain_name}]")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S"))  if 'end_date_time' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['session_duration'])/60) if 'session_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Drone Application: {e}")
                    logging.exception(f"[!] ERROR Drone Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story



def crypto_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/cryptoApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Crypto Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "CRYPTO APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER','PUBLIC IP/PORT','DESTINATION IP/PORT/PROTOCOL','COUNTRY','START TIME/END TIME','DURATION (min)','SERVICE PROVIDER','DOMAIN']
            column_widths = [1.5,2,2,2,2,2,2,3.5,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append(row['phone_no'] if 'phone_no' in row else 'N/A')
                    public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f"{public_ip}/{public_port}")
                    destination_ip=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    protocol=row['protocol_name'] if 'protocol_name' in row else 'N/A'
                    temper.append(f"{destination_ip}/{destination_port}/{protocol}")
                    temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
                    start_date_time=datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S") if 'start_date_time' in row else 'N/A'
                    end_date_time=datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S") if 'end_date_time' in row else 'N/A'
                    temper.append(f"{start_date_time}/{end_date_time}")
                    temper.append("{:.2f}".format(float(row['session_duration'])/60) if 'session_duration' in row else 'N/A')
                    temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
                    temper.append(row['hosted_domain_name'] if 'hosted_domain_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Crypto Application: {e}")
                    logging.exception(f"[!] ERROR Crypto Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story


def calling_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/callingApkIpa'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Calling Application: ',len(response_data))

    if response_data:
            data = []
            sr = 0
            title = "CALLING APPLICATION"
            columns = ['SR.NO.','PHONE NUMBER','APP NAME','DOWNLINK VOL(MB)','UPLINK VOL(MB)']
            column_widths = [2,4,6,3.5,3]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append(row['phone_no'] if 'phone_no' in row else 'N/A')
                    temper.append(row['voip_call_platform_name'] if 'voip_call_platform_name' in row else 'N/A')
                    temper.append('{:.2f}'.format(float(row['downlink_vol']) * 0.000000125) if row['downlink_vol'] else 'N/A')
                    temper.append('{:.2f}'.format(float(row['uplink_vol']) * 0.000000125) if row['uplink_vol'] else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Calling Application: {e}")
                    logging.exception(f"[!] ERROR Calling Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def chatting_nd_surfing_apps(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/mobileApp'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Chatting and Surfing Application: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "CHATTING AND SURFING APPLICATIONS"
            columns = ['SR.NO.','PHONE NUMBER','APP NAME','DURATION (min)','DOWNLINK VOL(MB)','UPLINK VOL(MB)']
            column_widths = [2,3,5.5,3,3,2.5]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append(row['phone_no'] if 'phone_no' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if row['apk_ipa_total_duration'] else 'N/A')
                    temper.append('{:.2f}'.format(float(row['apk_ipa_total_downlink']) * 0.000000125) if row['apk_ipa_total_downlink'] else 'N/A')
                    temper.append('{:.2f}'.format(float(row['apk_ipa_total_uplink']) * 0.000000125) if row['apk_ipa_total_uplink'] else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Chatting and Surfing Application: {e}")
                    logging.exception(f"[!] ERROR Chatting and Surfing Application: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story


''' Table of Watchlist (suspected group data)'''
def watch_list(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/cluster/suspectedGroupData'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total watchlist(suspected group data): ',len(response_data))

    if response_data:
            data = []
            sr = 0
            title = "TABLE OF WATCHLIST(SUSPECTED GROUP DATA)"
            columns = ['SR.NO.','GROUP NAME','TARGET NAME', 'ENTITY']
            column_widths = [2,6.5,5.5,5]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append((str(row['group_name'])) if 'group_name' in row else 'N/A')
                    temper.append((str(row['target_name'])) if 'target_name' in row else 'N/A')
                    temper.append((str(row['entity_type']))+" : "+ str(row['entity_value']) if 'entity_value' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR in watchlist(suspected group data): {e}")
                    logging.exception(f"[!] ERROR in watchlist(suspected group data): {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story


def tor_identification(d,jwt_token,rows_to_show):
    story = []
    count = 0
    url = 'http://localhost:3000/api/tor/tor_application'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    tor_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total tor records: ',len(tor_data))
    # print(vpn_data)
    if tor_data:
        count = len(tor_data)
        title = "TOR DETAILS"
        columns = ['SR NO.', 'PHONE NO ', 'PUBLIC IP/PORT', 'COMPANY NAME', 'DESTINATION IP', 'COUNTRY', 'START TIME', 'END TIME', 'DURATION (min)']
        column_widths = [2,2,2.5,2,2,2,2,2,2]
        data = []
        sr = 0 
        for row in tor_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append((str(row['phone_no'])) if 'phone_no' in row else 'N/A')
            public_ip=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
            public_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
            temper.append(f"{public_ip}/{public_port}")

            # temper.append(f"{row['public_ip_address']}/{row['public_ip_port']}" if 'public_ip_address' in row and 'public_ip_port' in row else '')
            # temper.append(row['public_ip_port'] if 'public_ip_port' in row else '')
            temper.append(row['company_name'] if 'company_name' in row else 'N/A')
            temper.append(row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A')
            temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
            temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
            temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'end_date_time' in row else 'N/A')
            temper.append("{:.2f}".format(float(row['session_duration'])/60) if 'session_duration' in row else 'N/A')
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story





def voip_page(d,jwt_token,rows_to_show):
    story = []
    # core_name = 'ipdr_details'
    # voip_data = fetch_pysolr_data(core_name, d, ['b_party_table_status:yes AND t_detection:no AND -service_provider_detail:UNKNOWN AND -service_provider_detail:unknown'], {'rows': 1000})
    url = 'http://localhost:3000/api/case/getAllBpartyByCaseId'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    voip_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total VOIP calls: ',len(voip_data))
    if voip_data:
        print('voip',len(voip_data))
        title = "VOIP CALL B-PARTY LIST"
        columns = ['B-Party Public IP', 'Public Port', 'Platform', 'ISP Details', 'Start Time', 'End Time', 'Duration (min)', 'Country', 'Source IP']
        column_widths = [2, 1.5, 2, 4.5, 2, 2, 1.2, 2, 2.75]
        data = []
        for row in voip_data:
            temper = []
            temper.append(row['bparty_ip'] if 'bparty_ip' in row else 'N/A')
            temper.append(str(row['bparty_port']) if 'bparty_port' in row else 'N/A')
            temper.append(row['voip_call_platform_name'] if 'voip_call_platform_name' in row else 'N/A')
            temper.append(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A')
            temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
            temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'end_date_time' in row else 'N/A')
            # temper.append(str(int(float(row['session_duration']))/60)  if 'session_duration' in row else 'N/A')
            temper.append("{:.2f}".format(float(row['session_duration'])/60) if 'session_duration' in row else 'N/A')
            temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
            temper.append(row['source_ip_address'] if 'source_ip_address' in row else 'N/A')
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story

def domain_page(d):
    story = []
    count = 0
    table = 'mact.ipdr_details'

    filter_condition = ["hosted_domain_name IS NOT NULL"]
    extra_query = "GROUP BY hosted_domain_name LIMIT 1"

    response_data = fetch_clickhouse_data(table, d, filter_conditions=filter_condition, extra_query=extra_query,fields=["hosted_domain_name"])
    # response_json = fetch_pysolr_data(core_name, d, ['hosted_domain_name:*'], {
    #     'rows': 0,
    #     'group': 'true',
    #     'group.field': 'hosted_domain_name',
    #     'group.limit': 1,
    # })
  
    # print('domain:',len(response_json))
    domains = []
    if response_data:
        for row in response_data:
            key = row.get('hosted_domain_name', None)
            count = row.get('count', 0)  # Adjust based on the column name for count if it differs
            if key is not None:
                domains.append([key, count])
    sorted_domains = sorted(domains, key=lambda x: x[1], reverse=True)
    # count = len(sorted_domains)        
    domain_top_10 = sorted_domains[:10]
    if domain_top_10:

        title = "TOP 10 DOMAINS"
        columns = ['SR.No.', 'Domain', 'Frequency']
        column_widths = [6, 7, 6 ]
        data = []
        sr = 0
        for row in domain_top_10:
            print(row)
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(str(row[0]))
            temper.append(str(row[1]))
            data.append(temper)
        # columns = ['SR.No','Phone','Destination IP','Destination Port','Domains','Duration','Downlink','Uplink']
        # column_widths = [1.5, 3, 3.5, 1.5, 5, 1.5, 2, 2]
        # data = []
        # sr = 0
        # for row in domain_data:
        #     sr += 1
        #     temper = []
        #     temper.append(str(sr))
        #     temper.append(str(row['phone_no'] if 'phone_no' in row else ''))
        #     temper.append(row['destination_ip_address'] if 'destination_ip_address' in row else '')
        #     temper.append(str(row['destination_port']) if 'destination_port' in row else '')
        #     temper.append(str(row['hosted_domain_name']) if 'hosted_domain_name' in row else '')
        #     temper.append("{:.2f}".format(row['session_duration']/60) if row['session_duration'] else 'NA')
        #     temper.append('{:.2f}'.format(float(row['downlink_vol']) * 0.000000125) if row['downlink_vol'] else 'NA')
        #     temper.append('{:.2f}'.format(float(row['uplink_vol']) * 0.000000125) if row['uplink_vol'] else 'NA')
        #     data.append(temper)
        story.extend(create_table(title, columns, column_widths, data, False))

    return story

# def apk_ipa(d):
#     story = []
#     count = 0
#     core_name = 'ipdr_details'
   
#     apk_ipa_data = fetch_pysolr_data(core_name, d, ['app_name:*'], {
#         'group': 'true',
#         'group.field': 'app_name',
#         'group.limit': 1
#     })
#     top_5_apps = []
#     response_json = fetch_pysolr_data(core_name, d, ['app_name:*'], {
#         'rows': 0,
#         'group': 'true',
#         'group.field': 'app_name',
#         'group.limit': 1
#     })

#     groups = response_json.grouped['app_name']['groups']
#     if groups:
#         for group in groups:
#             key = group['groupValue']
#             count = group['doclist']['numFound']
#             top_5_apps.append([key, count])
#     top_5_apps = sorted(top_5_apps, key=lambda x: x[1], reverse=True)
#     top_5_apps = [app[0] for app in top_5_apps[:5]]
#     if apk_ipa_data.grouped['app_name']['groups']:
#         count = len(apk_ipa_data.grouped['app_name']['groups'])
#         print('apk/ipa',len(apk_ipa_data.grouped['app_name']['groups']))
#         title = "APPLICATION DETAILS"
#         columns = ['SR NO.', 'App Name', 'Mobile', 'Session Duration (min)', 'Downlink Volume (mb)', 'Uplink Volume (mb)']
#         column_widths = [1.5, 7, 3, 4, 2.5, 2.5]
#         data = []
#         sr = 0
#         for rrow in apk_ipa_data.grouped['app_name']['groups']:
#             row = rrow['doclist']['docs'][0]
#             sr += 1
#             temper = []
#             temper.append(str(sr))
#             temper.append(row['app_name'] if 'app_name' in row else 'N/A')
#             temper.append(row['phone_no'] if 'phone_no' in row else 'N/A')
#             temper.append("{:.2f}".format(float(row['apk_ipa_total_duration'])/60) if row['apk_ipa_total_duration'] else 'N/A')
#             temper.append('{:.2f}'.format(float(row['apk_ipa_total_downlink']) * 0.000000125) if row['apk_ipa_total_downlink'] else 'N/A')
#             temper.append('{:.2f}'.format(float(row['apk_ipa_total_uplink']) * 0.000000125) if row['apk_ipa_total_uplink'] else 'N/A')
#             data.append(temper)
#         story.extend(create_table(title, columns, column_widths, data))

#     return story

def apk_ipa(d):
    story = []
    count = 0
    table = 'mact.ipdr_details'

    filter_condition = ["app_name IS NOT NULL"]
    extra_query = "GROUP BY app_name"
    apk_ipa_data = fetch_clickhouse_data(table,d,filter_conditions=filter_condition,extra_query=extra_query,fields=["app_name"])

    top_5_apps_query = "GROUP BY app_name ORDER BY COUNT(*) DESC LIMIT 5"
    top_5_apps_response = fetch_clickhouse_data(table,d,filter_conditions=filter_condition,extra_query=top_5_apps_query,fields=["app_name"])

    top_5_apps = []
    if top_5_apps_response:
        for app in top_5_apps_response:
            app_name = app['app_name']
            app_count = app['count']
            top_5_apps.append([app_name, app_count])
        top_5_apps = sorted(top_5_apps, key=lambda x: x[1], reverse=True)
        top_5_apps = [app[0] for app in top_5_apps[:5]]

    if apk_ipa_data:
        count = len(apk_ipa_data)
        print('apk/ipa', count)
        title = "APPLICATION DETAILS"
        columns = ['SR NO.', 'App Name', 'Mobile', 'Session Duration (min)', 'Downlink Volume (mb)', 'Uplink Volume (mb)']
        column_widths = [1.5, 7, 3, 4, 2.5, 2.5]
        data = []
        sr = 0
        for row in apk_ipa_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(row['app_name'] if 'app_name' in row else 'N/A')
            temper.append(row['phone_no'] if 'phone_no' in row else 'N/A')
            temper.append("{:.2f}".format(float(row['apk_ipa_total_duration']) / 60) if row.get('apk_ipa_total_duration') else 'N/A')
            temper.append('{:.2f}'.format(float(row['apk_ipa_total_downlink']) * 0.000000125) if row.get('apk_ipa_total_downlink') else 'N/A')
            temper.append('{:.2f}'.format(float(row['apk_ipa_total_uplink']) * 0.000000125) if row.get('apk_ipa_total_uplink') else 'N/A')
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))

    return story


# def recent(d):
#     res_imei = ''
#     res_imsi = ''
#     res_cell_id = ''
#     res_activity = ''
#     recent_imei = fetch_pysolr_data('ipdr_details', d, ['imei_no:* AND -imei_no:0'], {
#         'sort': 'start_date_time desc',
#         'rows': 1
#     })
#     recent_imsi = fetch_pysolr_data('ipdr_details', d, ['imsi_no:* AND -imsi_no:0'], {
#         'sort': 'start_date_time desc',
#         'rows': 1
#     })
#     recent_cell_id = fetch_pysolr_data('ipdr_details', d, ['cell_id:* AND -cell_id:0'], {
#         'sort': 'start_date_time desc',
#         'rows': 1
#     })
#     recent_activity = fetch_pysolr_data('ipdr_details', d, ['b_party_table_status:yes AND -is_tor_detected:yes AND -service_provider_detail:UNKNOWN AND -service_provider_detail:unknown'], {
#         'sort': 'start_date_time desc',
#         'rows': 1
#     })
#     if recent_imei:
#         if recent_imei.docs[0]['imei_no']:
#             res_imei = f"recent imei was <b>{recent_imei.docs[0]['imei_no']}</b>, "
#     if recent_imsi:
#         if recent_imsi.docs[0]['imsi_no']:
#             res_imsi = f"recent imsi was <b>{recent_imsi.docs[0]['imsi_no']}</b>, "
#     if recent_cell_id:
#         if recent_cell_id.docs[0]['cell_id']:
#             res_cell_id = f"recent cell-id was <b>{recent_cell_id.docs[0]['cell_id']}</b>. "
#     if recent_activity:
#         recent_activity = recent_activity.docs[0]
#         if recent_activity['phone_no'] and recent_activity['destination_ip_address'] and recent_activity['start_date_time']:
#             res_activity = f"Target <b>{recent_activity['phone_no']}</b> has made last call to <b>{recent_activity['destination_ip_address']}</b> bparty IP on <b>{datetime.datetime.fromtimestamp(recent_activity['start_date_time']).strftime('%Y-%m-%d %H:%M:%S')}</b>. "  
#     if res_imei or res_imsi or res_cell_id:
#         return "Target's " + res_imei + res_imsi + res_cell_id, res_activity
#     else:
#         return "", res_activity

def recent(d):
    res_imei = ''
    res_imsi = ''
    res_cell_id = ''
    res_activity = ''
    table = 'mact.ipdr_details'

    filter_conditions = ["imei_no IS NOT NULL","imei_no != '0'"]
    extra_query = "ORDER BY start_date_time DESC LIMIT 1"  
    recent_imei = fetch_clickhouse_data(table,d,filter_conditions=filter_conditions,extra_query=extra_query)

    filter_conditions = ["imsi_no IS NOT NULL","imsi_no != '0'" ]
    extra_query = "ORDER BY start_date_time DESC LIMIT 1"  
    recent_imsi = fetch_clickhouse_data(table,d,filter_conditions=filter_conditions,extra_query=extra_query)

    filter_conditions = ["cell_id IS NOT NULL","cell_id != '0'" ]
    extra_query = "ORDER BY start_date_time DESC LIMIT 1"  
    recent_cell_id = fetch_clickhouse_data(table,d,filter_conditions=filter_conditions,extra_query=extra_query)

    filter_conditions = ["b_party_table_status = 'yes'","is_tor_detected != 'yes'","service_provider_detail != 'UNKNOWN'","service_provider_detail != 'unknown'"]
    extra_query = "ORDER BY start_date_time DESC LIMIT 1"  
    recent_activity = fetch_clickhouse_data(table,d,filter_conditions=filter_conditions,extra_query=extra_query)

    if recent_imei and recent_imei[0].get('imei_no'):
        res_imei = f"recent imei was <b>{recent_imei[0]['imei_no']}</b>, "

    if recent_imsi and recent_imsi[0].get('imsi_no'):
        res_imsi = f"recent imsi was <b>{recent_imsi[0]['imsi_no']}</b>, "

    if recent_cell_id and recent_cell_id[0].get('cell_id'):
        res_cell_id = f"recent cell-id was <b>{recent_cell_id[0]['cell_id']}</b>. "

    if recent_activity and recent_activity[0].get('phone_no') and recent_activity[0].get('destination_ip_address') and recent_activity[0].get('start_date_time'):

        start_date_time = recent_activity[0]['start_date_time']
        if isinstance(start_date_time, str):
            start_date_time = int(start_date_time)  
        formatted_time = datetime.datetime.fromtimestamp(start_date_time).strftime('%Y-%m-%d %H:%M:%S')

        res_activity = (
            f"Target <b>{recent_activity[0]['phone_no']}</b> has made last call to "
            f"<b>{recent_activity[0]['destination_ip_address']}</b> bparty IP on "
            f"<b>{formatted_time}</b>. "
        )

    if res_imei or res_imsi or res_cell_id:
        return "Target's " + res_imei + res_imsi + res_cell_id, res_activity
    else:
        return "", res_activity


def vpn_list(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/vpnDatabyVpnAndMobile'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    vpn_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total VPN ips: ',len(vpn_data))
    if vpn_data:
        title = "VPN DETAILS"
        columns = ['SR NO.', 'Phone', 'App Name', 'Destination IP', 'Country', 'Start Time', 'End Time', 'Duration (min)']
        column_widths = [1,2,4,2,2,3,3,2]
        data = []
        sr = 0 
        for row in vpn_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append((str(row['phone_no'])) if 'phone_no' in row else 'N/A')
            temper.append(row['vpn_name'] if 'vpn_name' in row else 'N/A')
            temper.append(row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A')
            temper.append(row['ip_country'] if 'ip_country' in row else 'N/A')
            temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
            temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'end_date_time' in row else 'N/A')
            temper.append("{:.2f}".format(float(row['session_duration'])/60) if 'session_duration' in row else 'N/A')
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story

def extracted_media(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/pcap/extractedMedia'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Extracted Media Data: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "EXTRACTED MEDIA"
            columns = ['SR.NO.','Destination Ip','Destination Port','File Type','Domain Name']
            column_widths = [2,4,4,4,4]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append(row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A')
                    temper.append(row['destination_port'] if 'destination_port' in row else 'N/A')
                    temper.append(row['file_type'] if 'file_type' in row else 'N/A')
                    temper.append(row['domain_name'] if 'domain_name' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Extracted Media: {e}")
                    logging.exception(f"[!] ERROR Extracted Media: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def plain_text_credentials(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/pcap/userCredentials'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Plain Text Credentials Data: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "PLAIN TEXT CREDENTIALS"
            columns = ['SR.NO.','Phone number','Date/Time','Destination Ip','Username','Password']
            column_widths = [2,3,4,3,3.5,3.5]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append(row['phone_no'] if 'phone_no' in row else 'N/A')
                    if 'start_date_time' in row and len(str(row['start_date_time']))==13:
                            row['start_date_time']=int(row['start_date_time']) / 1000
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A')
                    temper.append(row['username'] if 'username' in row else 'N/A')
                    temper.append(row['password'] if 'password' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Plain Text Credentials: {e}")
                    logging.exception(f"[!] ERROR Plain Text Credentials: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

def media_correlation(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/correlated/mediaCorrelatedData'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Media Correlation Data: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "MEDIA CORRELATION"
            columns = ['A Party/B Party','Public Ip/Port','Destination Ip/Port','App name','Date','Media','Media data','BParty Media','BParty data']
            column_widths = [2,2,2,2,2,2,2,2,2]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    # temper.append(str(sr))
                    a_party=row['phone_no'] if 'phone_no' in row else 'N/A'
                    b_party=row['b_party'] if 'b_party' in row else 'N/A'
                    temper.append(f'{a_party}/{b_party}')
                    public_ip_address=row['public_ip_address'] if 'public_ip_address' in row else 'N/A'
                    public_ip_port=row['public_ip_port'] if 'public_ip_port' in row else 'N/A'
                    temper.append(f'{public_ip_address}/{public_ip_port}')
                    destination_ip_address=row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'
                    destination_port=row['destination_port'] if 'destination_port' in row else 'N/A'
                    temper.append(f'{destination_ip_address}/{destination_port}')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    temper.append(row['media_upload_download'] if 'media_upload_download' in row else 'N/A')
                    temper.append(row['media_upload_data'] if 'media_upload_data' in row else 'N/A')
                    temper.append(row['b_party_media_download_upload'] if 'b_party_media_download_upload' in row else 'N/A')
                    temper.append(row['b_party_media_download_data'] if 'b_party_media_download_data' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Media Correlation: {e}")
                    logging.exception(f"[!] ERROR Media Correlation: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story


def media_files(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/mediaFiles'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total Media Files Data: ',len(response_data))
    if response_data:
            data = []
            sr = 0
            title = "MEDIA FILES"
            columns = ['SR.NO.','PHONE NO','APPLICATION NAME','DOWNLOAD/UPLOAD','DATA SIZE(KB)','DATE TIME']
            column_widths = [2,3,4,3,3,4]
            for row in response_data:
                # print(row)
                sr += 1
                temper = []
                try:
                    temper.append(str(sr))
                    temper.append(row['phone_no'] if 'phone_no' in row else 'N/A')
                    temper.append(row['app_name'] if 'app_name' in row else 'N/A')
                    temper.append(row['media_upload_download'] if 'media_upload_download' in row else 'N/A')
                    if row['media_upload_download']=='Download':
                        data_size = round(int(row['media_download_data']) / 1024, 3)
                    elif row['media_upload_download']=='Upload':
                        data_size = round(int(row['media_upload_data']) / 1024, 3)
                    elif row['media_upload_download']=='Mixed':
                        data_size = round((int(row['media_download_data'])+int(row['media_upload_data'])) / 1024, 3)
                    else:
                        data_size='N/A'
                    temper.append(data_size)
                    temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
                    data.append(temper)
                except Exception as e:
                    print(f"[!] ERROR Media Files: {e}")
                    logging.exception(f"[!] ERROR Media Files: {e} \n [i] Error data: {row}\n")
            story.extend(create_table(title, columns, column_widths, data))
    return story

    


'''CDR total IMSI'''
def imsi(d, jwt_token,rows_to_show):
    story = []
    data = []
    sr = 0
    title = "TABLE OF IMSI" 
    columns = ['SR.NO.','PHONE NO','IMSI']
    column_widths = [2,8.5,8.5]
    url = 'http://localhost:3000/api/deviceIdentification/imsi'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    response_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total IMSI Count: ',len(response_data))

    if response_data:
        for row in response_data:
            sr += 1
            temper = []
            try:
                temper.append(str(sr))
                temper.append((str(row['phone_no'])) if 'phone_no' in row else 'N/A')
                temper.append((str(row['imsi_no'])) if 'imsi_no' in row else 'N/A')
                # temper.append((str(row['on_imei_no'])) if 'on_imei_no' in row else '')
                data.append(temper)
            except Exception as e:
                print(f"[!] ERROR in IMSI Count: {e}")
                logging.exception(f"[!] ERROR in IMSI Count: {e} \n [i] Error data: {row}\n")
        story.extend(create_table(title, columns, column_widths, data))
    return story


def imei(d, jwt_token,rows_to_show):
    story = []
    url = 'http://localhost:3000/api/case/getImei'
    body_payload = d_to_json_data_mapper(d,rows_to_show)
    imei_data = api_call_fun(url,body_payload,jwt_token)
    print('[+] Total IMEI : ',len(imei_data))    
    if imei_data:
        title = "IMEI DETAILS"
        columns = ['SR NO.', 'Phone Number', 'IMEI Number']
        column_widths = [5,7, 7]
        data = []
        sr = 0 
        for row in imei_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(str(row['phone_no']) if 'phone_no' in row else 'N/A')
            temper.append(str(row['imei_no'] if 'imei_no' in row else 'N/A'))
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story

def ipdr_correlation(d, jwt_token,rows_to_show):
    story = []
    count = 0
    url = 'http://localhost:3000/api/case/mutualCalls'
    body_payload = d_to_json_data_mapper(d,rows_to_show,extra_key_dict={"isPublicIP":0,"isPublicPort":0,"isDestinationIP":0,"isDestinationPort":0,"isSourceIP":0,"isSourcePort":0,"accuracy":1,"publictimeinterval":1800,"sourcetimeinterval":1800,"direction":2})
    # print(body_payload)
    correlation_data = api_call_fun(url,body_payload,jwt_token)
    if correlation_data:
        print('[+] Total correlation calls : ',len(correlation_data))    
        count = len(correlation_data)
        title = "KNOWN VOIP CORRELATION"
        columns = ['SR NO.','A PARTY','B PARTY','START DATE TIME','END DATE TIME','DURATION(min)','PUBLIC IPADDRESS','PUBLIC IP PORT']
        column_widths = [2,2,2,4,4,2,2,2]
        data = []
        sr = 0 
        # a_party,b_party,start_date_time,end_date_time,session_duration,public_ip_address,public_ip_port

        for row in correlation_data:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(str(row['a_party']) if 'a_party' in row else 'N/A')
            temper.append(str(row['b_party'] if 'b_party' in row else 'N/A'))
            temper.append(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'start_date_time' in row else 'N/A')
            temper.append(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S")) if 'end_date_time' in row else 'N/A')
            temper.append("{:.2f}".format(float(row['session_duration'])/60) if 'session_duration' in row else 'N/A')
            temper.append(str(row['public_ip_address'] if 'public_ip_address' in row else 'N/A'))
            temper.append(str(row['public_ip_port'] if 'public_ip_port' in row else 'N/A'))
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story

def country(d):
    table='mact.ipdr_details'
    story = []
    country_list = []
    filter_conditions = ["ip_country IS NOT NULL","ip_country != 'unknown'","ip_country != 'UNKNOWN'"]
    extra_query = "GROUP BY ip_country LIMIT 1000"      
    countries = fetch_clickhouse_data(table,d,filter_conditions=filter_conditions,extra_query=extra_query,fields=["ip_country"])

    # country_data =  fetch_pysolr_data('ipdr_details', d, ['ip_country:* AND -ip_country:unknown AND -ip_country:UNKNOWN'], {
    #     'group': 'true',
    #     'group.field': 'ip_country',
    #     'group.limit': 1000
    # })
    if countries:
        country_list = [row['ip_country'] for row in countries if 'ip_country' in row]
    else:
        country_list = []
        print('country',len(country_list))
        # count = len(country_list)
        title = "COUNTRY DETAILS"
        columns = ['SR.No', 'Country']
        column_widths = [5, 14]
        data = []
        sr = 0 
        for country in country_list:
            sr += 1
            temper = []
            temper.append(str(sr))
            temper.append(country)
            data.append(temper)
        story.extend(create_table(title, columns, column_widths, data))
    return story

def each_country(d, countries):
    story = []
    table='mact.ipdr_details'
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='th1', alignment=TA_CENTER))
    styles.add(ParagraphStyle(name='Left', alignment=TA_LEFT))
    styles.add(ParagraphStyle(name='note', alignment=TA_RIGHT, fontSize=7, textColor=HexColor('#7F7F7F')))
    styles.add(ParagraphStyle(name='tp1', alignment=TA_CENTER, fontSize=16, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='tp2', alignment=TA_LEFT, fontSize=12, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line1', alignment=TA_CENTER, fontSize=20, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line2', alignment=TA_CENTER, fontSize=12, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line3', alignment=TA_CENTER, fontSize=9, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Right', alignment=TA_RIGHT))
    styleN = styles["BodyText"]
    s = Spacer(1, 12)
    if countries:
        # note = Paragraph("(Note -Top 1000 rows displayed. For viewing more rows please create a CSV report.)", style=styles["note"])
        country_list_statement = Paragraph("DETAILS BY COUNTRY", styles["tp1"])
        story.extend([country_list_statement,s])
        # story.extend([country_list_statement,s])
        # countries = fetch_pysolr_data('ipdr_details', d, ['ip_country:* AND -ip_country:unknown AND -ip_country:UNKNOWN'], {
        #     'group': 'true',
        #     'group.field': 'ip_country',
        #     'group.limit': 1000
        # })
        # for item in countries.grouped['ip_country']['groups']:
        #     country = item['groupValue']
        #     country_name = Paragraph(country.upper(), styles["tp2"])
        #     table_rows = [
        #         [Paragraph("<font color=white><b>{} DETAILS </b></font>".format(country.upper()), styles["th1"]), '','','','','','',''],
        #         [Paragraph('Sr.No.', styleN), Paragraph('Phone no.', styleN), Paragraph('Destination IP', styleN), Paragraph('Protocol', styleN), Paragraph('Start Time', styleN), Paragraph('End Time', styleN), Paragraph('Duration', styleN), Paragraph('Service Provider', styleN)]
        #     ]
        filter_conditions = ["ip_country IS NOT NULL","ip_country != 'unknown'","ip_country != 'UNKNOWN'"]
        extra_query = "GROUP BY ip_country LIMIT 1000"     
        countries = fetch_clickhouse_data(table,d,filter_conditions=filter_conditions,extra_query=extra_query,fields=["ip_country"])

        for item in countries:
            country = item.get('ip_country', '').upper()
            if not country:
                continue

            country_name = Paragraph(country, styles["tp2"])

            table_rows = [
                [Paragraph(f"<font color=white><b>{country} DETAILS </b></font>", styles["th1"]), '', '', '', '', '', '', ''],
                [Paragraph('Sr.No.', styleN), Paragraph('Phone no.', styleN), Paragraph('Destination IP', styleN),
                Paragraph('Protocol', styleN), Paragraph('Start Time', styleN), Paragraph('End Time', styleN),
                Paragraph('Duration', styleN), Paragraph('Service Provider', styleN)]
            ]

            # country_data = fetch_pysolr_data('ipdr_details', d, [f'ip_country:{country}'], {})
            # print('country-', country, len(item['doclist']['docs']))
            sr = 0
            for row in item['doclist']['docs']:
                sr += 1
                temper = []
                temper.append(Paragraph(str(sr), styleN))
                temper.append(Paragraph(str(row['phone_no'] if 'phone_no' in row else 'N/A'), styleN))
                temper.append(Paragraph(str(row['destination_ip_address'] if 'destination_ip_address' in row else 'N/A'), styleN))
                temper.append(Paragraph(str(row['protocol_name'] if 'protocol_name' in row else 'N/A'), styleN))
                temper.append(Paragraph(str(datetime.datetime.fromtimestamp(int(row['start_date_time'])).strftime("%d-%m-%Y %H:%M:%S") if 'start_date_time' in row else 'N/A'), styleN))
                temper.append(Paragraph(str(datetime.datetime.fromtimestamp(int(row['end_date_time'])).strftime("%d-%m-%Y %H:%M:%S") if 'end_date_time' in row else 'N/A'), styleN))
                temper.append(Paragraph("%.2f" % int(int(row['session_duration'])/60) if 'session_duration' in row else 'N/A', styleN))
                temper.append(Paragraph(str(row['service_provider_detail'] if 'service_provider_detail' in row else 'N/A'), styleN))
                table_rows.append(temper)
            tx = Table(table_rows, colWidths=[1 * cm, 2 * cm, 2 * cm, 2.5 * cm, 2.7 * cm, 2.7 * cm, 2 * cm, 5 * cm])
            tx.setStyle(TableStyle([('SPAN',(0,0),(7,0)),
                ('BACKGROUND', (0,0),(7,0), HexColor('#295cad')),
                #('TEXTCOLOR',(0,1),(3,0), colors.white),
                ('BACKGROUND', (0, 1), (7, 1), HexColor('#e1e1e1')),
                # ('BACKGROUND', (0, 5), (1, 5), HexColor('#e1e1e1')),
                ('INNERGRID', (0,0), (-1,-1), 0.25, HexColor('#295cad')),
                
                ('BOX', (0,0), (7,(len(table_rows)-1)), 0.25, HexColor('#ababab')),
                ('ALIGN',(0,0),(7,(len(table_rows)-1)),'LEFT'),
                ]))
            story.extend([s, country_name, s, tx, PageBreak()])
    return story

def get_counts(d,phone_no,jwt_token):
    d_copy=d.copy()
    d_copy['phone_no']=phone_no

    url = 'http://localhost:3000/api/case/dashboardData'
    url2 = 'http://localhost:3000/api/case/getAllBpartyByCaseId'
    body_payload = d_to_json_data_mapper_for_count(d_copy)
    counts = api_call_fun(url,body_payload,jwt_token)
    voip_bparty_response = api_call_fun(url2,body_payload,jwt_token)
    # counts = {'voip_count': voip_count, 'domain_count': domain_count, 'app_count': app_count, 'vpn_count': vpn_count, 'imei_count': imei_count, 'country_count': country_count}
    # [{'calls_total': 3, 'vpn_total': 1, 'apkIpa': 45, 'imei_total': 1, 'domain_total': 26, 'countries_total': 11, 'total_files': 5066, 'mutualCalls_total': 5, 'b_party_total': 1, 'voip_count': 7}]    print(counts)
    print("JWT Token:", jwt_token)
    print("API Response for counts:", counts)
    print("API Response for voip_bparty_response:", voip_bparty_response)
    count_dict={}
    count_dict['voip_count']=len(voip_bparty_response)
    count_dict['domain_count']=counts[0]['domain_total']
    count_dict['app_count']=counts[0]['apkIpa']
    count_dict['vpn_count']=counts[0]['vpn_total']
    count_dict['imei_count']=counts[0]['imei_total']
    count_dict['country_count']=counts[0]['countries_total']
    return count_dict


def info(d, data, country_list, top_5_apps, recent_imei_imsi_cell_id, recent_activity):
    # def report_summary_builder(d, data, country_list, recent_imei_imsi_cell_id, recent_activity):
    #     dd_list = []
    #     if 'phone_no' in d:
    #         dd_list.append("Target with mobile number <b>{0}</b> is :-".format(d['phone_no']))
    #     if 'TOTAL DEVICES' in data:
    #         dd_list.append("Using <b>{0}</b> phone(s) for connection(s)".format(data['TOTAL DEVICES']))
    #     elif 'imei' in d:
    #         dd_list.append("Using IMEI as <b>{0}</b>".format(d['imei']))
    #     elif 'imsi' in d:
    #         dd_list.append("Using IMSI <b>{0}</b>".format(d['imsi']))
    #     elif 'publicIp' in d:
    #         dd_list.append("Using public IPs <b>{0}</b>".format(d['publicIp']))
    #     elif 'sourceIp' in d:
    #         dd_list.append("Using source IPs <b>{0}</b>".format(d['sourceIp']))
    #     elif 'destination_ip_address' in d:
    #         dd_list.append("Using destination IPs <b>{0}</b>".format(d['destination_ip_address']))

    #     if 'TOTAL VPN' in data:
    #         dd_list.append("Using <b>{0}</b> VPN Applications for connections".format(data['TOTAL VPN']))
    #     platform_names = []#[item for item in platform_names if 'unk' not in item]
    #     if platform_names:
    #         dd_list.append("Using platforms <b>{0}</b> for making calls".format(data['TOTAL VPN']))
    #     countries = [item for item in country_list if 'unk' not in item]
    #     if countries:
    #         dd_list.append("Calls is connected to various countries including <b>{0}</b>".format(", ".join(countries[:5])))
    #     if data['TOTAL APPLICATIONS']:
    #         dd_list.append("Using <b>{0}</b> mobile applications including applications like <b>{1}</b>".format(data['TOTAL APPLICATIONS'], ', '.join(top_5_apps).replace('[', '').replace(']', '')))
    #     if recent_imei_imsi_cell_id:
    #         dd_list.append(recent_imei_imsi_cell_id)
    #     if recent_activity:
    #         print("recent_activity ================")
    #         print(recent_activity)
    #         dd_list.append(recent_activity)
    #     print("report_summary_builder ---------")
    #     print(dd_list)

    #     dd = ' '.join(dd_list)
    #     return "<font color='#295cad'>" + dd + "</font>"
    
    
    def get_case_details(d):
        conn  = ipdr_conn()
        cursor = conn.cursor()
        case_query = "SELECT case_name,case_description,datetime FROM case_details where case_id ="+str(d['case_id'])
        res = cursor.execute(case_query)
        case_detail_cursor = cursor.fetchone()
        case_details = {
            "case_name": case_detail_cursor[0] if case_detail_cursor else '',
            "case_desc":case_detail_cursor[1] if case_detail_cursor else '',
            "case_datetime":case_detail_cursor[2] if case_detail_cursor else ''
        }
        conn.close()
        # print(case_details)
        return case_details
    
    def get_file_details(d):
        table='mact.ipdr_details'
        file_details = {}
        conn = ipdr_conn()
        cursor = conn.cursor()
        file_count_query = "SELECT count(file_id) FROM files_meta_details WHERE case_id = " + str(d['case_id'])
        res = cursor.execute(file_count_query)
        file_detail_cursor = cursor.fetchone()
        if file_detail_cursor:
            file_details["total_files"] = file_detail_cursor[0]

        filter_conditions = ["tower_operator IS NOT NULL"]
        extra_query = "GROUP BY tower_operator LIMIT 1"
        telecom_name_cursor = fetch_clickhouse_data(table, d, filter_conditions=filter_conditions, extra_query=extra_query,fields=["tower_operator"])
        # telecom_name_cursor = fetch_pysolr_data('ipdr_details', d, [], {
        #     'group': 'true',
        #     'group.field': 'tower_operator',
        #     'group.limit': 1
        # }, 'tower_operator')

        # telecom_data = telecom_name_cursor.grouped['tower_operator']['groups']
        # print('temp telecom data:', telecom_data)

        # Validate and process the fetched data
        if telecom_name_cursor:
            valid_operators = []

            # Iterate through each result
            for group in telecom_name_cursor:
                # Handle grouped results, if applicable
                if isinstance(group, dict) and 'tower_operator' in group:
                    valid_operators.append(group['tower_operator'])

            # Join valid operators into a single string
            if valid_operators:
                file_details['telecom_name'] = ", ".join(valid_operators)
            
        conn.close()
        return file_details
           
        # if d['phone_no']:
        #     solr_query = {
        #         'q': '*:*',
        #         'fq': f'phone_no:({d["phone_no"]})',
        #         'fl': 'mapper_name',
        #         'rows': 1
        #     }
        #     json_file= open('database.config','r').read()
        #     database = json.loads(json_file)
        #     auth = CustomAuth(database['SOLR_USERNAME'], database['SOLR_PASSWORD'])
        #     solr = pysolr.Solr(f"{database['solr_server']}:{database['solr_port']}/solr/ipdr_details",auth=auth) 
        #     response_object = solr.search(**solr_query)
        #     for item in response_object:
        #         if 'mapper_name' in item:
        #             file_details['telecom_name'] = item['mapper_name'].split('_')[0]

    
    case_details = get_case_details(d)
   
    file_details = get_file_details(d)

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='th1', alignment=TA_CENTER))
    styles.add(ParagraphStyle(name='th2', alignment=TA_LEFT))
    styles.add(ParagraphStyle(name='tt', alignment=TA_CENTER, fontSize=6))
    styles.add(ParagraphStyle(name='Line1', alignment=TA_CENTER, fontSize=20, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line2', alignment=TA_CENTER, fontSize=12, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Line3', alignment=TA_CENTER, fontSize=9, textColor= HexColor('#333333')))
    styles.add(ParagraphStyle(name='Right', alignment=TA_RIGHT))
    s = Spacer(1, 12)
    p = PageBreak() 
    if d['start_date_time']!=0 and d['end_date_time']!=0:
        start_date_time  = datetime.datetime.utcfromtimestamp(int(d['start_date_time']))
        # add some offsets in seconds 
        start_date_time = start_date_time + datetime.timedelta(seconds=19800)
        start_date_time = start_date_time.strftime("%d-%m-%Y %H:%M:%S %p")
        
        end_date_time = datetime.datetime.utcfromtimestamp(int(d['end_date_time']))
        # add some offsets in seconds 
        end_date_time = end_date_time + datetime.timedelta(seconds=19800)
        end_date_time = end_date_time.strftime("%d-%m-%Y %H:%M:%S %p")
        # d['start_end_time'] = start_date_time
        # d['end_date_time'] = end_date_time
    else:
        start_date_time = "-"
        end_date_time = "-"
        # d['start_end_time'] = start_date_time
        # d['end_date_time'] = end_date_time

    # rs = report_summary_builder(d, data, country_list, recent_imei_imsi_cell_id, recent_activity)
    '''[+] Fetch IPDR Summary (BEHAVIOURAL ANALYSIS)
        python ipdr_summary.py 95 8964023047 1672641125 1693452575 public
        ipdr_summary.exe <case-id> <mobile-number> <start-date-time-int> <end-date-time-int> <log-dir-path>
        ipdr_summary.exe 95 8964023047 1672641125 1693452575 public
    '''
    # rs = report_summary_builder(d, data, country_list)
    # print('[+ RS: ]',rs)
    print('-+'*50)
    print("[+] Start Building Behavioural Summery :")
    print('-+'*50)
    # print(d['case_id'], d['phone_no'], d['start_date_time'], d['end_date_time'], 'public', jwt_token.split(' ')[1])
    cmd = f"{d['case_id']} {d['phone_no']} {d['start_date_time']} {d['end_date_time']} 'public'"
    print(cmd)
    phone_numbers_list = str(d['phone_no']).split(',')
    rst_l=[]
    for phone_no in phone_numbers_list:
        try:
            rst = ipdr_summary.main_function('ipdr_summary.py',d['case_id'], phone_no, d['start_date_time'], d['end_date_time'], 'public')
            rst_l.extend(rst)
            rs = " ".join(rst_l)
            # rs = "<font color='#295cad'>"+rs.replace('id="summary_main"','').replace('<span >','<b>').replace('</span>','</b>')+"</font>"
            rs = "<font color='#295cad'>"+rs.replace("<span id='summary_main'>",'<b>').replace('</span>','</b>')+"</font>"
        except Exception as e:
            print(f"[!] ERROR in Behavioural Analysis: Check ipdr_summery \n", e)
            logging.exception(f"[!] ERROR in Behavioural Analysis \n [EXECUTION COMMAND]: {cmd}\n")
            rs = ""
    rows=[
        [Paragraph("<font color=white><b>CASE INFORMATION DETAILS</b></font>", styles["th1"]), ''],
        ['PHONE NUMBER', str(d['phone_no'])],
        ['CASE NAME', str(case_details['case_name'])],
        ['CASE DESCRIPTION',  textwrap.fill(case_details['case_desc'], 40)],
        ['CASE ASSIGNED DATE',  str(datetime.datetime.fromtimestamp(int(case_details['case_datetime'])/1000).strftime("%d-%m-%Y %H:%M:%S %p")) if case_details['case_datetime'] else ''],
        ['TOTAL IPDR FILES', str(file_details['total_files'])],
        ['IPDR START DATE', str(start_date_time)],
        ['IPDR END DATE', str(end_date_time)],
        ['OPERATOR NAME', str(file_details['telecom_name']) if 'telecom_name' in file_details else '-'],
        # ['OPERATOR NAME', str('General')],
        ['IMEI', str(d['imei']) if d['imei'] else '-'],
        ['IMSI', str(d['imsi']) if d['imsi'] else '-'],
        ['PUBLIC IP', Paragraph(str(d['publicIp']) if d['publicIp'] else '-', getSampleStyleSheet()["Normal"])],
        ['SOURCE IP', str(d['sourceIp']) if d['sourceIp'] else '-'],
        [
            'DESTINATION IP', 
            Paragraph(str(d['destination_ip_address']), getSampleStyleSheet()["Normal"])
        ],
        # [
        #     'BEHAVIOURAL ANALYSIS',
        #     Paragraph(str(rs), getSampleStyleSheet()["Normal"])
        # ]
    ]

    Behavioural_title = Paragraph(str('BEHAVIOURAL ANALYSIS'), getSampleStyleSheet()["Heading3"])
    Behavioural_data = Paragraph(str(rs), getSampleStyleSheet()["Normal"])

    t = Table(rows, colWidths=[4*inch,4*inch])
    t.setStyle(TableStyle([('SPAN',(0,0),(1,0)),
                            ('BACKGROUND', (0,0),(1,0), HexColor('#295cad')),
                            #('TEXTCOLOR',(0,1),(3,0), colors.white),
                            ('BACKGROUND', (0, 1), (1, 1), HexColor('#e1e1e1')),
                            ('BACKGROUND', (0, 3), (1, 3), HexColor('#e1e1e1')),
                            ('BACKGROUND', (0, 5), (1, 5), HexColor('#e1e1e1')),
                            ('BACKGROUND', (0, 7), (1, 7), HexColor('#e1e1e1')),
                            ('BACKGROUND', (0, 9), (1, 9), HexColor('#e1e1e1')),
                            ('BACKGROUND', (0, 11), (1, 11), HexColor('#e1e1e1')),
                            ('BACKGROUND', (0, 13), (1, 13), HexColor('#e1e1e1')),
                            ('BOX', (0,0), (1,(len(rows)-1)), 0.15, HexColor('#ababab')),
                            ('ALIGN',(0,0),(1,(len(rows)-1)),'LEFT'),
                            ]))
    return [s, t, s,Behavioural_title, Behavioural_data, PageBreak()]

def build_report(d, jwt_token,tab,tab_list,rows_to_show):
    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    table='mact.ipdr_details'
    report_file_name = None
    if d['start_date_time']!=0 and d['end_date_time']!= 0:
        report_file_name = database['pdf_name']+'_'+str(d['case_id'])+ str(int(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))) +'_'+str(d['case_id'])+'_'+str(datetime.datetime.fromtimestamp(int(d['start_date_time'])).strftime("%d-%m-%Y_%H_%M_%S")).replace(" ",'_')+'_'+str(datetime.datetime.fromtimestamp(int(d['end_date_time'])).strftime("%d-%m-%Y_%H_%M_%S")).replace(" ",'_')+'.pdf'
    else:
        report_file_name = database['pdf_name']+str(d['case_id'])+ str(int(datetime.datetime.now().strftime("%Y%m%d%H%M%S")))+'.pdf'
    doc = SimpleDocTemplate(os.path.join(save_directory, report_file_name), rightMargin=0.5*cm, leftMargin=0.5*cm, topMargin=0.5*cm, bottomMargin=0.5*cm, showBoundary=0)
    # doc.title = "I-ACT"
    story = []

    p1 = first_page()
    # domain_count = 0
    # app_count, top_5_apps = 0,0
    country_list = []
   
    filter_conditions = ["ip_country IS NOT NULL","ip_country != 'unknown'","ip_country != 'UNKNOWN'"]   
    extra_query = "GROUP BY ip_country LIMIT 1000"
    country_data = fetch_clickhouse_data(table,d,filter_conditions=filter_conditions,extra_query = extra_query,fields=["ip_country"])
    if country_data:  # Check if there are any rows returned
        country_list = [row['ip_country'] for row in country_data if row['ip_country']]  # Extract and filter valid country names

    # country_data =  fetch_pysolr_data('ipdr_details', d, ['ip_country:* AND -ip_country:unknown AND -ip_country:UNKNOWN'], {
    #     'group': 'true',
    #     'group.field': 'ip_country',
    #     'group.limit': 1000
    # })
    # if country_data.grouped['ip_country']['groups']:
    #     country_list = [item['groupValue'] for item in country_data.grouped['ip_country']['groups']]
    if 'Pakistan' in country_list:
        country_list.remove('Pakistan')
        country_list = ['Pakistan'] + country_list
    # data, p3 = stats(counts, d)
    phone_numbers_list = str(d['phone_no']).split(',')
    all_p3_values = []   
    for phone_no in phone_numbers_list:
        counts = get_counts(d,phone_no,jwt_token)
        data, p3= stats(counts, d,phone_no)
        all_p3_values.append(p3)

    top_5_apps = []
    filter_conditions = ["app_name IS NOT NULL"]
    extra_query = "GROUP BY app_name LIMIT 1"
    response_data = fetch_clickhouse_data(table,d,filter_conditions=filter_conditions,extra_query=extra_query,fields=["app_name"])

    if response_data:
        for row in response_data:
            app_name = row.get('app_name')  
            count = row.get('count', 0)  
            
            if app_name:  
                top_5_apps.append([app_name, count])

# `top_5_apps` now contains the top 5 apps and their counts

    # top_5_apps = []
    # response_json = fetch_pysolr_data('ipdr_details', d, ['app_name:*'], {
    #     'rows': 0,
    #     'group': 'true',
    #     'group.field': 'app_name',
    #     'group.limit': 1
    # })
    # groups = response_json.grouped['app_name']['groups']
    # if groups:
    #     for group in groups:
    #         key = group['groupValue']
    #         count = group['doclist']['numFound']
    #         top_5_apps.append([key, count])

    top_5_apps = sorted(top_5_apps, key=lambda x: x[1], reverse=True)
    top_5_apps = [app[0] for app in top_5_apps[:5]]
    recent_imei_imsi_cell_id, recent_activity = recent(d)
    p2 = info(d, data, country_list, top_5_apps, recent_imei_imsi_cell_id, recent_activity) 
    

    story.extend(p1)
    story.extend(p2)
    # story.extend(p3)
    for p3 in all_p3_values:
        story.extend(p3)

    if tab=='INDIVIDUAL':
        if 'Voip Call Bparty' in tab_list:
            p4 = voip_page(d, jwt_token,rows_to_show)
            story.extend(p4)
        if 'Visited Domains' in tab_list:
            p5 = domain_page(d)
            story.extend(p5)
        p6= apk_ipa(d)
        story.extend(p6)
        if 'Known Voip Correlation' in tab_list:
            p7 = ipdr_correlation(d, jwt_token,rows_to_show)
            story.extend(p7)
        if 'VPN Call Correlation' in tab_list:
            p8=vpn_call_correlation(d,jwt_token,rows_to_show)
            story.extend(p8)
        if 'VPN List' in tab_list:
            p9 = vpn_list(d, jwt_token,rows_to_show)
            story.extend(p9)
        if 'TOR Identification' in tab_list:
            p10= tor_identification(d,jwt_token,rows_to_show)
            story.extend(p10)
        if 'VPN Bparty List' in tab_list:
            p11=vpn_bparty_list(d,jwt_token,rows_to_show)
            story.extend(p11)
        if 'Watch List' in tab_list:
            p12= watch_list(d,jwt_token,rows_to_show)
            story.extend(p12)
        if 'IP Locations' in tab_list:
            p13 = country(d)
            story.extend(p13)
            p14 = each_country(d, country_list)
            story.extend(p14)
        if 'Chatting and Surfing Application' in tab_list:
            p15= chatting_nd_surfing_apps(d,jwt_token,rows_to_show)
            story.extend(p15)
        if 'Calling Application' in tab_list:
            p16= calling_apps(d,jwt_token,rows_to_show)
            story.extend(p16)
        if 'Crypto Application' in tab_list:
            p17= crypto_apps(d,jwt_token,rows_to_show)
            story.extend(p17)
        if 'Drone Application' in tab_list:
            p18= drone_apps(d,jwt_token,rows_to_show)
            story.extend(p18)
        if 'News Application' in tab_list:
            p19= news_apps(d,jwt_token,rows_to_show)
            story.extend(p19)
        if 'Streaming media Application' in tab_list:
            p20= streaming_media_apps(d,jwt_token,rows_to_show)
            story.extend(p20)
        if 'Wallet Application' in tab_list:
            p21= wallet_apps(d,jwt_token,rows_to_show)
            story.extend(p21)
        if 'Government Application' in tab_list:
            p22= govt_apps(d,jwt_token,rows_to_show)
            story.extend(p22)
        if 'Mail Application' in tab_list:
            p23= mail_apps(d,jwt_token,rows_to_show)
            story.extend(p23)
        if 'Shopping Application' in tab_list:
            p24= shopping_apps(d,jwt_token,rows_to_show)
            story.extend(p24)
        if 'File Sharing Application' in tab_list:
            p25= file_sharing_apps(d,jwt_token,rows_to_show)
            story.extend(p25)
        if 'Remote Desktop Application' in tab_list:
            p26= remote_desktop_apps(d,jwt_token,rows_to_show)
            story.extend(p26)
        if 'Games Application' in tab_list:
            p27= games_apps(d,jwt_token,rows_to_show)
            story.extend(p27)
        if 'Betting Application' in tab_list:
            p28= betting_apps(d,jwt_token,rows_to_show)
            story.extend(p28)
        if 'District wise top 3 Locations' in tab_list:
            p29, pb= district_location(d,rows_to_show)
            story.extend(p29)
            if pb:
                story.append(PageBreak())
        if 'No Network Analysis' in tab_list:
            p30=no_network_analysis(d,jwt_token,tab,rows_to_show)
            story.extend(p30)
        if 'Important Travel Routes' in tab_list:
            p31=important_travel_routes(d,rows_to_show)
            story.extend(p31)
        if 'Visited Rail/Bus/Airport' in tab_list:
            p32=visited_transport(d, jwt_token,rows_to_show)
            story.extend(p32)
        if 'Tower Movements' in tab_list:
            p33=tower_movement(d, jwt_token,rows_to_show)
            story.extend(p33)
        if 'Phone Change' in tab_list:
            p34=phone_change(d, jwt_token,rows_to_show)
            story.extend(p34)
        if 'Mobile Phones' in tab_list:
            p35=mobile_phones(d,jwt_token,tab,rows_to_show)
            story.extend(p35)
        if 'IMEI' in tab_list:
            p36 = imei(d, jwt_token,rows_to_show)
            story.extend(p36)
        if 'IMSI' in tab_list:
            p37 = imsi(d, jwt_token,rows_to_show)
            story.extend(p37) 
        if 'Media Files' in tab_list:
            p38= media_files(d, jwt_token,rows_to_show)
            story.extend(p38)
        if 'Media Correlation' in tab_list:
            p38= media_correlation(d, jwt_token,rows_to_show)
            story.extend(p38)
        if 'Plain Text Credentials' in tab_list:
            p39= plain_text_credentials(d, jwt_token,rows_to_show)
            story.extend(p39)
        if 'Extracted Media' in tab_list:
            p40= extracted_media(d, jwt_token,rows_to_show)
            story.extend(p40)
    elif tab=='CLUSTER':
        if 'P2P correlation Graph' in tab_list:
            p4=p_to_p_correlation_graph(d,jwt_token,rows_to_show)
            story.extend(p4)
        if 'Destination Correlation Graph' in tab_list:
            p5=destination_correlation_graph(d,jwt_token,rows_to_show)
            story.extend(p5)
        if 'APK/IPA Correlation Graph' in tab_list:
            p6=apk_ipa_correlation_graph(d,jwt_token,rows_to_show)
            story.extend(p6)
        if 'Common Connection' in tab_list:
            p7=common_connection(d,jwt_token,rows_to_show)
            story.extend(p7)
        if 'Tower Movements' in tab_list:
            p8=tower_movement(d,jwt_token,rows_to_show)
            story.extend(p8)
    elif tab=='DISCOVER UNKNOWN':
        if 'Voip Call Bparty' in tab_list:
            p4 = voip_page(d, jwt_token,rows_to_show)
            story.extend(p4)
        if 'Visited Domains' in tab_list:
            p5 = domain_page(d)
            story.extend(p5)
        if 'VPN List' in tab_list:
            p6 = vpn_list(d, jwt_token,rows_to_show)
            story.extend(p6)
        if 'VPN B-Party list' in tab_list:
            p7=vpn_bparty_list(d,jwt_token,rows_to_show)
            story.extend(p7)
        if 'TOR Identification' in tab_list:
            p8= tor_identification(d,jwt_token,rows_to_show)
            story.extend(p8)
        if 'Chatting and surfing Application' in tab_list:
            p9= chatting_nd_surfing_apps(d,jwt_token,rows_to_show)
            story.extend(p9)
        if 'Calling Application' in tab_list:
            p10= calling_apps(d,jwt_token,rows_to_show)
            story.extend(p10)
        if 'Crypto Application' in tab_list:
            p11= crypto_apps(d,jwt_token,rows_to_show)
            story.extend(p11)
        if 'Drone Application' in tab_list:
            p12= drone_apps(d,jwt_token,rows_to_show)
            story.extend(p12)
        if 'News Application' in tab_list:
            p13= news_apps(d,jwt_token,rows_to_show)
            story.extend(p13)
        if 'Mail Application' in tab_list:
            p14= mail_apps(d,jwt_token,rows_to_show)
            story.extend(p14)
        if 'Streaming media Application' in tab_list:
            p15= streaming_media_apps(d,jwt_token,rows_to_show)
            story.extend(p15)
        if 'Wallet Application' in tab_list:
            p16= wallet_apps(d,jwt_token,rows_to_show)
            story.extend(p16)
        if 'Government Application' in tab_list:
            p17= govt_apps(d,jwt_token,rows_to_show)
            story.extend(p17)
        if 'Shopping Application' in tab_list:
            p18= shopping_apps(d,jwt_token,rows_to_show)
            story.extend(p18)
        if 'File Sharing Application' in tab_list:
            p19= file_sharing_apps(d,jwt_token,rows_to_show)
            story.extend(p19)
        if 'Remote Desktop Application' in tab_list:
            p20= remote_desktop_apps(d,jwt_token,rows_to_show)
            story.extend(p20)
        if 'Games Application' in tab_list:
            p21= games_apps(d,jwt_token,rows_to_show)
            story.extend(p21)
        if 'Betting Application' in tab_list:
            p22= betting_apps(d,jwt_token,rows_to_show)
            story.extend(p22)
        if 'Cross Country' in tab_list:
            p23 = country(d)
            story.extend(p23)
            p24 = each_country(d, country_list)
            story.extend(p24)
        if 'Vacuum Analysis' in tab_list:
            p25=no_network_analysis(d,jwt_token,tab,rows_to_show)
            story.extend(p25)
        if 'Mobile Brand' in tab_list:
            p26=mobile_phones(d,jwt_token,tab,rows_to_show)
            story.extend(p26)
    else:
        print('Tab Name is Invailid')
        print('[i] Note: It should be INDIVIDUAL, CLUSTER Or DISCOVER UNKNOWN')

    doc.build(story)
    update_progress(report_id,2,report_file_name)
    #os.chdir(path)

if __name__ == '__main__':
    arg = sys.argv
    if len(arg) == 6:
        report_id = arg[1]
        rows_to_show=arg[2]
        jwt_token = arg[3]
        tab_name=arg[4].upper()
        tab_list=arg[5].split(',')
        dict_report = reports_mssql_table(report_id)
        if dict_report:
            # jwt_token = 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJJRCI6MSwiZW1haWwiOiJhZG1pbm5ld0BnbWFpbC5jb20iLCJyb2xlIjoxLCJuYW1lIjoiYWRtaW4iLCJ1dWlkX2NvZGUiOiI3ZmU5ODIyYS01NzdiLTRkNGMtOGU5OS0zZDhhN2NjMDQzYjgiLCJtZWRpYV9jb3JyZWxhdGlvbl9yYW5nZSI6OTUsInRyYXZlbGluZ19kaXN0YW5jZSI6MTAsImlhdCI6MTY5ODczMDE1OH0.I5DpLkaRcJZQ6rNXtgVXbwruUF74W5ATLqHL8UK6aQU'
            # logging.basicConfig(filename=os.path.join(log_dir_path, f"{arg[0].split('.')[0]}.log"), level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            jwt_token = 'Bearer ' + jwt_token
            dict_report['report_id'] = report_id
            update_progress(dict_report['report_id'],1,'')
            build_report(dict_report, jwt_token,tab_name,tab_list,rows_to_show)
        else:
            print(f'report id - {report_id} does not exists or already created')
    else:
        print('Use the command: "{} <Report-ID> <No of Rows> <JWT-Token> <TAB NAME> <Tab List> "'.format(arg[0]))
        print('Example: "{} 10057 no_of_rows Bearer_token tab_name tab_list "'.format(arg[0]))
        print('[i] Note: Pass JWT-Token in Double-Quotes as argument.')