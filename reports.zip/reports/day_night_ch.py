# DAY NIGHT SCRIPT
# Author: Sresht
# Date: 27th Nov 2023

# Import necessary libraries/modules at the beginning of your script.
import warnings
warnings.filterwarnings('ignore')
import sys
import numpy as np
import pandas as pd
import clickhouse_connect
import logging
import os
import pysolr
from math import radians, sin, cos, sqrt, atan2
import json,requests,base64
# from pprint import pprint
table = 'ipdr_details'
class CustomAuth(requests.auth.AuthBase):
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def __call__(self, r):
        # Add your custom authentication logic here
        auth_string = f'{self.username}:{self.password}'.encode('utf-8')
        auth_bytes = base64.b64encode(auth_string)
        auth_header = f'Basic {auth_bytes.decode("utf-8")}'
        r.headers['Authorization'] = auth_header
        return r
    
def clickhouse_connection():    

    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    
    client = clickhouse_connect.get_client(
            host=database['click_house_node1'],
            port=database['click_house_port'],
            user=database['click_house_username'],
            password=database['click_house_password'],
            database=database['click_house_database'],
        )
    return client

def fetch_clickhouse_data(core_name, param_dict, filter_conditions, add_clickhouse_query, fl=None, ext_param_dict=None):
    query_conditions = []

    if 'mapper_name' in param_dict and param_dict['mapper_name']:
        query_conditions.append(f"mapper_name = '{param_dict['mapper_name']}'")
    if 'case_id' in param_dict and param_dict['case_id']:
        query_conditions.append(f"case_id = '{param_dict['case_id']}'")
    if 'phone_no' in param_dict and param_dict['phone_no']:
        query_conditions.append(f"phone_no = '{param_dict['phone_no']}'")
    if 'imei' in param_dict and param_dict['imei']:
        query_conditions.append(f"imei_no:{param_dict['imei']}")
    if 'imsi' in param_dict and param_dict['imsi']:
        query_conditions.append(f"imsi_no:{param_dict['imsi']}")
    if 'start_date_time' in param_dict and param_dict['start_date_time']:
        query_conditions.append(f"start_date_time >= '{param_dict['start_date_time']}'")
    if 'end_date_time' in param_dict and param_dict['end_date_time']:
        query_conditions.append(f"end_date_time <= '{param_dict['end_date_time']}'")

    if 'sourceIp' in param_dict:
        if param_dict['sourceIp']:
            if param_dict['sourceIp'] != 'all':
                ips = param_dict['sourceIp'].split(',')
                query_conditions.append("(" + " OR ".join(f"source_ip_address = '{ip}'" for ip in ips) + ")")
            else:
                query_conditions.append("source_ip_address IS NOT NULL")

    if 'publicIp' in param_dict:
        if param_dict['publicIp']:
            if param_dict['publicIp'] != 'all':
                ips = param_dict['publicIp'].split(',')
                query_conditions.append("(" + " OR ".join(f"public_ip_address = '{ip}'" for ip in ips) + ")")
            else:
                query_conditions.append("public_ip_address IS NOT NULL")

    if 'destination_ip_address' in param_dict:
        if param_dict['destination_ip_address']:
            if param_dict['destination_ip_address'] != 'all':
                ips = param_dict['destination_ip_address'].split(',')
                query_conditions.append("(" + " OR ".join(f"destination_ip_address = '{ip}'" for ip in ips) + ")")
            else:
                query_conditions.append("destination_ip_address IS NOT NULL")

    
    query_conditions.extend(filter_conditions)

    clickhouse_query = f"SELECT * FROM {core_name}"

    # Add WHERE clause only if there are conditions
    if query_conditions:
        clickhouse_query += " WHERE " + " AND ".join(query_conditions)

    # Add additional query (if any)
    if add_clickhouse_query:
        clickhouse_query += f" {add_clickhouse_query}"

    print('clickhouse_query', clickhouse_query)
    
    client = clickhouse_connection()
    response = client.query(clickhouse_query)

    return response.result_rows


# def fetch_pysolr_data(core_name, param_dict, filter, add_solr_query, fl=None, ext_param_dict=None):
#     print("fetch_pysolr_data runs")
#     query = []
#     # if is_cdr=='yes':
#     #         query.append(f"mapper_name:*CDR*")
#     # if is_cdr=='no':
#     #         query.append(f"-mapper_name:*CDR*")
#     if 'mapper_name' in param_dict:
#         if param_dict['mapper_name']:
#             query.append(f"mapper_name:{param_dict['mapper_name']}")
#     if 'case_id' in param_dict:
#         if param_dict['case_id']:
#             query.append(f"case_id:{param_dict['case_id']}")
#     if 'phone_no' in param_dict:
#         if param_dict['phone_no']:    
#             query.append(f"phone_no:{param_dict['phone_no']}")
#     if 'imei' in param_dict:
#         if param_dict['imei']:
#             query.append(f"imei_no:{param_dict['imei']}")
#     if 'imsi' in param_dict:
#         if param_dict['imsi']:
#             query.append(f"imsi_no:{param_dict['imsi']}")
#     if 'start_date_time' in param_dict:
#         if param_dict['start_date_time']:
#             query.append(f"start_date_time:[{param_dict['start_date_time']} TO *]")
#     if 'end_date_time' in param_dict:
#         if param_dict['end_date_time']:
#             query.append(f"start_date_time:[* TO {param_dict['end_date_time']}]")
#     if 'sourceIp' in param_dict:
#         if param_dict['sourceIp']:
#             if param_dict['sourceIp'] != 'all':
#                 query.append(" OR ".join(f'source_ip_address:"{ip}"' for ip in param_dict['sourceIp'].split(',')))
#             else:
#                 query.append(f"source_ip_address:*")
#     if 'publicIp' in param_dict:
#         if param_dict['publicIp']:
#             if param_dict['publicIp'] != 'all':
#                 query.append(" OR ".join(f'public_ip_address:"{ip}"' for ip in param_dict['publicIp'].split(',')))
#             else:
#                 query.append(f"public_ip_address:*")
#     if 'destination_ip_address' in param_dict:
#         if param_dict['destination_ip_address']:
#             if param_dict['destination_ip_address'] != 'all':
#                 query.append(" OR ".join(f'destination_ip_address:"{ip}"' for ip in param_dict['destination_ip_address'].split(',')))
#             else:
#                 query.append(f"destination_ip_address:*")
#     if ext_param_dict:
#         query.append(ext_param_dict)
#     query.extend(filter)
    
#     solr_query = {
#         'q': '*:*'
#     }

#     if fl:
#         solr_query.update({'fl': fl})

#     if query:
#         solr_query.update({'fq': query})

#     if add_solr_query:
#         solr_query.update(add_solr_query)
    
#     # solr_query.update({'rows': 100000})
#     json_file= open('database.config','r').read()
#     database = json.loads(json_file)
#     auth = CustomAuth(database['SOLR_USERNAME'], database['SOLR_PASSWORD'])
#     solr = pysolr.Solr(f"{database['solr_server']}:{database['solr_port']}/solr/{core_name}",auth=auth)
#     response_object = solr.search(**solr_query)
#     return response_object



def solr_to_df(solr_response):
    docs = [doc for doc in solr_response]
    df = pd.DataFrame(docs)
    return df

def clickhouse_to_df(clickhouse_response):
    docs = [doc for doc in clickhouse_response]
    df = pd.DataFrame(docs)
    return df

def haversine(lat1, lon1, lat2, lon2):
    # Convert latitude and longitude from degrees to radians
    lat1 = radians(lat1)
    lon1 = radians(lon1)
    lat2 = radians(lat2)
    lon2 = radians(lon2)

    # Radius of the Earth in kilometers
    radius = 6371.0

    # Calculate the differences between latitudes and longitudes
    dlat = lat2 - lat1
    dlon = lon2 - lon1

    # Haversine formula
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    # Calculate the distance
    distance = radius * c

    return distance

# Define functions or classes (if applicable) to encapsulate your code logically.
def main_function(script_name, case_id, mobile_number, imei_number, imsi_number, start_date_time, end_date_time, log_dir_path):
    # Your code for the main functionality of the script goes here.
    # Check if the file exists
    # Configure the logging settings
    logging.basicConfig(filename=os.path.join(log_dir_path, f"{script_name.split('.')[0]}.log"), level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    d = {
        "case_id": case_id,
        "start_date_time": int(start_date_time),
        "end_date_time": int(end_date_time),
        "phone_no": mobile_number,
        "imei_no": int(imei_number),
        "imsi_no": int(imsi_number),
        # "is_cdr": is_cdr
    }
    nd = d.copy()

    # fetch all rows/docs
    # day_df = solr_to_df(fetch_pysolr_data('ipdr_details', d, ['office_hours:YES', 'tower_latitude:*', 'tower_longitude:*'], {
    #     'rows': 100000000
    # }))
   

    filter_conditions = ["office_hours = 'YES'", "tower_latitude IS NOT NULL", "tower_longitude IS NOT NULL"]
    add_clickhouse_query = "LIMIT 100000000"
    day_df = clickhouse_to_df(fetch_clickhouse_data(core_name='ipdr_details',param_dict=d, filter_conditions=filter_conditions,add_clickhouse_query=add_clickhouse_query))

    print("length of daydf:",len(day_df))
    print(day_df.columns)

    grouped = day_df.groupby(['tower_latitude', 'tower_longitude']).size().reset_index(name='Count')
    day_df = pd.merge(day_df, grouped, on=['tower_latitude', 'tower_longitude'], how='left')
    day_df = day_df.drop_duplicates(subset=['tower_latitude', 'tower_longitude'])
    day_df = day_df.sort_values(by=['Count'], ascending=False)
    day_df = day_df.head(20)
        
    day_df = day_df[['tower_latitude', 'tower_longitude', 'tower_azimuth', 'tower_location', 'cell_id']]
    day_df['tower_azimuth'].fillna('0.0',inplace=True)
    
    # day_df['tower_azimuth']=day_df['tower_azimuth'].replace(NaN,'0.0')
    
    day_dict_2 = {}
    day_dict_all = {}

    for idx1, row1 in day_df.iterrows():
        for idx2, row2 in day_df.iterrows():
            if row1['tower_latitude'] != row2['tower_latitude'] and row1['tower_longitude'] != row2['tower_longitude']:
                # print(row1['tower_latitude'], row1['tower_longitude'], '<------>', row2['tower_latitude'], row2['tower_longitude'])
                d = haversine(row1['tower_latitude'], row1['tower_longitude'], row2['tower_latitude'], row2['tower_longitude'])
                if d <= 2:
                    day_dict_2[f"{row1['tower_latitude']}{row1['tower_longitude']}{row1['tower_azimuth']}{ row1['tower_location']}{ row1['cell_id']}"] = {
                        "tower_latitude": row1['tower_latitude'],
                        "tower_longitude":  row1['tower_longitude'],
                        "tower_azimuth": row1['tower_azimuth'],
                        "tower_location": row1['tower_location'],
                        "cell_id": row1['cell_id']
                    }
                    day_dict_2[f"{row2['tower_latitude']}{row2['tower_longitude']}{row2['tower_azimuth']}{row2['tower_location']}{ row2['cell_id']}"] = {
                        "tower_latitude": row2['tower_latitude'],
                        "tower_longitude":  row2['tower_longitude'],
                        "tower_azimuth": row2['tower_azimuth'],
                        "tower_location": row2['tower_location'],
                        "cell_id": row2['cell_id']
                    }
                day_dict_all[f"{row1['tower_latitude']}{row1['tower_longitude']}{row1['tower_azimuth']}{ row1['tower_location']}{ row1['cell_id']}"] = {
                        "tower_latitude": row1['tower_latitude'],
                        "tower_longitude":  row1['tower_longitude'],
                        "tower_azimuth": row1['tower_azimuth'],
                        "tower_location": row1['tower_location'],
                        "cell_id": row1['cell_id']
                    }
                day_dict_all[f"{row2['tower_latitude']}{row2['tower_longitude']}{row2['tower_azimuth']}{row2['tower_location']}{ row2['cell_id']}"] = {
                        "tower_latitude": row2['tower_latitude'],
                        "tower_longitude":  row2['tower_longitude'],
                        "tower_azimuth": row2['tower_azimuth'],
                        "tower_location": row2['tower_location'],
                        "cell_id": row2['cell_id']
                    }
                

     # fetch all rows/docs
    filter_conditions = ["time_shift = 'NIGHT'", "tower_latitude IS NOT NULL", "tower_longitude IS NOT NULL"]
    add_clickhouse_query = "100000000"
    night_df = clickhouse_to_df(fetch_clickhouse_data('ipdr_details', param_dict=d, filter_conditions=filter_conditions,add_clickhouse_query=add_clickhouse_query))
    # night_df = solr_to_df(fetch_pysolr_data('ipdr_details', nd, ['time_shift:NIGHT', 'tower_latitude:*', 'tower_longitude:*'], {
    #     'rows': 100000000
    # }))
    grouped = night_df.groupby(['tower_latitude', 'tower_longitude']).size().reset_index(name='Count')
    night_df = pd.merge(night_df, grouped, on=['tower_latitude', 'tower_longitude'], how='left')
    night_df = night_df.drop_duplicates(subset=['tower_latitude', 'tower_longitude'])
    night_df = night_df.sort_values(by=['Count'], ascending=False)
    night_df = night_df.head(20)
    night_df = night_df[['tower_latitude', 'tower_longitude', 'tower_azimuth', 'tower_location', 'cell_id']]
    night_df['tower_azimuth'].fillna('0.0',inplace=True)

    
    night_dict_2 = {}
    night_dict_all = {}

    for idx1, row1 in night_df.iterrows():
        for idx2, row2 in night_df.iterrows():
            if row1['tower_latitude'] != row2['tower_latitude'] and row1['tower_longitude'] != row2['tower_longitude']:
                # print(row1['tower_latitude'], row1['tower_longitude'], '<------>', row2['tower_latitude'], row2['tower_longitude'])
                d = haversine(row1['tower_latitude'], row1['tower_longitude'], row2['tower_latitude'], row2['tower_longitude'])
                if d <= 2:
                    night_dict_2[f"{row1['tower_latitude']}{row1['tower_longitude']}{row1['tower_azimuth']}{ row1['tower_location']}{ row1['cell_id']}"] = {
                        "tower_latitude": row1['tower_latitude'],
                        "tower_longitude":  row1['tower_longitude'],
                        "tower_azimuth": row1['tower_azimuth'],
                        "tower_location": row1['tower_location'],
                        "cell_id": row1['cell_id']
                    }
                    night_dict_2[f"{row2['tower_latitude']}{row2['tower_longitude']}{row2['tower_azimuth']}{row2['tower_location']}{ row2['cell_id']}"] = {
                        "tower_latitude": row2['tower_latitude'],
                        "tower_longitude":  row2['tower_longitude'],
                        "tower_azimuth": row2['tower_azimuth'],
                        "tower_location": row2['tower_location'],
                        "cell_id": row2['cell_id']
                    }
                night_dict_all[f"{row1['tower_latitude']}{row1['tower_longitude']}{row1['tower_azimuth']}{ row1['tower_location']}{ row1['cell_id']}"] = {
                        "tower_latitude": row1['tower_latitude'],
                        "tower_longitude":  row1['tower_longitude'],
                        "tower_azimuth": row1['tower_azimuth'],
                        "tower_location": row1['tower_location'],
                        "cell_id": row1['cell_id']
                    }
                night_dict_all[f"{row2['tower_latitude']}{row2['tower_longitude']}{row2['tower_azimuth']}{row2['tower_location']}{ row2['cell_id']}"] = {
                        "tower_latitude": row2['tower_latitude'],
                        "tower_longitude":  row2['tower_longitude'],
                        "tower_azimuth": row2['tower_azimuth'],
                        "tower_location": row2['tower_location'],
                        "cell_id": row2['cell_id']
                    }
                
    result = {
        'night_data': list(night_dict_2.values())[:5] if night_dict_2 else night_dict_all,
        'day_data': list(day_dict_2.values())[:5] if day_dict_2 else day_dict_all
    }
    print(json.dumps(result))
    # j_d=json.dumps(result)
    # for x in j_d['night_data']:
    #     print(x['tower_azimuth'])
    # # print(j_d)

                
  
    logging.info(f"Execution complete for {mobile_number}")


# Check if the script is the main program being run (not imported as a module).
if __name__ == "__main__":
    # Take values from the arguments
    args = sys.argv
    # Validate the arguments
    if len(args) == 8:
        # Get the excel path from the arguments
        case_id = args[1]
        mobile_number = args[2]
        imei_number = args[3]
        imsi_number = args[4]
        start_date_time = args[5]
        end_date_time = args[6]
        log_dir_path = args[7]
        # is_cdr=args[8]
        # Call the main function to execute the script's primary logic.
        main_function(args[0], case_id, mobile_number, imei_number, imsi_number, start_date_time, end_date_time, log_dir_path)
    else:
        # Console the sample command
        print("Sample command :-")
        print(f"{args[0]} <case-id> <mobile-number> <imei-number> <imsi-number> <start-date-time-int> <end-date-time-int> <log-dir-path>")