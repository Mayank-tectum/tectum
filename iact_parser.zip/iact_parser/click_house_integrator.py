"""
Integration of clickhouse db for IPDR CDR data processing

"""
from functools import total_ordering
from re import A, U, sub
from sqlite3 import Row
from telnetlib import DET
from threading import main_thread
from tracemalloc import start
import clickhouse_connect
import pandas as pd 
import numpy as np  
import datetime
import json
import os
import platform
import multiprocessing as mp
import time
import MySQLdb
from logging import warnings,logging,info,error
import traceback
import sys
import hashlib
import random
import base64
import Levenshtein
import shutil

""" Create logs of the script to identify the errors and any other issues
"""
logging.basicConfig(filename='data_integrator.log',  level=logging.ERROR,format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
warnings.filterwarnings("ignore")
current_path = os.getcwd()

json_file= open('database.config','r').read()
database = json.loads(json_file)

#create connection with clickhouse database
# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']

taran_ip = database['taran_ip']
taran_port = database['taran_port']
matched_ips,not_matched_ips = [],[]
# msgpack.UNPACK = {'max_map_leng':100}
# connection = tarantool.connect(taran_ip,taran_port)


CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

# Prepare clickhouse configuration
clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        # Add more nodes as necessary
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    # Connect to ClickHouse
    client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
    )
    return client

# Create a ClickHouse client to work on each node
def create_client_node(node):
    try:
        client = clickhouse_connect.get_client(
            host=node["url"].replace("http://", ""),
            port=node["port"],
            username=node["username"],
            password=node["password"],
            compress=clickhouse_configs["is_use_gzip"],
        )
        return client
    except Exception as error:
        print(f"Failed to connect to ClickHouse node {node['url']}: {error}")
        return None

def data_insertion(df,table):
    if df.empty:
        print("DataFrame is empty. No data to insert.")
        return
    try:
        df = df[sorted(df.columns)].astype(str)
        client = create_client_node(clickhouse_configs["nodes"][0])  
        if client:
            client.insert(table, df.to_records(index=False).tolist(), column_names=list(df.columns))
            print(f"Data inserted successfully into table {table}.")
    except Exception as error:
        print(f"Error during data insertion: {error}")

def run_delete_query_on_all_nodes(delete_query):
    for node in clickhouse_configs["nodes"]:
        try:
            # Initialize the client for the current node
            client = create_client_node(node)
            client.command(delete_query)
            print(f"Successfully executed DELETE query on node {node['url']}")

        except Exception as error:
            print(f"Error executing DELETE query on node {node['url']}: {error}")
            # If query fails on this node, move to the next one

# Select data from a ClickHouse table
def select_data(query):
    try:
        client = create_client_node(clickhouse_configs["nodes"][0])  # Use the first node for selection 
        if client:
            result = client.query(query)
            print("Query executed successfully.")
            return result.result_rows, result.columns
    except Exception as error:
        print(f"Error during SELECT query execution: {error}")
        return None

# select data from clickhouse and convert it to dataframe
def select_data_df(query):
    try:
        client = create_client_node(clickhouse_configs["nodes"][0])  # Use the first node for selection
        if client:
            result = client.query(query)
            print("Query executed successfully.")
            return result
    except Exception as error:
        print(f"Error during SELECT query execution: {error}")
        return None


# Update data in a ClickHouse table
def update_data(update_query):
    for node in clickhouse_configs["nodes"]:
        try:
            client = create_client_node(node)
            if client:
                client.command(update_query)
                print(f"Successfully executed UPDATE query on node {node['url']}")
        except Exception as error:
            print(f"Error executing UPDATE query on node {node['url']}: {error}")

# run opitmize query on all nodes in clickhouse
def run_optimize_query_on_all_nodes(table_name):
    for node in clickhouse_configs["nodes"]:
        try:
            # Initialize the client for the current node
            client = create_client_node(node)
            optimize_query = f"OPTIMIZE TABLE {table_name} FINAL"
            client.command(optimize_query)
            print(f"Successfully executed OPTIMIZE query on node {node['url']}")
        except Exception as error:
            print(f"Error executing OPTIMIZE query on node {node['url']}: {error}")
            # If query fails on this node, move to the next one

# create connection with mysql database
def ipdr_conn():
    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    return MySQLdb.connect(
            host=database['database_url'],
            port=database['database_port'],  # Replace with your desired port number
            user=database['database_user'],
            passwd=database['database_password'],
            db=database['database_name']
            )


def delete_records_phone_no_case_id(phone_no, case_id, phone_field_name, table_name):
    # If phone_no is provided, filter by both case_id and phone_no
    if phone_no == '':
        query = f"ALTER TABLE {table_name} DELETE WHERE case_id = {case_id}"
    else:
        query = f"ALTER TABLE {table_name} DELETE WHERE case_id = {case_id} AND {phone_field_name} = '{phone_no}'"
    return query

# create vpn corelation integerator function
def vpn_corelation_integerator(case_id):
    print("[+] running vpn corelation integerator")
    # check for ipdr_id_session_hash in ipdr_details table
    query = f""" SELECT ipdr_id_session_hash FROM ipdr_details WHERE case_id = '{str(case_id)}' AND NOT mapper_name LIKE '%CDR%' AND is_ip_ipdr = '2' LIMIT 1;"""
    result = select_data(query)
    if result:
        delete_query = f"ALTER TABLE vpn_correlation DELETE WHERE case_id = '{str(case_id)}'"
        run_delete_query_on_all_nodes(delete_query)
        run_optimize_query_on_all_nodes('vpn_correlation')

        # Condition 1: get the count of records on the basis of filter query
        row_count_query = f"""SELECT COUNT(*) FROM ipdr_details WHERE case_id = '{str(case_id)}'
                AND mapper_name NOT LIKE '%CDR%'
                AND phone_no NOT LIKE '.*'
                AND session_duration = 0
                AND is_ip_ipdr = 0
                AND public_ip_address = destination_ip_address
                AND (is_vpn = 1 OR vpn_tor = 1 OR vpn_is_relay = 1 OR vpn_proxy = 1)
                AND destination_port NOT IN (51820, 53133)
                AND destination_port >= 10000""" 
            
        # Fetch row count
        result_row, result_column = select_data(row_count_query)
        total_rows = result_row[0][0]
        
        if total_rows > 0:
            start_counter = 0
            row_counter = total_rows
            # execute the query
            details_query = f""" SELECT phone_no, public_ip_address, source_ip_address, destination_ip_address, 
                           destination_port, start_date_time, end_date_time, vpn_name FROM ipdr_details WHERE case_id = '{str(case_id)}'
                        AND mapper_name NOT LIKE '%CDR%'
                        AND phone_no NOT LIKE '.*'
                        AND session_duration = 0
                        AND is_ip_ipdr = 0
                        AND public_ip_address = destination_ip_address
                        AND (is_vpn = 1 OR vpn_tor = 1 OR vpn_is_relay = 1 OR vpn_proxy = 1)
                        AND destination_port NOT IN (51820, 53133)
                        AND destination_port >= 10000 limit {row_counter} offset {start_counter}"""
            
            # Fetch detailed data
            row_data, column_names = select_data(details_query)

            # Create DataFrame
            ipdr_data_with_vpn_use_df = pd.DataFrame(row_data, columns=column_names)
            ipdr_data_with_vpn_use_df['case_id'] = case_id

            # Rename columns
            ipdr_data_with_vpn_use_df.rename(
                columns={
                    'start_date_time': 'aparty_start_date_time',
                    'end_date_time': 'aparty_end_date_time',
                    'phone_no': 'aparty'
                }, inplace=True)

            advanced_query = f"""
                    SELECT phone_no, destination_ip_address, start_date_time, end_date_time, destination_port
                    FROM ipdr_details
                    WHERE case_id = '{str(case_id)}'
                      AND mapper_name NOT LIKE '%CDR%'
                      AND phone_no NOT LIKE '.*'
                      AND session_duration = 0
                      AND is_ip_ipdr = 2
                      AND public_ip_address != destination_ip_address
                      AND (
                          (is_vpn = 1 OR vpn_tor = 1 OR vpn_is_relay = 1 OR vpn_proxy = 1)
                          AND destination_port IN (90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 443, 500, 4500, 
                                                   6881, 6882, 6883, 600, 1600, 4600, 1390, 3390, 1723, 
                                                   1194, 1701, 51820, 53133)
                      ) 
                      OR (
                          destination_port IN (90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 443, 500, 4500, 
                                               6881, 6882, 6883, 600, 1600, 4600, 1390, 3390, 1723, 
                                               1194, 1701, 51820, 53133)
                          AND ip_country != 'India'
                      )
                """

            # Fetch advanced data
            advanced_result_row, adnvanced_result_column = select_data(advanced_query)

            # Create DataFrame
            ipdr_data_with_vpn_call_df = pd.DataFrame(advanced_result_row, columns=adnvanced_result_column)
            # Add hash for deduplication
            ipdr_data_with_vpn_call_df['temp_session_hash_1'] = ipdr_data_with_vpn_call_df.apply(
                lambda x: hashlib.sha256(
                    f"{x.phone_no}{x.destination_ip_address}{x.destination_port}{x.start_date_time}{x.end_date_time}".encode()
                ).hexdigest(), axis=1)

            # Remove duplicates and process
            remove_duplicate_mask = ipdr_data_with_vpn_call_df.duplicated(subset='temp_session_hash_1', keep='first')
            ipdr_data_with_vpn_call_df = ipdr_data_with_vpn_call_df[~remove_duplicate_mask]
            ipdr_data_with_vpn_call_df = ipdr_data_with_vpn_call_df.sort_values('start_date_time', ascending=False).reset_index(drop=True)

            # Group by and aggregate data
            ipdr_data_with_vpn_call_df = ipdr_data_with_vpn_call_df.groupby(
                ['phone_no', 'destination_ip_address']
            ).agg({'start_date_time': 'min', 'end_date_time': 'max', 'temp_session_hash_1': 'first'}).reset_index()
            ipdr_data_with_vpn_call_df = ipdr_data_with_vpn_call_df.sort_values('start_date_time', ascending=False).reset_index(drop=True)

            ipdr_data_with_vpn_call_df.rename(columns={'phone_no': 'bparty'}, inplace=True)

            # Merge DataFrames and filter results
            merged_df = ipdr_data_with_vpn_use_df.merge(ipdr_data_with_vpn_call_df, on='destination_ip_address', how='left')
            merged_df = merged_df[(merged_df['start_date_time'] >= merged_df['aparty_start_date_time']) &
                                    (merged_df['start_date_time'] <= merged_df['aparty_end_date_time'])]

            # Drop unnecessary columns
            merged_df.drop(columns=['start_date_time', 'end_date_time', 'temp_session_hash_1', 'destination_port'], inplace=True)

            # Aggregate final output
            output_df = merged_df.groupby(['aparty', 'bparty'], as_index=False).agg(list)
            output_df['case_id'] = case_id
            output_df['destination_ip_address'] = output_df['destination_ip_address'].apply(lambda x: list(set(x)))
            output_df['vpn_name'] = output_df['vpn_name'].apply(lambda x: list(set(x)))
            output_df['total_count'] = output_df['destination_ip_address'].apply(len)
            output_df['destination_ip_address'] = output_df['destination_ip_address'].apply(lambda x: ', '.join(map(str, x)))
            output_df['vpn_name'] = output_df['vpn_name'].apply(lambda x: ', '.join(map(str, x)))
            output_df.sort_values('total_count', ascending=False, inplace=True)
            output_df = output_df[output_df['aparty'] != output_df['bparty']]
            output_df['scenario_type'] = 1
            output_df['vpn_correlation_hash'] = output_df.apply(
                lambda x: hashlib.sha256(
                    f"{x.case_id}{x.aparty}{x.destination_ip_address}{x.bparty}{x.vpn_name}{x.scenario_type}".encode()
                ).hexdigest(), axis=1)

            delete_query = delete_records_phone_no_case_id("", case_id, phone_field_name='phone_no', table_name='vpn_correlation')
            run_delete_query_on_all_nodes(delete_query)
            data_insertion(output_df,'vpn_correlation')

        # Condition 2: get the count of records on the basis of filter query
        row_count_query = f"""
            SELECT COUNT(*) AS num_found
            FROM ipdr_details
            WHERE case_id = '{str(case_id)}'
              AND NOT (mapper_name LIKE '%CDR%')
              AND session_duration = 0
              AND is_ip_ipdr = 0
              AND public_ip_address != destination_ip_address
              AND (                (
                  (is_vpn = 1 OR vpn_tor = 1 OR vpn_is_relay = 1 OR vpn_proxy = 1)
                  AND destination_port IN (90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 443, 500, 4500, 
                                           6881, 6882, 6883, 600, 1600, 4600, 1390, 3390, 1723, 
                                           1194, 1701, 51820, 53133)
                )
                OR (
                  destination_port IN (90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 443, 500, 4500, 
                                       6881, 6882, 6883, 600, 1600, 4600, 1390, 3390, 1723, 
                                       1194, 1701, 51820, 53133)
                  AND ip_country != 'India'
                )
              )
            """
        data_row, data_column = select_data(row_count_query)
        total_rows = data_row[0][0]
        if total_rows > 0:
            start_counter = 0
            row_counter = total_rows
            # Query to fetch detailed data
            details_query = f"""
            SELECT phone_no, public_ip_address, source_ip_address, destination_ip_address, 
                    destination_port, start_date_time, end_date_time, vpn_name
            FROM ipdr_details
            WHERE case_id = '{str(case_id)}'
                AND NOT (mapper_name LIKE '%CDR%')
                AND session_duration = 0
                AND is_ip_ipdr = 0
                AND public_ip_address != destination_ip_address
                AND (
                (
                    (is_vpn = 1 OR vpn_tor = 1 OR vpn_is_relay = 1 OR vpn_proxy = 1)
                    AND destination_port IN (90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 443, 500, 4500, 
                                            6881, 6882, 6883, 600, 1600, 4600, 1390, 3390, 1723, 
                                            1194, 1701, 51820, 53133)
                )
                OR (
                    destination_port IN (90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 443, 500, 4500, 
                                        6881, 6882, 6883, 600, 1600, 4600, 1390, 3390, 1723, 
                                        1194, 1701, 51820, 53133)
                    AND ip_country != 'India'
                )
                )
            LIMIT {row_counter} OFFSET {start_counter}
                """

            detail_data_row, detail_data_column = select_data(details_query)

            # create details query data frame    
            ipdr_data_with_vpn_use_df = pd.DataFrame(detail_data_row, columns=detail_data_column)
            ipdr_data_with_vpn_use_df['case_id'] = case_id

            # Add hash for deduplication
            ipdr_data_with_vpn_use_df['temp_session_hash_1'] = ipdr_data_with_vpn_use_df.apply(
                lambda x: hashlib.sha256(
                    f"{x.phone_no}{x.destination_ip_address}{x.destination_port}{x.start_date_time}{x.end_date_time}".encode()
                ).hexdigest(), axis=1)

            # Remove duplicates and process
            ipdr_data_with_vpn_use_df.drop_duplicates(subset='temp_session_hash_1', inplace=True)
            ipdr_data_with_vpn_use_df.sort_values('start_date_time', ascending=False, inplace=True)

            # Group by and aggregate data
            ipdr_data_with_vpn_use_df = ipdr_data_with_vpn_use_df.groupby(
                ['phone_no', 'destination_ip_address', 'vpn_name']
            ).agg({'start_date_time': 'min', 'end_date_time': 'max', 'temp_session_hash_1': 'first'}).reset_index()

            ipdr_data_with_vpn_use_df.rename(
                columns={
                    'start_date_time': 'aparty_start_date_time',
                    'end_date_time': 'aparty_end_date_time',
                    'phone_no': 'aparty'
                }, inplace=True)

            # further checking the records on new condition
            query = f"""
                SELECT count(*)
                FROM ipdr_details
                WHERE case_id = {str(case_id)}
                  AND mapper_name NOT LIKE '%CDR%'
                  AND phone_no != ''
                  AND session_duration = 0
                  AND is_ip_ipdr = 2
                  AND public_ip_address != destination_ip_address
                  AND (is_vpn = 1 OR vpn_tor = 1 OR vpn_is_relay = 1 OR vpn_proxy = 1)
                  AND destination_port >= 10000
                ORDER BY start_date_time
                """

            data_row, data_column = select_data(query)

            total_rows = data_row[0][0]

            if total_rows > 0:
                row_counter = total_rows
                start_counter = 0
                # Query to fetch detailed data
                query = """
                    SELECT phone_no, destination_ip_address, start_date_time, end_date_time
                    FROM ipdr_details
                    WHERE case_id = %s
                      AND mapper_name NOT LIKE '%CDR%'
                      AND phone_no != ''
                      AND session_duration = 0
                      AND is_ip_ipdr = 2
                      AND public_ip_address != destination_ip_address
                      AND (is_vpn = 1 OR vpn_tor = 1 OR vpn_is_relay = 1 OR vpn_proxy = 1)
                      AND destination_port >= 10000
                    ORDER BY start_date_time
                    LIMIT %s OFFSET %s
                    """

                data_row, data_column = select_data(query, (case_id, row_counter, start_counter))
                # Create DataFrame for next stage
                ipdr_data_with_vpn_call_df = pd.DataFrame(data_row, columns=data_column)

                # Merge the dataframes and filter based on start and end times
                merged_df = ipdr_data_with_vpn_use_df.merge(ipdr_data_with_vpn_call_df, on='destination_ip_address', how='left')
                merged_df = merged_df[(merged_df['start_date_time'] >= merged_df['aparty_start_date_time']) & 
                                      (merged_df['start_date_time'] <= merged_df['aparty_end_date_time'])]
                merged_df = merged_df.drop(["start_date_time", "end_date_time", "temp_session_hash_1"], axis=1)

                # Compute output DataFrame
                output_df = merged_df.groupby(['aparty', 'bparty'], as_index=False).agg(list)
                output_df['case_id'] = case_id
                output_df['destination_ip_address'] = output_df['destination_ip_address'].apply(lambda x: list(set(x)))
                output_df['vpn_name'] = output_df['vpn_name'].apply(lambda x: list(set(x)))
                output_df['total_count'] = output_df['destination_ip_address'].apply(len)

                # Format the output
                output_df['destination_ip_address'] = output_df['destination_ip_address'].apply(
                    lambda x: str(x).replace("[", "").replace("]", "").replace('"', '')
                )
                output_df['vpn_name'] = output_df['vpn_name'].apply(
                    lambda x: str(x).replace("[", "").replace("]", "").replace('"', '')
                )
                output_df.sort_values('total_count', ascending=False, inplace=True)
                output_df = output_df[output_df['aparty'] != output_df['bparty']]
                output_df['scenario_type'] = 0
                output_df['vpn_correlation_hash'] = output_df.apply(
                    lambda x: hashlib.sha256(
                        f"{x.case_id}{x.aparty}{x.destination_ip_address}{x.bparty}{x.vpn_name}{x.scenario_type}".encode()
                    ).hexdigest(), axis=1
                )

                delete_query = delete_records_phone_no_case_id("", case_id, phone_field_name='phone_no', table_name='vpn_correlation')
                run_delete_query_on_all_nodes(delete_query)
                data_insertion(output_df,'vpn_correlation')


def correlation_data_insertion_for_bidirectional(ipdr_data_df_row):
    a_party = ipdr_data_df_row['phone_no']
    start_date_time_from = int(ipdr_data_df_row['start_date_time'])-1800
    start_date_time_to = int(ipdr_data_df_row['end_date_time'])+1800
    destination_ip_address_main = str(ipdr_data_df_row['destination_ip_address']).strip()
    destination_port_main = ipdr_data_df_row['destination_port']
    public_ip_address_main = str(ipdr_data_df_row['public_ip_address']).strip()
    public_ip_port_main = ipdr_data_df_row['public_ip_port']
    source_ip_address_main = str(ipdr_data_df_row['source_ip_address']).strip()
    source_port_main = ipdr_data_df_row['source_port']

    # [1] PUBLIC IP ADDRESS: Bidirectional correlation count check for Public IP address
    count_check_query = f"""SELECT count(*) FROM ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND public_ip_address = '{destination_ip_address_main}' AND destination_ip_address = '{public_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes';"""
    row_data, column_data = select_data(count_check_query)
    total_rows = row_data[0][0]
    if total_rows > 0:
        total_corelation_rows = total_rows
        start_corelation_counter = 0
        row_corelation_counter = 10000
        while True:
            # fetch data in chunk
            main_query = f"""SELECT b_party, public_ip_address, public_ip_port, source_ip_address, source_port, destination_ip_address, destination_port, start_date_time, end_date_time, imei_no, imsi_no, cell_id, tower_location, service_provider_detail, session_duration, ip_country FROM ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND public_ip_address = '{public_ip_address_main}' AND destination_ip_address = '{destination_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes' LIMIT {row_corelation_counter} OFFSET {start_corelation_counter};"""
            row_data, column_data = select_data(main_query)
            if row_data:
                b_party_ipdr_data_df = pd.DataFrame(row_data, columns=column_data)
                b_party_ipdr_data_df['is_public_ip_match'] = "yes"
                b_party_ipdr_data_df['is_public_ip_port_match'] = b_party_ipdr_data_df['public_ip_port'].apply(lambda x: "yes" if x == destination_port_main  else "no")
                b_party_ipdr_data_df['a_party'] = a_party
                b_party_ipdr_data_df['case_id'] = ipdr_data_df_row['case_id']
                try:
                    b_party_ipdr_data_df['imei_no'] = ipdr_data_df_row['imei_no']
                except:
                    b_party_ipdr_data_df['imei_no'] = ''
                try:
                    b_party_ipdr_data_df['imsi_no'] = ipdr_data_df_row['imsi_no']
                except:
                    b_party_ipdr_data_df['imsi_no'] = ''
                            
                b_party_ipdr_data_df['public_ip_address'] = ipdr_data_df_row['public_ip_address'].strip()
                b_party_ipdr_data_df['public_ip_port'] = ipdr_data_df_row['public_ip_port']
                b_party_ipdr_data_df['source_ip_address'] = ipdr_data_df_row['source_ip_address'].strip()
                b_party_ipdr_data_df['source_port'] = ipdr_data_df_row['source_port']
                b_party_ipdr_data_df['destination_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                b_party_ipdr_data_df['destination_port'] = ipdr_data_df_row['destination_port']
                b_party_ipdr_data_df['start_date_time'] = ipdr_data_df_row['start_date_time']
                b_party_ipdr_data_df['end_date_time'] = ipdr_data_df_row['end_date_time']
                b_party_ipdr_data_df['session_duration'] = ipdr_data_df_row['session_duration']
                try:
                    b_party_ipdr_data_df['cell_id'] = b_party_ipdr_data_df['cell_id']
                except:
                        b_party_ipdr_data_df['cell_id'] = ''
                try:
                    b_party_ipdr_data_df['tower_location'] = ipdr_data_df_row['tower_location']
                except:b_party_ipdr_data_df['tower_location'] = ''
                b_party_ipdr_data_df['service_provider_detail'] = ipdr_data_df_row['service_provider_detail']
                b_party_ipdr_data_df['is_source_ip_match'] = "no"
                b_party_ipdr_data_df['is_source_port_match'] = "no"
                b_party_ipdr_data_df['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                b_party_ipdr_data_df['ip_country'] = ipdr_data_df_row['ip_country']
                b_party_ipdr_data_df['direction'] = 2
                            
                b_party_ipdr_data_df['correlation_hash'] = b_party_ipdr_data_df.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}{}'.format(str(x.case_id),str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask = b_party_ipdr_data_df.duplicated(subset='correlation_hash', keep='first')
                b_party_ipdr_data_df = b_party_ipdr_data_df[~b_party_remove_duplicate_mask]

                # Insert data to the p2p_connections_solr table
                data_insertion(b_party_ipdr_data_df,'p2p_connections')

                b_party_ipdr_data_df2 = pd.DataFrame(row_data, columns=column_data)
                b_party_ipdr_data_df2['is_public_ip_match'] = b_party_ipdr_data_df2['destination_ip_address'].apply(lambda x: "yes" if x == public_ip_address_main  else "no")
                b_party_ipdr_data_df2['is_public_ip_port_match'] = b_party_ipdr_data_df2['destination_port'].apply(lambda x: "yes" if x == public_ip_port_main  else "no")
                b_party_ipdr_data_df2['a_party'] = b_party_ipdr_data_df2['b_party']
                b_party_ipdr_data_df2['b_party'] = a_party
                b_party_ipdr_data_df2['start_date_time'] = ipdr_data_df_row['start_date_time']
                b_party_ipdr_data_df2['end_date_time'] = ipdr_data_df_row['end_date_time']
                b_party_ipdr_data_df2['session_duration'] = ipdr_data_df_row['session_duration']
                b_party_ipdr_data_df2['is_source_ip_match'] = "no"
                b_party_ipdr_data_df2['is_source_port_match'] = "no"
                b_party_ipdr_data_df2['destination_ip_address'] = ipdr_data_df_row['public_ip_address'].strip()
                b_party_ipdr_data_df2['destination_port'] = ipdr_data_df_row['public_ip_port']
                b_party_ipdr_data_df2['public_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                b_party_ipdr_data_df2['public_ip_port'] = ipdr_data_df_row['destination_port']
                try:
                    b_party_ipdr_data_df2['cell_id'] = ipdr_data_df_row['cell_id']
                except:
                    b_party_ipdr_data_df2['cell_id'] = ''
                b_party_ipdr_data_df2['case_id'] = ipdr_data_df_row['case_id']
                b_party_ipdr_data_df2['direction'] = 2
                b_party_ipdr_data_df2['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                b_party_ipdr_data_df2['correlation_hash'] = b_party_ipdr_data_df2.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}{}'.format(str(x.case_id),str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask2 = b_party_ipdr_data_df2.duplicated(subset='correlation_hash', keep='first')
                b_party_ipdr_data_df2 = b_party_ipdr_data_df2[~b_party_remove_duplicate_mask2]
                # Insert data to the p2p_connections_solr table
                data_insertion(b_party_ipdr_data_df2,'p2p_connections')
            
            # Increamnet and exit the loop once all rows are processed
            start_corelation_counter += row_corelation_counter
            if start_corelation_counter>=total_corelation_rows:
                break

    # [2] SOURCE IP ADDRESS: Bidirectional correlation count check for Source IP address
    count_check_query = f"""SELECT count(*) FROM ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND source_ip_address = '{destination_ip_address_main}' AND destination_ip_address = '{source_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes';"""
    row_data, column_data = select_data(count_check_query)
    total_rows = row_data[0][0]
    if total_rows > 0:
        total_corelation_rows = total_rows
        start_corelation_counter = 0
        row_corelation_counter = 10000
        while True:
            # fetch data in chunk
            main_query = f"""SELECT b_party, public_ip_address, public_ip_port, source_ip_address, source_port, destination_ip_address, destination_port, start_date_time, end_date_time, imei_no, imsi_no, cell_id, tower_location, service_provider_detail, session_duration, ip_country FROM ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND source_ip_address = '{destination_ip_address_main}' AND destination_ip_address = '{source_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes' LIMIT {row_corelation_counter} OFFSET {start_corelation_counter};"""
            row_data, column_data = select_data(main_query)
            if row_data:
                source_b_party_ipdr_data_df = pd.DataFrame(row_data, columns=column_data)
                source_b_party_ipdr_data_df['is_source_ip_match'] = "yes"
                source_b_party_ipdr_data_df['is_source_port_match'] = source_b_party_ipdr_data_df['source_port'].apply(lambda x: "yes" if x == destination_port_main  else "no")
                source_b_party_ipdr_data_df['is_public_ip_match'] = "no"
                source_b_party_ipdr_data_df['is_public_ip_port_match'] = "no"
                source_b_party_ipdr_data_df['a_party'] = a_party
                source_b_party_ipdr_data_df['case_id'] = ipdr_data_df_row['case_id']
                try:
                    source_b_party_ipdr_data_df['imei_no'] = ipdr_data_df_row['imei_no']
                except:
                    source_b_party_ipdr_data_df['imei_no'] = ''
                try:
                    source_b_party_ipdr_data_df['imsi_no'] = ipdr_data_df_row['imsi_no']
                except:
                    source_b_party_ipdr_data_df['imsi_no'] = ''

                source_b_party_ipdr_data_df['public_ip_address'] = ipdr_data_df_row['public_ip_address'].strip()
                source_b_party_ipdr_data_df['public_ip_port'] = ipdr_data_df_row['public_ip_port']
                source_b_party_ipdr_data_df['source_ip_address'] = ipdr_data_df_row['source_ip_address'].strip()
                source_b_party_ipdr_data_df['source_port'] = ipdr_data_df_row['source_port']
                source_b_party_ipdr_data_df['destination_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                source_b_party_ipdr_data_df['destination_port'] = ipdr_data_df_row['destination_port']
                source_b_party_ipdr_data_df['start_date_time'] = ipdr_data_df_row['start_date_time']
                source_b_party_ipdr_data_df['end_date_time'] = ipdr_data_df_row['end_date_time']
                source_b_party_ipdr_data_df['session_duration'] = ipdr_data_df_row['session_duration']
                try:
                    source_b_party_ipdr_data_df['cell_id'] = source_b_party_ipdr_data_df['cell_id']
                except:
                    source_b_party_ipdr_data_df['cell_id'] = ''
                source_b_party_ipdr_data_df['tower_location'] = ipdr_data_df_row['tower_location']
                source_b_party_ipdr_data_df['service_provider_detail'] = ipdr_data_df_row['service_provider_detail']
                source_b_party_ipdr_data_df['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                source_b_party_ipdr_data_df['ip_country'] = ipdr_data_df_row['ip_country']
                source_b_party_ipdr_data_df['direction'] = 2
                            
                source_b_party_ipdr_data_df['correlation_hash'] = source_b_party_ipdr_data_df.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}{}'.format(str(x.case_id),str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask = source_b_party_ipdr_data_df.duplicated(subset='correlation_hash', keep='first')
                source_b_party_ipdr_data_df = source_b_party_ipdr_data_df[~b_party_remove_duplicate_mask]

                # Insertion of data in p2p_connections_solr table
                data_insertion(source_b_party_ipdr_data_df,'p2p_connections')

                source_b_party_ipdr_data_df2 = pd.DataFrame(row_data, columns=column_data)
                source_b_party_ipdr_data_df2['is_source_ip_match'] = source_b_party_ipdr_data_df2['destination_ip_address'].apply(lambda x: "yes" if x == source_ip_address_main  else "no")
                source_b_party_ipdr_data_df2['is_source_port_match'] = source_b_party_ipdr_data_df2['destination_port'].apply(lambda x: "yes" if x == source_port_main  else "no")
                source_b_party_ipdr_data_df2['is_public_ip_match'] = "no"
                source_b_party_ipdr_data_df2['is_public_ip_port_match'] = "no"
                source_b_party_ipdr_data_df2['start_date_time'] = ipdr_data_df_row['start_date_time']
                source_b_party_ipdr_data_df2['end_date_time'] = ipdr_data_df_row['end_date_time']
                source_b_party_ipdr_data_df2['session_duration'] = ipdr_data_df_row['session_duration']

                            
                source_b_party_ipdr_data_df2['destination_ip_address'] = ipdr_data_df_row['source_ip_address'].strip()
                source_b_party_ipdr_data_df2['destination_port'] = ipdr_data_df_row['source_port']
                source_b_party_ipdr_data_df2['source_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                source_b_party_ipdr_data_df2['source_port'] = ipdr_data_df_row['destination_port']
                try:
                    source_b_party_ipdr_data_df2['cell_id'] = ipdr_data_df_row['cell_id']
                except:
                    source_b_party_ipdr_data_df2['cell_id'] = ''
                            

                source_b_party_ipdr_data_df2['case_id'] = ipdr_data_df_row['case_id']
                source_b_party_ipdr_data_df2['a_party'] = source_b_party_ipdr_data_df2['b_party']
                source_b_party_ipdr_data_df2['b_party'] = a_party
                source_b_party_ipdr_data_df2['is_source_ip_match'] = "no"
                source_b_party_ipdr_data_df2['is_source_port_match'] = "no"
                source_b_party_ipdr_data_df2['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                source_b_party_ipdr_data_df2['direction'] = 2

                source_b_party_ipdr_data_df2['correlation_hash'] = source_b_party_ipdr_data_df2.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}{}'.format(str(x.case_id),str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask2 = source_b_party_ipdr_data_df2.duplicated(subset='correlation_hash', keep='first')
                source_b_party_ipdr_data_df2 = source_b_party_ipdr_data_df2[~b_party_remove_duplicate_mask2]
                # Insertion of data in p2p_connections table
                data_insertion(source_b_party_ipdr_data_df2,'p2p_connections')
            else:
                break

            # Increment the corelation counter and check if it exceeds the total corelation rows
            start_corelation_counter += row_corelation_counter
            if start_corelation_counter>=total_corelation_rows:
                break


def correlation_data_insertion_for_unidirectional(ipdr_data_df_row):
    a_party = ipdr_data_df_row['phone_no']
    start_date_time_from = int(ipdr_data_df_row['start_date_time'])-1800
    start_date_time_to = int(ipdr_data_df_row['end_date_time'])+1800
    destination_ip_address_main = ipdr_data_df_row['destination_ip_address'].strip()
    destination_port_main = ipdr_data_df_row['destination_port']
    public_ip_address_main = ipdr_data_df_row['public_ip_address'].strip()
    public_ip_port_main = ipdr_data_df_row['public_ip_port']
    source_ip_address_main = ipdr_data_df_row['source_ip_address']
    source_port_main = ipdr_data_df_row['source_port']

    # [1] PUBLIC IP ADDRESS: UNI-directional correlation count check for Public IP address
    count_check_query = f"""SELECT count(*) FROM ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND public_ip_address = '{destination_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes';"""
    row_data, column_data = select_data(count_check_query)
    total_rows = row_data[0][0]
    if total_rows > 0:
        total_corelation_rows = total_rows
        start_corelation_counter = 0
        row_corelation_counter = 10000
        while True:
            # fetch data in chunks from ipdr_details table
            main_query = f"""SELECT b_party, public_ip_address, public_ip_port, source_ip_address, source_port, destination_ip_address, destination_port, start_date_time, end_date_time, imei_no, imsi_no, cell_id, tower_location, service_provider_detail, session_duration, ip_country FROM ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND public_ip_address = '{destination_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes' LIMIT {row_corelation_counter} OFFSET {start_corelation_counter};"""
            row_data, column_data = select_data(main_query)
            if row_data:
                b_party_ipdr_data_df = pd.DataFrame(row_data, columns=column_data)
                b_party_ipdr_data_df['is_public_ip_match'] = "yes"
                b_party_ipdr_data_df['is_public_ip_port_match'] = b_party_ipdr_data_df['public_ip_port'].apply(lambda x: "yes" if x == destination_port_main  else "no")
                b_party_ipdr_data_df['a_party'] = a_party
                b_party_ipdr_data_df['case_id'] = ipdr_data_df_row['case_id']
                try:
                    b_party_ipdr_data_df['imei_no'] = ipdr_data_df_row['imei_no']
                except:
                    b_party_ipdr_data_df['imei_no'] = ''
                try:
                    b_party_ipdr_data_df['imsi_no'] = ipdr_data_df_row['imsi_no']
                except:
                    b_party_ipdr_data_df['imsi_no'] = ''

                b_party_ipdr_data_df['public_ip_address'] = ipdr_data_df_row['public_ip_address'].strip()
                b_party_ipdr_data_df['public_ip_port'] = ipdr_data_df_row['public_ip_port']
                b_party_ipdr_data_df['source_ip_address'] = ipdr_data_df_row['source_ip_address'].strip()
                b_party_ipdr_data_df['source_port'] = ipdr_data_df_row['source_port']
                b_party_ipdr_data_df['destination_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                b_party_ipdr_data_df['destination_port'] = ipdr_data_df_row['destination_port']
                b_party_ipdr_data_df['start_date_time'] = ipdr_data_df_row['start_date_time']
                b_party_ipdr_data_df['end_date_time'] = ipdr_data_df_row['end_date_time']
                b_party_ipdr_data_df['session_duration'] = ipdr_data_df_row['session_duration']
                            
                try:
                    b_party_ipdr_data_df['cell_id'] = b_party_ipdr_data_df['cell_id']
                except:
                    b_party_ipdr_data_df['cell_id'] = ''
                try:
                    b_party_ipdr_data_df['tower_location'] = ipdr_data_df_row['tower_location']
                except:
                    b_party_ipdr_data_df['tower_location'] = ''

                b_party_ipdr_data_df['service_provider_detail'] = ipdr_data_df_row['service_provider_detail']
                b_party_ipdr_data_df['is_source_ip_match'] = "no"
                b_party_ipdr_data_df['is_source_port_match'] = "no"
                b_party_ipdr_data_df['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                b_party_ipdr_data_df['ip_country'] = ipdr_data_df_row['ip_country']
                b_party_ipdr_data_df['direction'] = 1
                            
                b_party_ipdr_data_df['correlation_hash'] = b_party_ipdr_data_df.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}{}'.format(str(x.case_id),str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask = b_party_ipdr_data_df.duplicated(subset='correlation_hash', keep='first')
                b_party_ipdr_data_df = b_party_ipdr_data_df[~b_party_remove_duplicate_mask]

                # Insert the data in the p2p_connections table
                data_insertion(b_party_ipdr_data_df, 'p2p_connections')
            else:
                break
            # Increase the counter with chunk size after processing the rows
            start_corelation_counter = start_corelation_counter+row_corelation_counter
            if start_corelation_counter>=total_corelation_rows:
                break 

    # [2] SOURCE IP ADDRESS: UNI-directional correlation count check for Source IP address
    count_check_query = f"""SELECT count(*) FROM ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND source_ip_address = '{destination_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes';"""
    row_data, column_data = select_data(count_check_query)
    total_rows = row_data[0][0]
    if total_rows > 0:
        total_corelation_rows = total_rows
        start_corelation_counter = 0
        row_corelation_counter = 10000
        while True:
            main_query = f"""SELECT b_party, public_ip_address, public_ip_port,source_ip_address, source_port,destination_ip_address, destination_port, start_date_time, end_date_time, imei_no, imsi_no, cell_id, tower_location, service_provider_detail, session_duration, ip_country FROM ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND source_ip_address = '{destination_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes' LIMIT {row_corelation_counter} OFFSET {start_corelation_counter};"""
            row_data, column_data = select_data(main_query)
            if row_data:
                source_b_party_ipdr_data_df = pd.DataFrame(row_data, columns=column_data)
                source_b_party_ipdr_data_df['is_source_ip_match'] = "yes"
                source_b_party_ipdr_data_df['is_source_port_match'] = source_b_party_ipdr_data_df['source_port'].apply(lambda x: "yes" if x == destination_port_main  else "no")
                source_b_party_ipdr_data_df['is_public_ip_match'] = "no"
                source_b_party_ipdr_data_df['is_public_ip_port_match'] = "no"
                source_b_party_ipdr_data_df['a_party'] = a_party
                source_b_party_ipdr_data_df['case_id'] = ipdr_data_df_row['case_id']

                try:
                    source_b_party_ipdr_data_df['imei_no'] = ipdr_data_df_row['imei_no']
                except:
                    source_b_party_ipdr_data_df['imei_no'] = ''
                try:
                    source_b_party_ipdr_data_df['imsi_no'] = ipdr_data_df_row['imsi_no']
                except:
                    source_b_party_ipdr_data_df['imsi_no'] = ''
                            
                try:
                    source_b_party_ipdr_data_df['cell_id'] = ipdr_data_df_row['cell_id']
                except:
                    source_b_party_ipdr_data_df['cell_id'] = ''
                            
                source_b_party_ipdr_data_df['public_ip_address'] = ipdr_data_df_row['public_ip_address'].strip()
                source_b_party_ipdr_data_df['public_ip_port'] = ipdr_data_df_row['public_ip_port']
                source_b_party_ipdr_data_df['source_ip_address'] = ipdr_data_df_row['source_ip_address'].strip()
                source_b_party_ipdr_data_df['source_port'] = ipdr_data_df_row['source_port']
                source_b_party_ipdr_data_df['destination_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                source_b_party_ipdr_data_df['destination_port'] = ipdr_data_df_row['destination_port']
                source_b_party_ipdr_data_df['start_date_time'] = ipdr_data_df_row['start_date_time']
                source_b_party_ipdr_data_df['end_date_time'] = ipdr_data_df_row['end_date_time']
                source_b_party_ipdr_data_df['session_duration'] = ipdr_data_df_row['session_duration']                            
                source_b_party_ipdr_data_df['tower_location'] = ipdr_data_df_row['tower_location']
                source_b_party_ipdr_data_df['service_provider_detail'] = ipdr_data_df_row['service_provider_detail']
                source_b_party_ipdr_data_df['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                source_b_party_ipdr_data_df['ip_country'] = ipdr_data_df_row['ip_country']
                source_b_party_ipdr_data_df['direction'] = 1                            
                            
                source_b_party_ipdr_data_df['correlation_hash'] = source_b_party_ipdr_data_df.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}{}'.format(str(x.case_id),str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask = source_b_party_ipdr_data_df.duplicated(subset='correlation_hash', keep='first')
                source_b_party_ipdr_data_df = source_b_party_ipdr_data_df[~b_party_remove_duplicate_mask]
                
                # Insert data to p2p_connections table
                data_insertion(source_b_party_ipdr_data_df, 'p2p_connections')
            else:
                break

            # Increase the counter and process the rows in chunk
            start_corelation_counter += row_corelation_counter
            if start_corelation_counter>=total_corelation_rows:
                break



def known_voip_corelation_integerator(case_id):    
    print("into the known voip call")
    delete_query = delete_records_phone_no_case_id("", case_id, phone_field_name='phone_no', table_name='p2p_connections')
    run_delete_query_on_all_nodes(delete_query)

    query = f"SELECT COUNT(*) AS num_found FROM u_phone_no WHERE case_id = '{case_id}' AND phone_no != '' AND phone_no != '0';"
    response_row, response_column = select_data(query)
    num_found = response_row[0][0]

    if int(num_found) > 1:
        query = f"""SELECT COUNT(*) AS num_found FROM ipdr_details WHERE case_id = '{case_id}' AND NOT (mapper_name LIKE '%CDR%') AND public_ip_address != destination_ip_address AND destination_port >= 1000 AND b_party_table_status = 'yes';"""
        response_row, response_column = select_data(query)
        num_found = response_row[0][0]

        if int(num_found) > 0:
            total_rows = num_found
            start_counter = 0
            row_counter = 100000
            
            while True:
                # Query to fetch the actual data
                query = f"""SELECT phone_no, imei_no, imsi_no, public_ip_address, public_ip_port, source_ip_address, source_port, destination_ip_address, destination_port, start_date_time, end_date_time, session_duration, cell_id, tower_location, service_provider_detail, b_party_table_status, ip_country FROM ipdr_details WHERE case_id = '{case_id}' AND NOT (mapper_name LIKE '%CDR%') AND public_ip_address != destination_ip_address AND destination_port >= 1000
                  AND b_party_table_status = 'yes' LIMIT {row_counter} OFFSET {start_counter};"""                
                ipdr_data, response_ipdr_column = select_data(query)               

                if ipdr_data:
                    ipdr_data_df = pd.DataFrame(ipdr_data, columns=[
                        'phone_no', 'imei_no', 'imsi_no', 'public_ip_address', 'public_ip_port',
                        'source_ip_address', 'source_port', 'destination_ip_address', 'destination_port',
                        'start_date_time', 'end_date_time', 'session_duration', 'cell_id', 'tower_location',
                        'service_provider_detail', 'b_party_table_status', 'ip_country'
                    ])
                    ipdr_data_df['case_id'] = case_id
                    
                    unwanted_ports = [80, 53, 443, 123, 5222, 5223, 5228, 8443, 8130, 853, 500, 4500,
                                      8080, 6881, 6882, 6883, 600, 1600, 4600, 1390, 3390, 1723,
                                      1194, 1701, 5242, 3478, 3479, 3480, 3481, 3482, 3483, 3484,
                                      3485, 3486, 3487, 3488, 3489, 3490, 3491, 3492, 3493, 3494,
                                      3495, 3496, 3497, 5349, 1400, 599, 19302, 19305]
                    ipdr_data_df = ipdr_data_df[~ipdr_data_df['destination_port'].isin(unwanted_ports)]
                    
                    # Call your correlation functions
                    ipdr_data_df.apply(correlation_data_insertion_for_bidirectional, axis=1)
                    ipdr_data_df.apply(correlation_data_insertion_for_unidirectional, axis=1)
                else:
                    break
                
                start_counter += row_counter
                if start_counter >= total_rows:
                    break

def tower_row_modification(temp,tower_row,type):
    phone_number_row = tower_row['phone_no']
    start_date_time_row = tower_row['start_date_time']
    end_date_time_row = tower_row['end_date_time']
    cell_id_row = tower_row['cell_id']

    try:
        public_ip_address_row = tower_row['public_ip_address']
    except:
        public_ip_address_row = ''
    try:
        public_ip_port_row = tower_row['public_ip_port']
    except :
        public_ip_port_row = ''
    try:
        source_ip_address_row = tower_row['source_ip_address']
    except :
        source_ip_address_row = ''
    try:
        source_port_row = tower_row['source_port']
    except :
        source_port_row = ''
    try:
        imei_no_row = tower_row['imei_no']
    except :
        imei_no_row = ''
    try:
        imsi_no_row = tower_row['imsi_no']
    except :
        imsi_no_row = ''
    try:
        user_agent_row = tower_row['user_agent']
    except :
        user_agent_row = ''
    try:
        tower_location_row = tower_row['tower_location']
    except :
        tower_location_row = ''
    try:
        tower_state_row = tower_row['tower_state']
    except :
        tower_state_row = ''
    try:
        tower_district_row = tower_row['tower_district']
    except :
        tower_district_row = ''                                                           
    try:
        tower_latitude_row = tower_row['tower_latitude']
    except :
        tower_latitude_row = ''
    try:
        tower_longitude_row = tower_row['tower_longitude']
    except :
        tower_longitude_row = ''
    try:
        tower_pincode_row = tower_row['tower_pincode']
    except :
        tower_pincode_row = ''
    try:
        tower_azimuth_row = tower_row['tower_azimuth']
    except :
        tower_azimuth_row = ''
    try:
        second_cell_id_row = tower_row['second_cell_id']
    except:
        second_cell_id_row = cell_id_row
    try:
        second_cell_id_row = str(round(second_cell_id_row))
        cell_id_row = str(round(cell_id_row))
    except:
        second_cell_id_row = str(second_cell_id_row)
        cell_id_row = str(cell_id_row)

    if second_cell_id_row.strip() == "":
        second_cell_id_row = cell_id_row.strip()
    if second_cell_id_row!='':
        try:second_tower_location_row = tower_row['second_tower_location']
        except:second_tower_location_row = tower_location_row
        try:second_tower_state_row = tower_row['second_tower_state']
        except:second_tower_state_row = tower_state_row
        try:second_tower_district_row = tower_row['second_tower_district']
        except:second_tower_district_row = tower_district_row
        try:second_tower_latitude_row = tower_row['second_tower_latitude']
        except:second_tower_latitude_row = tower_latitude_row
        try:second_tower_longitude_row = tower_row['second_tower_longitude']
        except:second_tower_longitude_row = tower_longitude_row
        try:second_tower_pincode_row = tower_row['second_tower_pincode']
        except:second_tower_pincode_row =tower_pincode_row
        try:second_tower_azimuth_row = tower_row['second_tower_azimuth']
        except:second_tower_azimuth_row = tower_azimuth_row
    else:
        second_tower_location_row = tower_location_row
        second_tower_state_row = tower_state_row
        second_tower_district_row = tower_district_row
        second_tower_latitude_row = tower_latitude_row
        second_tower_longitude_row = tower_longitude_row
        second_tower_pincode_row =tower_pincode_row
        second_tower_azimuth_row = tower_azimuth_row
        
    if type == 1:
        temp['phone_no'] = phone_number_row
        temp['public_ip_address'] = public_ip_address_row
        temp['public_ip_port'] = public_ip_port_row
        temp['source_ip_address'] = source_ip_address_row
        temp['source_port'] = source_port_row
        temp['imei_no'] = imei_no_row
        temp['imsi_no'] = imsi_no_row
        temp['user_agent'] = user_agent_row
        temp['start_cell_id'] = cell_id_row
        temp['start_tower_location'] = tower_location_row
        temp['start_tower_state'] = tower_state_row
        temp['start_tower_district'] = tower_district_row
        temp['start_tower_latitude'] = tower_latitude_row
        temp['start_tower_longitude'] = tower_longitude_row
        temp['start_tower_pincode'] = tower_pincode_row
        temp['start_tower_azimuth'] = tower_azimuth_row
        temp['cell_id_start_date_time'] = start_date_time_row
    elif type == 2:
        temp['end_cell_id'] = second_cell_id_row
        temp['end_tower_location'] = second_tower_location_row
        temp['end_tower_state'] = second_tower_state_row
        temp['end_tower_district'] = second_tower_district_row
        temp['end_tower_latitude'] = second_tower_latitude_row
        temp['end_tower_longitude'] = second_tower_longitude_row
        temp['end_tower_pincode'] = second_tower_pincode_row
        temp['end_tower_azimuth'] = second_tower_azimuth_row
        temp['cell_id_end_date_time'] = end_date_time_row
    elif type == 3:
        temp['phone_no'] = phone_number_row
        temp['public_ip_address'] = public_ip_address_row
        temp['public_ip_port'] = public_ip_port_row
        temp['source_ip_address'] = source_ip_address_row
        temp['source_port'] = source_port_row
        temp['imei_no'] = imei_no_row
        temp['imsi_no'] = imsi_no_row
        temp['user_agent'] = user_agent_row
        temp['start_cell_id'] = second_cell_id_row
        temp['start_tower_location'] = second_tower_location_row
        temp['start_tower_state'] = second_tower_state_row
        temp['start_tower_district'] = second_tower_district_row
        temp['start_tower_latitude'] = second_tower_latitude_row
        temp['start_tower_longitude'] = second_tower_longitude_row
        temp['start_tower_pincode'] = second_tower_pincode_row
        temp['start_tower_azimuth'] = second_tower_azimuth_row
        temp['cell_id_start_date_time'] = end_date_time_row
    elif type == 4:
        temp['end_cell_id'] = cell_id_row
        temp['end_tower_location'] = tower_location_row
        temp['end_tower_state'] = tower_state_row
        temp['end_tower_district'] = tower_district_row
        temp['end_tower_latitude'] = tower_latitude_row
        temp['end_tower_longitude'] = tower_longitude_row
        temp['end_tower_pincode'] = tower_pincode_row
        temp['end_tower_azimuth'] = tower_azimuth_row
        temp['cell_id_end_date_time'] = start_date_time_row
    return temp


def tower_integerator(case_id):
    # Query to get the count of phone numbers
    count_query = f"""SELECT COUNT(*) AS numFound FROM u_phone_no WHERE case_id = '{case_id}' AND phone_no != '' AND phone_no != '0';"""
    data_row, data_columns = select_data(count_query)
    print("into the tower patterns2", data_row[0][0])
    total_phone_numbers = data_row[0][0]

    if total_phone_numbers > 0:
        row_phone_numbers_count = 10000
        phone_counter = 0
        while True:
            # Query to get phone numbers
            phone_query = f"""SELECT phone_no FROM u_phone_no 
WHERE case_id = '{case_id}' AND phone_no != '' AND phone_no != '0'
LIMIT {row_phone_numbers_count} OFFSET{phone_counter};
"""
            phone_no_data_row, phone_no_data_columns = select_data(phone_query)
            print("into the tower patterns3", len(phone_no_data_row))

            # if no phone no found than break the loop
            if len(phone_no_data_row) == 0:
                break

            phone_numbers_df = pd.DataFrame(phone_no_data_row, columns=['phone_no'])
            for index, phone_number_row in phone_numbers_df.iterrows():
                phone_number = phone_number_row['phone_no']

                # Query to get record count from IPDR details
                ipdr_query = f"""
                    SELECT count(*) FROM ipdr_details
                    WHERE case_id = '{case_id}' AND phone_no = '{phone_number}' 
                      AND cell_id IS NOT NULL AND cell_id != 0 
                      AND is_ip_ipdr != 2 
                      AND tower_location IS NOT NULL 
                      AND tower_latitude IS NOT NULL 
                      AND tower_longitude IS NOT NULL;
                """

                ipdr_result, ipdr_column = select_data(ipdr_query)
                print("into the tower patterns4", ipdr_result[0][0])
                total_rows = ipdr_result[0][0]
                

                if total_rows > 0:
                    row_count = 10000
                    row_counter = 0
                    # Call your delete function for each table
                    delete_records_phone_no_case_id('u_district_wise_location', phone_number, case_id, 'phone_no')
                    delete_records_phone_no_case_id('u_tower_movements', phone_number, case_id, 'phone_no')
                    delete_records_phone_no_case_id('important_travel_routes', phone_number, case_id, 'phone_no')

                    while True:
                        # Query to get detailed IPDR records
                        details_query = f"""
                        SELECT phone_no, public_ip_address, public_ip_port, source_ip_address, source_port, 
                               imei_no, imsi_no, user_agent, start_date_time, end_date_time, 
                               cell_id, tower_location, tower_state, tower_district, 
                               tower_latitude, tower_longitude, tower_pincode, tower_azimuth, 
                               second_cell_id, second_tower_location, second_tower_state, 
                               second_tower_district, second_tower_latitude, second_tower_longitude, 
                               second_tower_pincode, second_tower_azimuth
                        FROM your_ipdr_table_name
                        WHERE case_id = '{case_id}' AND phone_no = '{phone_number}' 
                          AND cell_id IS NOT NULL AND cell_id != 0 
                          AND is_ip_ipdr != 2 
                          AND tower_location IS NOT NULL 
                          AND tower_latitude IS NOT NULL 
                          AND tower_longitude IS NOT NULL
                        LIMIT {row_count} OFFSET {row_counter};
                        """

                        details_result, details_column = select_data(details_query)
                        print("into the tower patterns5", len(details_result))

                        if details_result > 0:
                            main_data_df = pd.DataFrame(details_result, columns=details_column)
                            main_data_df = main_data_df.sort_values(by=['start_date_time', 'end_date_time'])

                            previous_cell_id = None
                            tower_movement_list = []
                            cols = ['tower_state','tower_district','second_tower_state','second_tower_district','second_cell_id','second_tower_latitude','second_tower_longitude','tower_location','tower_azimuth','second_tower_location','second_tower_azimuth','tower_pincode','second_tower_pincode']
                            main_data_df = main_data_df.reindex(main_data_df.columns.union(cols, sort=False), axis=1, fill_value='')
                            main_data_df = main_data_df.reset_index(drop=True)
                            main_data_df = main_data_df.dropna(subset=['tower_latitude'])
                            main_data_df = main_data_df.dropna(subset=['tower_longitude'])
                            main_data_df = main_data_df.dropna(subset=['cell_id'])
                            # main_data_df = main_data_df.fillna('0')
                                                        
                            ###################### top 3 location district wise started ######################

                            melted_first = main_data_df.melt(id_vars=['phone_no','cell_id', 'second_cell_id','tower_latitude','tower_longitude','second_tower_latitude','second_tower_longitude','tower_location','second_tower_location','second_tower_azimuth','tower_azimuth','tower_pincode','second_tower_pincode'],
                                                value_vars=['tower_district', 'second_tower_district'],
                                                var_name='common_cell',
                                                value_name='group_tower_district')
                            melted_first['group_cell_id'] = melted_first.apply(
                                lambda row: row['cell_id'] if row['common_cell'] == 'tower_district' else row['second_cell_id'],
                                axis=1
                            )
                            melted_first['group_cell_lat'] = melted_first.apply(
                                lambda row: row['tower_latitude'] if row['common_cell'] == 'tower_district' else row['second_tower_latitude'],
                                axis=1
                            )
                            melted_first['group_cell_long'] = melted_first.apply(
                                lambda row: row['tower_longitude'] if row['common_cell'] == 'tower_district' else row['second_tower_longitude'],
                                axis=1
                            )
                            melted_first['group_tower_location'] = melted_first.apply(
                                lambda row: row['tower_location'] if row['common_cell'] == 'tower_district' else row['second_tower_location'],
                                axis=1
                            )
                                                        
                            melted_first['group_tower_azimuth'] = melted_first.apply(
                                lambda row: row['tower_azimuth'] if row['common_cell'] == 'tower_district' else row['second_tower_azimuth'],
                                axis=1
                            )
                            melted_first['group_tower_pincode'] = melted_first.apply(
                                lambda row: row['tower_pincode'] if row['common_cell'] == 'tower_district' else row['second_tower_pincode'],
                                axis=1
                            )

                            final_df = melted_first.drop(columns=['cell_id', 'second_cell_id', 'common_cell','tower_latitude','tower_longitude','second_tower_latitude','second_tower_longitude','tower_location','second_tower_location','second_tower_azimuth','tower_azimuth','second_tower_pincode','tower_pincode'])

                            final_df = final_df[final_df['group_cell_id']!='']

                            count_df = final_df.groupby(['group_tower_district', 'group_cell_id']).size().reset_index(name='count')
                            top_rows = count_df.groupby('group_tower_district').apply(lambda x: x.nlargest(3, 'count')).reset_index(drop=True)
                            cell_coords = dict(zip(zip(final_df['group_tower_district'], final_df['group_cell_id']),
                                                zip(final_df['group_cell_lat'], final_df['group_cell_long'],final_df['group_tower_location'],final_df['group_tower_azimuth'],final_df['group_tower_pincode'])))

                            top_rows['group_cell_details'] = top_rows.apply(lambda row: f"{cell_coords[(row['group_tower_district'], row['group_cell_id'])][0]}#####{cell_coords[(row['group_tower_district'], row['group_cell_id'])][1]}#####{cell_coords[(row['group_tower_district'], row['group_cell_id'])][2]}#####{cell_coords[(row['group_tower_district'], row['group_cell_id'])][3]}#####{cell_coords[(row['group_tower_district'], row['group_cell_id'])][4]}", axis=1)

                            output_df = top_rows[['group_tower_district', 'group_cell_id', 'count', 'group_cell_details']]
                            output_df.rename(columns={
                                'group_tower_district': 'tower_district',
                                'group_cell_id': 'cell_id',
                            }, inplace=True)

                            output_df[['tower_latitude', 'tower_longitude','tower_location','tower_azimuth','tower_pincode']] = output_df['group_cell_details'].str.split('#####', expand=True)
                            output_df = output_df.drop(columns=['group_cell_details'])
                            output_df['count'] = output_df['count'].astype(int)
                            output_df['tower_latitude'] = output_df['tower_latitude'].astype(float)
                            output_df['tower_longitude'] = output_df['tower_longitude'].astype(float)
                            try:
                                output_df['tower_azimuth'] = output_df['tower_azimuth'].astype(float)
                            except:pass

                            grouped = output_df.groupby('tower_district').apply(lambda x: x.to_dict('records')).reset_index(name='tower_encode')
                            grouped['phone_number'] = phone_number
                            district_wise_result = []
                                                        
                            for _, row in grouped.iterrows():
                                state_data = {
                                    'case_id':str(case_id),
                                    'phone_no':row['phone_number'],
                                    'district_name': row['tower_district'],
                                    'location_dict_encode': base64.b64encode(str(row['tower_encode']).encode('utf-8')).decode('utf-8'),
                                    'district_wise_location_id':hashlib.sha256('{}{}{}'.format(str(case_id),str(row['phone_number']),str(row['tower_district'])).encode()).hexdigest()
                                }
                                district_wise_result.append(state_data)

                            # Insert data into the u_district table
                            data_insertion(pd.DataFrame(district_wise_result),"u_district_wise_location")
                            ###################### top 3 location district wise ended ######################
                                                        

                            ################ tower movements started ###############################
                            for row_index,tower_row in main_data_df.iterrows():
                                start_date_time = tower_row['start_date_time']
                                end_date_time = tower_row['end_date_time']
                                cell_id = tower_row['cell_id'].strip()

                                try:
                                    if tower_row['second_cell_id']!="":
                                        second_cell_id = tower_row['second_cell_id']
                                    else:
                                        second_cell_id = cell_id
                                except :
                                    second_cell_id = cell_id
                                try:
                                    second_cell_id = str(round(second_cell_id))
                                    cell_id = str(round(cell_id))
                                except:
                                    second_cell_id = str(second_cell_id)
                                    cell_id = str(cell_id)
                                if second_cell_id.strip() == "":
                                    second_cell_id = cell_id.strip()
                                if row_index==0:
                                    temp = {}
                                    temp = tower_row_modification(temp,tower_row,1)
                                    previous_cell_id = cell_id
                                    if cell_id!=second_cell_id and previous_cell_id!=second_cell_id:
                                        previous_cell_id = second_cell_id
                                        temp = tower_row_modification(temp,tower_row,2)
                                        temp['attempt'] = 1
                                        # temp['previous_cell_id'] = previous_cell_id
                                        tower_movement_list.append(temp)
                                        temp = {}
                                        temp = tower_row_modification(temp,tower_row,3)
                                else:
                                    if previous_cell_id==cell_id and cell_id!= second_cell_id:
                                        previous_cell_id = second_cell_id
                                        temp = tower_row_modification(temp,tower_row,2)
                                        temp['attempt'] = 2
                                        # temp['previous_cell_id'] = previous_cell_id
                                        tower_movement_list.append(temp)
                                        temp = {}
                                        temp = tower_row_modification(temp,tower_row,3)
                                    elif previous_cell_id==cell_id and cell_id== second_cell_id:
                                        previous_cell_id = second_cell_id
                                        temp = tower_row_modification(temp,tower_row,2)
                                    elif previous_cell_id != cell_id:
                                        previous_cell_id = cell_id
                                        temp = tower_row_modification(temp,tower_row,4)
                                        temp['attempt'] = 3
                                        # temp['previous_cell_id'] = previous_cell_id
                                        tower_movement_list.append(temp)
                                        temp = {}
                                        temp = tower_row_modification(temp,tower_row,1)
                                        if cell_id!=second_cell_id and previous_cell_id!=second_cell_id:
                                            previous_cell_id = second_cell_id
                                            temp = tower_row_modification(temp,tower_row,2)
                                                                        
                                            # print('first', cell_id,'sec',second_cell_id,'======================')
                                            temp['attempt'] = 4
                                            # temp['previous_cell_id'] = previous_cell_id
                                            tower_movement_list.append(temp)
                                            temp = {}
                                                                        
                                            temp = tower_row_modification(temp,tower_row,3)
                                    if row_index == len(main_data_df)-1:
                                        if 'end_cell_id' not in temp.keys():
                                            if temp['cell_id_start_date_time']!=end_date_time:
                                                temp = tower_row_modification(temp,tower_row,2)
                                                temp['attempt'] = 5
                                                # temp['previous_cell_id'] = previous_cell_id
                                                tower_movement_list.append(temp)
                            if len(tower_movement_list)!=0:
                                tower_movement_df = pd.DataFrame(tower_movement_list)
                                tower_movement_df['is_first'] = 0
                                tower_movement_df['is_last'] = 0
                                tower_movement_df['case_id'] = str(case_id)
                                tower_movement_df.loc[tower_movement_df.index[0], 'is_first'] = 1
                                tower_movement_df.loc[tower_movement_df.index[-1], 'is_last'] = 1
                                tower_movement_df = tower_movement_df.fillna('')
                                tower_movement_df['tower_movements_id'] = tower_movement_df.apply(calculate_hash, axis=1)
                                u_tower_movements_solr.add(tower_movement_df.to_dict('records'),commit=True)

                            ###################### tower movements ended ###############################
                            ###################### Important Travel Routes started ######################
                                important_travel_routes_df = tower_movement_df
                                important_travel_routes_df = important_travel_routes_df[important_travel_routes_df['start_tower_district'] != important_travel_routes_df['end_tower_district']]
                                important_travel_routes_df = important_travel_routes_df.rename(columns={'tower_movements_id': 'important_travel_route_id'})
                                important_travel_routes_solr.add(important_travel_routes_df.to_dict('records'),commit=True)
                                data_insertion(important_travel_routes_df,'important_travel_routes')
                            ###################### Important Travel Routes ended ######################
                row_counter = row_counter+row_count
                if row_counter>=total_rows:
                    break

            phone_counter += row_phone_numbers_count
            if phone_counter>=total_phone_numbers:
                break 

def format_timestamp(ts):
    dt = datetime.fromtimestamp(ts, pytz.timezone('Asia/Kolkata'))
    year = dt.year
    month = dt.month
    day = dt.strftime('%A')
    time = dt.strftime('%H:%M:%S')
    date = dt.strftime('%Y-%m-%d')
    return year, month, day, time,date

def calculate_hash(row):
    combined_values = ''.join(str(val) for val in sorted(row.items()))
    sha256_hash = hashlib.sha256(combined_values.encode()).hexdigest()
    return sha256_hash

def  get_location_insights_result(df, pattern, n, p_name, already_existing_cell_ids,case_id):
    df = df[~df['cell_id'].isin(already_existing_cell_ids)]
    main_df = df
    
    if p_name != 'pattern_6':
        df = main_df.drop_duplicates(subset=['date', 'cell_id'],keep='first')
    else:
        grouped = df.groupby(['cell_id'])
        to_remove_both = grouped['cdr_call_type'].transform(lambda x: ('INCOMING' in x.values) and ('OUTGOING' in x.values))
        to_remove_either = df['cdr_call_type'].isin(['INCOMING', 'OUTGOING'])
        to_remove = to_remove_both & to_remove_either
        df = df[~to_remove]

    cell_id_counts = main_df.groupby(pattern)['cell_id'].transform('count')
    cell_id_mapping = dict(zip(main_df['cell_id'], cell_id_counts))
    df['frequency'] = df['cell_id'].map(cell_id_mapping)    
    
    if p_name=='pattern_1':        
        df = df.groupby('cell_id').filter(lambda x: len(x['cdr_call_type'].unique()) == 1 and len(x['slot'].unique()) == 1 and len(x['day_name'].unique()) == 1)
        df['count'] = df.groupby('cell_id')['cell_id'].transform('count')          
        df['duration'] =  df['count'].astype(str)+' weeks'
    elif p_name=='pattern_2':        
        df = df.groupby('cell_id').filter(lambda x: len(x['cdr_call_type'].unique()) == 1 and len(x['slot'].unique()) == 1)
        df['count'] = df.groupby('cell_id')['cell_id'].transform('count') 
        df['duration'] =  df['count'].astype(str)+' days'
    elif p_name=='pattern_3':        
        df = df.groupby('cell_id').filter(lambda x: len(x['cdr_call_type'].unique()) == 1  and len(x['day_name'].unique()) == 1)
        df['count'] = df.groupby('cell_id')['cell_id'].transform('count')          
        df['duration'] =  df['count'].astype(str)+' weeks'
    elif p_name=='pattern_7':        
        df = df.groupby('cell_id').filter(lambda x: len(x['day_name'].unique()) == 1 and len(x['slot'].unique()) == 1)
        df['count'] = df.groupby('cell_id')['cell_id'].transform('count')          
        df['duration'] =  df['count'].astype(str)+' weeks'
    elif p_name=='pattern_4':        
        df = df.groupby('cell_id').filter(lambda x: len(x['day_name'].unique()) == 1)
        df['count'] = df.groupby('cell_id')['cell_id'].transform('count')          
        df['duration'] =  df['count'].astype(str)+' weeks'
    elif p_name=='pattern_5':        
        df = df.groupby('cell_id').filter(lambda x: len(x['slot'].unique()) == 1)
        df['count'] = df.groupby('cell_id')['cell_id'].transform('count') 
        df['duration'] =  df['count'].astype(str)+' days'
    elif p_name=='pattern_6':        
        df = df.groupby('cell_id').filter(lambda x: len(x['cdr_call_type'].unique()) == 1)
        df['count'] = df.groupby('cell_id')['cell_id'].transform('count') 
        df['duration'] =  df['count'].astype(str)+' times'

    df = df[pattern + ['phone_no' ,'imei_no', 'imsi_no', 'day_name', 'start_date_time', 'end_date_time', 'duration', 'count','frequency']]
    
    df = df[df['count'] >= n]
    df['pattern_id'] = df.apply(calculate_hash, axis=1)
    df = df.sort_values(by='count', ascending=False)
    df = df.drop_duplicates(subset='cell_id', keep='last')
    
    df['pattern_name'] = p_name
    df['pattern_type'] = 1
    df['case_id'] = str(case_id)
    if 'cell_id' not in df.columns:
       df['cell_id'] = ''
    if 'day_name' not in pattern:
        df['day_name'] = ''
    if 'slot' not in pattern:
        df['slot'] = ''
    if 'cdr_call_type' not in pattern:
        df['cdr_call_type'] = ''
    if 'frequency' not in df.columns:
        df['frequency'] = 0
    df['count'] = df['frequency']

    return df.to_dict('records'), df['cell_id'].tolist() + already_existing_cell_ids

def get_bparty_insights_result(df, pattern, n, p_name, already_existing_b_parties,case_id):
    df = df[~df['b_party'].isin(already_existing_b_parties)]
    unique_random_numbers = ''.join(map(str,random.sample(range(1, 100 + 1), 5)))
    
    main_df = df    
    if p_name != 'pattern_6':
        df = main_df.drop_duplicates(subset=['date', 'b_party'],keep='first')
    else:
        grouped = df.groupby(['b_party'])
        to_remove_both = grouped['cdr_call_type'].transform(lambda x: ('INCOMING' in x.values) and ('OUTGOING' in x.values))
        to_remove_either = df['cdr_call_type'].isin(['INCOMING', 'OUTGOING'])
        to_remove = to_remove_both & to_remove_either
        df = df[~to_remove]

    b_party_counts = main_df.groupby(pattern)['b_party'].transform('count')
    b_party_mapping = dict(zip(main_df['b_party'], b_party_counts))
    df['frequency'] = df['b_party'].map(b_party_mapping)    
    
    
    if p_name=='pattern_1':
        df = df.groupby('b_party').filter(lambda x: len(x['cdr_call_type'].unique()) == 1 and len(x['slot'].unique()) == 1 and len(x['day_name'].unique()) == 1)
        df['count'] = df.groupby('b_party')['b_party'].transform('count')          
        df['duration'] =  df['count'].astype(str)+' weeks'
    elif p_name=='pattern_2':
        df = df.groupby('b_party').filter(lambda x: len(x['cdr_call_type'].unique()) == 1 and len(x['slot'].unique()) == 1)
        df['count'] = df.groupby('b_party')['b_party'].transform('count') 
        df['duration'] =  df['count'].astype(str)+' days'
    elif p_name=='pattern_3':
        df = df.groupby('b_party').filter(lambda x: len(x['cdr_call_type'].unique()) == 1  and len(x['day_name'].unique()) == 1)
        df['count'] = df.groupby('b_party')['b_party'].transform('count')          
        df['duration'] =  df['count'].astype(str)+' weeks'
    elif p_name=='pattern_4':
        df = df.groupby('b_party').filter(lambda x: len(x['day_name'].unique()) == 1)
        df['count'] = df.groupby('b_party')['b_party'].transform('count')          
        df['duration'] =  df['count'].astype(str)+' weeks'
    elif p_name=='pattern_5':
        df = df.groupby('b_party').filter(lambda x: len(x['slot'].unique()) == 1)
        df['count'] = df.groupby('b_party')['b_party'].transform('count') 
        df['duration'] =  df['count'].astype(str)+' days'
    elif p_name=='pattern_6':
        df = df.groupby('b_party').filter(lambda x: len(x['cdr_call_type'].unique()) == 1)
        df['count'] = df.groupby('b_party')['b_party'].transform('count') 
        df['duration'] =  df['count'].astype(str)+' times'

    elif p_name=='pattern_7':
        df = df.groupby('b_party').filter(lambda x: len(x['day_name'].unique()) == 1 and len(x['slot'].unique()) == 1)
        df['count'] = df.groupby('b_party')['b_party'].transform('count')          
        df['duration'] =  df['count'].astype(str)+' weeks'

    df = df[pattern + ['phone_no' ,'imei_no', 'imsi_no', 'day_name', 'start_date_time', 'end_date_time', 'duration', 'count','frequency']]
    
    df = df[df['count'] >= n]
    df['pattern_id'] = df.apply(calculate_hash, axis=1)
    df = df.sort_values(by='count', ascending=False)
    df = df.drop_duplicates(subset='b_party', keep='last')
    
    df['pattern_name'] = p_name
    df['pattern_type'] = 0
    df['case_id'] = str(case_id)
    if 'b_party' not in df.columns:
        df['b_party'] = ''
    if 'day_name' not in df.columns:
        df['day_name'] = ''
    if 'slot' not in df.columns:
        df['slot'] = ''
    if 'cdr_call_type' not in df.columns:
        df['cdr_call_type'] = ''
    if 'frequency' not in df.columns:
        df['frequency'] = 0
    df['count'] = df['frequency']
    return df.to_dict('records'), df['b_party'].tolist() + already_existing_b_parties

def is_valid_latitude(latitude):
    return -90 <= latitude <= 90

def is_valid_longitude(longitude):
    return -180 <= longitude <= 180

def are_valid_coordinates(latitude,longitude):
    if latitude!="" and longitude !="":
        try:
            result =  is_valid_latitude(float(latitude)) and is_valid_longitude(float(longitude))
        except:
            result =  False
    else:
        result = False
    return result

def get_slot(x):
    result_slot = "Slot Unknown"
    if x >= '00:00:01' and x <= '02:00:00':
        result_slot = "12:00 AM to 02:00 AM"
    elif x >= '02:00:01' and x <= '04:00:00':
        result_slot = "02:00 AM to 04:00 AM"
    elif x >= '04:00:01' and x <= '06:00:00':
        result_slot = "04:00 AM to 06:00 AM"
    elif x >= '06:00:01' and x <= '08:00:00':
        result_slot = "06:00 AM to 08:00 AM"
    elif x >= '08:00:01' and x <= '10:00:00':
        result_slot = "08:00 AM to 10:00 AM"
    elif x >= '10:00:01' and x <= '12:00:00':
        result_slot = "10:00 AM to 12:00 PM"
    elif x >= '12:00:01' and x <= '14:00:00':
        result_slot = "12:00 PM to 02:00 PM"
    elif x >= '14:00:01' and x <= '16:00:00':
        result_slot = "02:00 PM to 04:00 PM"
    elif x >= '16:00:01' and x <= '18:00:00':
        result_slot = "04:00 PM to 06:00 PM"
    elif x >= '18:00:01' and x <= '20:00:00':
        result_slot = "06:00 PM to 08:00 PM"
    elif x >= '20:00:01' and x <= '22:00:00':
        result_slot = "08:00 PM to 10:00 PM"
    elif x >= '22:00:01' and x <= '24:00:00':
        result_slot = "10:00 PM to 12:00 AM"
    return result_slot

def extract_subscriber_details(bparty_no):
    subscriber_name = ""
    subscriber_relationer_name = ""
    subscriber_address1 = ""
    subscriber_address2 = ""
    subscriber_email = ""
    subscriber_dob = ""
    subscriber_area_name = ""
    subscriber_alternate_no = ""
    subscriber_district = ""
    subscriber_pincode = ""
    subscriber_lat = ""
    subscriber_long = ""
    b_party = ""
    mobile_number_str = str(bparty_no)    
    # If length is greater than 10, keep the last 10 digits
    if len(mobile_number_str) > 10:
        b_party = mobile_number_str[-10:]
    else:
        b_party = mobile_number_str

    subscriber_query = f"""SELECT 
        UPPER(name) AS name,
        UPPER(relationer_name) AS relationer_name,
        UPPER(address1) AS address1,
        UPPER(address2) AS address2,
        UPPER(email) AS email,
        UPPER(dob) AS dob,
        UPPER(area_name) AS area_name,
        UPPER(alternate_phone_no) AS alternate_phone_no,
        UPPER(district) AS district,
        UPPER(pincode) AS pincode,
        lat,
        long
    FROM u_subscriber_details
    WHERE phone_no = '{b_party}'
    LIMIT 1;"""
    subscriber_data_row, subscriber_data_columns = select_data(subscriber_query)
    if subscriber_data_row:
        doc = subscriber_data_row[0]  
        subscriber_name = str(doc[0]) if doc[0] is not None else ""
        subscriber_relationer_name = str(doc[1]) if doc[1] is not None else ""
        subscriber_address1 = str(doc[2]) if doc[2] is not None else ""
        subscriber_address2 = str(doc[3]) if doc[3] is not None else ""
        subscriber_email = str(doc[4]) if doc[4] is not None else ""
        subscriber_dob = str(doc[5]) if doc[5] is not None else ""
        subscriber_area_name = str(doc[6]) if doc[6] is not None else ""
        subscriber_alternate_no = str(doc[7]) if doc[7] is not None else ""
        subscriber_district = str(doc[8]) if doc[8] is not None else ""
        subscriber_pincode = str(doc[9]) if doc[9] is not None else ""
        subscriber_lat = str(doc[10]) if doc[10] is not None else ""
        subscriber_long = str(doc[11]) if doc[11] is not None else ""

    return subscriber_name, subscriber_relationer_name, subscriber_address1, subscriber_address2, subscriber_email, subscriber_dob, subscriber_area_name, subscriber_alternate_no, subscriber_district, subscriber_pincode, subscriber_lat, subscriber_long

def get_duplicate_count(case_id, result_df):
    query = f"""
    SELECT * FROM u_patterns WHERE case_id = '{case_id}' AND phone_no != '' AND phone_no != '0' AND pattern_type = 0 LIMIT 100000;
    """
    data_row, data_columns = select_data(query)
    if data_row:
        pattern_df = pd.DataFrame(data_row, columns=data_columns)
        merged_df = pd.merge(pattern_df, result_df, on=['b_party', 'pattern_name', 'case_id','services'], how='outer')
        print(f"\t [+] length of Merged :{len(merged_df)} Result :{len(result_df)} db _ptrn_rec : {len(pattern_df)}")
        merged_df['count_x'].fillna(0, inplace=True)
        merged_df['count_y'].fillna(0, inplace=True)

        # Add the 'count' values where 'bparty' values match
        merged_df['count'] = merged_df['count_x'] + merged_df['count_y']
        merged_df['duration'] = merged_df['count'].astype(str) + '_time'
        merged_df['frequency'] = merged_df['count']
        merged_df.to_csv(os.path.join(os.getcwd(), 'merged_df_output.csv'), index=False)
            
        # Get the count of duplicates
        duplicate_count = merged_df.duplicated(subset=['pattern_id_x']).sum()
        print('\t [+] Duplicate records found:', duplicate_count)
            
        # matched_dat(pattern_df, result_df)
        merged_df['pattern_id_x'] = merged_df.apply(calculate_hash, axis=1)

        # Count unique values and duplicate values in the 'Name' column
        unique_counts = merged_df['pattern_id_x'].nunique()  # Count of unique values
        duplicate_counts = merged_df.duplicated(subset='pattern_id_x', keep=False).sum()  # Count of duplicate values
            
        # Display counts of unique and duplicate values
        print("\t --> Count of Unique Values:", unique_counts)
        print("\t --> Count of Duplicate Values:", duplicate_counts)
            

        # .drop_duplicates(subset=['b_party', 'pattern_name', 'case_id','services'])
        final_df = merged_df[['b_party','phone_no_x','imei_no_x','imsi_no_x','day_name_x','start_date_time_x','end_date_time_x','duration','count','frequency','pattern_id_x','pattern_name','pattern_type_x','case_id','services']]

        # Rename the columns to match the original column names`
        final_df.columns = ['b_party','phone_no','imei_no','imsi_no','day_name','start_date_time','end_date_time','duration','count','frequency','pattern_id','pattern_name','pattern_type','case_id','services']
            
        print('\t [+] creating final csv:', len(final_df) )
        #final_df.to_csv(os.path.join(os.getcwd(),'final_df_output.csv' ),index=False)
        #print(final_df)
        return final_df

def cdr_call_integerator(case_id):
    count_check = f"SELECT count(*) FROM u_phone_no WHERE case_id = {case_id} AND phone_no != '' AND phone_no != '0';"
    data_row, data_columns = select_data(count_check)
    total_phone_numbers = data_row[0][0]
    if total_phone_numbers > 0:
        row_phone_numbers_count = 10000
        phone_counter = 0
        while True:
            phone_check = f"SELECT phone_no FROM u_phone_no WHERE case_id = {case_id} AND phone_no != '' AND phone_no != '0' LIMIT {row_phone_numbers_count} OFFSET {phone_counter};"
            phone_no_data_row, phone_no_data_columns = select_data(phone_check)
            phone_numers_df = pd.DataFrame(phone_no_data_row, columns=phone_no_data_columns)
            for ph_index,phone_number_row in phone_numers_df.iterrows():                                
                phone_number = phone_number_row['phone_no']
                print(f"[!!] Deleting data of u_pattern while start {phone_number}")
                # why are we deleting the data?
                # delete_records_phone_no_case_id('u_patterns',phone_number,case_id,'phone_no')
                # delete_records_phone_no_case_id('cdr_conference_calls',phone_number,case_id,'phone_no')
                get_phone_count_records = f"SELECT count(*) FROM ipdr_details WHERE case_id = {case_id} AND phone_no = '{phone_number}' AND mapper_name LIKE '%CDR%' AND cdr_service_type = CALL;"
                data_row, data_columns = select_data(get_phone_count_records)
                total_rows = data_row[0][0]
                if total_rows > 0:
                    row_count = 10000
                    row_counter = 0
                    while True:
                        chunk_ipdr_query = f"SELECT phone_no, b_party, session_duration, imei_no, imsi_no, start_date_time, end_date_time, cell_id,tower_location, tower_state, tower_district, tower_latitude, tower_longitude, tower_pincode, tower_azimuth, second_cell_id, second_tower_location, second_tower_state, second_tower_district, second_tower_latitude, second_tower_longitude, second_tower_pincode, second_tower_azimuth, cdr_call_type FROM ipdr_details WHERE case_id = {case_id} AND phone_no = '{phone_number}' AND mapper_name LIKE '%CDR%' AND cdr_service_type = CALL LIMIT {row_count} OFFSET {row_counter};"
                        data_row, data_columns = select_data(chunk_ipdr_query)
                        if data_row:
                            main_data_df = pd.DataFrame(data_row, columns=data_columns)
                            main_data_df['b_party'] = main_data_df['b_party'].astype(str)
                            unique_b_party = main_data_df['b_party'].unique()

                            bparty_to_subs_mapping = {val: extract_subscriber_details(val) for val in unique_b_party}
                            bparty_to_subs_mapping_dict = {key: list(value) for key, value in bparty_to_subs_mapping.items()}
                            main_data_df[['name' ,'relationer_name','address1','address2','email','dob','area_name','alternate_no','district','pincode', 'lat','long']] = [
                                bparty_to_subs_mapping_dict.get(b_party, ['','','','','','','','','','','',''])
                                for b_party in main_data_df['b_party']
                            ]
                            main_data_df['bparty_details'] = main_data_df.apply(lambda row: {
                                'name': row['name'],
                                'address1': row['address1'],
                                'address2': row['address2'],
                                'email': row['email'],
                                'dob': row['dob'],
                                'relationer_name': row['relationer_name'],
                                'area_name': row['area_name'],
                                'alternate_no': row['alternate_no'],
                                'district': row['district'],
                                'pincode': row['pincode'],
                                'lat': row['lat'],
                                'long': row['long'],
                                'b_party': row['b_party']
                            }, axis=1)
    ########################### Bparty insights started ###############
                            bparty_insights_result = []
                            bparty_insights_df = main_data_df
                            bparty_insights_df = bparty_insights_df[bparty_insights_df['start_date_time'] != 0]
                            bparty_insights_df.sort_values('start_date_time')
                            bparty_insights_df[['Year', 'Month', 'day_name', 'time','date']] = bparty_insights_df['start_date_time'].apply(lambda x: pd.Series(format_timestamp(x)))
                            bparty_insights_df.set_index('start_date_time')


                            bparty_insights_df['slot'] = bparty_insights_df["time"].apply(get_slot)
                            already_existing_b_parties = []
                            pattern_1_data, already_existing_b_parties = get_bparty_insights_result(bparty_insights_df, ['b_party', 'day_name', 'slot', 'cdr_call_type'], 5, 'pattern_1', already_existing_b_parties,case_id)
                            bparty_insights_result.extend(pattern_1_data)
                            pattern_2_data, already_existing_b_parties = get_bparty_insights_result(bparty_insights_df, ['b_party', 'slot', 'cdr_call_type'], 5, 'pattern_2', already_existing_b_parties,case_id)
                            bparty_insights_result.extend(pattern_2_data)
                            pattern_3_data, already_existing_b_parties = get_bparty_insights_result(bparty_insights_df, ['b_party', 'day_name', 'cdr_call_type'], 5, 'pattern_3', already_existing_b_parties,case_id)
                            bparty_insights_result.extend(pattern_3_data)
                            pattern_4_data, already_existing_b_parties = get_bparty_insights_result(bparty_insights_df, ['b_party', 'day_name'], 5, 'pattern_4', already_existing_b_parties,case_id)
                            bparty_insights_result.extend(pattern_4_data)
                            pattern_5_data, already_existing_b_parties = get_bparty_insights_result(bparty_insights_df, ['b_party', 'slot'], 5, 'pattern_5', already_existing_b_parties,case_id)
                            bparty_insights_result.extend(pattern_5_data)
                            pattern_6_data, already_existing_b_parties = get_bparty_insights_result(bparty_insights_df, ['b_party', 'cdr_call_type'], 5, 'pattern_6', already_existing_b_parties,case_id)
                            bparty_insights_result.extend(pattern_6_data)
                            pattern_7_data, already_existing_b_parties = get_bparty_insights_result(bparty_insights_df, ['b_party', 'day_name', 'slot'], 5, 'pattern_7', already_existing_b_parties,case_id)
                            bparty_insights_result.extend(pattern_7_data)
                            # print(bparty_insights_result)
                            if bparty_insights_result:
                                bparty_insights_result = pd.DataFrame(bparty_insights_result)
                                bparty_insights_result['services'] = bparty_insights_result['cdr_call_type']
                                bparty_insights_result.drop(columns='cdr_call_type', inplace=True)
                                bparty_insights_result.fillna('', inplace=True)
                                # print(bparty_insights_result)
                                print(f"\n[+] Row counter range: {row_counter, row_count }")
                                bparty_insights_result.to_csv(os.path.join(os.getcwd(),'b_party_result.csv'), mode='a')
                                if row_counter >= 10000:
                                    clean_pattern_data = get_duplicate_count(case_id, bparty_insights_result)
                                    # delete_records_phone_no_case_id('u_patterns','',case_id,'-phone_no:"" AND -phone_no:"0" AND pattern_type:0 ANd pattern_type:0')
                                    query = f"ALTER TABLE u_patterns DELETE WHERE case_id = {case_id} AND phone_no != '' AND phone_no != '0' AND pattern_type = 0';"
                                    run_delete_query_on_all_nodes(query)
                                    print(f"\t[-->] Records inserted in core: {len(clean_pattern_data)}")
                                    data_insertion(clean_pattern_data,'u_patterns')
                                    # check_indexing_status(case_id, clean_pattern_data)
                                if row_counter < 10000:
                                    print(f"\t[-->] First iteration record count {len(bparty_insights_result)}")
                                    # checking if data exist in core
                                    query = f"select count(*) from u_patterns where case_id = {case_id};"
                                    response_data, response_column = select_data(query)
                                    if response_data[0][0] > 0:
                                        print('\t[i] first insertion of 2nd loop call:')
                                        clean_pattern_data = get_duplicate_count(case_id, bparty_insights_result)
                                        delete_records_phone_no_case_id('u_patterns','',case_id,'-phone_no:"" AND -phone_no:"0" AND pattern_type:0 ANd pattern_type:0')
                                        #u_patterns_solr.add(clean_pattern_data.to_dict('records'),commit=True)
                                        data_insertion(clean_pattern_data,'u_patterns')
                                    else:
                                        #u_patterns_solr.add(bparty_insights_result.to_dict('records'),commit=True)
                                        data_insertion(bparty_insights_result,'u_patterns')
                                        #check_indexing_status(case_id, bparty_insights_result)
                                # u_patterns.add(bparty_insights_result, commit=True)
    ########################### bparty insight end ################
    ########################### location insights started ###############            
                            location_insights_result = []
                            location_insights_df = main_data_df
                            location_insights_df = location_insights_df[location_insights_df['start_date_time'] != 0]
                            location_insights_df.sort_values('start_date_time')
                            location_insights_df[['Year', 'Month', 'day_name', 'time','date']] = location_insights_df['start_date_time'].apply(lambda x: pd.Series(format_timestamp(x)))
                            location_insights_df.set_index('start_date_time')
                            location_insights_df['slot'] = location_insights_df["time"].apply(get_slot)
                            already_existing_cell_ids = []
                            location_insights_df['case_id'] = str(case_id)

                            pattern_1_data, already_existing_cell_ids = get_location_insights_result(location_insights_df, ['cell_id', 'day_name', 'slot', 'cdr_call_type'], 5, 'pattern_1', already_existing_cell_ids,case_id)
                            location_insights_result.extend(pattern_1_data)

                            pattern_2_data, already_existing_cell_ids = get_location_insights_result(location_insights_df, ['cell_id', 'slot', 'cdr_call_type'], 5, 'pattern_2', already_existing_cell_ids,case_id)
                            location_insights_result.extend(pattern_2_data)

                            pattern_3_data, already_existing_cell_ids = get_location_insights_result(location_insights_df, ['cell_id', 'day_name', 'cdr_call_type'], 5, 'pattern_3', already_existing_cell_ids,case_id)
                            location_insights_result.extend(pattern_3_data)

                            pattern_7_data, already_existing_cell_ids = get_location_insights_result(location_insights_df, ['cell_id', 'day_name', 'slot'], 5, 'pattern_7', already_existing_cell_ids,case_id)
                            location_insights_result.extend(pattern_7_data)
                                                        
                            pattern_4_data, already_existing_cell_ids = get_location_insights_result(location_insights_df, ['cell_id', 'day_name'], 5, 'pattern_4', already_existing_cell_ids,case_id)
                            location_insights_result.extend(pattern_4_data)

                            pattern_5_data, already_existing_cell_ids = get_location_insights_result(location_insights_df, ['cell_id', 'slot'], 5, 'pattern_5', already_existing_cell_ids,case_id)
                            location_insights_result.extend(pattern_5_data)

                            pattern_6_data, already_existing_cell_ids = get_location_insights_result(location_insights_df, ['cell_id', 'cdr_call_type'], 5, 'pattern_6', already_existing_cell_ids,case_id)
                            location_insights_result.extend(pattern_6_data)                                                        
                                                        
                            if location_insights_result:
                                location_insights_result = pd.DataFrame(location_insights_result)
                                location_insights_result['services'] =location_insights_result['cdr_call_type']
                                location_insights_result.drop(columns='cdr_call_type', inplace=True)
                                location_insights_result.fillna('', inplace=True)
                                print('[+] Location insight count:',len(location_insights_result))
                                # u_patterns_solr.add(location_insights_result.to_dict('records'),commit=True)
                                data_insertion(location_insights_result,'u_patterns')

                            main_conference_data_df = main_data_df.sort_values(by=['start_date_time', 'end_date_time'])
                            mask = main_conference_data_df['start_date_time'] > main_conference_data_df['end_date_time'].shift().fillna(0)
                                                        
                            main_conference_data_df['conference_group'] = mask.cumsum()
                            column_name = 'tower_location'
                            if column_name not in main_conference_data_df:
                                main_conference_data_df[column_name] = ''
                            main_conference_data_df[column_name].fillna('', inplace=True)
                            cdr_conference_calls_df = main_conference_data_df.groupby(['phone_no', 'conference_group']).agg({
                                'bparty_details': list,
                                'b_party':list,
                                'start_date_time': 'min',
                                'end_date_time': 'max',
                                'imei_no':list,
                                'imsi_no':list,
                                'cell_id':list,
                                'tower_location':list,
                            }).reset_index()
                                                        
                            cdr_conference_calls_df['imei_no'] = cdr_conference_calls_df['imei_no'].apply(lambda x: list(set(x)))
                            cdr_conference_calls_df['imsi_no'] = cdr_conference_calls_df['imsi_no'].apply(lambda x: list(set(x)))
                            cdr_conference_calls_df['cell_id'] = cdr_conference_calls_df['cell_id'].apply(lambda x: list(set(x)))
                            cdr_conference_calls_df['b_party'] = cdr_conference_calls_df['b_party'].apply(lambda x: list(set(x)))
                            cdr_conference_calls_df['tower_location'] = cdr_conference_calls_df['tower_location'].apply(lambda x: list(set(x)))

                            cdr_conference_calls_df.rename(columns={'bparty_details': 'conference_call_details'}, inplace=True)
                            cdr_conference_calls_df.drop('conference_group', axis=1, inplace=True)
                            cdr_conference_calls_df = cdr_conference_calls_df[cdr_conference_calls_df['conference_call_details'].apply(len) > 1]
                            cdr_conference_calls_df['phone_no'] =phone_number
                            cdr_conference_calls_df['case_id'] =str(case_id)
                            # pprint(cdr_conference_calls_df)

                            cdr_conference_calls_df['conference_id'] = cdr_conference_calls_df.apply(calculate_hash, axis=1)
                                                        
                            def list_length_gt_one(lst):return len(lst) > 1

                            def remove_duplicates_b_party_details(input_list):
                                unique_b_party = set()
                                filtered_list = []
                                for item in input_list:
                                    b_party = item['b_party']
                                    if b_party not in unique_b_party:
                                        unique_b_party.add(b_party)
                                        filtered_list.append(item)
                                return filtered_list
                            cdr_conference_calls_df = cdr_conference_calls_df[cdr_conference_calls_df['b_party'].apply(list_length_gt_one)]
                            cdr_conference_calls_df['conference_call_details'] = cdr_conference_calls_df['conference_call_details'].apply(remove_duplicates_b_party_details)
                            #cdr_conference_calls_solr.add(cdr_conference_calls_df.to_dict('records'),commit=True)
                            data_insertion(cdr_conference_calls_df,'cdr_conference_calls')
                        row_counter = row_counter+row_count
                        if row_counter>=total_rows:
                            break
            phone_counter = phone_counter+row_phone_numbers_count
            if phone_counter>=total_phone_numbers:
                break  

def extract_near_by_locations(lat_long):
    location_details_list = []
    if lat_long !='0' and lat_long!='':
        suspicious_location_query = f"""SELECT link, address, phone_no, title, main_category, latitude, longitude FROM suspicious_locations WHERE categories = 'ATM' AND latitude != 0 AND longitude != 0 AND (latitude, longitude) <-> (your_latitude, your_longitude) < 0.5 LIMIT 10;"""
        suspicious_row, suspicious_column = select_data(suspicious_location_query)
        if len(suspicious_row)>0:
            for row in suspicious_row:
                location_details = {
                'link': '',
                'address': '',
                'phone_no': '',
                'title': '',
                'main_category': '',
                'latitude': '',
                'longitude': ''
                }
                location_details['link'] = row[0]
                location_details['address'] = row[1]
                location_details['phone_no'] = row[2]
                location_details['title'] = row[3]
                location_details['main_category'] = row[4]
                location_details['latitude'] = row[5]
                location_details['longitude'] = row[6]
                location_details_list.append(location_details)
                condition_series = are_valid_coordinates(location_details['latitude'],location_details['longitude'])
                if condition_series == True:
                    location_details['lat_long'] = str(location_details['latitude'])+"~~~"+str(location_details['longitude'])
                else:
                    location_details['lat_long']  = '0~~~0'
                location_details_list.append(location_details)
    elif len(location_details_list)==0:
        return None
    else:
        return base64.b64encode(str(location_details_list).encode('utf-8')).decode('utf-8')

def cdr_sms_integerator(case_id):
    print("Processing the cdr sms")
    count_check_query = f"""Select conut(*) from u_phone_no where case_id = '{case_id}' AND phone_no != '' AND phone_no != '0';"""
    row_data, row_column = select_data(count_check_query)
    total_rows = row_data[0][0]
    if int(total_rows) > 0:
        row_phone_numbers_count = 10000
        phone_counter = 0
        while True:
            main_query = f"""select phone_no from u_phone_no where case_id = '{case_id}' AND phone_no != '' AND phone_no != '0' LIMIT {row_phone_numbers_count} OFFSET {phone_counter};"""
            response_data, response_column = select_data(main_query)
            row_count = len(response_data)
            if row_count == 0:
                break
            phone_numers_df = pd.DataFrame(response_data, columns=response_column)
            for ph_index, phone_number_row in phone_numers_df.iterrows():
                phone_number = phone_number_row['phone_no']
                response_query = delete_records_phone_no_case_id(phone_number, case_id, 'phone_no', 'a_party_cash_withdrawl')
                run_delete_query_on_all_nodes(response_query)
                count_query = f"""SELECT count(*) FROM ipdr_details WHERE case_id = '{case_id}' AND phone_no = '{phone_number}' AND mapper_name LIKE '%CDR%' AND cdr_service_type = 'SMS' AND sms_company LIKE '%BANK%' LIMIT 1;"""
                count_data, count_column = select_data(count_query)
                total_count = count_data[0][0]
                if int(total_count) > 0:
                    row_count = 10000
                    row_counter = 0
                    while True:
                        fetch_data_query = f""" SELECT phone_no, b_party, sms_app, sms_company, session_duration, imei_no, imsi_no, start_date_time, end_date_time, cell_id, tower_location, tower_state, tower_district, tower_latitude, tower_longitude, tower_pincode, tower_azimuth, tower_lat_long FROM ipdr_details WHERE case_id = '{case_id}' AND phone_no = '{phone_number}' AND mapper_name LIKE '%CDR%' AND cdr_service_type = 'SMS' AND AND (sms_company LIKE '%BANK%' OR sms_company LIKE '%ATM%' OR sms_app LIKE '%BANK%' OR sms_app LIKE '%ATM%') LIMIT {row_count} OFFSET {row_counter};"""
                        ipdr_data, ipdr_column = select_data(fetch_data_query)
                        if ipdr_data:
                            sms_data_df = pd.DataFrame(ipdr_data, columns=ipdr_column)
                            sms_data_df['count_cell_id'] = sms_data_df.groupby(['phone_no', 'cell_id'])['cell_id'].transform('count')
                            filterd_sms_data_df = sms_data_df[sms_data_df['count_cell_id'] > 4]
                            tower_lat_long_list = filterd_sms_data_df['tower_lat_long'].unique()
                            near_by_mapping = {val: extract_near_by_locations(val) if extract_near_by_locations(val) is not None else '' for val in tower_lat_long_list }
                            near_by_mapping_dict = {key: [value] for key, value in near_by_mapping.items()}
                            filterd_sms_data_df['near_by_atm'] = ""
                            filterd_sms_data_df[['near_by_atm']] = [
                                near_by_mapping_dict.get(tower_lat_long, [''])
                                for tower_lat_long in filterd_sms_data_df['tower_lat_long']
                            ]
                            filterd_sms_data_df = filterd_sms_data_df.groupby(['phone_no','sms_app','sms_company','session_duration','imei_no','imsi_no','cell_id','tower_location','tower_state','tower_district','tower_latitude','tower_longitude','tower_pincode','tower_azimuth','tower_lat_long','b_party','near_by_atm'])['start_date_time'].agg(list).reset_index()
                            filterd_sms_data_df['case_id'] = str(case_id)
                            filterd_sms_data_df['cash_withdrawl_id'] = filterd_sms_data_df.apply(calculate_hash, axis=1)
                            # Insert data in a_party_cash_withdrawl table
                            data_insertion(filterd_sms_data_df,'a_party_cash_withdrawl')
                        row_counter += row_count
                        if row_counter>=total_rows:
                            break
            phone_counter += row_phone_numbers_count
            if phone_counter>=total_rows:
                break

def b_party_family_cluster(arow, b_df):
    def calculate_cluster_similarity(row1, row2):
        return row2.to_dict() if Levenshtein.ratio(row1['name'], row2['name']) >= 0.5 and Levenshtein.ratio(row1['address1'], row2['address1']) >= 0.7 else 0
    def family(row):
       similarities = b_df.apply(lambda brow: calculate_cluster_similarity(row, brow), axis=1)
       l = similarities[similarities != 0].to_list()
       l1 = base64.b64encode(str(l).encode('utf-8')).decode('utf-8')
       return pd.Series([l1, len(l),  l[0]['name'].split()[-1]])
    b_df[['family_members', 'total_members', 'family_name']] = b_df.apply(family, axis=1)
    b_df = b_df.rename(columns={'name': 'bparty_name'})
    b_df['a_party_name'] = arow['name']
    b_df['a_party'] = arow['a_party']
    b_df['a_party_address'] = arow['address1']
    b_df = b_df[['family_members', 'total_members', 'family_name', 'a_party','a_party_name', 'a_party_address']]
    b_df = b_df.drop_duplicates(subset=['family_members'])
    return b_df


def family_relative_neighbour(arow, b_df, case_id):
    print('\n[+----------------------------] entering family  relative function')
    # Retrieve corresponding values from DataFrame based on matched labels
    b_df['relative'] = 0
    b_df['friend'] = 0
    matching_rows = b_df[b_df['last_name'] == arow['last_name']]
    unmatched_row_df = b_df[b_df['last_name'] != arow['last_name']]
    print('[+] Matching rows: ',matching_rows, len(matching_rows))
    print('[+] Unmatched rows: ',unmatched_row_df, len(unmatched_row_df))
    print(f'[+] Count of matching row {len(matching_rows)} and unmatched row: {len(unmatched_row_df)} ' )

    # retrieve aparty and b_party call count and update relative value id sir name match
    for index, row in matching_rows.iterrows():
        print(index)
        a_party_phone_number = row['a_party']
        b_party_phone_number = row['b_party']
        print('[+] Phonenumbers for matched records', a_party_phone_number, b_party_phone_number)
        # aparty and b_party call count query
        call_count_query = f"""Select count(*) from ipdr_details where case_id = '{case_id}' AND a_party='{a_party_phone_number}' AND b_party='{b_party_phone_number}' AND NOT (mapper_name LIKE '%CDR%');"""
        row_data, row_column = select_data(call_count_query)
        cdr_match_count = row_data[0][0]
        print('[+] Call count for matched records', cdr_match_count)
        if cdr_match_count > 1000:
            b_df.loc[(b_df['last_name'] == arow['last_name']) & (b_df['a_party'] == a_party_phone_number) & (b_df['b_party'] == b_party_phone_number), 'relative'] = 1

    # retrieve aparty and b_party call count and update relative value id sir name NOT matched
    for index, row in unmatched_row_df.iterrows():
        print('\n-->-->  row no: ',index)
        a_party_phone_number = row['a_party']
        b_party_phone_number = row['b_party']
        print('[+] phonenumbers for unmatched record: ', a_party_phone_number, b_party_phone_number)
        call_unmatched_query = f"""Select count(*) from ipdr_details where case_id = '{case_id}' AND a_party='{a_party_phone_number}' AND b_party='{b_party_phone_number}' AND NOT (mapper_name LIKE '%CDR%');"""
        row_data, row_column = select_data(call_unmatched_query)
        cdr_unmatch_count = row_data[0][0]
        print('[+] Call count for unmatched records', cdr_unmatch_count)
        if cdr_unmatch_count > 1000:
            b_df.loc[(b_df['a_party'] == a_party_phone_number) & (b_df['b_party'] == b_party_phone_number), 'friend'] = 1
    
    b_df['relative'] = b_df['relative'].fillna(0).astype(int)
    b_df['friend'] = b_df['friend'].fillna(0).astype(int)
    b_df['a_party_name'] = arow['name']
    b_df['a_party_address'] = arow['address1']
    
    b_dff = b_df[(b_df['relative'] != 0) | (b_df['friend'] != 0)]   # remove rows where both relative and friend value is 0
    print('[+] Final output:\n',b_dff)
    return b_dff



def family_cluster(case_id):
    print("Processing the family cluster")
    count_check_query = f"""Select conut(*) from u_phone_no where case_id = '{case_id}' AND phone_no != '' AND phone_no != '0';"""
    row_data, row_column = select_data(count_check_query)
    total_rows = row_data[0][0]
    if int(total_rows) > 0:
        row_phone_numbers_count = 10000
        phone_counter = 0
        while True:
            main_query = f"""select phone_no from u_phone_no where case_id = '{case_id}' AND phone_no != '' AND phone_no != '0' LIMIT {row_phone_numbers_count} OFFSET {phone_counter};"""
            response_data, response_column = select_data(main_query)
            row_count = len(response_data)
            if row_count == 0:
                break
            phone_numers_df = pd.DataFrame(response_data, columns=response_column)
            for ph_index, phone_number_row in phone_numers_df.iterrows():
                phone_number = phone_number_row['phone_no']
                # remove data from a_party_family_neighbour and b_party_family_cluster
                a_party_delete_query = delete_records_phone_no_case_id(phone_number, case_id, 'a_party', 'a_party_family_neighbour')
                run_delete_query_on_all_nodes(a_party_delete_query)
                b_party_delete_query = delete_records_phone_no_case_id(phone_number, case_id, 'a_party', 'b_party_family_cluster')
                run_delete_query_on_all_nodes(b_party_delete_query)

                record_count_query = f"""SELECT count(*) FROM u_aparty_bparty where case_id = '{case_id}' AND a_party = '{phone_number}';"""
                record_count, record_count_column = select_data(record_count_query)
                total_record_count= record_count[0][0]
                if int(total_record_count) > 0:
                    row_count = 10000
                    row_counter = 0
                    while True:
                        u_party_b_party_query = f"""SELECT a_party, b_party FROM u_aparty_bparty where case_id = '{case_id}' AND a_party = '{phone_number}' LIMIT {row_count} OFFSET {row_counter};"""
                        u_party_b_party_data, u_party_b_party_column = select_data(u_party_b_party_query)
                        if u_party_b_party_data:
                            a_party_df_json = {}
                            a_party_df_json['a_party'] = str(phone_number)
                            a_party_df_json['name'] ,a_party_df_json['relationer_name'],a_party_df_json['address1'],a_party_df_json['address2'],a_party_df_json['email'],a_party_df_json['dob'],a_party_df_json['area_name'],a_party_df_json['alternate_no'],a_party_df_json['district'],a_party_df_json['pincode'], a_party_df_json['lat'],a_party_df_json['long'] = extract_subscriber_details(str(phone_number))
                            unique_a_party_df = pd.DataFrame([a_party_df_json])
                            unique_b_party_df = pd.DataFrame(u_party_b_party_data, columns=u_party_b_party_column)
                            unique_b_party_df = unique_b_party_df[unique_b_party_df['a_party'] != unique_b_party_df['b_party']]
                            unique_b_party_df['b_party'] = unique_b_party_df['b_party'].astype(str)
                            unique_b_party_list = unique_b_party_df['b_party'].unique()
                            celld_to_b_party_sub_mapping = {val: extract_subscriber_details(val) 
                            if extract_subscriber_details(val) is not None else '' for val in unique_b_party_list }
                            b_party_sub_dict = {key: list(value) for key, value in celld_to_b_party_sub_mapping.items()}
                            unique_b_party_df[['name' ,'relationer_name','address1','address2','email','dob','area_name','alternate_no','district','pincode', 'lat','long']] = [
                                b_party_sub_dict.get(b_party, ['','','','','','','','','','','',''])
                                for b_party in unique_b_party_df['b_party']
                            ]
                            unique_b_party_df = unique_b_party_df[unique_b_party_df['name']!='']
                            unique_a_party_df = unique_a_party_df[unique_a_party_df['name']!='']
                            if len(unique_a_party_df)!=0:
                                unique_a_party_df['first_name'] = unique_a_party_df['name'].str.split(' ').str[0]
                                unique_a_party_df['last_name'] = unique_a_party_df['name'].str.split(' ').str[1].fillna('')
                                if len(unique_b_party_df)!=0:                                                                
                                    unique_b_party_df['first_name'] = unique_b_party_df['name'].str.split(' ').str[0]
                                    unique_b_party_df['last_name'] = unique_b_party_df['name'].str.split(' ').str[1].fillna('')
                                    print('[+] calling family relative neighbour \n',unique_b_party_df )
                                    a_party_family_df = family_relative_neighbour(unique_a_party_df.iloc[0], unique_b_party_df, case_id)
                                    a_party_family_df['a_party'] = str(phone_number)
                                    a_party_family_df['case_id'] = str(case_id)
                                    a_party_family_df['a_party_family_id'] = a_party_family_df.apply(calculate_hash, axis=1)
                                    # insert the data in a_party_family_neighbour table
                                    data_insertion(a_party_family_df,"a_party_family_neighbour")

                                    b_party_family_df = b_party_family_cluster(unique_a_party_df.iloc[0], unique_b_party_df)
                                    b_party_family_df['case_id'] = str(case_id)
                                    b_party_family_df['b_party_family_id'] = b_party_family_df.apply(calculate_hash, axis=1)
                                    # Insert the data in b_party_family_cluster
                                    data_insertion(b_party_family_df,"b_party_family_cluster")
                        row_counter = row_counter+row_count
                        if row_counter>=total_rows:
                            break
            phone_counter += row_phone_numbers_count
            if phone_counter>=total_rows:
                break

def calculate_commoan_bparty_hash(row):
    combined_values = str(row['b_party']) +str(row['a_parties_list'])+str(row['case_id'])
    sha256_hash = hashlib.sha256(combined_values.encode()).hexdigest()
    return sha256_hash


def common_bparty_cluster(case_id):
    print("[+] calling common_bparty_cluster ")
    u_aparty_bparty_counts_query = f"""SELECT count(*) FROM u_aparty_bparty where case_id = '{case_id}';"""
    u_aparty_bparty_counts_data, u_aparty_bparty_counts_column = select_data(u_aparty_bparty_counts_query)
    total_count = u_aparty_bparty_counts_data[0][0]
    if int(total_count) > 0:
        # clean data from common_bparty_single and common_bparty_joint table
        delete_records_phone_no_case_id('',case_id,'phone_no','common_bparty_single')
        delete_records_phone_no_case_id('',case_id,'phone_no', 'common_bparty_joint')

        # start processing data in chunks
        row_count = 10000
        row_counter = 0
        while True:
            u_aparty_bparty_query = f"""SELECT a_party, b_party FROM u_aparty_bparty where case_id = '{case_id}' LIMIT {row_count} OFFSET {row_counter};"""
            u_aparty_bparty_data, u_aparty_bparty_column = select_data(u_aparty_bparty_query)
            if u_aparty_bparty_data:
                a_party_b_party_df = pd.DataFrame(u_aparty_bparty_data, columns=u_aparty_bparty_column)
                a_party_b_party_df['case_id'] = str(case_id)
                mask = ~a_party_b_party_df.apply(lambda row: any(str(val).isalpha() for val in row), axis=1)
                a_party_b_party_df = a_party_b_party_df[mask]
                common_bparty_joint_result = a_party_b_party_df.groupby('b_party')['a_party'].apply(list).reset_index()
                common_bparty_joint_result['case_id'] = str(case_id)
                common_bparty_joint_result.columns = ['b_party', 'a_parties_list','case_id']

                common_bparty_joint_result = common_bparty_joint_result[common_bparty_joint_result['a_parties_list'].apply(len) > 1]
                if len(common_bparty_joint_result) > 0 :
                    common_bparty_joint_result['a_parties_b_party_hash'] = common_bparty_joint_result.apply(calculate_commoan_bparty_hash, axis=1)
                    common_bparty_joint_result = common_bparty_joint_result[['a_parties_b_party_hash', 'b_party', 'a_parties_list','case_id']]
                    common_bparty_joint_result = common_bparty_joint_result.sort_values(by='b_party')
                    bparty_to_hash = dict(zip(common_bparty_joint_result['b_party'], common_bparty_joint_result['a_parties_b_party_hash']))
                    common_bparty_single_result = a_party_b_party_df[['b_party', 'a_party','case_id']]
                    common_bparty_single_result['a_parties_b_party_hash'] = common_bparty_single_result['b_party'].map(bparty_to_hash)
                    common_bparty_single_result = common_bparty_single_result.sort_values(by='b_party')
                    common_bparty_single_result['common_bparty_single_id'] = common_bparty_single_result.apply(calculate_hash, axis=1)

                    # Insert data in common_bparty_single table and common_bparty_joint table
                    data_insertion(common_bparty_joint_result,"common_bparty_joint")
                    data_insertion(common_bparty_single_result,"common_bparty_single")

            row_counter = row_counter+row_count
            if row_counter>=total_count:
                break


def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # Radius of the Earth in kilometers
    lat1, lon1, lat2, lon2 = map(np.radians, [float(lat1), float(lon1), float(lat2), float(lon2)])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))
    distance = R * c
    return distance


def calculate_combine_hash_case_a_b_mob(row):
    combined_values = str(row['phone_no']) +str(row['b_party']) + str(row['case_id'])
    sha256_hash = hashlib.sha256(combined_values.encode()).hexdigest()
    return sha256_hash


def visited_bparty_location(case_id):
    print("[+] calling visited_bparty_location ")
    phone_counter_query = f"""SELECT count(*) FROM u_phone_no where case_id = '{case_id}' AND phone_no != '' AND phone_no != '0';"""
    phone_counter_data, phone_counter_column = select_data(phone_counter_query)
    total_rows = phone_counter_data[0][0]
    if int(total_rows) > 0:
        # start processing data in chunks
        row_phone_numbers_count = 10000
        phone_counter = 0
        while True:
            u_phone_no_query = f"""SELECT phone_no FROM u_phone_no where case_id = '{case_id}' AND phone_no != '' AND phone_no != '0' LIMIT {row_phone_numbers_count} OFFSET {phone_counter};"""
            u_phone_no_data, u_phone_no_column = select_data(u_phone_no_query)
            if u_phone_no_data:
                phone_number_df = pd.DataFrame(u_phone_no_data, columns=u_phone_no_column)
                for ph_index,phone_number_row in phone_number_df.iterrows():
                    phone_number = phone_number_row['phone_no']
                    # delete records from aparty_visited_bparty
                    delete_records_phone_no_case_id(phone_number,case_id,'phone_no', 'aparty_visited_bparty')
                    tower_movement_count_query = f"""SELECT count(*) FROM u_tower_movements where case_id = '{case_id}' AND phone_no = '{phone_number}';"""
                    tower_movement_count_data, tower_movement_count_column = select_data(tower_movement_count_query)
                    total_movement_count = tower_movement_count_data[0][0]
                    if int(total_movement_count) > 0:
                        row_count = 100000
                        row_counter = 0
                        while True:
                            # fetch data in chunk from u_tower_movements
                            u_tower_movements_query = f"""SELECT start_cell_id, start_tower_latitude, start_tower_longitude, start_tower_location, end_cell_id, end_tower_latitude, end_tower_longitude, end_tower_location, cell_id_start_date_time, cell_id_end_date_time, imei_no, imsi_no, phone_no FROM u_tower_movements where case_id = '{case_id}' AND phone_no = '{phone_number}' LIMIT {row_count} OFFSET {row_counter};"""
                            u_tower_movements_data, u_tower_movements_column = select_data(u_tower_movements_query)
                            if u_tower_movements_data:
                                tower_movement_df = pd.DataFrame(u_tower_movements_data, columns=u_tower_movements_column)
                                df1 = tower_movement_df.groupby(['phone_no', 'start_cell_id','start_tower_latitude','start_tower_longitude','start_tower_location'])[['cell_id_start_date_time','imei_no','imsi_no']].agg({'cell_id_start_date_time': list, 'imei_no': list, 'imsi_no': list}).reset_index()
                                df1.rename(columns={'start_cell_id': 'cell_id', 'cell_id_start_date_time': 'time_list', 'start_tower_latitude': 'tower_latitude', 'start_tower_longitude': 'tower_longitude', 'start_tower_location': 'tower_location'}, inplace=True)
                                df2 = tower_movement_df.groupby(['phone_no', 'end_cell_id','end_tower_latitude','end_tower_longitude','end_tower_location'])[['cell_id_end_date_time','imei_no','imsi_no']].agg({'cell_id_end_date_time': list, 'imei_no': list, 'imsi_no': list}).reset_index()
                                df2.rename(columns={'end_cell_id': 'cell_id', 'cell_id_end_date_time': 'time_list', 'end_tower_latitude': 'tower_latitude', 'end_tower_longitude': 'tower_longitude', 'end_tower_location': 'tower_location'}, inplace=True)
                                tower_df = pd.concat([df1, df2]).groupby(['phone_no', 'cell_id','tower_latitude','tower_longitude','tower_location'])[['time_list','imei_no','imsi_no']].sum().reset_index()
                                tower_df['imei_no'] = tower_df['imei_no'].apply(lambda x: list(set(x)))
                                tower_df['imsi_no'] = tower_df['imsi_no'].apply(lambda x: list(set(x)))
                                tower_df['tower_lat_long'] = tower_df['tower_latitude'].astype(str)+','+tower_df['tower_longitude'].astype(str)
                                
                                unique_b_party_df = []
                                bparty_count_query = f"""SELECT count(*) FROM u_aparty_bparty where case_id = '{case_id}' AND phone_no = '{phone_number}';"""
                                bparty_row_data, bparty_row_column = select_data(bparty_count_query)
                                total_bparty_count = bparty_row_data[0][0]
                                if int(total_bparty_count) > 0:
                                    row_count = 100000
                                    row_counter = 0
                                    bparty_query = f"""SELECT bparty_no FROM u_aparty_bparty where case_id = '{case_id}' AND phone_no = '{phone_number}' LIMIT {row_count} OFFSET {row_counter};"""
                                    bparty_row_data, bparty_row_column = select_data(bparty_query)
                                    if bparty_row_data:
                                        unique_b_party_df = pd.DataFrame(bparty_row_data, columns=bparty_row_column)
                                        unique_b_party_df['b_party'] = unique_b_party_df['b_party'].astype(str)
                                        unique_b_party_list = unique_b_party_df['b_party'].unique()
                                        celld_to_b_party_sub_mapping = {val: extract_subscriber_details(val) if extract_subscriber_details(val) is not None else '' for val in unique_b_party_list }
                                        b_party_sub_dict = {key: list(value) for key, value in celld_to_b_party_sub_mapping.items()}
                                        unique_b_party_df[['name' ,'relationer_name','address1','address2','email','dob','area_name','alternate_no','district','pincode', 'lat','long']] = [
                                                            b_party_sub_dict.get(b_party, ['','','','','','','','','','','',''])
                                                            for b_party in unique_b_party_df['b_party']
                                                        ]
                                        unique_b_party_df = unique_b_party_df[unique_b_party_df['lat']!='']
                                        unique_b_party_df = unique_b_party_df[unique_b_party_df['long']!='']
                                        unique_b_party_df['bparty_lat_long'] = unique_b_party_df['lat']+','+unique_b_party_df['long']
                                        if len(unique_b_party_df)!=0:
                                            visited_b_party_df = pd.DataFrame(columns=['tower_lat_long', 'bparty_lat_long', 'name' ,'relationer_name','address1','address2','b_party','email','dob','area_name','alternate_no','district','pincode','phone_no','imei_no','imsi_no','cell_id','tower_location','case_id'])

                                            for _, row1 in tower_df.iterrows():
                                                for _, row2 in unique_b_party_df.iterrows():
                                                    distance = haversine(row1['tower_latitude'], row1['tower_longitude'], row2['lat'], row2['long'])
                                                    # print(distance,'<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<')
                                                    if distance <= 2.0:                                                                                            
                                                        visited_b_party_df = pd.concat([visited_b_party_df, pd.DataFrame({'tower_lat_long': row1['tower_lat_long'],'bparty_lat_long': row2['bparty_lat_long'],'name': row2['name'],
                                                        'relationer_name': row2['relationer_name'],
                                                        'address1': row2['address1'],
                                                        'address2': row2['address2'],
                                                        'b_party': row2['b_party'],
                                                        'email': row2['email'],
                                                        'dob': row2['dob'],
                                                        'area_name': row2['area_name'],
                                                        'alternate_no': row2['alternate_no'],
                                                        'district': row2['district'],
                                                        'pincode': row2['pincode'],
                                                        'phone_no': row1['phone_no'],
                                                        'imei_no': row1['imei_no'],
                                                        'imsi_no': row1['imsi_no'],
                                                        'cell_id': row1['cell_id'],
                                                        'tower_location': row1['tower_location'],
                                                        'case_id':str(case_id)})], ignore_index=True)

                                                        visited_b_party_df['aparty_visited_bparty_hash'] = visited_b_party_df.apply(calculate_combine_hash_case_a_b_mob, axis=1)

                                                        if distance <= 0.2:
                                                            visited_b_party_df['accuracy']='accuracy1'
                                                        elif distance <= 0.5:
                                                            visited_b_party_df['accuracy']='accuracy2'
                                                        elif distance <= 1.0:
                                                            visited_b_party_df['accuracy']='accuracy3'
                                                        elif distance <= 1.5:
                                                            visited_b_party_df['accuracy']='accuracy4'
                                                        else:
                                                            visited_b_party_df['accuracy']='accuracy5'
    
                                                        data_insertion(visited_b_party_df,'aparty_visited_bparty')

                            row_counter += row_count
                            if row_counter>=total_movement_count:
                                break

            phone_counter +=row_phone_numbers_count
            if phone_counter>=total_rows:
                break 

def update_pcap_extracted_media(file_meta_id):
    IPDR_CONN = ipdr_conn()
    cursor_ipdr = IPDR_CONN.cursor()   
    sql = "UPDATE %s  SET is_extracted_media=1 WHERE ID=%s" % ('files_meta_details', file_meta_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()
    IPDR_CONN.close()

def media_reconstruction(case_id,file_dict_list,dc_path):
    for pcap_file in file_dict_list:
        phone_no = pcap_file['pcap_phone_no']
        public_ip_address = pcap_file['pcap_public_ip_address']
        
        if pcap_file['file_format'] == "gprsdata":
            pcap_dir_name = pcap_file['path']+'/'+str(pcap_file['name']).split('.')[0]+'/'
            full_path_pcap = str(pcap_file['path'])+'/'+str(pcap_file['name']).split('.')[0]+'/'+str(pcap_file['file_hash'])+'.pcap'
            pcap_file_name = pcap_file['file_hash']+'.pcap'
        else:
            pcap_dir_name = pcap_file['path']+'/'
            full_path_pcap  = pcap_file['path']+'/'+pcap_file['name']
            pcap_file_name = pcap_file['name']

        full_path_pcap_rtp = open(pcap_dir_name+'/'+pcap_file_name+".rtp",'w')
        full_path_pcap_rtp.close()
        dc_command  = dc_path+" "+ full_path_pcap
        platform_name = platform.system()
        try:os.mkdir(pcap_dir_name+ "//AssemblededFiles")
        except:pass
        try:os.mkdir(pcap_dir_name+ "//AssemblededFiles//cache")
        except:pass
        os.chdir(pcap_dir_name)
        if platform_name == "Windows":            
            os.system(dc_command)            
        else:
            os.system("mono "+dc_command)
        os.chdir(current_path)        
        s3_extract = pcap_dir_name + "//" + pcap_file_name.split(".")[0]
        try:
            os.mkdir(s3_extract)
            shutil.move(pcap_dir_name + "//AssemblededFiles", s3_extract)
        except:pass
        
        extractFileList=[]
        credentialList=[]
        netwrok_m_jsonFileData = open(pcap_dir_name + "//" + pcap_file_name + ".json", 'rb').readlines()
        for lines in netwrok_m_jsonFileData:
            nm_row = json.loads(lines.strip())
            
            try:
                domain_name = nm_row["sIp"].split(" ")[1].replace("[","").replace("]","")
            except:
                try:
                    domain_name = nm_row["dIp"].split(" ")[1].replace("[","").replace("]","")
                except:
                    domain_name =""
            timestampFrame = nm_row["eTimestamp"]
            filePath = nm_row["efilePath"]
            fileName = nm_row["efilename"]
            fileExt = nm_row["efileExt"]
            fileType = nm_row["efileStreamType"]
            fileSize = nm_row["efilesize"]
            clientToServer = nm_row["fileFlow"]
            if clientToServer == True:
                sourceIp = nm_row["sIp"].split(" ")[0]
                sourcePort = nm_row["sPort"]
                destinationIp = nm_row["dIp"].split(" ")[0]
                destinationPort = nm_row["dPort"]
            else:
                sourceIp = nm_row["dIp"].split(" ")[0]
                sourcePort = nm_row["dPort"]
                destinationIp = nm_row["sIp"].split(" ")[0]
                destinationPort = nm_row["sPort"]
            fileSHA256 = nm_row["eSHA256Sum"]
            fileArrivalFrameNumber = nm_row["eFrameNumber"]
            u_timeFrame = int(timestampFrame.split(".")[0])
            if public_ip_address=='':
                public_ip_address = sourceIp
            
            # u_filePath = "http://122.170.220.44:8080//"+lat_folder_name+filePath.split(lat_folder_name+"\\AssemblededFiles")[1].replace("\\","//")
            u_filePath = pcap_dir_name + "//" + pcap_file_name.split(".")[0]+ "//AssemblededFiles//"  + filePath.split("AssemblededFiles")[1]
            file_dict = {"phone_no":phone_no,"public_ip_address": public_ip_address,"public_ip_port": sourcePort,'source_ip_address':sourceIp,'source_port':sourcePort,"destination_ip_address": destinationIp,"destination_port": destinationPort,"file_name": fileName, "file_type": fileType, "file_size": fileSize,"file_flow": clientToServer,"file_hash": fileSHA256,  "file_extension": fileExt,"file_frame_number": fileArrivalFrameNumber, "start_date_time": u_timeFrame,"file_path_location": u_filePath,'case_id':str(case_id),"domain_name":domain_name}
            combined_values = file_dict['phone_no']+" "+file_dict['case_id']+' '+file_dict['file_hash']
            file_dict['extracted_media_id'] = hashlib.sha256(combined_values.encode()).hexdigest()
            extractFileList.append(file_dict)
        cred_jsonFileData = open(pcap_dir_name + "//" + pcap_file_name + ".cred", 'rb').readlines()
        for lines in cred_jsonFileData:
            nm_row = json.loads(lines.strip())                    
            sourceIp = nm_row["clientIp"].split(" ")[0]
            if public_ip_address == '':
                public_ip_address = sourceIp
            sourcePort = nm_row["clientPort"]
            destinationIp = nm_row["serverIp"].split(" ")[0]
            destinationPort = nm_row["serverPort"]
            timestampFrame = nm_row["timestamp"]
            username = nm_row["username"]
            password = nm_row["password"]
            domain = nm_row["domain"]
            if domain =='null' or domain is None:
                domain=''
            u_timeFrame = int(timestampFrame.split(".")[0])                    
            cred_dict = {"phone_no":phone_no,"public_ip_address": public_ip_address,"public_ip_port": sourcePort,'source_ip_address':sourceIp,'source_port':sourcePort,"destination_ip_address": destinationIp,"destination_port": destinationPort,"username": username, "password": password, "domain_name": domain,"start_date_time": u_timeFrame,'case_id':str(case_id)}
            combined_values = file_dict['phone_no']+" "+ str(file_dict['case_id'])+' '+file_dict['destination_ip_address']+' '+str(file_dict['destination_port'])
            cred_dict['credential_id'] = hashlib.sha256(combined_values.encode()).hexdigest()
            credentialList.append(cred_dict)
        # Insert data to pcap_user_credentials, pcap_extracted_media tables
        data_insertion(credentialList,"pcap_user_credentials")
        data_insertion(extractFileList,"pcap_extracted_media")
        update_pcap_extracted_media(pcap_file['file_meta_id'])


def calculate_similarity_score(number1, number2):
    difference = abs(number1 - number2)
    max_value = max(number1, number2)
    similarity_score = 1 - (difference / max_value)
    return similarity_score

def update_llmstatus(IPDR_CONN,case_id):
    cursor_ipdr = IPDR_CONN.cursor()   
    sql = "UPDATE %s  SET is_llm_train=0 WHERE case_id=%s" % ('case_details', case_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()

def update_voipstatus(IPDR_CONN,case_id):
    cursor_ipdr = IPDR_CONN.cursor()   
    sql = "UPDATE %s  SET voip_status=1 WHERE case_id=%s" % ('case_details', case_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()


def correlation_data_insertion_for_mediafiles(ipdr_data_df_main_row):
    # print(ipdr_data_df_main_row)
    ipdr_data_df_main_row = ipdr_data_df_main_row.to_dict()
    a_party = ipdr_data_df_main_row['phone_no']
    media_upload_data_main = ipdr_data_df_main_row['media_upload_data']
    case_id = ipdr_data_df_main_row['case_id']
    ipdr_hash_count_query = f""" SELECT count(*) FROM ipdr_details WHERE case_id = '{case_id}' ANd phone_no != '{a_party}' AND (app_name LIKE '%TLS_WhatsAppFiles%' OR app_name LIKE '%TLS_WHATSAPPFILES%') AND media_upload_download = 'Download' AND media_download_data <= '{media_upload_data_main}'; """
    count_rows, count_column = select_data(ipdr_hash_count_query)
    total_corelation_rows = count_rows[0][0]
    if int(total_corelation_rows) > 1:
        start_corelation_counter = 0
        row_corelation_counter = 1
        while True:
            ipdr_detail_chunk_query = f""" SELECT b_party, media_upload_download, media_download_data FROM ipdr_details WHERE case_id = '{case_id}' ANd phone_no != '{a_party}' AND (app_name LIKE '%TLS_WhatsAppFiles%' OR app_name LIKE '%TLS_WHATSAPPFILES%') AND media_upload_download = 'Download' AND media_download_data <= '{media_upload_data_main}' LIMIT {row_corelation_counter} OFFSET {start_corelation_counter};"""
            rows_data, row_cloumn = select_data(ipdr_detail_chunk_query)
            if rows_data:
                b_party_ipdr_data = rows_data[0]
                downloaded_data = b_party_ipdr_data[2]
                similarity_score = calculate_similarity_score(float(media_upload_data_main), float(downloaded_data))
                similarity_score = similarity_score*100
                        
                if similarity_score >90:
                    ipdr_data_df_main_row['matching_score'] = similarity_score
                    ipdr_data_df_main_row['b_party'] = b_party_ipdr_data['b_party']
                    ipdr_data_df_main_row['b_party_media_download_upload'] = b_party_ipdr_data['media_upload_download']
                    ipdr_data_df_main_row['b_party_media_download_data'] = b_party_ipdr_data['media_download_data']
                            
                    ipdr_data_df_main_row['correlation_hash'] = calculate_hash(ipdr_data_df_main_row)                           
                    data_insertion(ipdr_data_df_main_row, "ipdr_details")
                else: 
                    break
            start_corelation_counter = start_corelation_counter+row_corelation_counter
            if start_corelation_counter>=total_corelation_rows:
                break 
            

def media_files_corelation_integerator(case_id):
    print("[+] media_files_corelation_integerator")
    phone_no_count_query = f""" SELECT count(*) from u_phone_no where case_id = '{case_id}' ;"""
    rows_data, row_cloumn = select_data(phone_no_count_query)
    if int(rows_data[0][0]) > 1:
        ipdr_sessionhash_count_query = f""" SELECT count(*) FROM ipdr_details WHERE case_id = '{case_id}' AND (app_name LIKE '%TLS_WhatsAppFiles%' OR app_name LIKE '%TLS_WHATSAPPFILES%') AND media_upload_download = 'Upload'; """
        rows_data, row_cloumn = select_data(ipdr_sessionhash_count_query)
        total_rows = rows_data[0][0]
        if int(rows_data[0][0]) > 0:
            start_counter = 0
            row_counter = 100000
            while True:
                ipdr_data_query = f""" SELECT phone_no, imei_no, imsi_no, public_ip_address, public_ip_port, source_ip_address, source_port, destination_ip_address, destination_port, start_date_time, end_date_time, session_duration, cell_id, tower_location, service_provider_detail, app_name, media_upload_download, media_upload_data, ip_country FROM ipdr_details WHERE case_id = '{case_id}' AND (app_name LIKE '%TLS_WhatsAppFiles%' OR app_name LIKE '%TLS_WHATSAPPFILES%') AND media_upload_download = 'Upload' limit {row_counter} offset {start_counter};"""
                ipdr_row_data, ipdr_column = select_data(ipdr_data_query)
                if ipdr_row_data:
                    ipdr_data_df = pd.DataFrame(ipdr_row_data, columns=ipdr_column)
                    ipdr_data_df['case_id'] = str(case_id)
                    ipdr_data_df.apply(correlation_data_insertion_for_mediafiles,axis=1)
                start_counter = start_counter+row_counter
                if start_counter  >= total_rows:
                    break



# main function
if __name__ == '__main__':

    mp.freeze_support()

    data_config_json_file= open('database.config','r').read()
    database_json = json.loads(data_config_json_file)
    # identify the platform
    platform_name = platform.system()
    if platform_name == "Windows":            
        dc_path = str(database_json['dc_path_windows'])
    else:
        dc_path = str(database_json['dc_path_linux'])
    
    while True:
        time.sleep(1)
        conn = ipdr_conn()
        cursor = conn.cursor()
        cursor.execute("SELECT case_id FROM case_details where voip_status = 0")
        case_id_result = cursor.fetchall()
        if case_id_result:
            for result in case_id_result:
                # print("waiting for voip correlation to complete")
                case_id = result[0]
                res= cursor.execute("SELECT ID as file_meta_id,uploadStatus,file_format,file_type,path,name,pcap_phone_no,pcap_public_ip_address,file_hash,is_extracted_media FROM files_meta_details WHERE case_id="+str(case_id))
                dataframe_file_meta_details = pd.DataFrame.from_records(cursor.fetchall(),columns=[desc[0] for desc in cursor.description])
                all_status = dataframe_file_meta_details['uploadStatus'].tolist()
                file_format_list = dataframe_file_meta_details['file_format'].tolist()
                file_type_list = dataframe_file_meta_details['file_type'].tolist()
                file_details_list = dataframe_file_meta_details.to_dict('records')
                
                if 0 not in all_status and 1 not in all_status and len(all_status)!=0:
                    if 'ipdr' in file_type_list or 'broadband' in file_type_list or 'pcap' in file_format_list or 'pcapng' in file_format_list or 'gprsdata' in file_format_list:
                        try:
                            vpn_corelation_integerator(case_id)
                        except:
                            logging.error('vpn_corelation_integerator Failed: '+str(traceback.format_exc()))
                        try:
                            known_voip_corelation_integerator(case_id)
                        except Exception:
                            logging.error('known_voip_corelation_integerator Failed: '+str(traceback.format_exc()))

                    try:
                        tower_integerator(case_id)
                    except Exception:
                        logging.error('tower_integerator Failed: '+str(traceback.format_exc()))      

                    if 'cdr' in file_type_list:
                        try:
                            pass
                            cdr_call_integerator(case_id)
                        except Exception:
                            logging.error('cdr_call_integerator Failed: '+str(traceback.format_exc()))
                        try:
                            cdr_sms_integerator(case_id)
                        except Exception:
                            logging.error('cdr_sms_integerator Failed: '+str(traceback.format_exc()))
                        try:
                            family_cluster(case_id)
                        except Exception as e:
                            print('[!] ERROR: ',e)
                            logging.error('family_cluster Failed: '+str(traceback.format_exc()))
                        try:
                            common_bparty_cluster(case_id)
                        except Exception:
                            logging.error('common_bparty_cluster Failed: '+str(traceback.format_exc()))
                        try:
                            visited_bparty_location(case_id)
                        except Exception:
                            logging.error('visited_bparty_location Failed: '+str(traceback.format_exc()))
                    # Pcap, Pcapng, Gprsdata data processing functions
                    if 'pcap' in file_format_list or 'pcapng' in file_format_list or 'gprsdata' in file_format_list:
                        try:
                            file_details_list = [item for item in file_details_list if item.get('file_format') in ['pcap','pcapng','gprsdata'] and item.get('is_extracted_media') == 0 and item.get('uploadStatus') == 2]
                            if len(file_details_list)!=0:
                                media_reconstruction(case_id,file_details_list,dc_path)
                        except Exception:
                            logging.error('media_reconstruction Failed: '+str(traceback.format_exc()))

                        try:
                            media_files_corelation_integerator(case_id,ipdr_details_select_solr)
                        except Exception:
                            logging.error('media_files_corelation_integerator Failed: '+str(traceback.format_exc()))

                    # Update the voip_status and is_llm_train in case_details table
                    update_voipstatus(conn,case_id)
                    update_llmstatus(conn,case_id)
        conn.close()
        