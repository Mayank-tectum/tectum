import multiprocessing as mp
import pyximport; pyximport.install(),
import os
import re
import datetime
from statistics import multimode
import time,math
from tarfile import SUPPORTED_TYPES
# from itertools import islice
# from turtle import Turtle
import pandas as pd
import urllib.parse
import numpy as np
import pyodbc
import pygeoip
import socket
import hashlib
from ipaddress import ip_address, IPv4Address
from pprint import pprint
import multiprocessing as mp

from multiprocessing import Process, Queue
# import threading
from multiprocessing import Pool, cpu_count, current_process,set_start_method
import shutil,platform,subprocess
import netaddr,macaddress,psutil
import json
import ipaddress
from subprocess import check_output
import uuid
import traceback
import warnings
from itertools import tee
from urllib.parse import quote 
from dateutil import parser
from bs4 import BeautifulSoup
import logging
import maxminddb,requests
import pysolr
import data_extractor as de


if __name__ == '__main__':
    
    mp.freeze_support()
    # mp.set_start_method('spawn')
    de.start()