import multiprocessing as mp
import resolve_ip as re_ip

if __name__ == '__main__':
    
    mp.freeze_support()    
    re_ip.start()