import os,netaddr,time,hashlib,datetime,macaddress,uuid
from subprocess import check_output
def local_license_verification():
    file_time= 0

    getStarterIPList = open(os.path.join(os.getcwd(),'files',"vpn_address.txt"),"r").readlines()
    license_status = False
    operating_system = os.name
    if operating_system == 'nt':
        if os.path.isfile(os.path.join(os.getcwd(),'files','vpn_address.txt')):
            time_ip_address = getStarterIPList[8].replace("\n",'').replace("/24",'')
            license_harddrive_serial_number_hash = getStarterIPList[9].replace("\n",'')
            
            license_time = int(netaddr.IPAddress(time_ip_address))
            current_time = int(time.mktime((datetime.datetime.now()).timetuple()))
            harddrive_serial_number = check_output("vol C:", shell=True).decode().split('\n')[1:][0].split("is ")[1].strip()
            current_harddrive_serial_number_hash = hashlib.sha256(harddrive_serial_number.encode()).hexdigest()
            
            
            if current_time <= license_time and license_harddrive_serial_number_hash == current_harddrive_serial_number_hash:
                license_status = True
            else:
                license_status  = False
            if file_time > license_time or license_harddrive_serial_number_hash != current_harddrive_serial_number_hash:
                
                license_status = False
            
        else:
            license_status = False
    else:
        if os.path.isfile(os.path.join(os.getcwd(),'files','vpn_address.txt')):
        
            # getStarterIPList = open(os.path.join(os.getcwd(),asset_dir,'vpn_address.txt'),'r').readlines()
            time_ip_address = getStarterIPList[8].replace("\n",'').replace("/24",'')
            mac_ip_address = getStarterIPList[9].replace("\n",'').replace("/24",'')
            # print(time_ip_address,mac_ip_address)
            license_time = int(netaddr.IPAddress(time_ip_address))
            license_mac_int  = int(netaddr.IPAddress(mac_ip_address))
            current_time = int(time.mktime((datetime.datetime.now()).timetuple()))
            
            current_mac_address = ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
            for ele in range(0,8*6,8)][::-1])
            current_mac_add = macaddress.MAC(current_mac_address)
            current_mac_int = int(current_mac_add)
            # print(license_time,current_time,license_mac_int,current_mac_int)
            if current_time <= license_time and license_mac_int == current_mac_int:
                license_status = True
            else:
                license_status  = False
            if file_time > license_time or license_mac_int != current_mac_int:
                
                license_status = False
            
        else:
            license_status = False
    if license_status ==True:
        print(0)
    else:print(1)
local_license_verification()