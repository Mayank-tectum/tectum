# -*- coding: latin1 -*-
import pyximport; pyximport.install()
import os
import re
import magic,pytz
import rarfile
import datetime
from statistics import multimode
import time
import zipfile
from datetime import timedelta
import phonenumbers
import pycountry
from phonenumbers.phonenumberutil import region_code_for_number
import maxminddb
import pandas as pd
import numpy as np
import socket
import hashlib
from ipaddress import ip_address, IPv4Address
import multiprocessing as mp
import shutil,platform,subprocess
import json
import ipaddress
import traceback
import warnings
from itertools import tee
from dateutil import parser
from bs4 import BeautifulSoup
import logging
import maxminddb,requests,base64
import pysolr
from user_agents import parse
from mysql.connector import pooling
import data_extractor as de


if __name__ == '__main__':
    print(f"[+] starting data extractor")
    mp.freeze_support()
    CURR_WORK_DIR= os.getcwd()
    agent_id =  int(input("Enter agent ID: "))
    bulker_agent_dir=f"bulker_{agent_id}"
    try:
        os.mkdir(CURR_WORK_DIR+f"//{bulker_agent_dir}")
    except:pass
    BULKER_DIR = os.path.join(CURR_WORK_DIR, bulker_agent_dir)
    # start(agent_id,BULKER_DIR)    
    # mp.set_start_method('spawn')
    de.start(agent_id,BULKER_DIR)
    print(f"[i] Handling multiprocessing")
