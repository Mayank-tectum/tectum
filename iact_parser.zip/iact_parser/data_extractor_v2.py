import os
import re
import magic,pytz
import rarfile
import datetime
import time
import zipfile
from datetime import timedelta
import phonenumbers
import pycountry
from phonenumbers.phonenumberutil import region_code_for_number
import maxminddb
import pandas as pd
import numpy as np
import socket
import hashlib
from ipaddress import ip_address, IPv4Address
import multiprocessing as mp
import shutil,platform,subprocess
import json
import ipaddress
import traceback
import warnings
from itertools import tee
from dateutil import parser
from bs4 import BeautifulSoup
import logging
import maxminddb,requests,base64
import pysolr
from user_agents import parse
from mysql.connector import pooling
from concurrent.futures import ThreadPoolExecutor


class CustomAuth(requests.auth.AuthBase):
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def __call__(self, r):
        # Add your custom authentication logic here
        auth_string = f'{self.username}:{self.password}'.encode('utf-8')
        auth_bytes = base64.b64encode(auth_string)
        auth_header = f'Basic {auth_bytes.decode("utf-8")}'
        r.headers['Authorization'] = auth_header
        return r


def get_device_info(user_agent_string):
    device_info = 'UNKNOWN'
    user_agent_string = str(user_agent_string)
    if user_agent_string!='' and user_agent_string!='0':
        user_agent = parse(user_agent_string)
        device_info = 'UNKNOWN'
        if user_agent.device.brand != None:
            device_info = str(user_agent.device.brand)
        if user_agent.device.model != None:
            if device_info == 'UNKNOWN':
                model_string =  str(user_agent.device.model)
            else:
                model_string = "-" + str(user_agent.device.model)
            device_info += model_string
    
    if device_info =='' or device_info ==None:
        device_info = 'UNKNOWN'
    return device_info

json_file= open('database.config','r').read()
database = json.loads(json_file)
auth = CustomAuth(database['SOLR_USERNAME'], database['SOLR_PASSWORD'])
ipdr_details_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/ipdr_details',auth=auth,timeout=500)
apk_ipa_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_apk_ipa_name',auth=auth,timeout=500)
vpn_name_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_vpn_name',auth=auth,timeout=500)
phone_no_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_phone_no',auth=auth,timeout=500)
sip_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_source_ip_address',auth=auth,timeout=500)
pip_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_public_ip_address',auth=auth,timeout=500)
dip_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_destination_ip_address',auth=auth,timeout=500)
cell_id_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_cell_id',auth=auth,timeout=500)
imei_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_imei_no',auth=auth,timeout=500)
imsi_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_imsi_no',auth=auth,timeout=500)
tower_pincode_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_tower_pincode',auth=auth,timeout=500)
tower_lat_long_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_tower_lat_long',auth=auth,timeout=500)
destination_ip_phone_no_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_destination_ip_phone_no_solr',auth=auth,timeout=500)
apkipa_phone_no_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_apkipa_phone_no',auth=auth,timeout=500)
active_inactive_period_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/active_inactive_period',auth=auth,timeout=500)
a_party_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_a_party',auth=auth,timeout=500)
a_party_solr_ipdr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_a_party_ipdr',auth=auth,timeout=500)
b_party_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_b_party',auth=auth,timeout=500)
a_party_b_party_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_aparty_bparty',auth=auth,timeout=500)
a_party_date_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_aparty_date',auth=auth,timeout=500)
phone_no_imei_no_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_phone_no_imei_no',auth=auth,timeout=500)
phone_no_cell_id_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_phone_no_cell_id',auth=auth,timeout=500)
subscriber_details_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/u_subscriber_details',auth=auth,timeout=500)
meeting_point_solr = pysolr.Solr(f'{database["server_url"]}:{database["solr_port"]}/solr/meeting_point_essential',timeout=500)




logging.basicConfig(filename='crashanalytics1.log',  level=logging.ERROR,format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
data_dict = []
path= os.getcwd()

warnings.filterwarnings("ignore")
try:
    os.mkdir(path+"//bulker")
except:pass
try:
    os.mkdir(path+"//dst_bulker")
except:pass
try:
    os.mkdir(path+"//temp_file_exit")
except:pass

CURR_WORK_DIR = os.getcwd()
SOURCE_DIR = os.path.join(CURR_WORK_DIR, 'source')
BULKER_DIR = os.path.join(CURR_WORK_DIR, 'bulker')
DST_BULKER_DIR = os.path.join(CURR_WORK_DIR, 'dst_bulker')
FILE_EXIT_DIR = os.path.join(CURR_WORK_DIR, 'temp_file_exit')

SUPPORTED_CATEGORY = ['airtel','vi','jio','bsnl']

CASE_ID = ''
FILE_ID = ''



def calculate_hash(df):
    combined_values = df.astype(str).to_numpy().sum(axis=1)
    hashed_values = np.array([hashlib.sha256(val.encode()).hexdigest() for val in combined_values])
    return hashed_values

def asset_builder(i):
    asset_dir = os.path.join(os.getcwd(),'temp',i)
    if not os.path.exists(asset_dir):
        shutil.copytree(os.path.join(CURR_WORK_DIR,"files"), asset_dir)
    return asset_dir

# creating the pool for the Mysql connection
json_file = open('database.config','r').read()
database = json.loads(json_file)
def ipdr_conn():
    dbconfig = {
        "database": database['database_name'],
        "user": database['database_user'],
        "password": database['database_password'],
        "host": database['database_url'],
        "port": database['database_port']
    }
    connection_pool = pooling.MySQLConnectionPool(pool_name="mypool", pool_size=5, **dbconfig)
    return connection_pool.get_connection()


def voip_call_b_party_checker(isp_port_diff_list):
    b_party_status = 'no'
    voip_call_platform_name = 'P2P CONNECTIONS'
    destination_ports,operator_list,voip_call_index = [int(float(elem.split('######')[0])) for elem in isp_port_diff_list], [elem.split('######')[1] for elem in isp_port_diff_list], [str(i) for i in range(len(isp_port_diff_list))]
    for operators in isp_port_diff_list:
        operators = str(operators)
        b_party_counter = 0
        if operators != None:
            if operators.upper().find("FACEBOOK") == -1 and operators.upper().find("TELEGRAM") == -1 and operators.upper().find("MICROSOFT") == -1 and operators.upper().find("GOOGLE") == -1 and operators.upper().find("BIGO") == -1 and operators.upper().find("DNIC") == -1 and operators.upper().find("AMAZON") == -1 and operators.upper().find("APPLE") == -1  and operators.upper().find("UNKNOWN") == -1 and operators.split("######")[0] != '3478' and operators.split("######")[0] != 'nan' and  b_party_counter == 0:
                b_party_status = 'yes'
                b_party_counter = 1
                break
            
    for operators in operator_list:
            if operators.upper().find("FACEBOOK") != -1 and ((3478 in destination_ports or 3479 in destination_ports) and (40001 in destination_ports or 40002 in destination_ports or 40003 in destination_ports or 40004 in destination_ports or 40005 in destination_ports)):
                voip_call_platform_name = 'INSTAGRAM'
                break
            if operators.upper().find("FACEBOOK") != -1:
                voip_call_platform_name = 'WHATSAPP/MESSENGER'
                break
            if operators.upper().find("DISCORD") != -1:
                voip_call_platform_name = 'DISCORD'
                break
            if operators.upper().find("TELEGRAM") != -1 and (599 in destination_ports or 1400 in destination_ports):
                voip_call_platform_name =  'TELEGRAM'
                break
            if operators.upper().find("MICROSOFT") != -1:
                voip_call_platform_name =  'SKYPE'
                break
            if (operators.upper().find("GOOGLE") != -1 or operators.upper().find("AMAZON") != -1)  and 19302 in destination_ports:
                voip_call_platform_name =  'IMO/SIGNAL'
                break  

            if operators.upper().find("GOOGLE") != -1 and (19302 in destination_ports and 19305 in destination_ports and 3478 not in destination_ports):
                voip_call_platform_name =  'GOOGLE MEET'
                break
            if operators.upper().find("GOOGLE") != -1 and (19302 in destination_ports and 3478 in destination_ports):
                voip_call_platform_name =  'SIGNAL'
                break
            if operators.upper().find("GOOGLE") != -1 and 3478 in destination_ports and (599 not in destination_ports and 1400 not in destination_ports):
                voip_call_platform_name =  'GOOGLE DUO'
                break
            if (operators.upper().find("AMAZON") != -1 or operators.upper().find("SNAPCHAT") != -1) and 3478 in destination_ports and (599 not in destination_ports and 1400 not in destination_ports):
                voip_call_platform_name =  'SNAPCHAT'
                break
            if operators.upper().find("BIGO") != -1  or operators.upper().find("PAGEBITES") != -1:
                voip_call_platform_name =  'IMO'
                break
            if operators.upper().find("APPLE") != -1 and (3478 in destination_ports or 3479 in destination_ports or 3480 in destination_ports or 3481 in destination_ports or 3482 in destination_ports or 3483 in destination_ports or 3484 in destination_ports or 3485 in destination_ports or 3486 in destination_ports or 3487 in destination_ports or 3488 in destination_ports or 3489 in destination_ports or 3490 in destination_ports or 3491 in destination_ports or 3492 in destination_ports or 3493 in destination_ports or 3494 in destination_ports or 3495 in destination_ports or 3496 in destination_ports or 3497 in destination_ports or 16384 in destination_ports or 16385 in destination_ports or 16386 in destination_ports or 16387 in destination_ports or 16388 in destination_ports or 16389 in destination_ports or 16390 in destination_ports or 16391 in destination_ports or 16392 in destination_ports):
                voip_call_platform_name =  'FACETIME'
                break
    
    return b_party_status,voip_call_platform_name,voip_call_index


def tower_movements_group(group):
    try:
        group['cell_id_start_date_time'] = group['start_date_time'].iloc[0]
    except:
        group['cell_id_start_date_time']=0
    try:    
        group['cell_id_end_date_time'] = group['end_date_time'].iloc[-1]
    except:
        group['cell_id_end_date_time'] = 0
    group['tower_movements_index'] = list(range(len(group)))
    return group



def voip_call_analysis(ipdr_df,file_format,telecom_name):
    if file_format in ['pcap', 'pcapng', 'gprsdata']:
        telecom_name = telecom_name.strip().upper()
        
        # Create a mask for rows with a colon in the destination IP address
        mask = ipdr_df['destination_ip_address'].str.contains(':')
        
        # Initialize a counter for conditions
        conditions = {
            'JIO': ~ipdr_df['service_provider_detail_public'].str.upper().str.contains('RJIL|JIO|RELIANCE'),
            'AIRTEL': ~ipdr_df['service_provider_detail_public'].str.upper().str.contains('AIRTEL|BHARTITELESONIC'),
            'VI': ~ipdr_df['service_provider_detail_public'].str.upper().str.contains('VODAFONE|IDEA'),
            'MTNL': ~ipdr_df['service_provider_detail_public'].str.upper().str.contains('MAHANAGAR|MTNL'),
            'BSNL': ~ipdr_df['service_provider_detail_public'].str.upper().str.contains('BSNL')
        }
        
        # Check if the telecom name is valid and apply the corresponding condition
        if telecom_name in conditions:
            condition_mask = mask & conditions[telecom_name]
            
            # Apply the swap operation where the condition is met
            ipdr_df.loc[condition_mask, ['public_ip_address', 'destination_ip_address']] = ipdr_df.loc[condition_mask, ['destination_ip_address', 'public_ip_address']].values
            ipdr_df.loc[condition_mask, ['public_ip_port','destination_port']] = ipdr_df.loc[condition_mask, ['destination_port','public_ip_port']].values
            ipdr_df.loc[condition_mask, ['uplink_vol','downlink_vol']] = ipdr_df.loc[condition_mask, ['downlink_vol','uplink_vol']].values
            ipdr_df.loc[condition_mask, ['media_upload_data', 'media_download_data']] = ipdr_df.loc[condition_mask, ['media_download_data', 'media_upload_data']].values
            
            ipdr_df.loc[condition_mask, ['hosted_domain_name', 'hosted_domain_name_public']] = ipdr_df.loc[condition_mask, ['hosted_domain_name_public', 'hosted_domain_name']].values
            ipdr_df.loc[condition_mask, ['company_name', 'company_name_public']] = ipdr_df.loc[condition_mask, ['company_name_public', 'company_name']].values
            ipdr_df.loc[condition_mask, ['company_domain', 'company_domain_public']] = ipdr_df.loc[condition_mask, ['company_domain_public', 'company_domain']].values
            ipdr_df.loc[condition_mask, ['company_type', 'company_type_public']] = ipdr_df.loc[condition_mask, ['company_type_public', 'company_type']].values
            ipdr_df.loc[condition_mask, ['company_asn', 'company_asn_public']] = ipdr_df.loc[condition_mask, ['company_asn_public', 'company_asn']].values
            ipdr_df.loc[condition_mask, ['vpn_hosting', 'vpn_hosting_public']] = ipdr_df.loc[condition_mask, ['vpn_hosting_public', 'vpn_hosting']].values
            ipdr_df.loc[condition_mask, ['vpn_proxy', 'vpn_proxy_public']] = ipdr_df.loc[condition_mask, ['vpn_proxy_public', 'vpn_proxy']].values
            ipdr_df.loc[condition_mask, ['vpn_tor', 'vpn_tor_public']] = ipdr_df.loc[condition_mask, ['vpn_tor_public', 'vpn_tor']].values
            ipdr_df.loc[condition_mask, ['is_vpn', 'is_vpn_public']] = ipdr_df.loc[condition_mask, ['is_vpn_public', 'is_vpn']].values
            ipdr_df.loc[condition_mask, ['vpn_is_relay', 'vpn_is_relay_public']] = ipdr_df.loc[condition_mask, ['vpn_is_relay_public', 'vpn_is_relay']].values
            ipdr_df.loc[condition_mask, ['vpn_name', 'vpn_name_public']] = ipdr_df.loc[condition_mask, ['vpn_name_public', 'vpn_name']].assign(vpn_name_public=lambda x: x['vpn_name_public'].str.upper()).values            
            ipdr_df.loc[condition_mask, ['app_name', 'app_name_public']] = ipdr_df.loc[condition_mask, ['app_name_public', 'app_name']].assign(app_name_public=lambda x: x['app_name_public'].str.upper()).values
            ipdr_df.loc[condition_mask, ['app_category', 'app_category_public']] = ipdr_df.loc[condition_mask,['app_category_public', 'app_category']]
            ipdr_df.loc[condition_mask, ['app_logo', 'app_logo_public']] = ipdr_df.loc[condition_mask,['app_logo_public', 'app_logo']]
            ipdr_df.loc[condition_mask, ['app_company_name', 'app_company_name_public']] = ipdr_df.loc[condition_mask,['app_company_name_public', 'app_company_name']]
            ipdr_df.loc[condition_mask, ['app_domain', 'app_domain_public']] = ipdr_df.loc[condition_mask, ['app_domain_public', 'app_domain']].assign(app_domain_public=lambda x: x['app_domain_public'].str.upper()).values
            ipdr_df.loc[condition_mask, ['ip_city', 'ip_city_public']] = ipdr_df.loc[condition_mask, ['ip_city_public', 'ip_city']].assign(ip_city_public=lambda x: x['ip_city_public'].str.upper()).values
            ipdr_df.loc[condition_mask, ['ip_country', 'ip_country_public']] = ipdr_df.loc[condition_mask, ['ip_country_public', 'ip_country']].assign(ip_country_public=lambda x: x['ip_country_public'].str.upper()).values
            ipdr_df.loc[condition_mask, ['ip_lat', 'ip_lat_public']] = ipdr_df.loc[condition_mask,['ip_lat_public', 'ip_lat']]
            ipdr_df.loc[condition_mask, ['service_provider_detail','service_provider_detail_public']] = ipdr_df.loc[condition_mask, ['service_provider_detail_public', 'service_provider_detail']].assign(service_provider_detail_public=lambda x: x['service_provider_detail_public'].str.upper()).values
            ipdr_df.loc[condition_mask, ['ip_long', 'ip_long_public']] = ipdr_df.loc[condition_mask,['ip_long_public', 'ip_long']]
            ipdr_df.loc[condition_mask, ['ip_state_name', 'ip_state_name_public']] = ipdr_df.loc[condition_mask, ['ip_state_name_public', 'ip_state_name']].assign(ip_state_name_public=lambda x: x['ip_state_name_public'].str.upper()).values
            ipdr_df.loc[condition_mask, ['ip_district_name', 'ip_district_name_public']] = ipdr_df.loc[condition_mask, ['ip_district_name_public', 'ip_district_name']].assign(ip_district_name_public=lambda x: x['ip_district_name_public'].str.upper()).values
            ipdr_df.loc[condition_mask, ['ip_continent_name', 'ip_continent_name_public']]= ipdr_df.loc[condition_mask,['ip_continent_name_public', 'ip_continent_name']].assign(ip_continent_name_public=lambda x: x['ip_continent_name_public'].str.upper()).values
            ipdr_df.loc[condition_mask, ['ip_connection_type', 'ip_connection_type_public']] = ipdr_df.loc[condition_mask,['ip_connection_type_public', 'ip_connection_type']]

    ipdr_df['hosted_domain_name'] = ipdr_df['hosted_domain_name'].astype(str)
    ipdr_df['domain_name'] = ipdr_df['domain_name'].astype(str)
    ipdr_df['app_name'] = ipdr_df['app_name'].astype(str)
    ipdr_df['apk_ipa_pact'] = ipdr_df['apk_ipa_pact'].astype(str)
    
    condition_both = (ipdr_df['app_name'].str.strip() != '') & (ipdr_df['apk_ipa_pact'].str.strip() != '') & (ipdr_df['app_name'].str.strip() != '0') & (ipdr_df['apk_ipa_pact'].str.strip() != '0')
    condition_only_a = (ipdr_df['app_name'].str.strip() != '') & (ipdr_df['app_name'].str.strip() != '0') &  ((ipdr_df['apk_ipa_pact'].str.strip() == '') | (ipdr_df['apk_ipa_pact'].str.strip() == '0'))
    condition_only_b = ((ipdr_df['app_name'].str.strip() == '') | (ipdr_df['app_name'].str.strip() == '0')) & (ipdr_df['apk_ipa_pact'].str.strip() != '') & (ipdr_df['apk_ipa_pact'].str.strip() != '0')

    ipdr_df['app_name'] = ipdr_df['app_name'].where(~condition_both, ipdr_df['app_name'] + '[' + ipdr_df['apk_ipa_pact'] + ']')
    ipdr_df['app_name'] = ipdr_df['app_name'].where(~condition_only_a, ipdr_df['app_name'])
    ipdr_df['app_name'] = ipdr_df['app_name'].where(~condition_only_b, ipdr_df['apk_ipa_pact'])
    ipdr_df['app_name'] = ipdr_df['app_name'].str.replace('.', '_').str.upper()


    condition_both = (ipdr_df['hosted_domain_name'].str.strip() != '') & (ipdr_df['hosted_domain_name'].str.strip() != '0') & (ipdr_df['domain_name'].str.strip() != '') & (ipdr_df['domain_name'].str.strip() != '0')
    condition_only_a = (ipdr_df['hosted_domain_name'].str.strip() != '') & (ipdr_df['hosted_domain_name'].str.strip() != '0') & ((ipdr_df['domain_name'].str.strip() == '') | (ipdr_df['domain_name'].str.strip() == '0'))
    condition_only_b = ((ipdr_df['hosted_domain_name'].str.strip() == '') | (ipdr_df['hosted_domain_name'].str.strip() == '0')) & (ipdr_df['domain_name'].str.strip() != '') & (ipdr_df['domain_name'].str.strip() != '0')

    ipdr_df['hosted_domain_name'] = ipdr_df['hosted_domain_name'].where(~condition_both, ipdr_df['hosted_domain_name'] + '[' + ipdr_df['domain_name'] + ']')
    ipdr_df['hosted_domain_name'] = ipdr_df['hosted_domain_name'].where(~condition_only_a, ipdr_df['hosted_domain_name'])
    ipdr_df['hosted_domain_name'] = ipdr_df['hosted_domain_name'].where(~condition_only_b, ipdr_df['domain_name'])


    exclude_list = ['DNIC','ZENLAYER','ZEN-ECN','ALIBABA','GUANGDONG','TENCENT','OVH','GERENA','GARENA','CLOUDFLARE','DIGITALOCEAN','GMBH','WHATBOX','KOREA TELECOM','CHINA','SANDHILL SOLUTION','ORACLE','INFORMACINES','AS-GLOBAL TELEHOST','M247','KEMINET SHPK','ONLINE S.A.S','DATACAMP','PONYNET','COMCAST','BGPNET','DEUTSCHE TELEKOM','ROSTELECOM','TRADER SOFT','UUNET','CLOUD','QUANTILNETWORKS','DATAPLANET','SOFTBANK','MEVSPACE','SONY NETWORK','TIME DOTCOM','DEN DIGITAL','ASN-QUADRANET','LINODE','NODE','IETF PROTOCOL']

    pcap_call_signatures = ['STUN','UDP','IMO']    
    ipdr_df['service_provider_detail'] = ipdr_df['service_provider_detail'].str.strip().fillna('')
    

    #  comb1
    if file_format in ['pcap','pcapng','gprsdata']:
        df = ipdr_df[((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port']))  & (ipdr_df['destination_port']>1000) & (~ipdr_df['destination_port'].isin([80,53,443,123,5222,5223,5228,8443,8130,853,500,4500,5000,8080,600,1600,4600,1390,3390,1723,1194,1701,1433,3306,1434])) & (~ipdr_df['service_provider_detail'].str.contains('|'.join(exclude_list),case=False))  & (ipdr_df['app_name'].str.contains('|'.join(pcap_call_signatures),case=False)) & (~ipdr_df['app_name'].str.contains('bittorrent',case=False)) & (ipdr_df['voip_call_status'] == '0') & (ipdr_df['is_ip_ipdr'] != 2)]
    else:
        df = ipdr_df[((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port']))  & (ipdr_df['destination_port']>1000) & (~ipdr_df['destination_port'].isin([80,53,443,123,5222,5223,5228,8443,8130,853,500,4500,5000,8080,600,1600,4600,1390,3390,1723,1194,1701,1433,3306,1434])) & (~ipdr_df['service_provider_detail'].str.contains('|'.join(exclude_list),case=False)) & (ipdr_df['voip_call_status'] == '0') & (ipdr_df['is_ip_ipdr'] != 2)]

    
    if len(df)!=0:
        # print(f'\t [+] type 1 start')
        df_having_count = df.groupby('session_hash').size()
        having_groups = df_having_count[df_having_count > 1].index.tolist()
        df = df[df['session_hash'].isin(having_groups)]
        column_type_to_int = ['destination_port', 'public_ip_port']
        df[column_type_to_int] = df[column_type_to_int].fillna(0).astype(int)
        df['isp_port_diff'] = df['destination_port'].astype(str).str.cat(df[['service_provider_detail']], sep='######')
        df2 = df.groupby("session_hash").agg(list)
        df3 = df2[df2['destination_port'].apply(lambda x: any(port in x for port in [3478, 3479, 3480, 3481, 3482, 3483, 3484, 3485, 3486, 3487, 3488, 3489, 3490, 3491, 3492, 3493, 3494, 3495, 3496, 3497, 1400, 599, 19305, 19302, 16384, 16385, 16386, 16387, 16388, 16389, 16390, 16391, 16392, 40001, 40002, 40003, 40004, 40005, 50001, 50002, 50003, 50004, 50005]))]
                
        if len(df3) !=0:
            # print(f'\t [+] type 1 identify.. {len(df3)}')
            df3['voip_call_type'] = 'type1'
            df3['voip_call_status'] = '1'
            df3[['voip_call_b_party_status','voip_call_platform_name','voip_call_index']]= df3['isp_port_diff'].apply(voip_call_b_party_checker).apply(pd.Series)

            df3['voip_call_session_hash'] = df3.index

            # Reset index to ensure unique labels before exploding
            dataframe_voip_call = df3.reset_index(drop=True)

            # Apply the explode method
            dataframe_voip_call = dataframe_voip_call.apply(pd.Series.explode)

            # Reset index again after exploding to avoid duplicate index labels
            dataframe_voip_call = dataframe_voip_call.reset_index(drop=True)
            
            ipdr_df.set_index('ipdr_id_session_hash', inplace=True)
            dataframe_voip_call.set_index('ipdr_id_session_hash', inplace=True)
            ipdr_df.update(dataframe_voip_call)
            ipdr_df.reset_index(inplace=True)
            
    
    # comb3

    if file_format in ['pcap','pcapng','gprsdata']:
        df = ipdr_df[((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port']))   & (ipdr_df['destination_port']>1000) & (~ipdr_df['destination_port'].isin([80,53,443,123,5222,5223,5228,8443,8130,853,500,4500,5000,8080,600,1600,4600,1390,3390,1723,1194,1701,1433,3306,1434])) & (~ipdr_df['service_provider_detail'].str.contains('|'.join(exclude_list),case=False))  & (ipdr_df['app_name'].str.contains('|'.join(pcap_call_signatures),case=False)) & (~ipdr_df['app_name'].str.contains('bittorrent',case=False)) & (ipdr_df['voip_call_status'] == '0') & (ipdr_df['voip_call_status'] == '0') & (ipdr_df['is_ip_ipdr'] != 2)]
    else:
        df = ipdr_df[((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port']))   & (ipdr_df['destination_port']>1000) & (~ipdr_df['destination_port'].isin([80,53,443,123,5222,5223,5228,8443,8130,853,500,4500,5000,8080,600,1600,4600,1390,3390,1723,1194,1701,1433,3306,1434])) & (~ipdr_df['service_provider_detail'].str.contains('|'.join(exclude_list),case=False)) & (ipdr_df['voip_call_status'] == '0') & (ipdr_df['is_ip_ipdr'] != 2)]
    
    if len(df)!=0:
        # print(f'\t [+] type 5 start')
        df_having_count = df.groupby('comb_session_hash5').size()
        having_groups = df_having_count[df_having_count > 1].index.tolist()
        df = df[df['session_hash'].isin(having_groups)]
        column_type_to_int = ['destination_port', 'public_ip_port']
        df[column_type_to_int] = df[column_type_to_int].fillna(0).astype(int)
        df['isp_port_diff'] = df['destination_port'].astype(str).str.cat(df[['service_provider_detail']], sep='######')
        df2 = df.groupby("session_hash").agg(list)
        df3 = df2[df2['destination_port'].apply(lambda x: any(port in x for port in [3478, 3479, 3480, 3481, 3482, 3483, 3484, 3485, 3486, 3487, 3488, 3489, 3490, 3491, 3492, 3493, 3494, 3495, 3496, 3497, 1400, 599, 19305, 19302, 16384, 16385, 16386, 16387, 16388, 16389, 16390, 16391, 16392, 40001, 40002, 40003, 40004, 40005, 50001, 50002, 50003, 50004, 50005]))]

        if len(df3) !=0:
            # print(f'\t [+] type 5 identify {len(df3)}')
            df3['voip_call_type'] = 'type5'
            df3['voip_call_status'] = '1'
            df3[['voip_call_b_party_status','voip_call_platform_name','voip_call_index']]= df3['isp_port_diff'].apply(voip_call_b_party_checker).apply(pd.Series)
            dataframe_voip_call = df3.reset_index(drop=True)
            df3['voip_call_session_hash'] = df3.index

            # Apply the explode method
            dataframe_voip_call = dataframe_voip_call.apply(pd.Series.explode)

            # Reset index again after exploding to avoid duplicate index labels
            dataframe_voip_call = dataframe_voip_call.reset_index(drop=True)

            ipdr_df.set_index('ipdr_id_session_hash', inplace=True)
            dataframe_voip_call.set_index('ipdr_id_session_hash', inplace=True)
            ipdr_df.update(dataframe_voip_call)
            ipdr_df.reset_index(inplace=True)
    
    # comb2
    if file_format in ['pcap','pcapng','gprsdata']:
        df = ipdr_df[((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port'])) & (ipdr_df['destination_port']>1000) & (~ipdr_df['destination_port'].isin([80,53,443,123,5222,5223,5228,8443,8130,853,500,4500,5000,8080,600,1600,4600,1390,3390,1723,1194,1701,1433,3306,1434])) & (~ipdr_df['service_provider_detail'].str.contains('|'.join(exclude_list),case=False)) & (ipdr_df['app_name'].str.contains('|'.join(pcap_call_signatures),case=False)) & (~ipdr_df['app_name'].str.contains('bittorrent',case=False)) & (ipdr_df['voip_call_status'] == '0')]
    else:
        df = ipdr_df[((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port'])) & (ipdr_df['destination_port']>1000) & (~ipdr_df['destination_port'].isin([80,53,443,123,5222,5223,5228,8443,8130,853,500,4500,5000,8080,600,1600,4600,1390,3390,1723,1194,1701,1433,3306,1434])) & (~ipdr_df['service_provider_detail'].str.contains('|'.join(exclude_list),case=False)) & (ipdr_df['voip_call_status'] == '0')]

    if len(df)!=0:
        # print(f'\t [+] Type_2 start')
        df_having_count = df.groupby('comb_session_hash5').size()
        having_groups = df_having_count[df_having_count > 0].index.tolist()
        df = df[df['session_hash'].isin(having_groups)]
        column_type_to_int = ['destination_port', 'public_ip_port']
        df[column_type_to_int] = df[column_type_to_int].fillna(0).astype(int)
        df['isp_port_diff'] = df['destination_port'].astype(str).str.cat(df[['service_provider_detail']], sep='######')
        df2 = df.groupby("session_hash").agg(list)
        df3 = df2[df2['destination_port'].apply(lambda x: any(port in x for port in [3478, 3479, 3480, 3481, 3482, 3483, 3484, 3485, 3486, 3487, 3488, 3489, 3490, 3491, 3492, 3493, 3494, 3495, 3496, 3497, 1400, 599, 19305, 19302, 16384, 16385, 16386, 16387, 16388, 16389, 16390, 16391, 16392, 40001, 40002, 40003, 40004, 40005, 50001, 50002, 50003, 50004, 50005]))]

        if len(df3) !=0:
            # print(f'\t [i] type 2 identify...{len(df3)}')
            df3['voip_call_type'] = 'type2'
            df3['voip_call_status'] = '1'
            df3[['voip_call_b_party_status','voip_call_platform_name','voip_call_index']]= df3['isp_port_diff'].apply(voip_call_b_party_checker).apply(pd.Series)
            dataframe_voip_call = df3.reset_index(drop=True)
            df3['voip_call_session_hash'] = df3.index

            # Apply the explode method
            dataframe_voip_call = dataframe_voip_call.apply(pd.Series.explode)

            # Reset index again after exploding to avoid duplicate index labels
            dataframe_voip_call = dataframe_voip_call.reset_index(drop=True)

            ipdr_df.set_index('ipdr_id_session_hash', inplace=True)
            dataframe_voip_call.set_index('ipdr_id_session_hash', inplace=True)
            # dataframe_voip_call.to_csv('type2.csv')
            ipdr_df.update(dataframe_voip_call)
            ipdr_df.reset_index(inplace=True)
    
    # comb_unknown_voip_call
    # included_countries = ['India','Pakistan','Nepal','Bangladesh','Afganistan','Sri Lanka','United Arab Emirates','Qatar','Bahrain','Turkey','Malaysia','Maldives','Oman','Jordan','Libya','Kuwait','Iran','Indonesia','Iraq','Egypt']
    exclude_type6_list = ['META','FACEBOOK','GOOGLE','AMAZON','APPLE','BIGO','TELEGRAM','IMO','MICROSOFT','DNIC','ZENLAYER','ZEN-ECN','ALIBABA','GUANGDONG','TENCENT','OVH','GERENA','GARENA','CLOUDFLARE','DIGITALOCEAN','GMBH','WHATBOX','KOREA TELECOM','CHINA','SANDHILL SOLUTION','ORACLE','INFORMACINES','AS-GLOBAL TELEHOST','M247','KEMINET SHPK','ONLINE S.A.S','DATACAMP','PONYNET','COMCAST','BGPNET','DEUTSCHE TELEKOM','ROSTELECOM','TRADER SOFT','CLOUD','UUNET','QUANTILNETWORKS','DATAPLANET','SOFTBANK','MEVSPACE','SONY NETWORK','TIME DOTCOM','DEN DIGITAL','ASN-QUADRANET','RUSSIAN','UNITED STATES','LINODE','NODE','DISCORD','IETF PROTOCOL']
    
    # remove duplicates
    if not ipdr_df.index.is_unique:
        ipdr_df = ipdr_df.loc[~ipdr_df.index.duplicated()]
    
    # Processing actual party
    ipdr_df['actual_party'] = 0
    grouped = ipdr_df.groupby(['destination_ip_address','phone_no','public_ip_address', 'destination_port', 'start_date_time'])
    port_counts = grouped['public_ip_port'].transform('count')
    port_counts = port_counts.fillna(0)
    ipdr_df.loc[port_counts > 1, 'actual_party'] = 1
    ipdr_df['service_provider_detail'] = ipdr_df['service_provider_detail'].str.strip().fillna('')

    # Type 6 voip call identification
    multi_condition_voip_call =  (ipdr_df['is_ip_ipdr'] != 2) & ((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port'])) & (ipdr_df['destination_port']>1000) & (~ipdr_df['destination_port'].isin([80,53,443,123,5222,5223,5228,8443,8130,853,500,4500,5000,8080,6881,6882,6883,600,1600,4600,1390,8080,3390,1723,1194,1701,1433,3306,1434])) & (~ipdr_df['service_provider_detail'].str.contains('|'.join(exclude_type6_list),case=False)) & (~ipdr_df['app_name'].str.contains('|'.join(['bittorrent','http','ntp','tls','dtls','QUIC']),case=False)) & (ipdr_df['voip_call_status'] == '0') & (ipdr_df['actual_party']==0)
    
    session_hash_df = ipdr_df.loc[multi_condition_voip_call, ['session_hash']]
    if len(session_hash_df)!=0:
        # print(f'\t [+] Type 6 identified: {len(session_hash_df)}')
        ipdr_df.loc[multi_condition_voip_call, ['voip_call_session_hash']] = session_hash_df['session_hash']
        ipdr_df.loc[multi_condition_voip_call, ['voip_call_type','voip_call_status','voip_call_b_party_status','voip_call_platform_name','voip_call_index']] = ['type6','1','yes','P2P CONNECTIONS','0']
    
    # Type 7 voip call Identification 
    gaming_server_list = ['TENCENT','GERENA','GARENA']
    multi_condition_gaming_server_call = (ipdr_df['is_ip_ipdr'] != 2) & ((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port'])) & (ipdr_df['destination_port'].isin([8000,8080,3478,3479])) & (ipdr_df['service_provider_detail'].str.contains('|'.join(gaming_server_list),case=False)) & (ipdr_df['voip_call_status'] == '0')
    session_hash_df = ipdr_df.loc[multi_condition_gaming_server_call, ['session_hash']]
    if len(session_hash_df)!=0:
        # print(f'[+] Type 7 identified: {len(session_hash_df)}')
        ipdr_df.loc[multi_condition_gaming_server_call, ['voip_call_session_hash']] = session_hash_df['session_hash']
        ipdr_df.loc[multi_condition_gaming_server_call, ['voip_call_type','voip_call_status','voip_call_b_party_status','voip_call_platform_name','voip_call_index']] = ['type7','1','no','GAMING CALL','0']
    
    # setting b_party_table_status to yes
    multi_condition_b_party = ((ipdr_df['destination_ip_address'] != ipdr_df['public_ip_address']) & (ipdr_df['destination_port'] != ipdr_df['public_ip_port'])) &  (~ipdr_df['destination_port'].isin([80,53,443,123,5222,5223,5228,8443,8130,853,500,4500,5000,8080,6881,6882,6883,600,1600,4600,1390,3390,1723,1194,1701,3478,1433,1434,3306])) & (~ipdr_df['service_provider_detail'].str.contains('|'.join(exclude_type6_list),case=False))  & (~ipdr_df['app_name'].str.contains('|'.join(['bittorrent']),case=False)) & (ipdr_df['voip_call_status'] == '1')
    
    ipdr_df.loc[multi_condition_b_party, ['b_party_table_status']] = ['yes']
    ipdr_df = ipdr_df.sort_values(by=['start_date_time', 'public_ip_port'])

    torrent_ports = [6881, 6882, 6883, 6884, 6885, 6886, 6887, 6888, 6889, 6889, 6890, 6891, 6969]
    group1 = ipdr_df[ipdr_df['voip_call_b_party_status'] == 'yes'].groupby('voip_call_session_hash')
    
    for index,group in group1:
        port_diff = group['public_ip_port'].diff()
        destination_ports = group['destination_port']
        unique_countries = group.loc[group['b_party_table_status'].eq('yes'), 'ip_country'].nunique()

        if ((group['destination_ip_address'].nunique() > 1) and (unique_countries > 2)) or ((port_diff <=10) & (port_diff > 0)).sum() > 2 or any(value in destination_ports 
        
        for value in torrent_ports):  
            ipdr_df.loc[group.index, 't_detection'] = 'yes'
            ipdr_df.loc[group.index, 'voip_call_platform_name'] = 'PROBABLE_'+ipdr_df.loc[group.index, 'voip_call_platform_name']

    ipdr_df['voip_call_index'] = ipdr_df.groupby(['voip_call_session_hash']).cumcount()
    ipdr_df['voip_call_platform_name'] = (ipdr_df['voip_call_platform_name'].str.replace(" ", '_').str.replace(r"r\[0\]", '').str.replace(r"r\[\]", ''))
    return ipdr_df


def celld_to_Tower(cell_id,tower_session,second_tower = "no"):
    tower_details = {}
    query_url = database["server_url"]+':'+ str(database["solr_port"])+ '/solr/tower_test/select'    
    response = None
    response_json= {}
    params ={}
    docTowerDetailsResult ={}
    tower_details['tower_operator']=''
    tower_details['tower_network_type']=''
    tower_details['tower_location']=''
    tower_details['tower_state']=''    
    tower_details['tower_town']=''
    tower_details['tower_district']=''
    tower_details['tower_azimuth']=''
    tower_details['tower_pincode']=''
    tower_details['tower_latitude']=''
    tower_details['tower_longitude']=''
    tower_details['tower_height']=''
    tower_details['tower_lat_long'] = '0~~~0'
    if second_tower == "no" :
        tower_details['tower_lat_long_rpt'] = 'POINT (0 0)'
    if cell_id !='0' and cell_id!='':
        params = {
            'q': 'tower_cgi:"%s"'%(str(cell_id)),
            'fl': 'tower_operator,tower_network_type,tower_location,tower_state,tower_town,tower_district,tower_azimuth,tower_pincode,tower_latitude,tower_longitude,tower_height',
            'rows': 1
        }
        
        response = tower_session.get(query_url, params=params,auth= auth)
        if response.status_code == 200:
            response_json = response.json()
            if response_json['response']['numFound'] > 0:
                docTowerDetailsResult = response_json['response']['docs'][0]
                tower_details.update(docTowerDetailsResult)
    condition_series = are_valid_coordinates(tower_details['tower_latitude'],tower_details['tower_longitude'])

    if condition_series == True:
        tower_details['tower_lat_long'] = str(tower_details['tower_latitude'])+"~~~"+str(tower_details['tower_longitude'])
        if second_tower == "no" :
            tower_details['tower_lat_long_rpt'] = 'POINT ('+str(tower_details['tower_longitude'])+' '+str(tower_details['tower_latitude']) +')'
    else:
        tower_details['tower_lat_long']  = '0~~~0'
        if second_tower == "no" :
            tower_details['tower_lat_long_rpt'] = "POINT (0 0)"

    try:
        tower_details['tower_district']  = tower_details['tower_district'].upper().replace(" NAGARTAHSIL",'').replace(" TAHSIL",'').replace("TEHSIL",'')
    except:pass 

    try:
        pattern = re.compile(r'[^a-zA-Z0-9\s]')
        tower_details['tower_location'] = re.sub(pattern, ' ', str(tower_details['tower_location'].upper()))
    except:pass 
    
    if second_tower == "no" :
        return tower_details['tower_operator'],tower_details['tower_network_type'],tower_details['tower_location'].upper(),tower_details['tower_state'],tower_details['tower_town'],tower_details['tower_district'],tower_details['tower_azimuth'],tower_details['tower_pincode'],tower_details['tower_latitude'],tower_details['tower_longitude'],tower_details['tower_height'],tower_details['tower_lat_long'],tower_details['tower_lat_long_rpt']
    else :
        return tower_details['tower_operator'],tower_details['tower_network_type'],tower_details['tower_location'].upper(),tower_details['tower_state'],tower_details['tower_town'],tower_details['tower_district'],tower_details['tower_azimuth'],tower_details['tower_pincode'],tower_details['tower_latitude'],tower_details['tower_longitude'],tower_details['tower_height'],tower_details['tower_lat_long']
# ip_to_dict_lock = threading.Lock()

def imei_to_tac(imei_no,session):
    tac_no = imei_no[:8]
    phone_model = ''
    phone_name = ''
    phone_brand = ''
    is_basic = 'no'
    query_url = database["server_url"] +':'+ str(database["solr_port"])+ '/solr/tac_data/select'

    params = {
            'q': 'tac_number:"%s" '%(str(tac_no)),
            'rows': 1
            }

    response = session.get(query_url, params=params,auth=auth)
    if response.status_code == 200:
        response_json = response.json()
        if response_json['response']['numFound'] > 0:
            doc= response_json['response']['docs'][0]
            phone_model =  str(doc['model']).replace("[","").replace("]","").replace("'","").upper()
            phone_name =  str(doc['name']).replace("[","").replace("]","").replace("'","").upper()
            phone_brand =  str(doc['brand']).replace("[","").replace("]","").replace("'","").upper()
            if 'is_basic' in doc:
                is_basic = doc['is_basic']

    return phone_name,phone_model,phone_brand,is_basic

def ip_to_dict (destination_ip_address, session, reader ,reader_vpn ,app_reader):

    response = None
    query_url = database["server_url"] +':'+ str(database["solr_port"])+ '/solr/hosted_domain_details/select'
    tor_query_url = database["server_url"] +':'+ str(database["solr_port"])+ '/solr/tor_details/select'    
    domains = ''
    is_tor_detected = 'no'
    tor_name = ''
    tor_onion_port = ''
    tor_directory_port = ''
    tor_flags = ''
    tor_uptime = ''
    tor_version = ''
    tor_email = ''
    response_json ={}
    doc  ={}
    params ={}
    # cdef object reader
    result = None
    company_details = {}     
    # cdef object reader_vpn
    result_vpn =None
    vpn_hosting=''
    vpn_proxy=''
    vpn_tor=''
    is_vpn=''
    vpn_is_relay=''
    vpn_name=''
    vpn_details = {} 
    select_data_query =''
    IPDR_CONN =None
    cursor_ipdr =None
    app_details = {}
    isp_temp =''
    ip_details = {}
    service_provider_detail ='UNKNOWN'
    # cdef str operator_name = 'UNKNOWN'
    country_name = 'UNKNOWN'
    city_name = 'UNKNOWN'
    ip_lat = 0
    ip_long = 0
    city_temp = {}
    ip_type = ''
    company_details['company_name']=''
    company_details['company_domain']=''
    company_details['company_type']=''
    company_details['company_asn']=''
    vpn_details['vpn_hosting']=''
    vpn_details['vpn_proxy']=''
    vpn_details['vpn_tor']=''
    vpn_details['is_vpn']=''
    vpn_details['vpn_is_relay']=''
    vpn_details['vpn_name']=''    
    app_details['app_name'] = ''
    app_details['app_category'] = ''
    app_details['app_logo'] = ''
    app_details['app_company_name'] = ''
    app_details['app_domain'] = ''
    app_details['app_source_country'] = ''
    app_details['app_ip_type'] = ''
    ip_details['ip_lat']=0
    ip_details['ip_long']=0
    ip_details['ip_lat_long']='0~~~0'
    ip_details['ip_country'] = ''
    # ip_details['operator_name'] = 'UNKNOWN'
    ip_details['service_provider_detail'] = 'UNKNOWN'
    ip_details['ip_city']=''
    ip_details['ip_state_name']=''
    ip_details['ip_district_name']=''
    ip_details['ip_continent_name']=''
    ip_details['ip_connection_type']=''

    try:
            ip_type = "IPv4" if type(ip_address(destination_ip_address)) is IPv4Address else "IPv6"
    except:
            ip_type =  "Invalid"
    if destination_ip_address !='0' and destination_ip_address!=''  and destination_ip_address !='0.0' and destination_ip_address.strip().find(" ") == -1 and ip_type != 'Invalid':

        # with ip_to_dict_lock:
            # try:
                params = {
                    'q': 'ip_address:"%s" AND total:[* TO 5] '%(str(destination_ip_address)),
                    'fl': 'domains',
                    'rows': 1
                }
                response = session.get(query_url, params=params,auth=auth)
                if response.status_code == 200:
                    response_json = response.json()
                    if response_json['response']['numFound'] > 0:
                        doc= response_json['response']['docs'][0]
                        domains =  str(doc['domains']).replace("[","").replace("]","").replace("'","").upper()

                # TOR data reader
                params = {
                    'q': 'ip_address:"%s" '%(str(destination_ip_address)),
                    'rows': 1
                }
                response = session.get(tor_query_url, params=params,auth=auth)
                if response.status_code == 200:
                    response_json = response.json()
                    if response_json['response']['numFound'] > 0:
                        doc= response_json['response']['docs'][0]
                        tor_name =  str(doc['name']).replace("[","").replace("]","").replace("'","").upper()
                        tor_onion_port =  str(doc['onion_port']).replace("[","").replace("]","").replace("'","")
                        tor_directory_port =  str(doc['directory_port']).replace("[","").replace("]","").replace("'","") if doc['directory_port'] != '0' else 'UNKNOWN'
                        tor_flags =  str(doc['flags']).replace("[","").replace("]","").replace("'","")
                        tor_uptime =  str(doc['uptime']).replace("[","").replace("]","").replace("'","").upper()
                        tor_version =  str(doc['tor_version']).replace("[","").replace("]","").replace("'","").upper()
                        tor_email =  str(doc['email']).replace("[","").replace("]","").replace("'","").upper() if 'email' in doc and pd.notna(doc['email']) and doc['email'] != 'NaN' else 'UNKNOWN'
                        is_tor_detected = 'yes'

                # reader = maxminddb.open_database(os.path.join(asset_dir,'chexfile'))
                result = reader.get(str(destination_ip_address))
                # check for specific ip address                
                    
                if result != None:                        
                    ip_details['ip_lat'] = result['location']['latitude']
                    ip_details['ip_long'] = result['location']['longitude']
                    condition_series = are_valid_coordinates(ip_details['ip_lat'],ip_details['ip_long'])
                    if condition_series == True:
                        ip_details['ip_lat_long'] = str(ip_details['ip_lat'])+"~~~"+str(ip_details['ip_long'])
                    else:
                        ip_details['ip_lat_long'] = '0~~~0'
                    try:
                        ip_details['ip_city'] = result['city']['names']['en'].upper()
                    except :
                        ip_details['ip_city'] = 'UNKNOWN'
                    try:
                        ip_details['ip_country'] = result['country']['names']['en'].upper()
                    except:
                        ip_details['ip_country'] = 'UNKNOWN'
                    try:
                        ip_details['ip_state_name'] = result['subdivisions'][0]['names']['en'].upper()
                    except:
                        ip_details['ip_state_name'] = ip_details['ip_city'].upper()
                    try:
                        ip_details['ip_district_name'] = result['subdivisions'][1]['names']['en'].upper()
                    except:
                        ip_details['ip_district_name'] = ip_details['ip_city'].upper()
                    try:
                        ip_details['ip_continent_name'] = result['continent']['names']['en'].upper()
                    except:
                        ip_details['ip_continent_name'] = 'UNKNOWN'
                    try:
                        ip_details['isp_name'] = result['traits']['isp']
                    except:
                        ip_details['isp_name'] = 'UNKNOWN'
                    try:
                        ip_details['asn_name'] = result['traits']['autonomous_system_organization']
                        company_details['company_asn']  = "AS"+str(result['traits']['autonomous_system_number'])
                    except:     
                        ip_details['asn_name'] = ip_details['isp_name']    
                        company_details['company_asn']  = "" 
                    try:
                        ip_details['ip_connection_type'] = result['traits']['connection_type']
                    except:
                        ip_details['ip_connection_type'] = 'UNKNOWN'
                    try:
                        company_details['company_name'] = result['traits']['organization']
                    except:
                        company_details['company_name'] = ip_details['isp_name']
                    company_details['company_type']  = result['traits']['user_type']
                    
                    ip_details['service_provider_detail'] = company_details['company_name']+" "+ip_details['isp_name']+" "+ip_details['asn_name']+" "+ip_details['ip_city']+" "+ip_details['ip_district_name']+" "+ip_details['ip_state_name']+" "+ip_details['ip_country']+" "+str(ip_details['ip_lat'])+" "+str(ip_details['ip_long'])
                    ip_details['service_provider_detail'] = ip_details['service_provider_detail'].upper()

                try:
                    # reader_vpn = maxminddb.open_database(os.path.join(asset_dir,'phexfile'))
                    result_vpn = reader_vpn.get(str(destination_ip_address))
                except:
                    result_vpn = None
                
                if result_vpn != None:
                    # if result_vpn['service']!='Free VPN':
                    vpn_details['vpn_hosting']="true"
                    vpn_details['vpn_proxy']="true"
                    vpn_details['vpn_tor']="false"
                    vpn_details['is_vpn']="true"
                    vpn_details['vpn_is_relay']=""
                    vpn_details['vpn_name']= result_vpn['vpn_name']
                    # if result_vpn['service']!='':
                    #     vpn_details['vpn_name']=result_vpn['service'].upper()
                    # elif result_vpn['service']=='' and result_vpn['tor']=='true':
                    #     vpn_details['vpn_name']="TOR BROWSER"
                    # elif result_vpn['service']=='' and (result_vpn['proxy']=='true' or result_vpn['vpn']=='true' or result_vpn['relay']=='true'):
                    #     vpn_details['vpn_name']="FREE VPN"
                    # else:
                        # vpn_details['vpn_name']=''
                else:
                    vpn_details['vpn_hosting']=''
                    vpn_details['vpn_proxy']=''
                    vpn_details['vpn_tor']=''
                    vpn_details['is_vpn']=''
                    vpn_details['vpn_is_relay']=''
                    vpn_details['vpn_name']=''
                # app_reader = maxminddb.open_database(os.path.join(asset_dir,'ahexfile'))
                app_result = app_reader.get(str(destination_ip_address))

                if app_result != None:
                    app_details['app_category']=app_result['app_category'].upper()
                    app_details['app_name']=app_result['app_name'].upper()
                    
                    try:
                        app_details['app_source_country']=app_result['country_flow']
                    except:
                        pass

                    try:
                        app_details['app_ip_type']=app_result['shared_type'].upper().replace("B'","").replace("'","")
                    except:
                        pass                    
    return [domains,company_details['company_name'],company_details['company_domain'],company_details['company_type'],company_details['company_asn'],vpn_details['vpn_hosting'],vpn_details['vpn_proxy'],vpn_details['vpn_tor'],vpn_details['is_vpn'],vpn_details['vpn_is_relay'],vpn_details['vpn_name'],app_details['app_name'],app_details['app_category'],app_details['app_logo'],app_details['app_source_country'],app_details['app_domain'],ip_details['ip_city'],ip_details['ip_country'],ip_details['ip_lat'],ip_details['ip_long'],ip_details['service_provider_detail'],ip_details['ip_state_name'],ip_details['ip_district_name'],ip_details['ip_continent_name'],ip_details['ip_connection_type'],ip_details['ip_lat_long'],app_details['app_ip_type'],tor_name,tor_onion_port,tor_directory_port,tor_flags,tor_uptime,tor_version,tor_email,is_tor_detected]


def ip_to_dict_cdr (destination_ip_address, session, reader):
    # cdef object reader
    result =None
    company_details = {} 
    company_details['company_name']=''
    ip_details = {}
    ip_type = ''
    ip_details['ip_lat']=0
    ip_details['ip_long']=0
    ip_details['ip_country'] = ''
    ip_details['service_provider_detail'] = 'UNKNOWN'
    ip_details['ip_city']=''
    ip_details['ip_state_name']=''
    ip_details['ip_district_name']=''
    ip_details['ip_continent_name']=''
    ip_details['ip_connection_type']=''
    ip_details['ip_lat_long'] = '0~~~0'
    try:
            ip_type = "IPv4" if type(ip_address(destination_ip_address)) is IPv4Address else "IPv6"
    except:
            ip_type =  "Invalid"
    if destination_ip_address !='0' and destination_ip_address!=''  and destination_ip_address !='0.0' and destination_ip_address.strip().find(" ") == -1 and ip_type != 'Invalid':
                # reader = maxminddb.open_database(os.path.join(asset_dir,'chexfile'))
                result = reader.get(str(destination_ip_address))
                if result != None:
                    ip_details['ip_lat'] = result['location']['latitude']
                    ip_details['ip_long'] = result['location']['longitude']
                    condition_series = are_valid_coordinates(ip_details['ip_lat'],ip_details['ip_long'])
                    if condition_series == True:
                        ip_details['ip_lat_long'] = str(ip_details['ip_lat'])+"~~~"+str(ip_details['ip_long'])
                    else:
                        ip_details['ip_lat_long'] = '0~~~0'
                    ip_details['ip_city'] = result['city']['names']['en'].upper()
                    ip_details['ip_country'] = result['country']['names']['en'].upper()
                    try:
                        ip_details['ip_state_name'] = result['subdivisions'][0]['names']['en'].upper()
                    except:
                        ip_details['ip_state_name'] = ip_details['ip_city'].upper()
                    try:
                        ip_details['ip_district_name'] = result['subdivisions'][1]['names']['en'].upper()
                    except:
                        ip_details['ip_district_name'] = ip_details['ip_city'].upper()
                    try:
                        ip_details['ip_continent_name'] = result['continent']['names']['en'].upper()
                    except:
                        ip_details['ip_continent_name'] = 'UNKNOWN'
                    try:
                        ip_details['isp_name'] = result['traits']['isp']
                    except:
                        ip_details['isp_name'] = 'UNKNOWN'
                    try:
                        ip_details['asn_name'] = result['traits']['autonomous_system_organization']
                        company_details['company_asn']  = "AS"+str(result['traits']['autonomous_system_number'])
                    except:     
                        ip_details['asn_name'] = ip_details['isp_name']    
                        company_details['company_asn']  = "" 
                    try:
                        ip_details['ip_connection_type'] = result['traits']['connection_type']
                    except:
                        ip_details['ip_connection_type'] = 'UNKNOWN'
                    try:
                        company_details['company_name'] = result['traits']['organization']
                    except:
                        company_details['company_name'] = ip_details['isp_name']
                    company_details['company_type']  = result['traits']['user_type']
                    
                    ip_details['service_provider_detail'] = company_details['company_name']+" "+ip_details['isp_name']+" "+ip_details['asn_name']+" "+ip_details['ip_city']+" "+ip_details['ip_district_name']+" "+ip_details['ip_state_name']+" "+ip_details['ip_country']+" "+str(ip_details['ip_lat'])+" "+str(ip_details['ip_long'])
                    ip_details['service_provider_detail'] = ip_details['service_provider_detail'].upper()

    return company_details['company_name'],ip_details['ip_city'],ip_details['ip_country'],ip_details['ip_lat'],ip_details['ip_long'],ip_details['service_provider_detail'],ip_details['ip_state_name'],ip_details['ip_district_name'],ip_details['ip_continent_name'],ip_details['ip_connection_type'],ip_details['ip_lat_long']

def execute_curl(url):
    command = ['curl', '-s', url]  # -s flag suppresses progress meter and error messages
    result = subprocess.run(command, capture_output=True, text=True)
    
    if result.returncode == 0:
        json_data = json.loads(result.stdout)
        return json_data
    else:
        print("Error executing curl command:")
        print(result.stderr)
        return None
        

def load_mapper(s):
    conn = ipdr_conn()
    mapper_df = pd.read_sql(f"SELECT * FROM mapper_data WHERE mapper_name='{s['mapper_name']}'", conn)
    merge_df = pd.read_sql(f"SELECT * FROM mapper_data_merge WHERE mapper_name='{s['mapper_name']}'", conn)
    conn.close()
    return mapper_df, merge_df

def load_mappers(mapper_folder):
    mapped_data = {}
    mapper_name =''
    df =None
    row =None

    for root, _, files in os.walk(mapper_folder):
        for file in files:
            file_path = os.path.join(root, file)
            df = pd.read_excel(file_path,engine='openpyxl')
            df = df.replace(np.nan, '', regex=True)
            mapper_name = file.split('.')[0]
            if mapper_name not in mapped_data:
                mapped_data[mapper_name] = {}
                for _, row in df.iterrows():
                    if len(row) == 2:
                        mapped_data[mapper_name][row[0]] = ["" if row[1] == np.nan else row[1].strip()]
                    elif len(row) == 3:
                        mapped_data[mapper_name][row[0]] = ["" if row[1] == np.nan else row[1].strip(), "" if row[2] == np.nan else row[2].strip()]
    return mapped_data


def dest_ip_bin(ip):
    try:
        return ipaddress.ip_address(ip).packed.hex()
    except:
        return ipaddress.ip_address('0.0.0.0').packed.hex()

def session_hash_generator(session_string):
    return hashlib.sha256(session_string.encode()).hexdigest()
    
# Helper function for hashing
def compute_hash(series, case_id):
    """Compute SHA-256 hash for a series with a case ID."""
    return series.map(lambda x: hashlib.sha256(f"{x}{case_id}".encode()).hexdigest())

def process_session_hash(df, csv_operator_name):
    # Create session strings based on the operator
    if csv_operator_name in ["jio", "bsnl", "pcap"]:
        session_string = (
            df['phone_no'].astype(str) +
            df['public_ip_address'].astype(str) +
            df['start_date_time'].astype(str) +
            df['end_date_time'].astype(str)
        )
    else:
        session_string = (
            df['phone_no'].astype(str) +
            df['public_ip_address'].astype(str) +
            df['start_date_time'].astype(str)
        )

    # Compute hashes
    session_hash = session_string.map(lambda x: hashlib.sha256(x.encode()).hexdigest())

    session_string2 = (
        df['phone_no'].astype(str) +
        df['public_ip_address'].astype(str) +
        df['end_date_time'].astype(str)
    )
    comb_session_hash5 = session_string2.map(lambda x: hashlib.sha256(x.encode()).hexdigest())

    session_string3 = df.astype(str).agg(''.join, axis=1)
    ipdr_id_session_hash = session_string3.map(lambda x: hashlib.sha256(x.encode()).hexdigest())

    return pd.DataFrame({
        'session_hash': session_hash,
        'comb_session_hash5': comb_session_hash5,
        'ipdr_id_session_hash': ipdr_id_session_hash
    })



def process_session_hash_cdr(df):
    session_strings = df.astype(str).agg(''.join, axis=1)
    return session_strings.map(lambda x: hashlib.sha256(x.encode()).hexdigest())


def mapper_finder(source):
    all_columns = []
    mapper_name = ""
    date_format = ""
    header_position = 0
    header_length = 0
    merge_columns = {}
    rename_columns = {}
    empty_columns = []
    keys_to_remove = ['id', 'is_ipdr', 'is_cdr', 'is_pcap', 'is_gprs', 'mapper_name', 'service_provider', 'created_at', 'date_format']
    mapper_df, merge_df = load_mapper(source)
    if len(mapper_df):
        mapper_df = mapper_df.fillna(0)
        mapper_dicts = mapper_df.to_dict('records')
        mapper_dict = mapper_dicts[0]
        mapper_name = source['mapper_name']
        date_format = mapper_dict['date_format']
        header_position = source['header_position']
        header_length = source['header_length']
        mapper_dict = {key: value for key, value in mapper_dict.items() if key not in keys_to_remove}
        all_columns = list(mapper_dict.keys())

        for column in all_columns:
            if mapper_dict[column] == 0:
                empty_columns.append(column)
            else:
                rename_columns[mapper_dict[column]] = column

    if len(merge_df):
        merge_dicts = merge_df.to_dict('records')
        merge_columns_string = merge_dicts[0]['merge_columns']
        merge_columns = json.loads(merge_columns_string)

    return all_columns, mapper_name, rename_columns, merge_columns, date_format, empty_columns, header_position, header_length


def mapper_finderX(source, mapping):
    limit = 20
    header_pos = 0
    nan_count = 0
    header_len =0
    results =[]
    header_compatibilty =0
    temp = []
    match_max ={}
    mapped_data = {}
    rename_data = {}
    merge_data = {}
    date_format_data = ''
    empty_data = {}
    k =''
    v =[]
    head =''
    headers = []

    if source['extension'] == 'xlsx':
        source_df = pd.read_excel(source['source_path'],sheet_name=0, header=None,engine='openpyxl')

        for _, row in source_df.iterrows():
            row_list = row.tolist()
            if len(row_list) >10:
                header_pos = _
                headers = row_list
                break
    elif source['extension'] == 'pcap' or source['extension'] == 'pcapng' or source['extension'] == 'gprsdata':
        with open(source['source_path'], 'r') as sf:
            for n, line in enumerate(sf, 1):
                row = line.split(',')
                if len(line)>100 and len(row) > 10:
                    header_pos = n
                    headers = [item.strip() for item in row]
                    break
                limit -= 1
                if not limit:
                    break
    elif source['extension'] == 'html':
        with open(source['source_path'], 'r') as sf:
            for n, line in enumerate(sf, 1):
                row = line.split('|')
                if len(line)>120 and len(row) > 10:
                    header_pos = n
                    headers = [item.strip() for item in row]
                    break
                limit -= 1
                if not limit:
                    break
    else:
        with open(source['source_path'], 'r') as sf:
            for n, line in enumerate(sf, 1):
                row = line.split(',')
                if len(line)>95 and len(row) > 10:
                    header_pos = n
                    headers = [item.strip() for item in row]
                    break
                limit -= 1
                if not limit:
                    break
    header_len = len(headers)
    results = []
    for obj in mapping:
        header_compatibilty = 0
        temp = []
        for obj1 in mapping[obj]:
            cols = mapping[obj][obj1]
            if cols:
                for col in cols:
                    temp.append(col)
        for head in headers:
            if head in temp:
                header_compatibilty += 1
        
        results.append({
            'x': (float(header_compatibilty)/float(header_len))*100.0 if float(header_compatibilty) else float(header_compatibilty),
            'match': (float(header_compatibilty)/float(header_len))*100.0 if float(header_compatibilty) else float(header_compatibilty),
            'mapping': obj,
            'header_pos': header_pos
        })
    match_max = sorted(results, key=lambda d: d['match'])[-1]
    mapped_data = mapping[match_max['mapping']]
    date_format_data = mapped_data['date_format'][0]
    for k, v in mapped_data.items():
        strip_v = [val for val in v if val]
        if len(strip_v) == 1:
            rename_data[v[0]] = k
        elif len(strip_v) == 2:
            merge_data[k] = v
        else:
            empty_data[k] = 0

    return list(mapped_data.keys()), match_max['mapping'], rename_data, merge_data,date_format_data, list(empty_data.keys()), match_max['header_pos'], header_len


def process_cellid(cell_id):
    if cell_id:
        try:
            
            combined_cell_id=''
            if isinstance(cell_id, (int, float)):
                combined_cell_id = "{:d}".format(int(float(cell_id)))
            else:
                if cell_id.upper().find('MCC')!=-1:
                    splited_cell_id = cell_id.split(' ')
                    combined_cell_id = ''
                    for ss in splited_cell_id:
                        combined_cell_id = combined_cell_id + ss.split(':')[1]
                else:
                    combined_cell_id =str(cell_id)
            cell_id = str(combined_cell_id).replace("-",'').replace(".0",'').replace("'",'').upper()
        except:pass
    else:
        pass
    try:
        cell_id = str(round(cell_id))
    except:
        cell_id = str(cell_id)
    return cell_id

def convertFloatToInt(x):
    try:
        return int(float(x))
    except:
        return 0

def process_start_date_time_cdr(x):
    x = x.strip()

    ############ For Nepal ###############
    if x.find(' ')==-1 and len(x)==14:
        yyyy, mm, dd,hh, mmt, ss = x[0:4], x[4:6], x[6:8], x[8:10], x[10:12], x[12:14]
        x="{}-{}-{} {}:{}:{}".format(dd, mm, yyyy, hh, mmt, ss)        
    # print(x)
    x = x.replace("'","").replace('"',"")

    try:
        start_datetime = datetime.datetime.strptime(x, '%d-%m-%Y %H:%M:%S')
        start_timestamp = datetime.datetime.timestamp(start_datetime)      
        return int(start_timestamp)
    except:
        try:
            start_datetime = datetime.datetime.strptime(x, '%d/%m/%Y %H:%M:%S')
            
            start_timestamp = datetime.datetime.timestamp(start_datetime)
            return int(start_timestamp)
        except:
            try:
                return int(datetime.datetime.timestamp(parser.parse(x)))
            except:
                return 0


def process_start_date_time( start_datetime, date_format):
    start_datetime = start_datetime.replace("'","").replace('"',"")

    try:
        if start_datetime:
            start_datetime_format = datetime.datetime.strptime(start_datetime, date_format)
            start_timestamp = datetime.datetime.timestamp(start_datetime_format)
            start_timestamp =  int(start_timestamp)
            return int(start_timestamp)
    except:
        if start_datetime: 
            try:
                try:
                    start_datetime_format = datetime.datetime.strptime(start_datetime, '%Y-%m-%d %H:%M:%S')
                    start_timestamp = datetime.datetime.timestamp(start_datetime_format)
                    start_timestamp =  int(start_timestamp)
                    return int(start_timestamp)
                except:
                    try:
                        start_datetime_format = datetime.datetime.strptime(start_datetime, '%d-%m-%Y %H:%M:%S')
                        start_timestamp = datetime.datetime.timestamp(start_datetime_format)
                        start_timestamp =  int(start_timestamp)
                        return int(start_timestamp)
                    except:
                        try:
                            return int(datetime.datetime.timestamp(parser.parse(start_datetime)))
                        except:
                            return 0
            except:
                return 0
            
def process_end_date_time_cdr(main_row):
    end_date_time = 0
    session_duration = 0    
    if main_row['end_date_time'] == "":
        if  isinstance(main_row['cdr_duration'], str):
            end_date_time = int(main_row['start_date_time']) + (int(main_row['cdr_duration']) if main_row['cdr_duration'].isdigit() else 0)
            session_duration = (int(main_row['cdr_duration']) if main_row['cdr_duration'].isdigit() else 0)
        else:
            end_date_time = int(main_row['start_date_time']) + int(main_row['cdr_duration'])
            session_duration = int(main_row['cdr_duration'])         
    return end_date_time,session_duration

def process_is_voip(x, VOIP_PORTS):
    try:
        if (len(str(int(x.public_ip_port))) == 5 and len(str(int(x.destination_port))) == 5) or str(int(x.destination_port)) in VOIP_PORTS:
            return 'yes'
    except:
        return 'no'

def process_protocol(x):
    try:
        return socket.getservbyport(int(x))
    except:
        return 'udp'

def update_progress(file_id):
    IPDR_CONN = ipdr_conn()
    cursor_ipdr = IPDR_CONN.cursor()   
    sql = "UPDATE %s  SET uploadStatus=1 WHERE ID=%s" % ('files_meta_details',file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()
    IPDR_CONN.close()

def update_operator(file_id, operator_name):
    IPDR_CONN = ipdr_conn()
    cursor_ipdr = IPDR_CONN.cursor()   
    sql = "UPDATE %s SET telecom_name='%s' WHERE ID=%s" % ('files_meta_details', operator_name, file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()
    IPDR_CONN.close()  

    
def update_failover(IPDR_CONN,file_id,case_id):
    cursor_ipdr = IPDR_CONN.cursor()      
    sql = "UPDATE %s SET uploadStatus=0 WHERE ID=%s" % ('files_meta_details', file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()

def update_completion(file_id,case_id):
    IPDR_CONN1 = ipdr_conn()
    cursor_ipdr = IPDR_CONN1.cursor()      
    sql = "UPDATE %s SET uploadStatus=2 WHERE ID=%s" % ('files_meta_details', file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN1.commit()
    IPDR_CONN1.close()

def update_format_not_found(IPDR_CONN,file_id,case_id):
    cursor_ipdr = IPDR_CONN.cursor()      
    sql = "UPDATE %s SET uploadStatus=9 WHERE ID=%s" % ('files_meta_details', file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()

def update_empty_file(IPDR_CONN,file_id,case_id):
    cursor_ipdr = IPDR_CONN.cursor()      
    sql = "UPDATE %s SET uploadStatus=5 WHERE ID=%s" % ('files_meta_details', file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()
    
def update_license_invalid(IPDR_CONN,file_id,case_id):
    cursor_ipdr = IPDR_CONN.cursor()      
    sql = "UPDATE %s SET uploadStatus=10 WHERE ID=%s" % ('files_meta_details', file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()


def update_failed(file_id,case_id):
    IPDR_CONN = ipdr_conn()
    cursor_ipdr = IPDR_CONN.cursor()      
    sql = "UPDATE %s SET uploadStatus=3 WHERE ID=%s" % ('files_meta_details', file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()
    IPDR_CONN.close()


def update_stopped(file_id):
    IPDR_CONN = ipdr_conn()
    cursor_ipdr = IPDR_CONN.cursor()      
    sql = "UPDATE %s SET uploadStatus=15 WHERE ID=%s" % ('files_meta_details', file_id)
    cursor_ipdr.execute(sql)
    IPDR_CONN.commit()
    IPDR_CONN.close()

def convertToFloat(number):
    return float(number)

def bulk_save_loop(temp,IPDR_CONN,table_name):
    cursor_ipdr = IPDR_CONN.cursor()
    placeholders = ', '.join(['?'] * len(temp[0]))
    columns = ', '.join(temp[0].keys())
    sql = "INSERT INTO %s ( %s ) VALUES ( %s )" % (table_name, columns, placeholders)
    cursor_ipdr.executemany(sql, [list(item.values()) for item in temp])
    IPDR_CONN.commit()
    
def validIPAddress(IP: str) -> str:
    try:
        return "IPv4" if type(ip_address(IP)) is IPv4Address else "IPv6"
    except ValueError:
        return "Invalid"


def bulk_solr_update(BULKER_DIR):
    # "java  -Dtype=application/json -Dc=ipdr_details -jar C:\\Users\\Arvind\\Desktop\\bigdata\\solr-8.11.2\\example\\exampledocs\\post.jar *.json"
    database_json_file= open('database.config','r').read()
    database = json.loads(database_json_file)
    solr_post_windows_path = database['solr_post_windows_path']
    solr_post_linux_path = database['solr_post_linux_path']
    solr_port = database['solr_port']
    os.chdir(BULKER_DIR)
    while True:
        time.sleep(1)
        all_files = os.listdir(BULKER_DIR)
            # all_files.sort(key=os.path.getctime)
        all_files.sort(key=lambda L: (re.findall('_1_', L), L))
        for temp_files in all_files:
            if temp_files.endswith(".csv"):
                bulk_solr_time = time.time()
                try:
                    case_id = temp_files.split("_")[0]
                    file_id = temp_files.split("_")[1]
                    is_last = temp_files.split("_")[2]
                    if os.path.getsize(os.path.join(BULKER_DIR,temp_files))!=0:
                        core_name = "ipdr_details"
                        platform_name = platform.system()
                        s_username = database['SOLR_USERNAME']
                        s_password= database['SOLR_PASSWORD']
                        if platform_name == "Windows":
                            solr_post_tool_path = solr_post_windows_path
                            command = ["java","-Dtype=text/csv","-Dc=ipdr_details","-jar",solr_post_tool_path,temp_files,'-u', f"{s_username}:{s_password}"]
                        else:
                            solr_post_tool_path = solr_post_linux_path
                            #  command = [solr_post_tool_path,"-c","ipdr_details","-params",'"commit=true"',"-p",str(solr_port),temp_files]
                            command = [solr_post_tool_path,"-c","ipdr_details","-u",f"{s_username}:{s_password}","-params",'"commit=true"',"-p",str(solr_port),temp_files]
                        
                        try:
                            solr_post_tool_output = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                        except Exception as err:
                            logging.error('solr_post_tool_output Error ----------------: '+str(traceback.format_exc()))
                        
                        ipdr_details_solr.commit()
                        
                        if  solr_post_tool_output.returncode ==0:
                            os.remove(os.path.join(BULKER_DIR,temp_files))
                            print("bulk insertion time ",str(case_id),str(file_id),time.time()-bulk_solr_time)
                            if int(is_last) ==1:
                                os.chdir(CURR_WORK_DIR)
                                update_completion(file_id,case_id)
                                os.chdir(BULKER_DIR)  
                except Exception:
                    logging.error('Bulker Error: '+str(traceback.format_exc()))

def nan_exist(d):
    df = pd.DataFrame(d, index=[d.keys()])
    if df.isnull().values.any():
        return True
    else:
        return False

def split_dataframe(df, chunk_size = 10000): 
    chunks = list()
    num_chunks = len(df) // chunk_size + 1
    for i in range(num_chunks):
        chunks.append(df[i*chunk_size:(i+1)*chunk_size])
    return chunks

def get_country_code_sms_app(phone_number,sms_df): 
    country_code = "UNKNOWN"
    header_short = "UNKNOWN"
    header_com = "UNKNOWN"
    try:
        if len(str(phone_number))>10:
            new_phone_no = "+" + str(phone_number).lstrip('0')
        else:
            new_phone_no = "+91" + str(phone_number)
        pn = phonenumbers.parse(new_phone_no)
        country_code= pycountry.countries.get(alpha_2=region_code_for_number(pn)).name
    except:
        country_code = "UNKNOWN"
    if str(phone_number).find("-")!=-1:
        header_code = str(phone_number).upper().split('-')[-1]
        sms_df2 = sms_df[(sms_df['header'] == header_code)]
        if not sms_df2.empty:
            header_short =   str(sms_df2['header_short'].head(1).values[0])
            header_com =   str(sms_df2['header_com'].head(1).values[0])
    elif len(str(phone_number)) <=7:
        sms_df2 = sms_df[(sms_df['header'] == str(phone_number).upper())]
        if not sms_df2.empty:
            header_short =   str(sms_df2['header_short'].head(1).values[0])
            header_com =   str(sms_df2['header_com'].head(1).values[0])
    return country_code.upper(),header_short.upper(),header_com.upper()


def find_cdr_call_type(row):
    call_type = 'UNKNOWN'
    service_type = 'UNKNOWN'
    # Determine service type and call type based on MEASURE_UNIT
    if row['MEASURE_UNIT']:
        if 'SECONDS' in row['MEASURE_UNIT'].upper():
            service_type = 'CALL'
            call_type = 'INCOMING' if 'INCOMING' in row['cdr_service_type'].upper() or 'FREE' in row['cdr_service_type'].upper() else 'OUTGOING'
        else:
            call_type = 'INCOMING'
            service_type = 'SMS'
    else:
        # call_type, service_type = determine_call_and_service_type(row)        
        incoming_calls = ['a_in', 'IN', 'INC', 'Incoming', 'v_in', 'w_in', 'a_in_wv', 'a_in_vw', 'a_in_wifi']
        outgoing_calls = ['a_out', 'OUT', 'Outgoing', 'v_out', 'w_out', 'a_out_wv', 'a_out_vw', 'a_out_wifi']
        sms_incoming = ['A2P_SMSIN', 'P2P_SMSIN', 'P2P_SMSIN_wifi', 'A2P_SMSIN_wifi', 'SMT', 'SMS_INC']
        sms_outgoing = ['P2POUT', 'A2POUT', 'P2POUT_wifi', 'A2POUT_wifi', 'SMO', 'SMS_MOC']
        if row['cdr_call_type'] in incoming_calls:
            call_type = 'INCOMING'
            service_type = 'CALL' if row['cdr_service_type'] != 'SMS' else 'SMS'
        elif row['cdr_call_type'] in sms_incoming:
            call_type = 'INCOMING'
            service_type = 'SMS'
        elif row['cdr_call_type'] in outgoing_calls:
            call_type = 'OUTGOING'
            service_type = 'CALL' if row['cdr_service_type'] != 'SMS' else 'SMS'
        elif row['cdr_call_type'] in sms_outgoing:
            call_type = 'OUTGOING'
            service_type = 'SMS'
        elif str(row['cdr_call_type']) == '1':
            call_type = 'INCOMING'
            service_type = 'CALL'
        elif str(row['cdr_call_type']) == '0':
            call_type = 'OUTGOING'
            service_type = 'CALL'
    public_ip_address = str(row['public_ip_address']) or ''
    destination_ip_address = str(row['destination_ip_address']) or ''
    if not public_ip_address:
        cell_id = str(row['cell_id'])
        second_cell_id = str(row['second_cell_id'])
        if ':' in cell_id:
            public_ip_address = cell_id.split(':')[0]
        elif ':' in second_cell_id:
            public_ip_address = second_cell_id.split(':')[0]
    if not destination_ip_address and ':' in second_cell_id:
        destination_ip_address = second_cell_id.split(':')[0]
    if not row['cell_id']:
        cell_id= ''
    if isinstance(row['cell_id'], (int, float)):
        cell_id= "{:d}".format(int(float(row['cell_id']))).replace("-", '').replace(".0", '').replace("'", '').upper()
    if 'MCC' in str(row['cell_id']).upper():
        cell_id= ''.join(part.split(':')[1] for part in row['cell_id'].split(' ')).replace("-", '').replace(".0", '').replace("'", '').upper()
    cell_id= str(row['cell_id']).replace("-", '').replace(".0", '').replace("'", '').upper()
    if not row['second_cell_id']:
        second_cell_id= ''
    if isinstance(row['second_cell_id'], (int, float)):
        second_cell_id= "{:d}".format(int(float(row['second_cell_id']))).replace("-", '').replace(".0", '').replace("'", '').upper()
    if 'MCC' in str(row['second_cell_id']).upper():
        second_cell_id= ''.join(part.split(':')[1] for part in row['second_cell_id'].split(' ')).replace("-", '').replace(".0", '').replace("'", '').upper()
    second_cell_id= str(row['second_cell_id']).replace("-", '').replace(".0", '').replace("'", '').upper()
    return call_type, service_type, cell_id, second_cell_id, public_ip_address, destination_ip_address

def html_to_csv(full_path_html):
    csv_file_path = full_path_html.replace('.html','.csv')
    with open(csv_file_path, 'w') as cf:
        with open(full_path_html, 'r') as hf:
            soup = BeautifulSoup(hf, "html.parser")
            tables = soup.find_all('table')
            first_row = tables[0].find('tr')
            headers = [(header.text).strip()for header in first_row.find_all('td')]
            cf.write('|'.join(headers)+'\n')
            for table in tables:
                rows = table.find_all('tr')
                for i, row in enumerate(rows):
                    if i > 0:
                        r = [(val.text).strip() for val in row.find_all('td')]
                        cf.write('|'.join(r)+'\n')
    os.remove(full_path_html)
    return csv_file_path


def extract_nested_zip(zip_path,old_extract_dir):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        # pcap_file_name = os.path.basename(zip_path).replace('.zip','.pcap')
        extract_dir = os.path.splitext(zip_path)[0]
        zip_ref.extractall(extract_dir)
        for root, dirs, files in os.walk(extract_dir):
            for files_meta in files:
                if files_meta.lower().endswith('.zip'):
                    if os.path.getsize(os.path.join(root,files_meta))!=0:
                        try:
                            extract_nested_zip(os.path.join(root,files_meta),old_extract_dir)
                            shutil.rmtree(os.path.join(root,files_meta.split(".zip")[0]))
                        except:
                            pass
                        

def is_common_port(port):
    common_ports = [20, 21, 22, 23, 25, 53, 80, 110, 115, 123, 139, 443, 500, 523, 989, 990, 1433, 1434, 1600, 1723, 3389, 3306, 4244, 4433, 4500, 4600, 5000, 5222, 5223, 5228, 5432, 636, 6881, 6882, 6883, 6884, 6885, 6886, 6887, 6888, 6889, 6890, 6891, 6969, 7985, 8080, 8130, 8443, 853, 8888, 993, 1194, 1400, 1390, 16384, 16385, 16386, 16387, 16388, 16389, 16390, 16391, 16392, 1701, 19302, 19305, 3478, 3479, 3480, 3481, 3482, 3483, 3484, 3485, 3486, 3487, 3488, 3489, 3490, 3491, 3492, 3493, 3494, 3495, 3496, 3497, 50001, 50002, 50003, 50004, 50005, 600, 8000, 50005]
    return port in common_ports


def swap_values_for_common_ports(row):
    if is_common_port(row['src_port']) or (int(row['src_port'])<1000 and int(row['src_port']) < int(row['dst_port'])) or (row['pact_proto'].upper() in ["RTP","RTCP","HTTP","IMAPS","TLS","HTTPS"] and int(row['src_port']) < int(row['dst_port'])):
        row['src_ip'], row['dst_ip'] = row['dst_ip'], row['src_ip']
        row['src_port'], row['dst_port'] = row['dst_port'], row['src_port']
        row['c_to_s_bytes'], row['s_to_c_bytes'] = row['s_to_c_bytes'], row['c_to_s_bytes']
        row['c_to_s_goodput_bytes'], row['s_to_c_goodput_bytes'] = row['s_to_c_goodput_bytes'], row['c_to_s_goodput_bytes']
    return row

def detect_archive_type(file_path):
    mime = magic.Magic(mime=True)
    file_mime_type = mime.from_file(file_path)
    if file_mime_type in ['application/zip','application/x-zip-compressed','application/x-compressed','application/x-zip-compressed64','inode/blockdevice']:
        return 'ZIP'
    elif file_mime_type == 'application/x-rar-compressed':
        return 'RAR'
    else:
        return 'UNKNOWN'

def pcap_to_csv(file_id,telecom_name,full_path_pcap,file_extention,merger_path,pact_path,CURR_WORK_DIR,custom_phone_no,custom_public_ip_address,dc_path,file_hash):
    update_progress(file_id)
    if file_extention == 'gprsdata':
        zip_path  = full_path_pcap
        main_file_name = os.path.basename(full_path_pcap).split('.')[0]
        file_detected = detect_archive_type(zip_path)
        old_extract_dir = os.path.splitext(zip_path)[0]
        try:
            os.mkdir(old_extract_dir)
        except:
            pass
        if file_detected != 'UNKNOWN':
            if file_detected == 'ZIP':
                csv_file_path = zip_path.replace('.zip','_sessions.csv')
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(old_extract_dir)
                    os.chdir(old_extract_dir)
                    for root, dirs, files_s in os.walk(old_extract_dir):
                        for files in files_s:
                            # os.chdir(old_extract_dir)
                            if files.lower().endswith('.zip'):
                                if os.path.getsize(os.path.join(root,files))!=0:
                                    try:
                                        extract_nested_zip(os.path.join(root,files),old_extract_dir)
                                        # shutil.rmtree(os.path.join(os.getcwd(),files.split(".zip")[0]))
                                    except:
                                        pass
                                # os.remove(os.path.join(os.getcwd(),files))
            elif file_detected == 'RAR':
                csv_file_path = zip_path.replace('.rar','_sessions.csv')
                with rarfile.RarFile(zip_path) as rar:
                    rar.extractall(old_extract_dir)
            pcapCSV = open(old_extract_dir + '/pcapCSV.csv', 'w')
            pcap_files = []
            cri_files = []
            for root, dirs, files in os.walk(old_extract_dir):
                for file in files:
                    if file.endswith('.pcap'):
                        try:
                            u_file_name = hashlib.sha256(file.replace(".pcap",'').replace(" ",'_').encode()+str(time.time()).encode()).hexdigest()+".pcap"
                            shutil.move(os.path.join(root,file),os.path.join(root,u_file_name))
                            pcap_files.append(os.path.join(root,u_file_name))
                            pcapCSV.write(os.path.join(root,u_file_name)+"\n")
                        except:pass
                    elif file.endswith('.txt'):
                        try:
                            u_file_name = hashlib.sha256(file.replace(".txt",'').replace(" ",'_').encode()+str(time.time()).encode()).hexdigest()+".txt"
                            shutil.move(os.path.join(root,file),os.path.join(root,u_file_name))
                            cri_files.append(os.path.join(root,u_file_name))
                        except:pass
                    
            pcapCSV.close()
            os.chdir(old_extract_dir)

            phone_no = ''
            imei_no = ''
            imsi_no = ''
            cell_id = ''
            main_df_list = []
            for text_file in cri_files:
                txt_file_data_dict = []
                try:
                    with open(text_file, 'r') as file:
                        txt_data = file.read()
                    if txt_data.find('IRIRecordType')!=-1:
                        sections = txt_data.split('CDR Start')
                        temp ={}
                        for section in sections:
                            if section.replace(' ','').strip()!='':
                                temp={}
                                phone_no = re.findall(r'MSISDN\s*:\s*([0-9a-fA-F:]+)\n',section,re.DOTALL)
                                if len(phone_no)!=0:
                                    temp['phone_no'] = phone_no[0]
                                else:
                                    temp['phone_no']= ''
                                start_date_time = re.findall(r'TimeStamp\s*:\s*(.*?)\n',section,re.DOTALL)
                                if len(start_date_time)!=0:
                                    temp['start_date_time'] = start_date_time[0]
                                    
                                    datetime_obj = datetime.datetime.strptime(temp['start_date_time'], "%d-%m-%Y %H:%M:%S")
                                    temp['start_date_time'] = datetime_obj.timestamp()
                                    temp['end_date_time'] = temp['start_date_time']
                                    
                                else:
                                    temp['start_date_time']= 0
                                imei_no = re.findall(r'IMEI/MAC\s*:\s*(.*?)\n',section,re.DOTALL)
                                if len(imei_no)!=0:
                                    temp['imei_no'] = imei_no[0]
                                else:
                                    imei_no = re.findall(r'IMEI\s*:\s*(.*?)\n',section,re.DOTALL)
                                    if len(imei_no)!=0:
                                        temp['imei_no'] = imei_no[0]
                                    else:
                                        temp['imei_no'] = ''
                                imsi_no = re.findall(r'IMSI\s*:\s*(.*?)\n',section,re.DOTALL)
                                if len(imsi_no)!=0:
                                    temp['imsi_no'] = imsi_no[0]
                                else:
                                    temp['imsi_no'] = ''
                                ip_address = re.findall(r'IPAddress\s*:\s*(.*?)\n',section,re.DOTALL)
                                
                                if len(ip_address)!=0:
                                    try:
                                        temp['public_ipv6_address'] = ip_address[0].split("/")[0]
                                        temp['public_ip_address'] = ip_address[0].split("/")[1]
                                    except:
                                        temp['public_ipv6_address'] = ip_address[0]
                                        temp['public_ip_address'] = ''
                                else:
                                    temp['public_ipv6_address'] = ''
                                    temp['public_ip_address'] = ''

                                access_point_name = re.findall(r'AccessPoint\s*:\s*(.*?)\n',section,re.DOTALL)
                                if len(access_point_name)!=0:
                                    temp['access_point_name'] = access_point_name[0]
                                else:
                                    temp['access_point_name'] = ''
                                session_duration = re.findall(r'Duration\s*:\s*(.*?)\n',section,re.DOTALL)
                                if len(session_duration)!=0:
                                    if session_duration[0].find('Session')==-1:
                                        duration = datetime.datetime.strptime(session_duration[0], "%H:%M:%S")
                                        duration_timedelta = timedelta(hours=duration.hour, minutes=duration.minute, seconds=duration.second)
                                        duration_seconds = duration_timedelta.total_seconds()
                                        temp['session_duration'] = int(duration_seconds)
                                        temp['end_date_time'] = int(temp['start_date_time'])+int(duration_seconds)
                                    else:
                                        temp['session_duration'] = 0
                                cell_id = re.findall(r'CellId\s*:\s*(.*?)\n',section,re.DOTALL)
                                if len(cell_id)!=0:
                                    temp['cell_id'] = cell_id[0].replace('-','').replace('_','')
                                else:
                                    temp['cell_id'] = ''
                                if(temp['phone_no']!='' and temp['start_date_time']!=0):
                                    txt_file_data_dict.append(temp)

                    elif txt_data.find('RECORD_TYPE')!=-1:
                        sections = txt_data.split('RECORD_TYPE')

                        for section in sections:
                            if section.replace(' ','').strip()!='':
                                
                                temp={}
                                phone_no = re.findall(r'TARGET_NUMBER\s*=\s*(.*?)\n',section,re.DOTALL)
                                if len(phone_no)!=0:
                                    temp['phone_no'] = phone_no[0]
                                else:
                                    temp['phone_no']= ''
                                start_date_time = re.findall(r'CALL_START_TIME\s*=\s*(.*?)\n',section,re.DOTALL)
                                if len(start_date_time)!=0:
                                    temp['start_date_time'] = start_date_time[0]
                                    
                                    datetime_obj =datetime.datetime.strptime(temp['start_date_time'], "%Y-%m-%d %H:%M:%S")
                                    temp['start_date_time'] = datetime_obj.timestamp()
                                    
                                else:
                                    temp['start_date_time']= 0
                                imei_no = re.findall(r'TGT_IMEI\s*=\s*(.*?)\n',section,re.DOTALL)
                                if len(imei_no)!=0:
                                    temp['imei_no'] = imei_no[0]
                                else:
                                    temp['imei_no'] = ''
                                imsi_no = re.findall(r'TGT_IMSI\s*=\s*(.*?)\n',section,re.DOTALL)
                                if len(imsi_no)!=0:
                                    temp['imsi_no'] = imsi_no[0]
                                else:
                                    temp['imsi_no'] = ''
                                
                                sub_sections = section.split('IRI_LIID')
                                
                                for sub_section in sub_sections:
                                    
                                    end_date_time = re.findall(r'CONT_TIME\s*=\s*(.*?)\n',sub_section,re.DOTALL)
                                    if len(end_date_time)!=0:
                                        temp['end_date_time'] = end_date_time[0]
                                        datetime_obj = datetime.datetime.strptime(temp['end_date_time'], "%Y-%m-%d %H:%M:%S")
                                        temp['end_date_time'] = datetime_obj.timestamp()
                                    else:
                                        temp['end_date_time']= 0
                                    cell_id = re.findall(r'LOCATION\s*=\s*(.*?)\n',sub_section,re.DOTALL)
                                    if len(cell_id)!=0:
                                        temp['cell_id'] = cell_id[0].replace('-','')
                                    else:
                                        temp['cell_id'] = ''
                                    temp['public_ip_address'] = ''
                                    temp['public_ipv6_address'] = ''
                                    temp['access_point_name'] = ''
                                    temp['session_duration'] = int(temp['end_date_time'])-int(temp['start_date_time'])
                                    if(temp['phone_no']!='' and temp['start_date_time']!=0):
                                        txt_file_data_dict.append(temp)
                except:pass
                if len(txt_file_data_dict)!=0:
                    df = pd.DataFrame(txt_file_data_dict)
                    main_df_list.append(df)
                # os.remove(os.path.join(old_extract_dir,text_file))
            
            full_path_pcap = old_extract_dir+'/'+str(file_hash)+".pcap"
            temp_csv_file_path_pact = full_path_pcap.replace('.pcap','_pact.csv')
            merger_cmd = merger_path + " " +old_extract_dir+'/pcapCSV.csv '+ full_path_pcap
            pact_command = pact_path + ' -i "'+full_path_pcap +'" -v 2 -q -C "'+temp_csv_file_path_pact+'"'            
            dc_command  = dc_path+" "+ full_path_pcap+""
            platform_name = platform.system()
            # if platform_name == "Windows":
            #     os.system(merger_cmd)
            #     os.system(pact_command)
            # else:
            os.system(merger_cmd)
            os.system(pact_command)
            try:
                all_sessions = pd.read_csv(temp_csv_file_path_pact,sep='|')
                def remove_unwanted_chars(value):
                    if isinstance(value, str):
                            return value.replace(',', '')
                    return value
                all_sessions = all_sessions.applymap(remove_unwanted_chars)
                all_sessions.sort_values(by='#flow_id', ascending=True, inplace=True)
                all_sessions = all_sessions.apply(swap_values_for_common_ports, axis=1)

                relevant_columns = ['first_seen','last_seen','duration','src_ip','src_port','dst_ip','dst_port','pact_proto','proto_by_ip','server_name_sni','c_to_s_bytes','c_to_s_goodput_bytes','s_to_c_bytes','s_to_c_goodput_bytes','data_ratio','str_data_ratio','tls_version','ja3c','ja3s','http_user_agent','flow_info','proto_category','telnet_username','telnet_password','kerberos_domain','kerberos_hostname','kerberos_username','ftp_imap_pop_smtp_username','ftp_imap_pop_smtp_password','ftp_imap_pop_smtp_status','http_url','http_response_status_code','http_request_content_type','http_content_type','http_server','ssh_tls_server_info','ssh_tls_server_names','ssh_tls_tls_issuerDN','ssh_tls_tls_subjectDN','ssh_tls_encrypted_sni_esni','tls_browser','bittorent_hash','dhcp_fingerprint','human_readeable_string','pub_ip','pub_port']
            
                all_sessions = all_sessions[relevant_columns]

                all_sessions.columns = ['start_date_time','end_date_time','session_duration','source_ip','source_port', 'destination_ip', 'destination_port', 'apk_ipa_pact', 'application_name', 'domain_name', 'uplink_vol', 'uplink_data', 'downlink_vol', 'downlink_data','data_ratio', 'session_type', 'tls_version', 'ja3_client', 'ja3_server', 'user_agent','flow_info','proto_category','telnet_username','telnet_password','kerberos_domain','kerberos_hostname','kerberos_username','ftp_imap_pop_smtp_username','ftp_imap_pop_smtp_password','ftp_imap_pop_smtp_status','http_url','http_response_status_code','http_request_content_type','http_content_type','http_server','ssh_tls_server_info','ssh_tls_server_names','ssh_tls_tls_issuerDN','ssh_tls_tls_subjectDN','ssh_tls_encrypted_sni_esni','tls_browser','bittorent_hash','dhcp_fingerprint','human_readeable_string','pub_temp_ip','public_ip_port']

                if custom_phone_no!='':
                    all_sessions['phone_no'] = custom_phone_no
                else:
                    all_sessions['phone_no'] = main_file_name.replace(" ",'_')                

                print(full_path_pcap)
                print(temp_csv_file_path_pact)

                if len(main_df_list)!=0:
                    txt_file_df = pd.concat(main_df_list)
                    if len(all_sessions)!=0:
                        all_sessions = all_sessions.sort_values(by=['start_date_time'])
                        txt_file_df = txt_file_df.sort_values(by=['start_date_time'])
                        unknown_sessions = []
                        for _, row in txt_file_df.iterrows():
                            start_date_time = row['start_date_time']
                            phone_no=row['phone_no']
                            end_date_time = row['end_date_time']
                            imei_no = row['imei_no']
                            imsi_no = row['imsi_no']
                            cell_id = row['cell_id']
                            public_ip_address = row['public_ip_address']
                            public_ipv6_address = row['public_ipv6_address']
                            access_point_name = row['access_point_name']                            
                            all_sessions['phone_no'] = phone_no
                            condition = (((all_sessions['start_date_time'] >= start_date_time) & (all_sessions['end_date_time'] <= start_date_time)) | ((all_sessions['start_date_time'] <= end_date_time) & (all_sessions['end_date_time'] >= end_date_time)))
                            
                            all_sessions.loc[condition, ['imei_no','imsi_no','cell_id','public_ip_address','public_ipv6_address','access_point_name']] = [imei_no,imsi_no,cell_id,public_ip_address,public_ipv6_address,access_point_name]
                            
                            if len(all_sessions[condition])==0:
                                temp={'source_ip':'','source_port':0, 'destination_ip':'', 'destination_port':0, 'apk_ipa_pact':'',
                                        'application_name':'', 'domain_name':'', 'uplink_vol':0, 'uplink_data':0, 'downlink_vol':0, 'downlink_data':0,
                                        'data_ratio':0, 'session_type':'unknown', 'tls_version':'', 'ja3_client':'', 'ja3_server':'', 'user_agent':'','flow_info':'','pub_temp_ip':'','public_ip_port':0}
                                temp['phone_no'] = row['phone_no']
                                temp['start_date_time'] = start_date_time
                                temp['end_date_time'] = end_date_time
                                temp['imei_no'] = imei_no
                                temp['imsi_no'] = imsi_no
                                temp['cell_id'] = cell_id
                                temp['public_ip_address'] = public_ip_address
                                temp['public_ipv6_address'] = public_ipv6_address
                                temp['access_point_name'] = access_point_name
                                temp['session_duration'] = row['session_duration']
                                unknown_sessions.append(temp)

                        unknown_sessions_df = pd.DataFrame(unknown_sessions)
                        all_sessions = pd.concat([all_sessions,unknown_sessions_df])
                        all_sessions['start_date_time'] = all_sessions['start_date_time']+19800
                        all_sessions['end_date_time'] = all_sessions['end_date_time']+19800
                        all_sessions['start_date_time_temp'] = all_sessions['start_date_time']

                        for i in range(len(all_sessions) - 1):
                            if all_sessions['start_date_time'].iloc[i + 1] - all_sessions['start_date_time'].iloc[i] <= 1:
                                all_sessions.at[i + 1, 'start_date_time_temp'] = all_sessions['start_date_time'].iloc[i]

                        all_sessions['generated_time'] = all_sessions['start_date_time']
                        all_sessions['start_date_time'] = all_sessions['start_date_time_temp']
                        all_sessions['apk_ipa_pact'] = all_sessions['apk_ipa_pact'].fillna('')
                        all_sessions['pub_temp_ip'] = all_sessions['pub_temp_ip'].fillna('')
                        all_sessions['public_ip_port'] = all_sessions['public_ip_port'].fillna(0)
                        all_sessions['source_ip'] = all_sessions['source_ip'].fillna('')
                        mask = all_sessions['apk_ipa_pact'].str.contains('STUN', case=False)
                        all_sessions.loc[mask, 'public_ip_address'] = all_sessions.loc[mask, 'pub_temp_ip'] 
                        mask2 = all_sessions['source_ip'].str.contains(':', case=False)
                        all_sessions.loc[mask2, 'public_ip_address'] = all_sessions.loc[mask2, 'source_ip']
                        all_sessions.loc[mask2, 'public_ip_port'] = all_sessions.loc[mask2, 'source_port']
                        all_sessions = all_sessions.sort_values(by=['start_date_time'])
                        all_sessions = all_sessions.reset_index(drop=True)                        
                        all_sessions['session_duration'] = all_sessions['end_date_time']-all_sessions['generated_time']
                        all_sessions['end_date_time'] = all_sessions['start_date_time']+all_sessions['session_duration']
                        all_sessions['session_duration'] = all_sessions['end_date_time']-all_sessions['start_date_time']

                        first_occurrences = all_sessions[(all_sessions['apk_ipa_pact'].str.contains('STUN')) & (all_sessions['pub_temp_ip'] != all_sessions['destination_ip']) & (all_sessions['pub_temp_ip'] != '') & (all_sessions['pub_temp_ip'] != 'nan')  & (all_sessions['pub_temp_ip'] != 'nan') & (~all_sessions['source_ip'].str.contains(':'))].index
                        for ii,idx in enumerate(first_occurrences):
                            start_val = all_sessions.at[idx, 'pub_temp_ip']
                            public_ip_port = all_sessions.at[idx, 'public_ip_port']
                            end_idx = all_sessions.index[-1] if idx == first_occurrences[-1] else first_occurrences[first_occurrences.get_loc(idx) + 1]
                            if ii==0:
                                all_sessions.loc[0:idx, 'public_ip_address'] = start_val    
                                all_sessions.loc[0:idx, 'public_ip_port'] = public_ip_port    
                            all_sessions.loc[idx:end_idx, 'public_ip_address'] = start_val
                            all_sessions.loc[idx:end_idx, 'public_ip_port'] = public_ip_port
                        unique_public_ip_address = all_sessions['public_ip_address'].unique()
                        unique_public_ip_address = unique_public_ip_address[unique_public_ip_address != ""]
                        if len(unique_public_ip_address)==0:
                                all_sessions['public_ip_address']= all_sessions['source_ip']
                                all_sessions['public_ip_port']= all_sessions['source_port']
                        all_sessions.to_csv(csv_file_path,index=False)


                if len(all_sessions)!=0:
                    all_sessions.to_csv(csv_file_path,index=False)
                else:
                    csv_file_path = 'empty'
                    
            # except:
            except Exception as err:
                logging.error('Worker Error: '+str(traceback.format_exc()))
            os.chdir(CURR_WORK_DIR) 
            return csv_file_path
        else:
            csv_file_path = ''
            return csv_file_path
        

    elif file_extention == 'pcap':
        csv_file_path = full_path_pcap.replace('.pcap','_sessions.csv')
        main_file_name = os.path.basename(full_path_pcap).split('.pcap')[0]
        temp_csv_file_path_pact = full_path_pcap.replace('.pcap','_pact.csv')
        temp_full_path_pcap_media = full_path_pcap.replace('.pcap','.pcap.rtp')
        pact_command = pact_path + ' -i "'+full_path_pcap +'" -v 2 -q -C "'+temp_csv_file_path_pact+'"'
        print("=========>pact command:",pact_command)
        dc_command  = dc_path+" "+ full_path_pcap+""
        platform_name = platform.system()
        if platform_name == "Windows":
            result=os.system(pact_command)     
            print("======>result:",result)
        else:
            os.system(pact_command)            
        try:
            all_sessions = pd.read_csv(temp_csv_file_path_pact,sep='|')
            def remove_unwanted_chars(value):
                            if isinstance(value, str):
                                    return value.replace(',', '')
                            return value
            all_sessions = all_sessions.applymap(remove_unwanted_chars)
            all_sessions.sort_values(by='#flow_id', ascending=True, inplace=True)
            all_sessions = all_sessions.apply(swap_values_for_common_ports, axis=1)

            relevant_columns = ['first_seen','last_seen','duration','src_ip','src_port','dst_ip','dst_port','pact_proto','proto_by_ip','server_name_sni','c_to_s_bytes','c_to_s_goodput_bytes','s_to_c_bytes','s_to_c_goodput_bytes','data_ratio','str_data_ratio','tls_version','ja3c','ja3s','http_user_agent','flow_info','proto_category','telnet_username','telnet_password','kerberos_domain','kerberos_hostname','kerberos_username','ftp_imap_pop_smtp_username','ftp_imap_pop_smtp_password','ftp_imap_pop_smtp_status','http_url','http_response_status_code','http_request_content_type','http_content_type','http_server','ssh_tls_server_info','ssh_tls_server_names','ssh_tls_tls_issuerDN','ssh_tls_tls_subjectDN','ssh_tls_encrypted_sni_esni','tls_browser','bittorent_hash','dhcp_fingerprint','human_readeable_string','pub_ip','pub_port']
        
            all_sessions = all_sessions[relevant_columns]
            
            all_sessions.columns = ['start_date_time','end_date_time','session_duration','source_ip','source_port', 'destination_ip', 'destination_port', 'apk_ipa_pact', 'application_name', 'domain_name', 'uplink_vol', 'uplink_data', 'downlink_vol', 'downlink_data','data_ratio', 'session_type', 'tls_version', 'ja3_client', 'ja3_server', 'user_agent','flow_info','proto_category','telnet_username','telnet_password','kerberos_domain','kerberos_hostname','kerberos_username','ftp_imap_pop_smtp_username','ftp_imap_pop_smtp_password','ftp_imap_pop_smtp_status','http_url','http_response_status_code','http_request_content_type','http_content_type','http_server','ssh_tls_server_info','ssh_tls_server_names','ssh_tls_tls_issuerDN','ssh_tls_tls_subjectDN','ssh_tls_encrypted_sni_esni','tls_browser','bittorent_hash','dhcp_fingerprint','human_readeable_string','pub_temp_ip','public_ip_port']
        except:
            pass
        if custom_phone_no!='':
            all_sessions['phone_no'] = custom_phone_no
        else:            
            all_sessions['phone_no'] = main_file_name
        all_sessions['start_date_time_temp'] = all_sessions['start_date_time']
        for i in range(len(all_sessions) - 1):
            if all_sessions['start_date_time'].iloc[i + 1] - all_sessions['start_date_time'].iloc[i] <= 1:
                all_sessions.at[i + 1, 'start_date_time_temp'] = all_sessions['start_date_time'].iloc[i]
        all_sessions['generated_time'] = all_sessions['start_date_time']
        all_sessions['start_date_time'] = all_sessions['start_date_time_temp']
        all_sessions['apk_ipa_pact'] = all_sessions['apk_ipa_pact'].fillna('')
        all_sessions['pub_temp_ip'] = all_sessions['pub_temp_ip'].fillna('')
        all_sessions['public_ip_port'] = all_sessions['public_ip_port'].fillna(0)
        all_sessions['source_ip'] = all_sessions['source_ip'].fillna('')

        mask = all_sessions['apk_ipa_pact'].str.contains('STUN', case=False)
        all_sessions.loc[mask, 'public_ip_address'] = all_sessions.loc[mask, 'pub_temp_ip'] 
        mask2 = all_sessions['source_ip'].str.contains(':', case=False)
        all_sessions.loc[mask2, 'public_ip_address'] = all_sessions.loc[mask2, 'source_ip']
        all_sessions = all_sessions.sort_values(by=['start_date_time'])
        all_sessions = all_sessions.reset_index(drop=True)

        all_sessions['session_duration'] = all_sessions['end_date_time']-all_sessions['generated_time']
        all_sessions['end_date_time'] = all_sessions['start_date_time']+all_sessions['session_duration']
        all_sessions['session_duration'] = all_sessions['end_date_time']-all_sessions['start_date_time']

        first_occurrences = all_sessions[(all_sessions['apk_ipa_pact'].str.contains('STUN')) & (all_sessions['pub_temp_ip'] != all_sessions['destination_ip']) & (all_sessions['pub_temp_ip'] != '') & (all_sessions['pub_temp_ip'] != 'nan')  & (all_sessions['pub_temp_ip'] != 'nan') & (~all_sessions['source_ip'].str.contains(':'))].index
        for ii,idx in enumerate(first_occurrences):
            start_val = all_sessions.at[idx, 'pub_temp_ip']
            public_ip_port = all_sessions.at[idx, 'public_ip_port']
            end_idx = all_sessions.index[-1] if idx == first_occurrences[-1] else first_occurrences[first_occurrences.get_loc(idx) + 1]
            if ii==0:
                all_sessions.loc[0:idx, 'public_ip_address'] = start_val    
                all_sessions.loc[0:idx, 'public_ip_port'] = public_ip_port    
            all_sessions.loc[idx:end_idx, 'public_ip_address'] = start_val
            all_sessions.loc[idx:end_idx, 'public_ip_port'] = public_ip_port
        unique_public_ip_address = all_sessions['public_ip_address'].unique()
        unique_public_ip_address = unique_public_ip_address[unique_public_ip_address != ""]
        if len(unique_public_ip_address)==0:
            if custom_public_ip_address!='':
                all_sessions['public_ip_address']= custom_public_ip_address
                all_sessions['public_ip_port']= all_sessions['source_port']
            else:
                all_sessions['public_ip_address']= all_sessions['source_ip']
                all_sessions['public_ip_port']= all_sessions['source_port']
        all_sessions.to_csv(csv_file_path,index=False)
        os.chdir(CURR_WORK_DIR)
        return csv_file_path

file_counters = 0

def is_valid_latitude(latitude):
    return -90 <= latitude <= 90
def is_valid_longitude(longitude):
    return -180 <= longitude <= 180
def are_valid_coordinates(latitude,longitude):
    if latitude!="" and longitude !="":
        try:
            result =  is_valid_latitude(float(latitude)) and is_valid_longitude(float(longitude))
        except:
            result =  False
    else:
        result = False
    return result

def check_case_stop_status(case_id):
    need_stop = False
    IPDR_CONN = ipdr_conn()
    cursor_ipdr = IPDR_CONN.cursor()      
    sql = "SELECT COUNT(*) from case_details WHERE case_id=%s and case_status = 3" % (case_id)
    cursor_ipdr.execute(sql)
    row_count = cursor_ipdr.fetchone()
    if row_count:
        row_count = row_count[0]
        if row_count != 0:
            need_stop = True
    IPDR_CONN.close()
    return need_stop

def meeting_point_essentials(df):
    required_columns = ['case_id','cell_id','phone_no','b_party','start_date_time','end_date_time','tower_lat_long','tower_location']
    mpt_df = df[required_columns].copy()
    combined_values = mpt_df.astype(str).agg(''.join, axis=1)
    mpt_df['meeting_essential_hash'] = combined_values.apply(lambda x: hashlib.sha256(x.encode()).hexdigest())
    try:
        meeting_point_solr.add(mpt_df.to_dict('records'))
        meeting_point_solr.commit()
    except Exception as e:
        print(f"[!] Error inserting data into Solr: {e}")


def ipdr_worker(s,asset_dir_list):
    try:
        needs_stop  = check_case_stop_status(s['case_id'])
        if needs_stop:
            update_stopped(s['file_id'])
        else:
            try:        
                print('processing starting on ',s['file_name'])
                asset_dir = asset_dir_list[s['file_id'] % len(asset_dir_list)]
                last_index = 1
                category = s['source_type']
                IPDR_CONN = ipdr_conn()
                # VOIP_PORTS = open(os.path.join(asset_dir,"clear.txt"),"r").read().splitlines()      
                # license_data = open(os.path.join(asset_dir,"vpn_address.txt"),"r").readlines()

                TOR_ALL_INFO = ''
                ISP_DATA = ''
                CITY_DATA = ''
                COUNTRY_DATA = ''
                ORG_DATA = ''
                # TOWER_CONN = None
                if s['extension'] == 'html':
                    s['source_path'] = html_to_csv(s['source_path']) 
                if s['extension'] == 'pcap' or s['extension'] == 'pcapng' or s['extension'] == 'gprsdata':
                    s['source_path'] = pcap_to_csv(s['file_id'],s['source_type'],s['source_path'],s['extension'],s['merger_path'],s['pact_path'],CURR_WORK_DIR,s['phone_no'],s['public_ip_address'],s['dc_path'],s['file_hash'])
                # is_empty=0        
                if s['mapper_name']!='':
                    mapper_name = s['mapper_name']            
                    header_pos = s['header_position']
                    header_len  = s['header_length']
                    date_format = s['date_format']
                    # mapper_country_name = s['mapper_country_name']
                    mapper_dict_with_raw = s['mapper_dict_with_raw']
                    mapper_dict_with_raw = json.loads(mapper_dict_with_raw.replace("'",'"'))                    

                if s['extension'] not in ['pcap','pcapng','gprsdata']:
                    update_progress(s['file_id'])
                chunksize = s['total_row_count']
                if s['extension'] in ['csv', 'txt']:
                    dfs = pd.read_csv(s['source_path'], chunksize = chunksize, usecols=range(header_len),lineterminator='\n',on_bad_lines='skip', memory_map=True,skiprows=header_pos-1)
                    unique_destination_ip_address=(pd.read_csv(s['source_path'] , usecols=[mapper_dict_with_raw['destination_ip_address']], lineterminator='\n',on_bad_lines='skip', memory_map=True,skiprows=header_pos-1).dropna())[mapper_dict_with_raw['destination_ip_address']].unique()
                    reader = maxminddb.open_database(os.path.join(asset_dir,'chexfile'))
                    reader_vpn = maxminddb.open_database(os.path.join(asset_dir,'phexfile'))
                    app_reader = maxminddb.open_database(os.path.join(asset_dir,'ahexfile'))
                    ip_to_dict_session = requests.Session()                    
                    ip_to_dict_mapping_dict_destination = {val: ip_to_dict(val,ip_to_dict_session,reader,reader_vpn,app_reader) for val in unique_destination_ip_address}
                elif s['extension'] in ['pcap','pcapng','gprsdata']:
                    dfs = pd.read_csv(s['source_path'], chunksize = chunksize, usecols=range(header_len),lineterminator='\n',on_bad_lines='skip', memory_map=True,skiprows=header_pos-1)
                    unique_destination_ip_address=(pd.read_csv(s['source_path'] , usecols=[mapper_dict_with_raw['destination_ip_address']], lineterminator='\n',on_bad_lines='skip', memory_map=True,skiprows=header_pos-1).dropna())[mapper_dict_with_raw['destination_ip_address']].unique()
                    reader = maxminddb.open_database(os.path.join(asset_dir,'chexfile'))
                    reader_vpn = maxminddb.open_database(os.path.join(asset_dir,'phexfile'))
                    app_reader = maxminddb.open_database(os.path.join(asset_dir,'ahexfile'))
                    ip_to_dict_session = requests.Session()                    
                    ip_to_dict_mapping_dict_destination = {val: ip_to_dict(val,ip_to_dict_session,reader,reader_vpn,app_reader) for val in unique_destination_ip_address}
                elif s['extension'] in ['xls', 'xlsx','xlsb']:
                    dfs = pd.read_excel(s['source_path'],  usecols=range(header_len), skiprows=header_pos,sheet_name=0, engine='xlrd' if s['extension']=='xls' else 'openpyxl')
                    unique_destination_ip_address=df[mapper_dict_with_raw['destination_ip_address']].dropna().unique()
                    reader = maxminddb.open_database(os.path.join(asset_dir,'chexfile'))
                    reader_vpn = maxminddb.open_database(os.path.join(asset_dir,'phexfile'))
                    app_reader = maxminddb.open_database(os.path.join(asset_dir,'ahexfile'))
                    ip_to_dict_session = requests.Session()                    
                    ip_to_dict_mapping_dict_destination = {val: ip_to_dict(val,ip_to_dict_session,reader,reader_vpn,app_reader) for val in unique_destination_ip_address}
                    dfs = split_dataframe(df, chunk_size=chunksize)                     
                elif s['extension'] in ['html']:
                    dfs = pd.read_csv(s['source_path'], chunksize = chunksize, sep = '|', usecols=range(header_len),lineterminator='\n',on_bad_lines='skip', memory_map=True)
                    unique_destination_ip_address=(pd.read_csv(s['source_path'] , usecols=[mapper_dict_with_raw['destination_ip_address']],lineterminator='\n',on_bad_lines='skip', memory_map=True,skiprows=header_pos-1).dropna())[mapper_dict_with_raw['destination_ip_address']].unique()
                    reader = maxminddb.open_database(os.path.join(asset_dir,'chexfile'))
                    reader_vpn = maxminddb.open_database(os.path.join(asset_dir,'phexfile'))
                    app_reader = maxminddb.open_database(os.path.join(asset_dir,'ahexfile'))
                    ip_to_dict_session = requests.Session()                    
                    ip_to_dict_mapping_dict_destination = {val: ip_to_dict(val,ip_to_dict_session,reader,reader_vpn,app_reader) for val in unique_destination_ip_address}
                else:
                    print('Format not available')
                    
                final_index = -1
                dfs, len_df = tee(dfs)
                final_index = len(list(len_df))-1
                if final_index!=-1:
                    index=-1
                    for df in dfs:
                        needs_stop  = check_case_stop_status(s['case_id'])
                        if needs_stop:
                            update_stopped(s['file_id'])
                        else:
                            if len(df)!=0:
                                panda_s_time = time.time()
                                index = index+1
                                if index == final_index:
                                    last_index = 1
                                else:
                                    last_index = 0
                                df.reset_index(drop=True, inplace=True)
                                def remove_unwanted_chars(value):
                                    if isinstance(value, str):
                                            return value.strip().replace('="', '').replace('"', '').replace("'", '').replace(',', ' ').replace('~~~', ',').replace('=', '')
                                    return value
                                df = df.applymap(remove_unwanted_chars)
                                df = df.rename(columns={col: col.strip() for col in df.columns})
                                df.fillna(0, inplace=True)
                                df.columns = df.columns.str.upper()
                                result_df = pd.DataFrame()
                                for column in mapper_dict_with_raw.values():
                                        column = column.upper().strip()
                                        if '#####' not in column:
                                            key_result = next((key for key, value in mapper_dict_with_raw.items() if value.upper().strip() == column), None)
                                            result_df[key_result] = df[column]
                                        elif '#####' in column:
                                            base_column, extra_column = column.split('#####')
                                            base_column, extra_column = base_column.strip(), extra_column.strip()
                                            key_result = next((key for key, value in mapper_dict_with_raw.items() if value.upper().strip() == column), None)
                                            if key_result:
                                                result_df[key_result] = df[base_column].astype(str) + ' ' + df[extra_column].astype(str)
                                df = result_df
                                if s['extension'] not in ['pcap','pcapng','gprsdata']:
                                    df = df.loc[(df['phone_no'] != '') & (df['imsi_no'] != 0) & (df['destination_ip_address'] != '') & (df['public_ip_address'] != '')]
                                df.fillna('', inplace=True)
                                if len(df)!=0:
                                    df_columns_present_list = ['phone_no','imei_no','imsi_no','downlink_vol','uplink_vol','start_date_time','end_date_time','connection_type','roaming_circle','roaming_circle_type','icr_operator_name','home_circle','public_ip_address','public_ipv6_address','public_ip_port','destination_ip_address','destination_port','source_ip_address','source_port','session_duration','charging_id','access_point_name','pgw_ip_address','pgw_ip_ggsn_address','network_type','cell_id','ipdr_id','case_id','file_id','session_hash','ip_address_allocation','user_id_iaa','generated_time','tower_site_name','tower_pincode','tower_address','tower_latitude','tower_longitude','ip_lat','ip_long','ip_city','ip_country','protocol_name','application_name','tor_all_info','service_provider_detail','operator_name','is_voip','is_chat','is_tor_main_node','is_tor_exit_node','is_vpn','ipv6_lat','ipv6_long','ipv6_city','ipv6_country','ipv6_service_provider_detail','ipv6_operator_name','mac_id','pdp_address_ipv4','pdp_address_ipv6','cgi_id','ip_address_allocation_type','date_format','subscriber_name','subscriber_address','subscriber_alternate_no','subscriber_email','apk_ipa_pact','domain_name','media_upload_data','media_download_data','media_upload_download','tls_version','ja3_client','ja3_server','user_agent','flow_info','pub_temp_ip','proto_category','telnet_username','telnet_password','kerberos_domain','kerberos_hostname','kerberos_username','ftp_imap_pop_smtp_username','ftp_imap_pop_smtp_password','ftp_imap_pop_smtp_status','http_url','http_response_status_code','http_request_content_type','http_content_type','http_server','ssh_tls_server_info','ssh_tls_server_names','ssh_tls_tls_issuerDN','ssh_tls_tls_subjectDN','ssh_tls_encrypted_sni_esni','tls_browser','bittorent_hash','dhcp_fingerprint','human_readeable_string','hosted_domain_name']
                                    df = df.reindex(columns=df_columns_present_list, fill_value='')
                                    df['phone_no'] = df['phone_no'].astype(str).apply(lambda x: '' if not x else (x.split('.')[0] if (isinstance(x, str) and len(x.split('.')) == 2)  else str(x)))      
                                    df['destination_port'] = pd.to_numeric(df['destination_port'], errors='coerce').fillna(0).astype(int)
                                    df['imei_no'] = df['imei_no'].astype(str)
                                    df['imsi_no'] = df['imsi_no'].astype(str)
                                    if s['extension'] not in ['pcap','pcapng','gprsdata']:
                                        df['domain_name'] = df['hosted_domain_name']
                                            
                                        unique_destination_port = df['destination_port'].unique()
                                        destination_port_mapping = {val: process_protocol(int(val)) for val in unique_destination_port}
                                        df['protocol_name'] = df['destination_port'].map(destination_port_mapping)
                                        if(not mapper_name.startswith("N")):
                                            df = df[~df['imei_no'].apply(lambda x: '\r' in x or '\n' in x or ' ' in x or 'Dynamic' in x)]

                                        unique_start_date_time = df['start_date_time'].astype(str).unique()
                                        unique_end_date_time = df['end_date_time'].astype(str).unique()
                                        start_date_time_mapping = {str(val): process_start_date_time(str(val),str(date_format)) for val in unique_start_date_time}
                                        end_date_time_mapping = {str(val): process_start_date_time(str(val),str(date_format)) for val in unique_end_date_time}

                                        df['start_date_time'] = df['start_date_time'].astype(str).map(start_date_time_mapping)
                                        df['end_date_time'] = df['end_date_time'].astype(str).map(end_date_time_mapping)
                                    else:
                                        df['protocol_name'] = df['apk_ipa_pact']

                                    df['public_ip_port'] = pd.to_numeric(df['public_ip_port'], errors='coerce').fillna(0).astype(int)
                                    df['source_port'] = pd.to_numeric(df['source_port'], errors='coerce').fillna(0).astype(int)
                                    df['imei_no'] = df['imei_no'].apply(lambda x: '' if not x else (x.split('.')[0] if (isinstance(x, str) and len(x.split('.')) == 2)  else str(x)))
                                    df['imsi_no'] = df['imsi_no'].apply(lambda x: '' if not x else (x.split('.')[0] if (isinstance(x, str) and len(x.split('.')) == 2)  else str(x)))
                                        
                                    if(mapper_name.startswith("N")):
                                        df['destination_ip_address'] = df['destination_ip_address'].fillna('')
                                        df['source_ip_address'] = df['source_ip_address'].fillna('')
                                        df['public_ip_address'] = df['public_ip_address'].fillna('')
                                        df.loc[(df['source_ip_address'] == '') & (df['public_ip_address'] == ''), 'public_ip_address'] = df['phone_no'] + '_pub_source_missing'
                                        df.loc[(df['source_ip_address'] != '') & (df['public_ip_address'] == ''), 'public_ip_address'] = df['source_ip_address']
                                        df.loc[(df['source_ip_address'] != '') & ((df['public_ip_port'] == '') | (df['public_ip_port'] == 0)), 'public_ip_port'] = df['source_port']
                                    else:
                                        df['public_ip_address'] = df['public_ip_address'].apply(lambda x: x if x else '')
                                        df['destination_ip_address'] = df['destination_ip_address'].apply(lambda x: x if x else '')
                                        df['source_ip_address'] = df['source_ip_address'].apply(lambda x: x if x else '') 

                                    df['public_ip_port'] = df['public_ip_port'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                    df['source_port'] = df['source_port'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                    df['destination_port'] = df['destination_port'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                    df['application_name'] = df['application_name'].apply(lambda x: x if x else '')
                                    df['is_chat'] = df['is_chat'].apply(lambda x: x if x else '')                                    
                                    df['public_ipv6_address'] = df['public_ipv6_address'].apply(lambda x: x if x else '')
                                    df['downlink_vol'] = df['downlink_vol'].apply(lambda x: 0 if not isinstance(x, int) or not isinstance(x, float) or x in [np.nan, 'nan'] else x)
                                    df['uplink_vol'] = df['uplink_vol'].apply(lambda x: 0 if not isinstance(x, int) or not isinstance(x, float) or x in [np.nan, 'nan'] else x)

                                    df['charging_id'] = df['charging_id'].apply(lambda x: x if x else '')                                    
                                    if(mapper_name.startswith("N")):
                                        df['cell_id'] = df['cell_id'].fillna('')
                                        df['cell_id'] = df['cell_id'].astype(str)
                                    else:
                                        df['cell_id'] = df['cell_id'].apply(process_cellid)
                                        df['cell_id'] = df['cell_id'].astype(str)
                                    df['user_id_iaa'] = df['user_id_iaa'].astype(str)
                                        

                                    df['mapper_name'] = mapper_name
                                    df['case_id'] = s['case_id']
                                    df['file_id'] = s['file_id']
                                        
                                    if isinstance(df['start_date_time'], pd.DataFrame):
                                        df['start_date_time'] =  df['start_date_time'].iloc[-1]
                                    if isinstance(df['end_date_time'], pd.DataFrame):
                                        df['end_date_time'] =  df['end_date_time'].iloc[-1]
                                    df['start_date_time'] = df['start_date_time'].fillna(0)  # replace missing values with 0
                                    df['start_date_time'] = df['start_date_time'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                    df['end_date_time'] = df['end_date_time'].fillna(0)  # replace missing values with 0
                                    df['end_date_time'] = df['end_date_time'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                    df['start_date_time'] = df['start_date_time'].round().astype(int)
                                    df['end_date_time'] = df['end_date_time'].round().astype(int)
                                    df['generated_time'] = df['generated_time'].apply(lambda x: x if x else '')
                                    df['session_duration'] = np.where( (df['end_date_time'].notnull()) & (df['start_date_time'].notnull()), df['end_date_time'].astype(int) - df['start_date_time'].astype(int), 0 )                                
                                    df[['session_hash', 'comb_session_hash5', 'ipdr_id_session_hash']]=process_session_hash(df, category)
                                    remove_duplicate_mask = df.duplicated(subset='ipdr_id_session_hash', keep='first')
                                    df = df[~remove_duplicate_mask]   

                                    df = df[~df['phone_no'].apply(lambda x: '\r' in x or '\n' in x or ' ' in x)]
                                    df = df[df['phone_no'].notna() & (df['phone_no'] != '')]
                                    df = df[~df['destination_ip_address'].apply(lambda x: '\r' in x or '\n' in x or ' ' in x or 'destination' in x or 'Destination' in x)]
                                    df = df[~df['cell_id'].apply(lambda x: '\r' in x or '\n' in x or ' ' in x)] if 'cell_id' in df.columns else df
                                    df = df[~df['imsi_no'].apply(lambda x: '\r' in x or '\n' in x or ' ' in x or 'Dynamic' in x)] if 'imsi_no' in df.columns else df
                                    
                                    df['is_ip_ipdr'] = 0
                                    df['is_ip_ipdr'] = (0 if (df['phone_no'] == df['phone_no'].iloc[0]).all() else (2 if (df['destination_ip_address'] == df['destination_ip_address'].iloc[0]).all() else 1))

                                    unique_cell_id = df['cell_id'].unique()
                                    tower_session = requests.Session()
                                    celld_to_Tower_mapping = {val: tower if (tower := celld_to_Tower(val, tower_session)) is not None else '' for val in unique_cell_id }
                                    tower_mapping_dict = {key: list(value) for key, value in celld_to_Tower_mapping.items()}
                                    
                                    # Assign the mapped values to the DataFrame columns
                                    df[['tower_operator', 'tower_network_type', 'tower_location', 'tower_state', 'tower_town', 'tower_district', 'tower_azimuth', 'tower_pincode', 'tower_latitude', 'tower_longitude','tower_height','tower_lat_long','tower_lat_long_rpt']] = ''
                                    df[['tower_operator', 'tower_network_type', 'tower_location', 'tower_state', 'tower_town', 'tower_district', 'tower_azimuth', 'tower_pincode', 'tower_latitude', 'tower_longitude','tower_height','tower_lat_long','tower_lat_long_rpt']] = [ tower_mapping_dict.get(cell_id, ['', '', '', '', '', '', '', '', '', '', '', '','']) for cell_id in df['cell_id']]
                                    
                                    df['tower_location'] = df['tower_location'].replace('',"Latest tower information does not exist in our database")
                                    df['tower_location'] = df['tower_location'].fillna("Latest tower information does not exist in our database")

                                    ip_to_dict_time = time.time()
                                    df.drop(columns=['hosted_domain_name','company_name','company_domain','company_type','company_asn','vpn_hosting','vpn_proxy','vpn_tor','is_vpn','vpn_is_relay','vpn_name','app_name','app_category','app_logo','app_source_country','app_domain','ip_city','ip_country','ip_lat','ip_long','service_provider_detail','ip_state_name','ip_district_name','ip_continent_name','ip_connection_type','ip_lat_long','app_ip_type','tor_name','tor_onion_port','tor_directory_port','tor_flags','tor_uptime','tor_version','tor_email','is_tor_detected'],inplace=True,errors='ignore')
                                    mapping_df = pd.DataFrame.from_dict(ip_to_dict_mapping_dict_destination, orient='index',columns=['hosted_domain_name','company_name','company_domain','company_type','company_asn','vpn_hosting','vpn_proxy','vpn_tor','is_vpn','vpn_is_relay','vpn_name','app_name','app_category','app_logo','app_source_country','app_domain','ip_city','ip_country','ip_lat','ip_long','service_provider_detail','ip_state_name','ip_district_name','ip_continent_name','ip_connection_type','ip_lat_long','app_ip_type','tor_name','tor_onion_port','tor_directory_port','tor_flags','tor_uptime','tor_version','tor_email','is_tor_detected'])
                                    mapping_df.reset_index(inplace=True)
                                    mapping_df.rename(columns={'index': 'destination_ip_address'}, inplace=True)
                                    df = df.merge(mapping_df, on='destination_ip_address', how='left')

                                    df.fillna('', inplace=True)
                                    df['public_ip_address'] = df['public_ip_address'].astype(str)
                                    unique_public_ip_address = df['public_ip_address'].unique()
                                    ip_to_dict_mapping_dict = {val: ip_to_dict(val,ip_to_dict_session,reader,reader_vpn,app_reader) for val in unique_public_ip_address}
                                       
                                    df[['hosted_domain_name_public','company_name_public','company_domain_public','company_type_public','company_asn_public','vpn_hosting_public','vpn_proxy_public','vpn_tor_public','is_vpn_public','vpn_is_relay_public','vpn_name_public','app_name_public','app_category_public','app_logo_public','app_source_country_public','app_domain_public','ip_city_public','ip_country_public','ip_lat_public','ip_long_public','service_provider_detail_public','ip_state_name_public','ip_district_name_public','ip_continent_name_public','ip_connection_type_public','public_ip_lat_long','app_ip_type_public','tor_name','tor_onion_port','tor_directory_port','tor_flags','tor_uptime','tor_version','tor_email','is_tor_detected_public']] = ''
                                    df[['hosted_domain_name_public','company_name_public','company_domain_public','company_type_public','company_asn_public','vpn_hosting_public','vpn_proxy_public','vpn_tor_public','is_vpn_public','vpn_is_relay_public','vpn_name_public','app_name_public','app_category_public','app_logo_public','app_source_country_public','app_domain_public','ip_city_public','ip_country_public','ip_lat_public','ip_long_public','service_provider_detail_public','ip_state_name_public','ip_district_name_public','ip_continent_name_public','ip_connection_type_public','public_ip_lat_long','app_ip_type_public','tor_name','tor_onion_port','tor_directory_port','tor_flags','tor_uptime','tor_version','tor_email','is_tor_detected_public']] = [
                                        ip_to_dict_mapping_dict.get(unique_public_ip_address, ['','','','','','','','','','','','','','','','','','','','','','','','','','',''])
                                        for unique_public_ip_address in df['public_ip_address']
                                    ]

                                    print("ip to dict time",str(s['file_id']),time.time()-ip_to_dict_time)

                                    unique_imei_no_list = df['imei_no'].unique()
                                    unique_imei_no_list = unique_imei_no_list[unique_imei_no_list != ""]
                                    df[['phone_name','phone_model','phone_brand','is_basic']] = ''
                                    if len(unique_imei_no_list)!=0:
                                        tac_session = requests.Session()
                                        tac_mapping = {val: imei_to_tac(val,tac_session) for val in unique_imei_no_list}
                                        tac_mapping_dict = {key: list(value) for key, value in tac_mapping.items()}
                                        df[['phone_name','phone_model','phone_brand','is_basic']] = [
                                            tac_mapping_dict.get(imei_no, ['','','',''])
                                            for imei_no in df['imei_no']
                                        ]

                                    df['user_agent'] = df['user_agent'].astype(str).replace('0.',"").replace('0',"")
                                    unique_user_agent = df['user_agent'].unique()
                                    unique_user_agent = unique_user_agent[unique_user_agent != ""]
                                        
                                    if len(unique_user_agent)!=0:
                                        user_agent_mapping = {val: get_device_info(val) for val in unique_user_agent}
                                        df['user_agent'] = [user_agent_mapping.get(user_agent, '') for user_agent in df['user_agent']]
                                    else:
                                        df['user_agent'] = 'UNKNOWN'

                                    df['voip_call_status'] = '0'
                                    df['voip_call_platform_name'] = ''
                                    df['voip_call_b_party_status'] = 'no'
                                    df['voip_call_type'] = ''
                                    df['b_party_table_status'] = 'no'
                                    df['voip_call_session_hash'] = ''
                                    df['voip_call_index'] ='-1'
                                    df['t_detection']  = 'no'                                
                                    df['cell_id_start_date_time'] =''
                                    df['cell_id_end_date_time'] = ''
                                    df['tower_movements_index'] = '-1'
                                    df = df.sort_values(by=['phone_no', 'start_date_time'], ascending=[True, True])
                                    df['a_party'] = df['phone_no']
                                    df['b_party'] = df['phone_no']
                                    voip_call_time = time.time()
                                    df  = voip_call_analysis(df,s['extension'],category)
                                    df = df.reset_index()
                                    df['apk_ipa_index'] = df.groupby(['phone_no', 'app_name']).cumcount()
                                    df['apk_ipa_total_uplink'] = df.groupby(['phone_no', 'app_name'])['uplink_vol'].transform('sum')
                                    df['apk_ipa_total_downlink'] = df.groupby(['phone_no', 'app_name'])['downlink_vol'].transform('sum')
                                    df['apk_ipa_total_duration'] = df.groupby(['phone_no', 'app_name'])['session_duration'].transform('sum')
                                    print("voip_call timing", time.time()-voip_call_time)
                                        
                                    df = df.applymap(remove_unwanted_chars)
                                    df['date'] = pd.to_datetime(df['start_date_time'], unit='s')
                                    df['date'] = df['date'].apply(lambda x: x.strftime('%d-%m-%Y'))
                                    df['start_date_time'] = df['start_date_time'].apply(lambda x: 0 if x<0 else x)
                                    df['end_date_time'] = df['end_date_time'].apply(lambda x: 0 if x<0 else x)

                                    df['time_of_day'] = df['start_date_time'].apply(lambda x: datetime.datetime.fromtimestamp(x, tz=pytz.timezone('Asia/Kolkata')))
                                    df['time_of_day'] = df['time_of_day'].dt.time
                                    night_start = pd.to_datetime('00:00:00').time()
                                    morning_start = pd.to_datetime('06:00:00').time()
                                    afternoon_start = pd.to_datetime('12:00:00').time()
                                    evening_start = pd.to_datetime('18:00:00').time()
                                    office_hours_start = pd.to_datetime('10:00:00').time()
                                    office_hours_end = pd.to_datetime('19:00:00').time()
                                    df['time_shift'] = df['time_of_day'].apply(lambda x: 
                                        'NIGHT' if night_start <= x < morning_start else
                                        'MORNING' if morning_start <= x < afternoon_start else
                                        'AFTERNOON' if afternoon_start <= x < evening_start else
                                        'EVENING'
                                    )
                                    df['office_hours'] = df['time_of_day'].apply(lambda x: 'YES' if office_hours_start <= x <= office_hours_end else 'NO')

                                    df = df[['ipdr_id_session_hash','case_id','file_id','phone_no', 'date','source_ip_address','source_port','public_ip_address','public_ip_port','destination_ip_address','destination_port','start_date_time','end_date_time','ip_address_allocation','user_id_iaa','imei_no','imsi_no','pgw_ip_address','access_point_name','cell_id','generated_time','roaming_circle_type','roaming_circle','protocol_name','session_duration','application_name','is_chat','downlink_vol','uplink_vol','connection_type','home_circle','network_type','icr_operator_name','charging_id','pgw_ip_ggsn_address','public_ipv6_address','mac_id','pdp_address_ipv4','pdp_address_ipv6','ip_address_allocation_type','mapper_name','is_ip_ipdr','voip_call_session_hash','subscriber_name','subscriber_address','subscriber_alternate_no','subscriber_email','hosted_domain_name','tower_operator','tower_network_type','tower_location','tower_state','tower_town','tower_district','tower_azimuth','tower_height','tower_pincode','tower_latitude','tower_longitude','company_name','company_domain','company_type','company_asn','vpn_hosting','vpn_proxy','vpn_tor','is_vpn','vpn_is_relay','vpn_name','app_name','app_category','app_logo','app_source_country','app_ip_type','app_domain','ip_city','ip_country','ip_lat','ip_long','voip_call_status','voip_call_platform_name','voip_call_b_party_status','voip_call_type','b_party_table_status','voip_call_index','service_provider_detail','cell_id_start_date_time','cell_id_end_date_time','tower_movements_index','ip_state_name','ip_district_name','ip_continent_name','ip_connection_type','apk_ipa_index','apk_ipa_total_uplink','apk_ipa_total_downlink','apk_ipa_total_duration','t_detection','media_upload_data','media_download_data','media_upload_download','tls_version','ja3_client','ja3_server','user_agent','flow_info','pub_temp_ip','a_party','b_party','proto_category','telnet_username','telnet_password','kerberos_domain','kerberos_hostname','kerberos_username','ftp_imap_pop_smtp_username','ftp_imap_pop_smtp_password','ftp_imap_pop_smtp_status','http_url','http_response_status_code','http_request_content_type','http_content_type','http_server','ssh_tls_server_info','ssh_tls_server_names','ssh_tls_tls_issuerDN','ssh_tls_tls_subjectDN','ssh_tls_encrypted_sni_esni','tls_browser','bittorent_hash','dhcp_fingerprint','human_readeable_string','ip_lat_long','public_ip_lat_long','tower_lat_long','hosted_domain_name_public','company_name_public','company_domain_public','company_type_public','company_asn_public','vpn_hosting_public','vpn_proxy_public','vpn_tor_public','is_vpn_public','vpn_is_relay_public','vpn_name_public','app_name_public','app_category_public','app_logo_public','app_source_country_public','app_ip_type_public','app_domain_public','ip_city_public','ip_country_public','ip_lat_public','ip_long_public','service_provider_detail_public','ip_state_name_public','ip_district_name_public','ip_continent_name_public','ip_connection_type_public','time_of_day','time_shift','office_hours','tor_name','tor_onion_port','tor_directory_port','tor_flags','tor_uptime','tor_version','tor_email','is_tor_detected','phone_name','phone_model','phone_brand','tower_lat_long_rpt','is_basic']]

                                        
                                    active_inactive_df = pd.DataFrame(columns=['case_id', 'phone_no', 'off_imei_no', 'off_imsi_no', 'off_tower_location', 'off_cell_id', 'off_time', 'on_imei_no', 'on_imsi_no', 'on_tower_location', 'on_cell_id', 'on_time','is_phone_changed','on_tower_lat','on_tower_long','on_tower_district','on_tower_state','off_tower_lat','off_tower_long','off_tower_district','off_tower_state','on_time_shift','off_time_shift','vaccume_duration'])
                                    for idx, active_inactive_group in df.groupby(['case_id', 'phone_no']):
                                        active_inactive_group['on_time'] = active_inactive_group['start_date_time'].shift(-1)
                                        active_inactive_group['on_imei_no'] = active_inactive_group['imei_no'].shift(-1)
                                        active_inactive_group['on_imsi_no'] = active_inactive_group['imsi_no'].shift(-1)
                                        active_inactive_group['on_tower_location'] = active_inactive_group['tower_location'].shift(-1)
                                        active_inactive_group['on_tower_lat'] = active_inactive_group['tower_latitude'].shift(-1)
                                        active_inactive_group['on_tower_long'] = active_inactive_group['tower_longitude'].shift(-1)
                                        active_inactive_group['on_tower_district'] = active_inactive_group['tower_district'].shift(-1)
                                        active_inactive_group['on_tower_state'] = active_inactive_group['tower_state'].shift(-1)
                                        active_inactive_group['on_cell_id'] = active_inactive_group['cell_id'].shift(-1)
                                        active_inactive_group['on_time_shift'] = active_inactive_group['time_shift'].shift(-1)

                                        active_inactive_group = active_inactive_group.dropna(how='any')
                                        active_inactive_group = active_inactive_group.sort_values(by=['start_date_time','end_date_time'])

                                        active_inactive_boolean_index = ((df['end_date_time'] != df['start_date_time'].shift(-1)) & (df['start_date_time'] != df['start_date_time'].shift(-1)))
                                            
                                        active_inactive_extracted_rows = active_inactive_group.loc[active_inactive_boolean_index, ['case_id','phone_no','end_date_time', 'imei_no', 'imsi_no', 'tower_location', 'tower_latitude', 'tower_longitude', 'tower_district', 'time_shift','tower_state', 'cell_id','on_time','on_imei_no','on_imsi_no','on_tower_location','on_cell_id','on_tower_lat','on_tower_long','on_tower_district','on_tower_state','on_time_shift']].rename(columns={'end_date_time': 'off_time', 'imei_no': 'off_imei_no', 'imsi_no': 'off_imsi_no', 'cell_id': 'off_cell_id', 'tower_location': 'off_tower_location', 'tower_latitude': 'off_tower_lat', 'tower_longitude': 'off_tower_long', 'tower_district': 'off_tower_district','tower_state':'off_tower_state','time_shift':'off_time_shift'}).reset_index(drop=True)
                                        active_inactive_extracted_rows['on_time'] = active_inactive_extracted_rows['on_time'].round().astype(int)
                                        active_inactive_extracted_rows['vaccume_duration'] = active_inactive_extracted_rows['on_time'].round().astype(int) - active_inactive_extracted_rows['off_time'].round().astype(int)
                                        active_inactive_extracted_rows['is_phone_changed'] = ~(active_inactive_extracted_rows['off_imei_no'] == active_inactive_extracted_rows['on_imei_no'])
                                        active_inactive_extracted_rows = active_inactive_extracted_rows.astype({'is_phone_changed': int})

                                        active_inactive_df = pd.concat([active_inactive_df, active_inactive_extracted_rows])

                                    active_inactive_df = active_inactive_df.reset_index(drop=True)
                                    if len(active_inactive_df)!=0:
                                        active_inactive_df['active_inactive_period_id'] = calculate_hash(active_inactive_df)
                                        active_inactive_period_solr.add(active_inactive_df.to_dict('records'))
                                        active_inactive_period_solr.commit()

                                    # Processing meeting point data
                                    meeting_point_essentials(df)

                                    all_unique_time = time.time()
                                    unique_phone_no = df.loc[(df['is_ip_ipdr'] != 2) & (df['phone_no'] != ""), 'phone_no'].unique()
                                    unique_imei_no = df.loc[df['imei_no'] != "", 'imei_no'].unique()
                                    unique_imsi_no = df.loc[df['imsi_no'] != "", 'imsi_no'].unique()
                                    unique_pincode = df.loc[df['tower_pincode'] != "", 'tower_pincode'].unique()
                                    unique_tower_lat_long = df.loc[df['tower_lat_long'] != "", 'tower_lat_long'].unique()
                                    unique_public_ip_address = df.loc[df['public_ip_address'] != "", 'public_ip_address'].unique()
                                    unique_source_ip_address = df.loc[df['source_ip_address'] != "", 'source_ip_address'].unique()
                                    unique_destination_ip_address = df.loc[df['destination_ip_address'] != "", 'destination_ip_address'].unique()
                                    unique_cell_id = unique_cell_id[unique_cell_id != ""]
                                    unique_vpn_name = df.loc[df['vpn_name'] != "", 'vpn_name'].unique()
                                    unique_app_name = df.loc[df['app_name'] != "", 'app_name'].str.upper().unique()
                                    case_id = str(s['case_id'])
                                        
                                    # Phone Numbers
                                    if unique_phone_no.size > 0:
                                        phone_no_df = pd.DataFrame({'phone_no': unique_phone_no, 'case_id': case_id})
                                        phone_no_df['phone_no_hash'] = compute_hash(phone_no_df['phone_no'], case_id)
                                        phone_no_solr.add(phone_no_df.to_dict('records'))
                                        phone_no_solr.commit()
                                        a_party_solr_ipdr.add(phone_no_df.to_dict('records'))
                                        a_party_solr_ipdr.commit()

                                    # IMEI Numbers
                                    if unique_imei_no.size > 0:
                                        imei_no_df = pd.DataFrame({'imei_no': unique_imei_no, 'case_id': case_id})
                                        imei_no_df['imei_no_hash'] = compute_hash(imei_no_df['imei_no'], case_id)
                                        imei_solr.add(imei_no_df.to_dict('records'))
                                        imei_solr.commit()

                                    # IMSI Numbers
                                    if unique_imsi_no.size > 0:
                                        imsi_no_df = pd.DataFrame({'imsi_no': unique_imsi_no, 'case_id': case_id})
                                        imsi_no_df['imsi_no_hash'] = compute_hash(imsi_no_df['imsi_no'], case_id)
                                        imsi_solr.add(imsi_no_df.to_dict('records'))
                                        imsi_solr.commit()

                                    # Tower Pincodes
                                    if unique_pincode.size > 0:
                                        pincode_df = pd.DataFrame({'tower_pincode': unique_pincode, 'case_id': case_id})
                                        pincode_df['tower_pincode_hash'] = compute_hash(pincode_df['tower_pincode'], case_id)
                                        tower_pincode_solr.add(pincode_df.to_dict('records'))
                                        tower_pincode_solr.commit()

                                    # Tower Latitude/Longitude
                                    if unique_tower_lat_long.size > 0:
                                        lat_long_df = pd.DataFrame({'tower_lat_long': unique_tower_lat_long, 'case_id': case_id})
                                        lat_long_df['tower_lat_long_hash'] = compute_hash(lat_long_df['tower_lat_long'], case_id)
                                        tower_lat_long_solr.add(lat_long_df.to_dict('records'))
                                        tower_lat_long_solr.commit()

                                    destination_filtered_df = df[df['is_ip_ipdr'] == 0]
                                    unique_destination_ip_phone_no = destination_filtered_df.drop_duplicates(subset=['destination_ip_address', 'phone_no','case_id'], keep='first')
                                    if len(unique_destination_ip_phone_no)!=0:
                                        unique_destination_ip_phone_no = unique_destination_ip_phone_no[['destination_ip_address', 'phone_no','case_id']]
                                        unique_destination_ip_phone_no['destination_ip_phone_no_hash'] =  unique_destination_ip_phone_no.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.destination_ip_address), str(x.phone_no), str(x.case_id)).encode()).hexdigest(), axis=1)
                                        destination_ip_phone_no_solr.add(unique_destination_ip_phone_no.to_dict('records'))
                                        destination_ip_phone_no_solr.commit()

                                    unique_apkipa_phone_no = df.drop_duplicates(subset=['app_name', 'phone_no','case_id'], keep='first')
                                    if len(unique_apkipa_phone_no)!=0:
                                        unique_apkipa_phone_no = unique_apkipa_phone_no[['app_name', 'phone_no','case_id']]
                                        unique_apkipa_phone_no['app_name'] = unique_apkipa_phone_no['app_name'].str.upper()
                                        unique_apkipa_phone_no['apkipa_phone_no_hash'] =  unique_apkipa_phone_no.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.app_name), str(x.phone_no), str(x.case_id)).encode()).hexdigest(), axis=1)
                                        apkipa_phone_no_solr.add(unique_apkipa_phone_no.to_dict('records'))
                                        apkipa_phone_no_solr.commit()


                                    unique_phone_no_imei = df[['phone_no','imei_no','case_id']]
                                    unique_phone_no_imei = unique_phone_no_imei[((unique_phone_no_imei['phone_no']!='0') & (unique_phone_no_imei['phone_no']!=''))]
                                    unique_phone_no_imei = unique_phone_no_imei[(unique_phone_no_imei['imei_no']!='')]
                                        
                                    if len(unique_phone_no_imei)!=0:
                                        unique_phone_no_imei['phone_no_imei_no_hash'] =  unique_phone_no_imei.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.phone_no), str(x.imei_no), str(x.case_id)).encode()).hexdigest(), axis=1)
                                        remove_duplicate_phone_no_imei_no = unique_phone_no_imei.duplicated(subset='phone_no_imei_no_hash', keep='first')
                                        unique_phone_no_imei = unique_phone_no_imei[~remove_duplicate_phone_no_imei_no]
                                            
                                        phone_no_imei_no_solr.add(unique_phone_no_imei.to_dict('records'))
                                        phone_no_imei_no_solr.commit()

                                    unique_phone_no_cell_id = df[['phone_no','cell_id','tower_lat_long','case_id']]
                                    unique_phone_no_cell_id = unique_phone_no_cell_id.rename(columns={'tower_lat_long':'lat_long'})
                                    unique_phone_no_cell_id = unique_phone_no_cell_id[((unique_phone_no_cell_id['phone_no']!='0') & (unique_phone_no_cell_id['phone_no']!=''))]
                                    unique_phone_no_cell_id = unique_phone_no_cell_id[(unique_phone_no_cell_id['cell_id']!='')]
                                        
                                    if len(unique_phone_no_cell_id)!=0:
                                        unique_phone_no_cell_id['phone_no_cell_id_hash'] =  unique_phone_no_cell_id.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.phone_no), str(x.cell_id), str(x.lat_long), str(x.case_id)).encode()).hexdigest(), axis=1)
                                        remove_duplicate_phone_no_cell_id = unique_phone_no_cell_id.duplicated(subset='phone_no_cell_id_hash', keep='first')
                                        unique_phone_no_cell_id = unique_phone_no_cell_id[~remove_duplicate_phone_no_cell_id]
                                        phone_no_cell_id_solr.add(unique_phone_no_cell_id.to_dict('records'))
                                        phone_no_cell_id_solr.commit()

                                    # Public IP Address
                                    if unique_public_ip_address.size > 0:
                                        public_ip_df = pd.DataFrame({'public_ip_address': unique_public_ip_address, 'case_id': case_id})
                                        public_ip_df['public_ip_address_hash'] = compute_hash(public_ip_df['public_ip_address'], case_id)
                                        pip_solr.add(public_ip_df.to_dict('records'))
                                        pip_solr.commit()

                                    # Source IP Address
                                    if unique_source_ip_address.size > 0:
                                        source_ip_df = pd.DataFrame({'source_ip_address': unique_source_ip_address, 'case_id': case_id})
                                        source_ip_df['source_ip_address_hash'] = compute_hash(source_ip_df['source_ip_address'], case_id)
                                        sip_solr.add(source_ip_df.to_dict('records'))
                                        sip_solr.commit()

                                    # Destination IP Address
                                    if unique_destination_ip_address.size > 0:
                                        dest_ip_df = pd.DataFrame({'destination_ip_address': unique_destination_ip_address, 'case_id': case_id})
                                        dest_ip_df['destination_ip_address_hash'] = compute_hash(dest_ip_df['destination_ip_address'], case_id)
                                        dip_solr.add(dest_ip_df.to_dict('records'))
                                        dip_solr.commit()

                                    if unique_cell_id.size > 0:
                                        cell_id_df =  pd.DataFrame({'cell_id': unique_cell_id,'case_id':str(s['case_id'])})
                                        cell_id_df['cell_id_hash'] = compute_hash(cell_id_df['cell_id'], case_id)
                                        cell_id_solr.add(cell_id_df.to_dict('records'))
                                        cell_id_solr.commit()

                                    # VPN Name
                                    if unique_vpn_name.size > 0:
                                        vpn_df = pd.DataFrame({'vpn_name': unique_vpn_name, 'case_id': case_id})
                                        vpn_df['vpn_name_hash'] = compute_hash(vpn_df['vpn_name'], case_id)
                                        vpn_name_solr.add(vpn_df.to_dict('records'))
                                        vpn_name_solr.commit()

                                    # App Name
                                    if unique_app_name.size > 0:
                                        app_name_df = pd.DataFrame({'app_name': unique_app_name, 'case_id': case_id})
                                        app_name_df['app_name_hash'] = compute_hash(app_name_df['app_name'], case_id)
                                        apk_ipa_solr.add(app_name_df.to_dict('records'))
                                        apk_ipa_solr.commit()


                                    df['case_id'] = pd.to_numeric(df['case_id'], errors='coerce').fillna(0).astype(int)
                                    df['file_id'] = pd.to_numeric(df['file_id'], errors='coerce').fillna(0).astype(int)
                                    df['source_port'] = pd.to_numeric(df['source_port'], errors='coerce').fillna(0).astype(int)
                                    df['public_ip_port'] = pd.to_numeric(df['public_ip_port'], errors='coerce').fillna(0).astype(int)
                                    df['destination_port'] = pd.to_numeric(df['destination_port'], errors='coerce').fillna(0).astype(int)
                                    df['start_date_time'] = pd.to_numeric(df['start_date_time'], errors='coerce').fillna(0).astype(int)
                                    df['end_date_time'] = pd.to_numeric(df['end_date_time'], errors='coerce').fillna(0).astype(int)
                                    df['session_duration'] = pd.to_numeric(df['session_duration'], errors='coerce').fillna(0).astype(int)
                                    print('all Unique values',f'{time.time() - all_unique_time:.1f} seconds') 
                                    if 'protocol_name' in df.columns:
                                        df['protocol_name']=df['protocol_name'].astype(str).str.upper()
                                    if len(df)!=0:
                                        bulk_timer = time.time()
                                        bulk_file_name =BULKER_DIR+'//'+str(s['case_id'])+'_'+str(s['file_id'])+'_'+str(last_index)+'_'+str(bulk_timer).replace('.','')+'.csv'
                                        df.to_csv(bulk_file_name,sep=',',index= None)
                                        # df.to_csv("ipdr_data_for_test.csv",sep=',',index= None)
                                        print('[',mapper_name,'] File_id=',s['file_id'],'Bulk=',len(df),'Time=',f'{time.time() - panda_s_time:.1f} seconds')
                                else:
                                        update_empty_file(IPDR_CONN,s['file_id'],s['case_id'])
                            else:
                                update_empty_file(IPDR_CONN,s['file_id'],s['case_id'])

                else:
                    update_completion(s['file_id'],s['case_id'])
                del TOR_ALL_INFO, ISP_DATA, CITY_DATA, COUNTRY_DATA, ORG_DATA#VOIP_PORTS,
                IPDR_CONN.close()
                
            except Exception as err:
                logging.error('Worker Error: '+str(traceback.format_exc()))
                update_failed(s['file_id'],s['case_id'])
                pass
    except Exception as err:
            logging.error('checking stop status ipdrworker error: '+str(traceback.format_exc()))
        

def cdr_worker(s,asset_dir_list,sms_df):
    try:
        needs_stop  = check_case_stop_status(s['case_id'])
        if needs_stop:
            update_stopped(s['file_id'])
        else:
            try:
                print('processing starting on cdr file ',s['file_name'])
                asset_dir = asset_dir_list[s['file_id'] % len(asset_dir_list)]
                last_index = 1
                # category = s['source_type']
                IPDR_CONN = ipdr_conn()                
                TOR_ALL_INFO = ''
                ISP_DATA = ''
                CITY_DATA = ''
                COUNTRY_DATA = ''
                ORG_DATA = ''
                # TOWER_CONN = None
                if s['extension'] == 'html':
                    s['source_path'] = html_to_csv(s['source_path']) 
                # is_empty=0
                
                if s['mapper_name']!='':
                    mapper_name = s['mapper_name']            
                    header_pos = s['header_position']
                    header_len  = s['header_length']
                    # date_format = s['date_format']
                    mapper_country_name = s['mapper_country_name']
                    mapper_dict_with_raw = s['mapper_dict_with_raw']
                    mapper_dict_with_raw = json.loads(mapper_dict_with_raw.replace("'",'"'))

                    update_progress(s['file_id'])
                    dfs = []
                    chunksize = s['total_row_count']
                    if s['extension'] in ['csv', 'txt']:
                        dfs = pd.read_csv(s['source_path'], chunksize = chunksize, usecols=range(header_len),lineterminator='\n',on_bad_lines='skip', memory_map=True,skiprows=header_pos-1)
                    elif s['extension'] in ['xls', 'xlsx','xlsb']:
                        dfs = pd.read_excel(s['source_path'],  usecols=range(header_len), skiprows=header_pos,sheet_name=0, engine='xlrd' if s['extension']=='xls' else 'openpyxl')
                        dfs = split_dataframe(dfs, chunk_size=chunksize)
                    elif s['extension'] in ['html']:
                        dfs = pd.read_csv(s['source_path'], chunksize = chunksize, sep = '|', usecols=range(header_len),lineterminator='\n',on_bad_lines='skip', memory_map=True)
                    else:
                        print('Format not available')
                    final_index = -1
                    dfs, len_df = tee(dfs)
                    final_index = len(list(len_df))-1
                    
                    if final_index!=-1:
                        index=-1                        
                        for df in dfs:
                            needs_stop  = check_case_stop_status(s['case_id'])
                            if needs_stop:
                                update_stopped(s['file_id'])
                            else:
                                if len(df)!=0:
                                    panda_s_time = time.time()
                                    index = index+1
                                    if index == final_index:
                                        last_index = 1
                                    else:
                                        last_index = 0
                                    df.reset_index(drop=True, inplace=True)
                                    
                                    def remove_unwanted_chars(value):
                                        if isinstance(value, str):
                                            return value.replace('="', '').replace('"', '').replace("'", '').replace(',', ' ').replace('=', '').replace('\r', '').replace('~~~', ',')
                                        elif isinstance(value, dict):
                                            return {k: remove_unwanted_chars(v) for k, v in value.items()}
                                        return value

                                    df = df.applymap(remove_unwanted_chars)
                                    df = df.rename(columns={col: str(col).strip() for col in df.columns})
                                    df.fillna(0, inplace=True)

                                    try:
                                        next_destination_ports  = [index for index, value in enumerate(df.columns.get_loc('PORT')) if value]
                                    except:
                                        pass
                                    df.columns = df.columns.str.upper()
                                    result_df = pd.DataFrame()

                                    for column in mapper_dict_with_raw.values():
                                        column = column.upper().strip()
                                        if '#####' not in column.upper():
                                            key_result = next((key for key, value in mapper_dict_with_raw.items() if value.upper().strip() == column), None)
                                            key_result = key_result.strip()
                                            if column == 'PORT':
                                                if len(next_destination_ports) >0:
                                                    df.columns.values[int(next_destination_ports[0])] = 'destination_port'
                                                    result_df['destination_port'] =df['destination_port']
                                                    if len(next_destination_ports) >1:
                                                        df.columns.values[int(next_destination_ports[1])] = 'public_ip_port'
                                                        result_df['public_ip_port'] =df['public_ip_port']
                                                else:
                                                    result_df['public_ip_port'] =0
                                                    result_df['destination_port'] =0
                                            else:result_df[key_result] = df[column]
                                        elif '#####' in column.upper():
                                            base_column, extra_column = column.split('#####')
                                            base_column, extra_column = base_column.strip(), extra_column.strip()
                                            key_result = next((key for key, value in mapper_dict_with_raw.items() if value.upper().strip() == column), None)
                                            if key_result:
                                                result_df[key_result] = df[base_column].astype(str) + ' ' + df[extra_column].astype(str)
                                    
                                    df = result_df
                                    df.fillna(0, inplace=True)
                                    

                                    df_columns_present_list = ['phone_no','imei_no','imsi_no','downlink_vol','uplink_vol','start_date_time','end_date_time','connection_type','roaming_circle','roaming_circle_type','icr_operator_name','home_circle','public_ip_address','public_ipv6_address','public_ip_port','destination_ip_address','destination_port','source_ip_address','source_port','session_duration','charging_id','access_point_name','pgw_ip_address','pgw_ip_ggsn_address','network_type','cell_id','ipdr_id','case_id','file_id','session_hash','ip_address_allocation','user_id_iaa','generated_time','tower_site_name','tower_pincode','tower_address','tower_latitude','tower_longitude','ip_lat','ip_long','ip_city','ip_country','protocol_name','application_name','tor_all_info','service_provider_detail','operator_name','is_voip','is_chat','is_tor_main_node','is_tor_exit_node','is_vpn','ipv6_lat','ipv6_long','ipv6_city','ipv6_country','ipv6_service_provider_detail','ipv6_operator_name','mac_id','pdp_address_ipv4','pdp_address_ipv6','cgi_id','ip_address_allocation_type','date_format','subscriber_name','subscriber_address','subscriber_alternate_no','subscriber_email','subscriber_father','bparty_subscriber_name','bparty_subscriber_address','bparty_subscriber_alternate_no','bparty_subscriber_email','bparty_subscriber_father','cdr_calling','cdr_called','cdr_call_forwarding','cdr_lrn_called_no','cdr_duration','second_cell_id','cdr_call_type','cdr_sms_center_number','cdr_connection_type','cdr_sim_activation_date','cdr_port_in_out','cdr_wifi_latitude','cdr_wifi_longitude','cdr_first_bts','cdr_last_bts','cdr_service_type','a_party','b_party','cdr_duration_type']
                                    df = df.reindex(columns=df_columns_present_list, fill_value='')
                                    
                                    df.fillna('', inplace=True)
                                    df['public_ip_address'] = df['public_ip_address'].apply(lambda x: x if x else '')
                                    df['destination_ip_address'] = df['destination_ip_address'].apply(lambda x: x if x else '')
                                    try:
                                        if('MEASURE_UNIT' in df.columns):
                                            df['MEASURE_UNIT'] = df['MEASURE_UNIT'].apply(lambda x: x if x else '')
                                        elif('measure_unit' in df.columns):
                                            df['MEASURE_UNIT'] = df['measure_unit'].apply(lambda x: x if x else '')
                                        else:
                                            df['MEASURE_UNIT'] = ''
                                    except:df['MEASURE_UNIT'] = ''  
                                    df[['cdr_call_type','cdr_service_type','cell_id','second_cell_id','public_ip_address','destination_ip_address']] = df.apply(find_cdr_call_type,axis=1, result_type='expand') 
                                    u_cdr_called = df['cdr_called'].unique()
                                    u_cdr_called = u_cdr_called[u_cdr_called!='']
                                    if 'b_party' in df.columns and 'cell_id' in df.columns:
                                        df= df[(df['b_party'] != 0.0) | (df['cell_id'] != 0.0)]
                                    if(not df.empty):
                                        u_b_party = df['b_party'].unique()
                                        u_b_party = u_b_party[u_b_party!='']
                                        if len(u_b_party) == 0:
                                            incoming_mask = df['cdr_call_type'].str.contains('INCOMING')
                                            df['a_party'] = np.where(incoming_mask, df['cdr_called'], df['cdr_calling'])
                                            df['b_party'] = np.where(incoming_mask, df['cdr_calling'], df['cdr_called'])

                                        def replace_a_party_prefix(a_party, replace_value=''):
                                            a_party = str(a_party)
                                            if a_party.startswith('0') and len(a_party) ==11:
                                                return replace_value + a_party[1:]
                                            if a_party.startswith('091') and len(a_party) ==13:
                                                return replace_value + a_party[3:]
                                            elif a_party.startswith('91') and len(a_party) ==12:
                                                return replace_value + a_party[2:]
                                            elif a_party.startswith('+91') and len(a_party) ==13:
                                                return replace_value + a_party[3:]
                                            elif a_party.startswith('0977') and len(a_party) ==14:
                                                return replace_value + a_party[4:]
                                            elif a_party.startswith('977') and len(a_party) ==13:
                                                return replace_value + a_party[3:]
                                            elif a_party.startswith('+977') and len(a_party) ==14:
                                                return replace_value + a_party[4:]
                                            elif a_party.startswith('+0') and len(a_party) ==12:
                                                return replace_value + a_party[2:]
                                            elif a_party.startswith('+') and len(a_party) ==11:
                                                return replace_value + a_party[1:]    
                                            else:
                                                return a_party 

                                        if mapper_country_name in ['INDIA','NEPAL']:
                                            df['a_party'] = df['a_party'].apply(replace_a_party_prefix)
                                            df['b_party'] = df['b_party'].apply(replace_a_party_prefix)

                                        df['a_party'] = df['a_party'].astype(str)
                                        df['b_party'] = df['b_party'].astype(str)
                                        df['a_party'] = df['a_party'].str.replace(' ', '')
                                        df['b_party'] = df['b_party'].str.replace(' ', '').replace('+','')
                                        df = df[~df['a_party'].str.contains(r'\s')]
                                        df = df[~df['a_party'].str.contains('Disclaimer',case=False)]
                                        df = df[~df['a_party'].str.contains(r'\\r|\\n')]
                                        df['a_party'] = df['a_party'].str.lstrip('0')
                                        df['b_party'] = df['b_party'].str.lstrip('0')
                                        df['phone_no'] = df['a_party']

                                        df['cdr_last_bts'] = df['cdr_last_bts'].apply(lambda x: x if x else 'UNKNOWN')
                                        df['cdr_first_bts'] = df['cdr_first_bts'].apply(lambda x: x if x else 'UNKNOWN')

                                        if 'cdr_wifi_longitude' in df.columns:
                                            df['cdr_wifi_longitude'] = df['cdr_wifi_longitude'].apply(lambda x: x if x else 'UNKNOWN')
                                        else : df['cdr_wifi_longitude'] = ''

                                        if 'cdr_wifi_latitude' in df.columns:
                                            df['cdr_wifi_latitude'] = df['cdr_wifi_latitude'].apply(lambda x: x if x else 'UNKNOWN')
                                        else : df['cdr_wifi_latitude'] = ''

                                        df['cdr_port_in_out'] = df['cdr_port_in_out'].apply(lambda x: x if x else 'UNKNOWN')
                                        df['cdr_sim_activation_date'] = df['cdr_sim_activation_date'].apply(lambda x: x if x else 'UNKNOWN')
                                        df['cdr_connection_type'] = df['cdr_connection_type'].apply(lambda x: x if x else 'UNKNOWN')
                                        df['cdr_sms_center_number'] = df['cdr_sms_center_number'].apply(lambda x: x if(x and x != '') else  'UNKNOWN')                                        
                                        df['cdr_lrn_called_no'] = df['cdr_lrn_called_no'].apply(lambda x: x if x else 'UNKNOWN')
                                        df['cdr_call_forwarding'] = df['cdr_call_forwarding'].apply(lambda x: x if (x and x != '') else 'UNKNOWN')
                                        df['phone_no'] = df['phone_no'].astype(str).apply(lambda x: '' if not x else (x.split('.')[0].replace("'",'').replace('"','') if (isinstance(x, str) and len(x.split('.')) == 2)  else str(x).replace("'",'').replace('"','')))
                                        df['a_party'] = df['a_party'].astype(str).apply(lambda x: '' if not x else (x.split('.')[0].replace("'",'').replace('"','') if (isinstance(x, str) and len(x.split('.')) == 2)  else str(x).replace("'",'').replace('"','')))
                                        df['b_party'] = df['b_party'].astype(str).apply(lambda x: '' if not x else (x.split('.')[0].replace("'",'').replace('"','') if (isinstance(x, str) and len(x.split('.')) == 2)  else str(x).replace("'",'').replace('"','')))

                                        u_b_party = df['b_party'].unique()
                                        u_b_party = u_b_party[u_b_party!=""]
                                        bparty_mapping = {val: get_country_code_sms_app(val,sms_df) for val in u_b_party}
                                        bparty_mapping_dict = {key: list(value) for key, value in bparty_mapping.items()}
                                        df['bparty_country'] = ''
                                        df['sms_app'] = ''
                                        df['sms_company'] = ''
                                        df[['bparty_country', 'sms_app', 'sms_company']] = [
                                            bparty_mapping_dict.get(b_party, ['', '', ''])
                                            for b_party in df['b_party']
                                        ]
                                                            
                                        df['imei_no'] = df['imei_no'].astype(str)
                                        df['imsi_no'] = df['imsi_no'].astype(str)
                                        if(not mapper_name.startswith("N")):
                                            df = df[~df['imei_no'].apply(lambda x: '\r' in x or '\n' in x or ' ' in x or 'Dynamic' in x)]
                                        
                                        unique_start_date_time = df['start_date_time'].unique()
                                        unique_end_date_time = df['end_date_time'].unique()
                                        start_date_time_mapping = {val: process_start_date_time_cdr(str(val)) for val in unique_start_date_time}
                                        df['start_date_time'] = df['start_date_time'].fillna(0)
                                        df['start_date_time'] = df['start_date_time'].map(start_date_time_mapping)
                                        unique_end_date_time = unique_end_date_time[unique_end_date_time != ""]
                                        if len(unique_end_date_time)!=0:
                                            end_date_time_mapping = {val: process_start_date_time_cdr(str(val)) for val in unique_end_date_time}
                                            df['end_date_time'] = df['end_date_time'].map(end_date_time_mapping)
                                            df['session_duration'] = np.where(
                                            (df['end_date_time'].notnull()) & (df['start_date_time'].notnull()),
                                            df['end_date_time'].astype(int) - df['start_date_time'].astype(int),
                                            0
                                        )
                                        else:
                                            df[['end_date_time','session_duration']] = df.apply(process_end_date_time_cdr,axis=1, result_type='expand')

                                        df['imei_no'] = df['imei_no'].apply(lambda x: '' if not x else (x.split('.')[0] if (isinstance(x, str) and len(x.split('.')) == 2)  else str(x).replace("'",'').replace('"','')))
                                        df['imsi_no'] = df['imsi_no'].apply(lambda x: '' if not x else (x.split('.')[0] if (isinstance(x, str) and len(x.split('.')) == 2)  else str(x).replace("'",'').replace('"','')))
                                        df['mapper_name'] = mapper_name
                                        df['case_id'] = s['case_id']
                                        df['file_id'] = s['file_id']
                                        # print("data cleaning 4", time.time()-t2)
                                        # t4 = time.time()
                                        
                                        df['start_date_time'] = df['start_date_time'].fillna(0)  # replace missing values with 0
                                        df['start_date_time'] = df['start_date_time'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                        df['end_date_time'] = df['end_date_time'].fillna(0)  # replace missing values with 0
                                        df['end_date_time'] = df['end_date_time'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                        df['start_date_time'] = df['start_date_time'].round().astype(int)
                                        df['end_date_time'] = df['end_date_time'].round().astype(int)

                                        # session_time = time.time()
                                        df['generated_time'] = df['generated_time'].apply(lambda x: x if x else '')
                                        #login session duration not present then call below                                        
                                        # all_filters = time.time()
                                        df = df[~df['cell_id'].apply(lambda x: '\r' in x or '\n' in x or ' ' in x)]
                                        df = df[~df['imsi_no'].apply(lambda x: '\r' in x or '\n' in x or ' ' in x or 'Dynamic' in x)]

                                        # tower_time = time.time()
                                        # df['cell_id'] = df['cell_id'].astype(str)
                                        # unique_cell_id = df['cell_id'].unique()
                                        unique_cell_id = df['cell_id'].astype(str).unique()
                                        tower_session = requests.Session()
                                        celld_to_Tower_mapping = {val: celld_to_Tower(val,tower_session) for val in unique_cell_id}
                                        tower_mapping_dict = {key: list(value) for key, value in celld_to_Tower_mapping.items()}
                                        # Assign the mapped values to the DataFrame columns
                                        df[['tower_operator', 'tower_network_type', 'tower_location', 'tower_state', 'tower_town', 'tower_district', 'tower_azimuth', 'tower_pincode', 'tower_latitude', 'tower_longitude','tower_height','tower_lat_long','tower_lat_long_rpt']] = ''
                                        
                                        df[['tower_operator', 'tower_network_type', 'tower_location', 'tower_state', 'tower_town', 'tower_district', 'tower_azimuth', 'tower_pincode', 'tower_latitude', 'tower_longitude','tower_height','tower_lat_long','tower_lat_long_rpt']] = [
                                            tower_mapping_dict.get(cell_id, ['', '', '', '', '', '', '', '', '', '', '', '',''])
                                            for cell_id in df['cell_id']
                                        ]

                                        second_unique_cell_id = df['second_cell_id'].unique()
                                        second_celld_to_Tower_mapping = {val: tower if (tower := celld_to_Tower(str(val), tower_session,"yes")) != '' else 'UNKNOWN' for val in second_unique_cell_id }

                                        second_tower_mapping_dict = {key: list(value) for key, value in second_celld_to_Tower_mapping.items()}
                                        # Assign the mapped values to the DataFrame columns
                                        df[['second_tower_operator', 'second_tower_network_type', 'second_tower_location', 'second_tower_state', 'second_tower_town', 'second_tower_district', 'second_tower_azimuth', 'second_tower_pincode', 'second_tower_latitude', 'second_tower_longitude','second_tower_height','second_tower_lat_long']]  = ''
                                        df[['second_tower_operator', 'second_tower_network_type', 'second_tower_location', 'second_tower_state', 'second_tower_town', 'second_tower_district', 'second_tower_azimuth', 'second_tower_pincode', 'second_tower_latitude', 'second_tower_longitude','second_tower_height','second_tower_lat_long']] = [
                                            second_tower_mapping_dict.get(cell_id, ['', '', '', '', '', '', '', '', '', '', '', ''])
                                            for cell_id in df['second_cell_id']
                                        ]

                                        df['is_travelling'] = ((df['cell_id'] != df['second_cell_id']) & (df['second_cell_id'] != '')).astype(int)
                                        # ip_to_dict_time = time.time()
                                        # df['destination_ip_address'] = df['destination_ip_address'].astype(str)
                                        # unique_destination_ip_address = df['destination_ip_address'].unique()
                                        unique_destination_ip_address = df['destination_ip_address'].astype(str).unique()
                                        ip_to_dict_session = requests.Session()
                                        # ip_to_dict_mapping = {val: ip_to_dict_cdr(val,asset_dir,ip_to_dict_session) for val in unique_destination_ip_address}
                                        reader = maxminddb.open_database(os.path.join(asset_dir,'chexfile'))
                                        def query_ip(val):
                                            return val, ip_to_dict_cdr(val, ip_to_dict_session,reader)

                                        with ThreadPoolExecutor(max_workers=10) as executor:  # Adjust the number of workers
                                            results = list(executor.map(query_ip, unique_destination_ip_address))
                                        ip_to_dict_mapping_dict = dict(results)
                                        # ip_to_dict_mapping_dict = {key: list(value) for key, value in ip_to_dict_mapping.items()}
                                        
                                        df[['company_name','ip_city','ip_country','ip_lat','ip_long','service_provider_detail','ip_state_name','ip_district_name','ip_continent_name','ip_connection_type','ip_lat_long']] = ''
                                        df[['company_name','ip_city','ip_country','ip_lat','ip_long','service_provider_detail','ip_state_name','ip_district_name','ip_continent_name','ip_connection_type','ip_lat_long']] = [
                                            ip_to_dict_mapping_dict.get(destination_ip_address, ['','','','','','','','','','',''])
                                            for destination_ip_address in df['destination_ip_address']
                                        ]
                                        # df['public_ip_address'] = df['public_ip_address'].astype(str)
                                        # unique_public_ip_address = df['public_ip_address'].unique()
                                        unique_public_ip_address = df['public_ip_address'].astype(str).unique()
                                        # ip_to_dict_session = requests.Session()
                                        # ip_to_dict_mapping = {val: ip_to_dict_cdr(val,asset_dir,ip_to_dict_session) for val in unique_public_ip_address}
                                        with ThreadPoolExecutor(max_workers=10) as executor:  # Adjust the number of workers
                                            results = list(executor.map(query_ip, unique_public_ip_address))
                                        # ip_to_dict_mapping_dict = {key: list(value) for key, value in ip_to_dict_mapping.items()}
                                        ip_to_dict_mapping_dict = dict(results)
                                        df[['public_company_name','public_ip_city','public_ip_country','public_ip_lat','public_ip_long','public_service_provider_detail','public_ip_state_name','public_ip_district_name','public_ip_continent_name','public_ip_connection_type','public_ip_lat_long']] = ''
                                        df[['public_company_name','public_ip_city','public_ip_country','public_ip_lat','public_ip_long','public_service_provider_detail','public_ip_state_name','public_ip_district_name','public_ip_continent_name','public_ip_connection_type','public_ip_lat_long']] = [
                                            ip_to_dict_mapping_dict.get(public_ip_address, ['','','','','','','','','','',''])
                                            for public_ip_address in df['public_ip_address']
                                        ]
                                        
                                        unique_imei_no_list = df['imei_no'].unique()
                                        unique_imei_no_list = unique_imei_no_list[unique_imei_no_list != ""]
                                        df[['phone_name','phone_model','phone_brand','is_basic']] = ''
                                        if len(unique_imei_no_list)!=0:
                                            tac_session = requests.Session()
                                            tac_mapping = {val: imei_to_tac(val,tac_session) for val in unique_imei_no_list}
                                            tac_mapping_dict = {key: list(value) for key, value in tac_mapping.items()}
                                            df[['phone_name','phone_model','phone_brand','is_basic']] = [
                                                tac_mapping_dict.get(imei_no, ['','','',''])
                                                for imei_no in df['imei_no']
                                            ]
                                        df['cell_id_start_date_time'] =''
                                        df['cell_id_end_date_time'] = ''
                                        df['tower_movements_index'] = '-1'
                                        df = df.sort_values(by=['phone_no', 'start_date_time'], ascending=[True, True])

                                        df['ipdr_id_session_hash'] = process_session_hash_cdr(df)
                                        remove_duplicate_mask = df.duplicated(subset='ipdr_id_session_hash', keep='first')
                                        df = df[~remove_duplicate_mask]
                                        df = df.applymap(remove_unwanted_chars)

                                        df['subscriber_name'] = df['subscriber_name'].apply(lambda x: x if x else '')
                                        df['subscriber_address1'] = df['subscriber_address'].apply(lambda x: x if x else '')
                                        df['subscriber_alternate_no'] = df['subscriber_alternate_no'].apply(lambda x: x if x else '')
                                        df['subscriber_email'] = df['subscriber_email'].apply(lambda x: x if x else '')
                                        df['subscriber_father'] = df['subscriber_father'].apply(lambda x: x if x else '')                                        
                                        df['bparty_subscriber_name'] = df['bparty_subscriber_name'].apply(lambda x: x if x else '')
                                        df['bparty_subscriber_address1'] = df['bparty_subscriber_address'].apply(lambda x: x if x else '')
                                        df['bparty_subscriber_alternate_no'] = df['bparty_subscriber_alternate_no'].apply(lambda x: x if x else '')
                                        df['bparty_subscriber_email'] = df['bparty_subscriber_email'].apply(lambda x: x if x else '')
                                        df['bparty_subscriber_father'] = df['bparty_subscriber_father'].apply(lambda x: x if x else '')
                                        df['subscriber_name'] = df['subscriber_name'].fillna('')
                                        df['subscriber_realtioner_name'] = df['subscriber_father'].fillna('')                                        
                                        df['bparty_subscriber_name'] = df['bparty_subscriber_name'].fillna('')
                                        df['bparty_subscriber_realtioner_name'] = df['bparty_subscriber_father'].fillna('')                                        
                                        df['date'] = pd.to_datetime(df['start_date_time'], unit='s')
                                        df['date'] = df['date'].apply(lambda x: x.strftime('%d-%m-%Y'))
                                        df['time_of_day'] = df['start_date_time'].apply(lambda x: datetime.datetime.fromtimestamp(x, tz=pytz.timezone('Asia/Kolkata')))
                                        df['time_of_day'] = df['time_of_day'].dt.time
                                        night_start = pd.to_datetime('00:00:00').time()
                                        morning_start = pd.to_datetime('06:00:00').time()
                                        afternoon_start = pd.to_datetime('12:00:00').time()
                                        evening_start = pd.to_datetime('18:00:00').time()
                                        office_hours_start = pd.to_datetime('10:00:00').time()
                                        office_hours_end = pd.to_datetime('19:00:00').time()
                                        df['time_shift'] = df['time_of_day'].apply(lambda x: 
                                            'NIGHT' if night_start <= x < morning_start else
                                            'MORNING' if morning_start <= x < afternoon_start else
                                            'AFTERNOON' if afternoon_start <= x < evening_start else
                                            'EVENING'
                                        )
                                        df['office_hours'] = df['time_of_day'].apply(lambda x: 'YES' if office_hours_start <= x <= office_hours_end else 'NO')
                                        null_zero_exclude_condition = (
                                                    (df['a_party'] != 0) & 
                                                    (df['a_party'].notna()) &
                                                    (df['a_party']!= '') &
                                                    (df['a_party'] != '0.0') &
                                                    (df['a_party'] != 'nan') &                                
                                                    (df['b_party'] != 0) & 
                                                    (df['b_party'].notna()) &
                                                    (df['b_party']!= '') &
                                                    (df['b_party'] != '0.0') &
                                                    (df['b_party'] != 'nan') 
                                                )

                                        df = df[null_zero_exclude_condition]
                                        try:
                                            df['source_port'] = df['source_port'] .replace('0.0', 0)
                                            df['source_port'] = df['source_port'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                            df['source_port'] = df['source_port'].fillna(0)
                                            df['source_port'] = df['source_port'].round().astype(int)
                                        except:
                                            df['source_port'] =0
                                        try:
                                            df['destination_port'] = df['destination_port'] .replace('0.0', 0)
                                            df['destination_port'] = df['destination_port'].replace([np.inf, -np.inf], np.nan).fillna(0)
                                            df['destination_port'] = df['destination_port'].fillna(0)
                                            df['destination_port'] = df['destination_port'].round().astype(int)
                                        except:
                                            df['destination_port'] = 0
                                        try:
                                            next_destination_ports  = [index for index, value in enumerate(df.columns.get_loc('destination_port')) if value]
                                            if len(next_destination_ports) >0:
                                                df.columns.values[int(next_destination_ports[0])] = 'public_ip_port'
                                            else:
                                                df['public_ip_port'] =0
                                        except:
                                            df['public_ip_port'] =0
                                        
                                        df = df[['ipdr_id_session_hash','phone_no', 'imei_no', 'imsi_no', 'date',  'start_date_time', 'end_date_time',  'roaming_circle', 'roaming_circle_type',  'home_circle','mapper_name', 'public_ip_address', 'public_ip_port', 'destination_ip_address', 'destination_port',   'session_duration','cell_id', 'ipdr_id', 'case_id', 'file_id', 'tower_operator', 'tower_network_type', 'tower_location', 'tower_state', 'tower_town', 'tower_district', 'tower_azimuth', 'tower_pincode', 'tower_latitude', 'tower_longitude','tower_height','ip_lat', 'ip_long', 'ip_city', 'ip_country', 'protocol_name', 'application_name',  'service_provider_detail', 'mac_id',   'cgi_id',   'subscriber_name','subscriber_address1', 'subscriber_alternate_no', 'subscriber_email','subscriber_realtioner_name', 'bparty_subscriber_name','bparty_subscriber_address1', 'bparty_subscriber_alternate_no', 'bparty_subscriber_email', 'bparty_subscriber_realtioner_name', 'cdr_call_forwarding', 'cdr_lrn_called_no', 'cdr_duration', 'second_cell_id','second_tower_operator', 'second_tower_network_type', 'second_tower_location', 'second_tower_state', 'second_tower_town', 'second_tower_district', 'second_tower_azimuth', 'second_tower_pincode', 'second_tower_latitude', 'second_tower_longitude','second_tower_height', 'cdr_call_type', 'cdr_sms_center_number', 'cdr_connection_type', 'cdr_sim_activation_date', 'cdr_port_in_out', 'cdr_wifi_latitude', 'cdr_wifi_longitude', 'cdr_first_bts', 'cdr_last_bts', 'cdr_service_type', 'a_party', 'b_party','public_company_name','public_ip_city','public_ip_country','public_ip_lat','public_ip_long','public_service_provider_detail','public_ip_state_name','public_ip_district_name','public_ip_continent_name','public_ip_connection_type','bparty_country', 'sms_app', 'sms_company','ip_lat_long','public_ip_lat_long','tower_lat_long','second_tower_lat_long','time_of_day','time_shift','office_hours','is_travelling','tower_lat_long_rpt','phone_name','phone_model','phone_brand','is_basic']]
                                        
                                        active_inactive_df = pd.DataFrame(columns=['case_id', 'phone_no', 'off_imei_no', 'off_imsi_no', 'off_tower_location', 'off_cell_id', 'off_time', 'on_imei_no', 'on_imsi_no', 'on_tower_location', 'on_cell_id', 'on_time','is_phone_changed','on_tower_lat','on_tower_long','on_tower_district','on_tower_state','off_tower_lat','off_tower_long','off_tower_district','off_tower_state','on_time_shift','off_time_shift','vaccume_duration'])
                                        for idx, active_inactive_group in df.groupby(['case_id', 'phone_no']):
                                            active_inactive_group['on_time'] = active_inactive_group['start_date_time'].shift(-1)
                                            active_inactive_group['on_imei_no'] = active_inactive_group['imei_no'].shift(-1)
                                            active_inactive_group['on_imsi_no'] = active_inactive_group['imsi_no'].shift(-1)
                                            active_inactive_group['on_tower_location'] = active_inactive_group['tower_location'].shift(-1)
                                            active_inactive_group['on_tower_lat'] = active_inactive_group['tower_latitude'].shift(-1)
                                            active_inactive_group['on_tower_long'] = active_inactive_group['tower_longitude'].shift(-1)
                                            active_inactive_group['on_tower_district'] = active_inactive_group['tower_district'].shift(-1)
                                            active_inactive_group['on_tower_state'] = active_inactive_group['tower_state'].shift(-1)
                                            active_inactive_group['on_cell_id'] = active_inactive_group['cell_id'].shift(-1)
                                            active_inactive_group['on_time_shift'] = active_inactive_group['time_shift'].shift(-1)

                                            active_inactive_group = active_inactive_group.dropna(how='any')
                                            active_inactive_group = active_inactive_group.sort_values(by=['start_date_time','end_date_time'])

                                            active_inactive_boolean_index = ((df['end_date_time'] != df['start_date_time'].shift(-1)) & (df['start_date_time'] != df['start_date_time'].shift(-1)))
                                            
                                            active_inactive_extracted_rows = active_inactive_group.loc[active_inactive_boolean_index, ['case_id','phone_no','end_date_time', 'imei_no', 'imsi_no', 'tower_location', 'tower_latitude', 'tower_longitude', 'tower_district', 'time_shift','tower_state', 'cell_id','on_time','on_imei_no','on_imsi_no','on_tower_location','on_cell_id','on_tower_lat','on_tower_long','on_tower_district','on_tower_state','on_time_shift']].rename(columns={'end_date_time': 'off_time', 'imei_no': 'off_imei_no', 'imsi_no': 'off_imsi_no', 'cell_id': 'off_cell_id', 'tower_location': 'off_tower_location', 'tower_latitude': 'off_tower_lat', 'tower_longitude': 'off_tower_long', 'tower_district': 'off_tower_district','tower_state':'off_tower_state','time_shift':'off_time_shift'}).reset_index(drop=True)
                                            active_inactive_extracted_rows['on_time'] = active_inactive_extracted_rows['on_time'].round().astype(int)
                                            active_inactive_extracted_rows['vaccume_duration'] = active_inactive_extracted_rows['on_time'].round().astype(int) - active_inactive_extracted_rows['off_time'].round().astype(int)
                                            active_inactive_extracted_rows['is_phone_changed'] = ~(active_inactive_extracted_rows['off_imei_no'] == active_inactive_extracted_rows['on_imei_no'])

                                            active_inactive_extracted_rows = active_inactive_extracted_rows.astype({'is_phone_changed': int})
                                            active_inactive_df = pd.concat([active_inactive_df, active_inactive_extracted_rows])

                                        active_inactive_df = active_inactive_df.reset_index(drop=True)
                                        if len(active_inactive_df)!=0:
                                            active_inactive_df['active_inactive_period_id'] = calculate_hash(active_inactive_df)
                                            active_inactive_period_solr.add(active_inactive_df.to_dict('records'))
                                            active_inactive_period_solr.commit()

                                        # Processing meeting point data in cdr
                                        meeting_point_essentials(df)
                                        all_unique_time = time.time()
                                        unique_phone_no = df.loc[df['phone_no'] != "", 'phone_no'].unique()
                                        unique_a_party= df.loc[(df['a_party'] != "0") & (df['a_party'] != ""), 'a_party'].unique()
                                        unique_b_party= df.loc[(df['b_party'] != "0") & (df['b_party'] != ""), 'b_party'].unique()
                                        unique_imei_no = df.loc[df['imei_no'] != "", 'imei_no'].unique()
                                        unique_imsi_no = df.loc[df['imsi_no'] != "", 'imsi_no'].unique()
                                        unique_pincode = df.loc[df['tower_pincode'] != "", 'tower_pincode'].unique()
                                        unique_second_tower_pincode = df.loc[df['second_tower_pincode'] != "", 'second_tower_pincode'].unique()
                                        unique_tower_lat_long = df.loc[df['tower_lat_long'] != "", 'tower_lat_long'].unique()
                                        unique_second_tower_lat_long = df.loc[df['second_tower_lat_long'] != "", 'second_tower_lat_long'].unique()
                                        unique_public_ip_address = df.loc[df['public_ip_address'] != "", 'public_ip_address'].unique()
                                        unique_destination_ip_address = df.loc[df['destination_ip_address'] != "", 'destination_ip_address'].unique()

                                        case_id = str(s['case_id'])

                                        if unique_phone_no.size > 0:
                                            phone_no_df = pd.DataFrame({'phone_no': unique_phone_no, 'case_id': case_id})
                                            phone_no_df['phone_no_hash'] = compute_hash(phone_no_df['phone_no'], case_id)
                                            phone_no_solr.add(phone_no_df.to_dict('records'))
                                            phone_no_solr.commit()

                                        if unique_a_party.size > 0:
                                            a_party_df = pd.DataFrame({'a_party': unique_a_party,'case_id':str(s['case_id'])})
                                            a_party_df['a_party_hash'] =  compute_hash(a_party_df['a_party'], case_id)
                                            a_party_solr.add(a_party_df.to_dict('records'))
                                            a_party_solr.commit()

                                        if unique_b_party.size > 0:
                                            b_party_df = pd.DataFrame({'b_party': unique_b_party,'case_id':str(s['case_id'])})
                                            b_party_df['b_party_hash'] = compute_hash(b_party_df['b_party'], case_id)
                                            b_party_solr.add(b_party_df.to_dict('records'))
                                            b_party_solr.commit()

                                        unique_a_party_b_party = df[['a_party','b_party','case_id']]
                                        unique_a_party_b_party = unique_a_party_b_party[((unique_a_party_b_party['a_party']!='0') & (unique_a_party_b_party['a_party']!=''))]
                                        unique_a_party_b_party = unique_a_party_b_party[((unique_a_party_b_party['b_party']!='0') & (unique_a_party_b_party['b_party']!=''))]
                                        
                                        if len(unique_a_party_b_party)!=0:
                                            unique_a_party_b_party['a_party_b_party_hash'] =  unique_a_party_b_party.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.a_party), str(x.b_party), str(x.case_id)).encode()).hexdigest(), axis=1)
                                            remove_duplicate_a_party_b_party = unique_a_party_b_party.duplicated(subset='a_party_b_party_hash', keep='first')
                                            unique_a_party_b_party = unique_a_party_b_party[~remove_duplicate_a_party_b_party]
                                            
                                            a_party_b_party_solr.add(unique_a_party_b_party.to_dict('records'))
                                            a_party_b_party_solr.commit()
                                        
                                        unique_a_party_date = df[['a_party','date','case_id']]
                                        unique_a_party_date = unique_a_party_date[((unique_a_party_date['a_party']!='0') & (unique_a_party_date['a_party']!=''))]
                                        unique_a_party_date = unique_a_party_date[(unique_a_party_date['date']!='')]
                                        
                                        if len(unique_a_party_date)!=0:
                                            unique_a_party_date['a_party_date_hash'] =  unique_a_party_date.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.a_party), str(x.date), str(x.case_id)).encode()).hexdigest(), axis=1)
                                            remove_duplicate_a_party_date = unique_a_party_date.duplicated(subset='a_party_date_hash', keep='first')
                                            unique_a_party_date = unique_a_party_date[~remove_duplicate_a_party_date]
                                            
                                            a_party_date_solr.add(unique_a_party_date.to_dict('records'))
                                            a_party_date_solr.commit()
                                        
                                        unique_phone_no_imei = df[['phone_no','imei_no','case_id']]
                                        unique_phone_no_imei = unique_phone_no_imei[((unique_phone_no_imei['phone_no']!='0') & (unique_phone_no_imei['phone_no']!=''))]
                                        unique_phone_no_imei = unique_phone_no_imei[(unique_phone_no_imei['imei_no']!='')]
                                        
                                        if len(unique_phone_no_imei)!=0:
                                            unique_phone_no_imei['phone_no_imei_no_hash'] =  unique_phone_no_imei.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.phone_no), str(x.imei_no), str(x.case_id)).encode()).hexdigest(), axis=1)
                                            remove_duplicate_phone_no_imei_no = unique_phone_no_imei.duplicated(subset='phone_no_imei_no_hash', keep='first')
                                            unique_phone_no_imei = unique_phone_no_imei[~remove_duplicate_phone_no_imei_no]
                                            
                                            phone_no_imei_no_solr.add(unique_phone_no_imei.to_dict('records'))
                                            phone_no_imei_no_solr.commit()

                                        if unique_pincode.size > 0:
                                            u_pincode_df = pd.DataFrame({'tower_pincode': unique_pincode,'case_id':str(s['case_id'])})
                                            u_pincode_df['u_tower_pincode_id'] =  compute_hash(u_pincode_df['tower_pincode'], case_id)
                                            tower_pincode_solr.add(u_pincode_df.to_dict('records'))
                                            tower_pincode_solr.commit()

                                        if unique_second_tower_pincode.size > 0:
                                            u_pincode_df = pd.DataFrame({'tower_pincode': unique_second_tower_pincode,'case_id':str(s['case_id'])})
                                            u_pincode_df['u_tower_pincode_id'] =  compute_hash(u_pincode_df['tower_pincode'], case_id)
                                            tower_pincode_solr.add(u_pincode_df.to_dict('records'))
                                            tower_pincode_solr.commit()

                                        if unique_tower_lat_long.size > 0:
                                            u_tower_lat_long_df = pd.DataFrame({'tower_lat_long': unique_tower_lat_long,'case_id':str(s['case_id'])})
                                            u_tower_lat_long_df['u_tower_lat_long_id'] =  compute_hash(u_tower_lat_long_df['tower_lat_long'], case_id)
                                            tower_lat_long_solr.add(u_tower_lat_long_df.to_dict('records'))
                                            tower_lat_long_solr.commit()

                                        if unique_second_tower_lat_long.size > 0:
                                            u_tower_lat_long_df = pd.DataFrame({'tower_lat_long': unique_second_tower_lat_long,'case_id':str(s['case_id'])})
                                            u_tower_lat_long_df['u_tower_lat_long_id'] =  compute_hash(u_tower_lat_long_df['tower_lat_long'], case_id)
                                            tower_lat_long_solr.add(u_tower_lat_long_df.to_dict('records'))
                                            tower_lat_long_solr.commit()

                                        unique_phone_no_cell_id = df[['phone_no','cell_id','tower_lat_long','case_id']]
                                        unique_phone_no_cell_id = unique_phone_no_cell_id.rename(columns={'tower_lat_long':'lat_long'})
                                        unique_phone_no_cell_id = unique_phone_no_cell_id[((unique_phone_no_cell_id['phone_no']!='0') & (unique_phone_no_cell_id['phone_no']!=''))]
                                        unique_phone_no_cell_id = unique_phone_no_cell_id[(unique_phone_no_cell_id['cell_id']!='')]
                                        
                                        if len(unique_phone_no_cell_id)!=0:
                                            unique_phone_no_cell_id['phone_no_cell_id_hash'] =  unique_phone_no_cell_id.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.phone_no), str(x.cell_id), str(x.lat_long), str(x.case_id)).encode()).hexdigest(), axis=1)
                                            remove_duplicate_phone_no_cell_id = unique_phone_no_cell_id.duplicated(subset='phone_no_cell_id_hash', keep='first')
                                            unique_phone_no_cell_id = unique_phone_no_cell_id[~remove_duplicate_phone_no_cell_id]
                                            phone_no_cell_id_solr.add(unique_phone_no_cell_id.to_dict('records'))
                                            phone_no_cell_id_solr.commit()

                                        unique_phone_no_cell_id = df[['phone_no','second_cell_id','second_tower_lat_long','case_id']]
                                        unique_phone_no_cell_id = unique_phone_no_cell_id.rename(columns={'second_cell_id':'cell_id','second_tower_lat_long':'lat_long'})
                                        unique_phone_no_cell_id = unique_phone_no_cell_id[((unique_phone_no_cell_id['phone_no']!='0') & (unique_phone_no_cell_id['phone_no']!=''))]
                                        unique_phone_no_cell_id = unique_phone_no_cell_id[(unique_phone_no_cell_id['cell_id']!='')]
                                        
                                        if len(unique_phone_no_cell_id)!=0:
                                            unique_phone_no_cell_id['phone_no_cell_id_hash'] =  unique_phone_no_cell_id.apply(lambda x: hashlib.sha256('{}{}{}'.format(str(x.phone_no), str(x.cell_id), str(x.lat_long), str(x.case_id)).encode()).hexdigest(), axis=1)
                                            remove_duplicate_phone_no_cell_id = unique_phone_no_cell_id.duplicated(subset='phone_no_cell_id_hash', keep='first')
                                            unique_phone_no_cell_id = unique_phone_no_cell_id[~remove_duplicate_phone_no_cell_id]
                                            phone_no_cell_id_solr.add(unique_phone_no_cell_id.to_dict('records'))
                                            phone_no_cell_id_solr.commit()

                                        unique_a_party_subsriber = df.loc[df['a_party'].str.len()>8,['a_party','subscriber_name','subscriber_address1', 'subscriber_alternate_no', 'subscriber_email','subscriber_realtioner_name']]
                                        a_party_sub_rename = {'a_party':'phone_no','subscriber_name':'name','subscriber_address1':'address1','subscriber_alternate_no':'alternate_no','subscriber_email':'email','subscriber_realtioner_name':'relationer_name'}
                                        unique_a_party_subsriber = unique_a_party_subsriber.rename(columns=a_party_sub_rename)
                                        unique_b_party_subsriber = df.loc[df['b_party'].str.len()>8,['b_party','bparty_subscriber_name','bparty_subscriber_address1', 'bparty_subscriber_alternate_no', 'bparty_subscriber_email', 'bparty_subscriber_realtioner_name']]
                                        b_party_sub_rename = {'b_party':'phone_no','bparty_subscriber_name':'name','bparty_subscriber_address1':'address1','bparty_subscriber_alternate_no':'alternate_no','bparty_subscriber_email':'email','bparty_subscriber_realtioner_name':'relationer_name'}
                                        unique_b_party_subsriber = unique_b_party_subsriber.rename(columns=b_party_sub_rename)
                                        subscriber_details_df =pd.concat([unique_a_party_subsriber,unique_b_party_subsriber])
                                        subscriber_details_df = subscriber_details_df[(subscriber_details_df['name']!='')]
                                        if len(subscriber_details_df)!=0:
                                            subscriber_details_solr.add(subscriber_details_df.to_dict('records'))
                                            subscriber_details_solr.commit()

                                        if unique_imei_no.size > 0:
                                            imei_no_df = pd.DataFrame({'imei_no': unique_imei_no,'case_id':str(s['case_id'])})
                                            imei_no_df['imei_no_hash'] =  compute_hash(imei_no_df['imei_no'], case_id)
                                            imei_solr.add(imei_no_df.to_dict('records'))
                                            imei_solr.commit()

                                        if unique_imsi_no.size > 0:
                                            imsi_no_df = pd.DataFrame({'imsi_no': unique_imsi_no,'case_id':str(s['case_id'])})
                                            imsi_no_df['imsi_no_hash'] = compute_hash(imsi_no_df['imsi_no'], case_id)
                                            imsi_solr.add(imsi_no_df.to_dict('records'))
                                            imsi_solr.commit()

                                        if unique_public_ip_address.size > 0:
                                            public_ip_address_df = pd.DataFrame({'public_ip_address': unique_public_ip_address,'case_id':str(s['case_id'])})
                                            public_ip_address_df['public_ip_address_hash'] =  compute_hash(public_ip_address_df['public_ip_address'], case_id)
                                            pip_solr.add(public_ip_address_df.to_dict('records'))
                                            pip_solr.commit()

                                        if unique_destination_ip_address.size > 0:
                                            destination_ip_address_df = pd.DataFrame({'destination_ip_address': unique_destination_ip_address,'case_id':str(s['case_id'])})
                                            destination_ip_address_df['destination_ip_address_hash'] =  compute_hash(destination_ip_address_df['destination_ip_address'], case_id)
                                            dip_solr.add(destination_ip_address_df.to_dict('records'))
                                            dip_solr.commit()

                                        unique_cell_id = unique_cell_id[unique_cell_id != ""]
                                        second_unique_cell_id = second_unique_cell_id[second_unique_cell_id != ""]
                                        unique_cell_id = list(unique_cell_id)+list(second_unique_cell_id)
                                        
                                        if len(unique_cell_id)!=0:
                                            cell_id_df =  pd.DataFrame({'cell_id': unique_cell_id,'case_id':str(s['case_id'])})
                                            cell_id_df['cell_id_hash'] =  compute_hash(cell_id_df['cell_id'], case_id)
                                            cell_id_solr.add(cell_id_df.to_dict('records'))
                                            cell_id_solr.commit()

                                        print('all Unique values',f'{time.time() - all_unique_time:.1f} seconds') 
                                    else:update_empty_file(IPDR_CONN,s['file_id'],s['case_id'])
                                    if 'protocol_name' in df.columns:
                                        df['protocol_name']=df['protocol_name'].astype(str).str.upper()
                                    if len(df)!=0:
                                        bulk_timer = time.time()                                        
                                        bulk_file_name =BULKER_DIR+'//'+str(s['case_id'])+'_'+str(s['file_id'])+'_'+str(last_index)+'_'+str(bulk_timer).replace('.','')+'.csv'
                                        df.to_csv(bulk_file_name,sep=',',index= None)
                                        print('[',mapper_name,'] File_id=',s['file_id'],'Bulk=',len(df),'Time=',f'{time.time() - panda_s_time:.1f} seconds')
                                    else:update_empty_file(IPDR_CONN,s['file_id'],s['case_id'])
                                else:
                                    update_empty_file(IPDR_CONN,s['file_id'],s['case_id'])
                            
                    else:
                        update_completion(s['file_id'],s['case_id'])
                del TOR_ALL_INFO, ISP_DATA, CITY_DATA, COUNTRY_DATA, ORG_DATA#VOIP_PORTS,
                IPDR_CONN.close()
                
            except Exception as err:
                logging.error('Worker Error: '+str(traceback.format_exc()))
                update_failed(s['file_id'],s['case_id'])
                pass
    except Exception as err:
            logging.error('checking stop status cdrworker error:'+str(traceback.format_exc()))   




def file_finder_executor(data_config,asset_dir_list,user_id):
    while True:
        time.sleep(0.5)
        IPDR_CONN1 = ipdr_conn()
            
        meta_cursor = IPDR_CONN1.cursor()
        meta_cursor.execute("SELECT fmd.case_id,fmd.ID as file_id,fmd.telecom_name as source_type,fmd.path as source_path,fmd.name as file_name,fmd.uploadStatus,fmd.pcap_phone_no,fmd.pcap_public_ip_address,fmd.file_format,fmd.file_type,fmd.file_hash, fmd.mapper_name, fmd.header_position, fmd.header_length,fmd.date_format,fmd.mapper_country_name,fmd.mapper_dict_with_raw FROM files_meta_details as fmd INNER JOIN case_details as cd ON cd.case_id=fmd.case_id WHERE fmd.uploadStatus = 0 and cd.voip_status=0 and cd.user_Id="+str(user_id))
        result = meta_cursor.fetchall()
        if result:
            start_time = time.time()
            number_of_process = int(data_config['fileCount'])   
            file_process_pool = mp.Pool(processes=number_of_process)
            for file_row in result:
                r = file_row
                platform_name = platform.system()
                if platform_name == "Windows":            
                    dc_path = str(data_config['dc_path_windows'])
                    pact_path = str(data_config['pact_path_windows'])
                    merger_path = str(data_config['merger_path_windows'])
                else:
                    dc_path = str(data_config['dc_path_linux'])
                    pact_path = str(data_config['pact_path_linux'])
                    merger_path = str(data_config['merger_path_linux'])

                s = {
                    'case_id': r[0],
                    'file_id': r[1],
                    'source_type': r[2],
                    'source_path': r[3]+"//"+r[4],
                    'file_name':r[4],
                    'upload_status':r[5],
                    'phone_no':r[6],
                    'public_ip_address':r[7],
                    'extension': r[8],
                    'file_type':r[9],
                    'file_hash':r[10],
                    'mapper_name': r[11],
                    'header_position': r[12],
                    'header_length': r[13],
                    'date_format': r[14],
                    'mapper_country_name': r[15],
                    'mapper_dict_with_raw': r[16],
                    'total_row_count':int(data_config['rowCount']),
                    'merger_path':merger_path,
                    'pact_path':pact_path,
                    'dc_path':dc_path
                }
                
                if s['file_type'] != 'cdr':
                    file_process_pool.apply_async(ipdr_worker, args=(s,asset_dir_list,))
                elif s['file_type'] == 'cdr':
                    sms_df = pd.read_excel(os.path.join(os.getcwd(),'files',"shexfile.xlsx"),engine='openpyxl')
                    file_process_pool.apply_async(cdr_worker, args=(s,asset_dir_list,sms_df,))


            file_process_pool.close()
            file_process_pool.join()

            
            print(str(user_id),"complete time: ", time.time() - start_time)
        IPDR_CONN1.close()
        
            
def deleting_inprocess_data(del_type,directory_path,del_keyword):
    if del_type == 0:
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                if del_keyword in file:
                    os.remove(os.path.join(root, file))
                    print(f"Deleted file {os.path.join(root, file)}")

    if del_type==1:
        for root, dirs, files in os.walk(directory_path, topdown=False):
            for dir in dirs:
                if del_keyword in dir:
                    shutil.rmtree(os.path.join(root, dir))
                    print(f"Deleted directory {os.path.join(root, dir)}")

def start():
    try:
        # license_data = open(os.path.join(os.getcwd(),'files',"vpn_address.txt"),"r").readlines()
        IPDR_CONN2 = ipdr_conn()
        if 1 == 1:
            meta_cursor_failed_files = IPDR_CONN2.cursor()
            meta_cursor_failed_files.execute("SELECT ID as file_id,case_id,file_type FROM files_meta_details WHERE uploadStatus = 1")
            result_meta_cursor_failed_files = meta_cursor_failed_files.fetchall()

            if result_meta_cursor_failed_files:
                    print("Failover Management Start")
                    for failed_file_row in result_meta_cursor_failed_files:
                        failed_file_id = failed_file_row[0]
                        failed_file_case_id = failed_file_row[1]
                        delete_query = 'file_id:'+str(failed_file_id)
                        ipdr_details_solr.delete(q=delete_query)
                        ipdr_details_solr.commit()
                        del_keyword =str(failed_file_case_id)+"_"+str(failed_file_id)
                        deleting_inprocess_data(0,BULKER_DIR,del_keyword)
                        deleting_inprocess_data(0,DST_BULKER_DIR,del_keyword)
                        deleting_inprocess_data(1,FILE_EXIT_DIR,del_keyword)
                        deleting_inprocess_data(1,os.path.join(CURR_WORK_DIR,'temp'),del_keyword)
                        
                        update_failover(IPDR_CONN2,failed_file_id,failed_file_case_id)
                    print("Failover Management End")
            
            process_json_file= open('database.config','r').read()
            data_config = json.loads(process_json_file)
            total_process = data_config['fileCount']
            
            try:
                bulk_process1 = mp.Process(target=bulk_solr_update, args=(BULKER_DIR,))
                bulk_process1.start()
            except:
                logging.error('BULK Save Error: '+str(traceback.format_exc()))
            
        meta_cursor_users = IPDR_CONN2.cursor()
        meta_cursor_users.execute("SELECT ID as user_id FROM users")
        users_result = meta_cursor_users.fetchall()
        if users_result:
            for user_row in users_result:
                user_id  = user_row[0]
                asset_dir_list = []
                for p_counter in range(0,int(total_process)):
                    asset_dir_list.append(asset_builder(str(user_id)+"_"+str(p_counter)))
                try:
                    file_finder_process = mp.Process(target=file_finder_executor, args=(data_config,asset_dir_list,user_id,))
                    file_finder_process.start()
                    # file_finder_executor(data_config,asset_dir_list,user_id)
                except:
                    logging.error('file_finder_executor Error: '+str(traceback.format_exc()))
                    pass  
        else:
            print("User Not Found!")
        IPDR_CONN2.close()
    except:
        logging.error('Error: '+str(traceback.format_exc()))

if __name__=="__main__":
    start()