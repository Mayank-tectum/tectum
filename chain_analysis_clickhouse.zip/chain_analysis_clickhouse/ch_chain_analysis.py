# import pandas as pd
# import pysolr
# from datetime import timedelta
# import datetime
# from collections import defaultdict
# import sys


# def find_max_connected_chains_per_start(connections):
#     adjacency_list = defaultdict(list)
#     for a, b in connections:
#         adjacency_list[a].append(b)
#         adjacency_list[b].append(a)

#     def dfs(current, visited, path, start):
#         visited.add(current)
#         path.append(current)
        
#         if len(path) > 1:  # Only consider chains with more than 1 link
#             unique_nodes_in_path = set(path)
#             num_unique_nodes = len(unique_nodes_in_path)
#             if num_unique_nodes > len(set(max_chains[start])):
#                 max_chains[start] = path[:]
#             elif num_unique_nodes == len(set(max_chains[start])) and len(path) > len(max_chains[start]):
#                 max_chains[start] = path[:]
        
#         for neighbor in adjacency_list[current]:
#             if neighbor not in visited:
#                 dfs(neighbor, visited, path, start)
        
#         path.pop()
#         visited.remove(current)

#     # Dictionary to store max chains for each starting node
#     max_chains = defaultdict(list)
#     unique_nodes = set([item for sublist in connections for item in sublist])
#     for node in unique_nodes:
#         dfs(node, set(), [], node)
    
#     # Convert to list of lists format
#     max_chains_list_of_lists = {}
#     for start, chain in max_chains.items():
#         chain_list_of_lists = [[chain[i], chain[i+1]] for i in range(len(chain)-1)]
#         max_chains_list_of_lists[start] = chain_list_of_lists

#     return max_chains, max_chains_list_of_lists

# def perform_chain_analysis(df, duration):
#     df['start_date_time'] = pd.to_datetime(df['start_date_time'])
#     connections = {}
#     for index, row in df.iterrows():
#         a_party = row['a_party']
#         b_party = row['b_party']
#         start_date_time = row['start_date_time']

#         if a_party in connections:
#             prev_connections = connections[a_party]
#             if isinstance(prev_connections, list):
#                 for prev_b_party, prev_start_time in prev_connections:
#                     # print(f"{b_party} != {prev_b_party} and {start_date_time, prev_start_time} <= {prev_start_time + timedelta(minutes=200)}")
#                     if b_party != prev_b_party and start_date_time <= prev_start_time + timedelta(minutes=duration):
#                         prev_connections.append((b_party, start_date_time))
#                         break
#             else:
#                 connections[a_party] = [(b_party, start_date_time)]
#         else:
#             connections[a_party] = [(b_party, start_date_time)]

#     final_list = []
#     for a_party, connected_parties in connections.items():
#         for b_party, _ in connected_parties:
#             final_list.append([a_party, b_party])

#     return final_list

# def solr_connection_query(case_id):
#     # Solr connection settings
#     solr_url = 'http://192.168.1.175:8989/solr'
#     solr_core = 'ipdr_details'

#     # Create a connection to Solr
#     solr = pysolr.Solr(f'{solr_url}/{solr_core}')
#     data_query = f'case_id:{case_id}'
#     results = solr.search(data_query, rows=1000)
#     docs = [dict(doc) for doc in results.docs]
#     df = pd.DataFrame(docs)
#     df['start_date_time'] = pd.to_datetime(df['start_date_time'], unit='s')
#     df['end_date_time'] = pd.to_datetime(df['end_date_time'], unit='s')
#     return df

# if __name__ == "__main__":
#     args = sys.argv
#     if len(args) >= 3:
          
#         case_id = args[1]
#         phone_no = args[2]
#         duration_in_min = int(args[3])
        
#         df = solr_connection_query(case_id)
#         # print('-+-'*20)

#         chain_list = perform_chain_analysis(df, duration_in_min)
#         list_chains, list_of_list_chain = find_max_connected_chains_per_start(chain_list)
#         # Print the final list of connected parties
#         # print("[+]Chain List with single node")
#         for start, chain in list_chains.items():
#             # print(f" start {start}:\t allNumbers{chain}")
#             print(f'"start"  : {start} ,  allNumbers : [{", ".join(chain)}]')
            
        
#         # print("\n List with both node of Connected Parties:")
#         # for start, chain in list_of_list_chain.items():
#         #     # print(f"[i] Starting from {start}:\t{chain}")
#     else:
#         print("[+] Sample command :- 166 30")
#         print(f"{args[0]} <case_id> <duration in minutes>") 

from collections import defaultdict
from graph import DirectedGraph
import json
import sys
import clickhouse_connect
import pandas as pd

json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table = 'default.new_dossier'

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
# click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        # {
        #     "url": f"http://{click_house_node4}",
        #     "port": CLICKHOUSE_PORT,
        #     "username": CLICKHOUSE_USER,
        #     "password": CLICKHOUSE_PASSWORD,
        # }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception as e:
        print(e)
        return None

def get_data_from_clickhouse(phone_no):
    """
    Fetches data from ClickHouse for a given phone number.
    """
    client = create_client()
    query = f"""
    SELECT a_party, b_party, start_date_time, end_date_time
    FROM ipdr_details 
    WHERE phone_no = '{phone_no}'
    LIMIT 100
    """  
    print(query)
    result = client.query(query).result_rows

    if not result:
        return None  

    df = pd.DataFrame(result, columns=['a_party', 'b_party', 'start_date_time', 'end_date_time'])
    df = df.dropna(subset=['b_party']).drop_duplicates(subset=['b_party'], keep='first')
    df = df[~df['b_party'].str.contains('-', na=False)]  
    df['start_date_time'] = pd.to_datetime(df['start_date_time'], unit='s')
    df['end_date_time'] = pd.to_datetime(df['end_date_time'], unit='s')

    return df

def find_max_connected_chains_per_start(connections):
    adjacency_list = defaultdict(list)
    for connection in connections:
        a,b = connection[:2]
        adjacency_list[a].append(b)
        adjacency_list[b].append(a)

    def dfs(current, visited, path, start):
        visited.add(current)
        path.append(current)
        
        if len(path) > 1:  # Only consider chains with more than 1 link
            unique_nodes_in_path = set(path)
            num_unique_nodes = len(unique_nodes_in_path)
            if num_unique_nodes > len(set(max_chains[start])):
                max_chains[start] = path[:]
            elif num_unique_nodes == len(set(max_chains[start])) and len(path) > len(max_chains[start]):
                max_chains[start] = path[:]
        
        for neighbor in adjacency_list[current]:
            if neighbor not in visited:
                dfs(neighbor, visited, path, start)
        
        path.pop()
        visited.remove(current)

    # Dictionary to store max chains for each starting node
    max_chains = defaultdict(list)
    unique_nodes = set([item for sublist in connections for item in sublist])
    for node in unique_nodes:
        dfs(node, set(), [], node)
    
    # Convert to list of lists format
    max_chains_list_of_lists = {}
    for start, chain in max_chains.items():
        chain_list_of_lists = [[chain[i], chain[i+1]] for i in range(len(chain)-1)]
        max_chains_list_of_lists[start] = chain_list_of_lists

    return max_chains, max_chains_list_of_lists

def find_b_parties(df, duration, visited=None, final_list=None, depth=10, max_depth=3):
    """
    Recursively find b_parties for each number but limit recursion depth to avoid infinite loop.
    """

    if df is None or df.empty:
        print("DataFrame is empty")
        return final_list

    if visited is None:
        visited = set()
    if final_list is None:
        final_list = []

    df['start_date_time'] = pd.to_datetime(df['start_date_time'])
    connections = {}

    # Collect all a_party -> b_party mappings
    for index, row in df.iterrows():
        a_party = row['a_party']
        b_party = row['b_party']
        start_date_time = row['start_date_time']

        if a_party in connections:
            connections[a_party].append((b_party, start_date_time))
        else:
            connections[a_party] = [(b_party, start_date_time)]

    new_numbers = set()  # Collect newly found numbers
    for a_party, connected_parties in connections.items():
        for b_party, _ in connected_parties:
            if [a_party, b_party] not in final_list:
                final_list.append([a_party, b_party,depth])
                new_numbers.add(b_party)

    # Stop recursion after reaching max_depth
    if depth >= max_depth:
        return final_list

    # Recursively process only first-level b_parties (not deeper)
    for num in new_numbers:
        if num not in visited:
            visited.add(num)
            new_df = get_data_from_clickhouse(num)  
            if new_df is not None:
                find_b_parties(new_df, duration, visited, final_list, depth=depth+1, max_depth=max_depth)
            else:
                print("No records found for", num)

    return final_list

if __name__ == '__main__':
    max_length_cycle = []
    max = 0
    args = sys.argv
    if len(args) >= 1:
      
        final_list = [['7080000555', '9919372651', 0], ['7080000555', '8009007999', 0], ['7080000555', '9044779746', 0], ['7080000555', '9794847999', 0], ['9044779746', '7068148723', 1], ['9044779746', '7570926754', 1], ['9044779746', '7080000555', 1], ['9044779746', '8400300446', 1], ['9044779746', '7754852104', 1], ['9044779746', '7607091747', 1], ['7080000555', '9919372651', 2], ['7080000555', '8009007999', 2], ['7080000555', '9044779746', 2], ['7080000555', '9794847999', 2], ['9919372651', '8062595837', 3], ['9919372651', '9041483295', 3], ['9919372651', '52263', 3], ['9919372651', '7754852104', 3], ['9919372651', '9140394195', 3], ['9919372651', '9621555588', 3], ['9919372651', '8887565166', 3], ['9919372651', '8894028771', 3], ['9919372651', '6395675645', 3], ['9919372651', '9451047786', 3], ['9794847999', '9956721722', 3], ['9794847999', '6386815608', 3], ['9794847999', '8299771605', 3], ['9794847999', '9140899670', 3], ['9794847999', '7080000555', 3], ['9794847999', '9935235686', 3], ['9794847999', '9450299101', 3], ['9794847999', '8009244447', 3], ['9794847999', '9792485772', 3], ['8009007999', '7080000555', 3], ['8009007999', '9305474472', 3], ['8009007999', '9554437956', 3], ['7068148723', '8102061500', 2], ['7068148723', '8000457511', 2], ['7068148723', '9335401815', 2], ['7068148723', '6386153625', 2], ['7068148723', '7387649153', 2], ['7068148723', '8779843308', 2], ['7068148723', '9044779746', 2], ['7068148723', '6261122094', 2], ['9335401815', '9872412024', 3], ['9335401815', '9621560000', 3], ['9335401815', '8173987777', 3], ['9335401815', '9451048387', 3], ['9335401815', '7388775555', 3], ['9335401815', '50000', 3], ['9335401815', '9621771111', 3], ['9335401815', '9559442459', 3], ['9335401815', '9839978237', 3], ['9335401815', '7705939110', 3], ['9335401815', '9795919489', 3], ['9335401815', '9794920000', 3], ['9335401815', '9082434416', 3], ['9335401815', '9903386147', 3], ['9335401815', '9335101190', 3], ['9335401815', '9517034444', 3], ['9335401815', '9581755525', 3], ['9335401815', '8176020849', 3], ['9335401815', '9867498676', 3], ['9335401815', '9129513372', 3], ['9335401815', '9517576709', 3], ['9335401815', '9794580000', 3], ['9335401815', '9005838892', 3], ['9335401815', '9519791664', 3], ['9335401815', '8736852676', 3], ['9335401815', '9506528282', 3], ['9335401815', '9511114770', 3], ['9335401815', '7084442427', 3], ['9335401815', '7318543333', 3], ['9335401815', '7002013479', 3], ['9335401815', '9335081873', 3], ['9335401815', '9935954087', 3], ['7387649153', '52263', 3], ['7387649153', '9120137280', 3], ['7387649153', '8737883991', 3], ['7387649153', '9621330812', 3], ['6386153625', '8433346543', 3], ['6386153625', '7068148723', 3], ['6261122094', '7068148723', 3], ['8102061500', '7068148723', 3]]
        graph_dict = {}
        for source, destination, _ in final_list:
            if source not in graph_dict:
                graph_dict[source] = set()  
            graph_dict[source].add(destination)  
        graph_dict = {k: list(v) for k, v in graph_dict.items()}
        dgraph = DirectedGraph(graph_dict)
        print("Original graph: {}\n".format(dgraph))
        longest_chain,all_chains = dgraph.find_all_chains()
        print('+'*200)  
        print("Longest Chain in the Graph:", longest_chain)
        print('+'*200)  
        for index, chain in enumerate(all_chains):
            print(f"Chain {index + 1}: {chain}")
        print()
        print('+'*200+"\n")    
        detected_cycles = dgraph.find_cycles(max_depth=10, max_repeats=2)
        for index,cycle in enumerate(detected_cycles):
            if max <= len(cycle):
                max_length_cycle = cycle
                max = len(cycle)
            print(f"Cycle {index+1}: {cycle} ")

    else:
        print("[+] Sample command :- 1234567890 30")

        print(f"{args[0]} <phone_no> <duration in minutes>") 
    print(max_length_cycle)    