import sys
import clickhouse_connect
import pandas as pd
import json

json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table = 'default.new_dossier'

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception as e:
        print(e)
        return None
    
def get_max_sub_day(start_time,end_time):
    client = create_client()
    query = f"""SELECT phone_no AS Phone_No, 
                COUNT(DISTINCT cell_id) AS cell_id_count,
                imei_no AS a_party_imei_no, 
                imsi_no AS a_party_imsi_no,
                MAX(a_party_name) AS a_party_name,  
                MAX(a_party_tc_name) AS a_party_tc_name,
                SUM(toInt32(session_duration)) AS total_duration
                FROM ipdr_details
                WHERE start_date_time >= '{start_time}' 
                AND end_date_time <= '{end_time}'
                AND phone_no REGEXP '^[0-9]+$' 
                AND LENGTH(phone_no) >= 10   
                GROUP BY phone_no, imei_no, imsi_no  
                ORDER BY cell_id_count DESC
                LIMIT 10

            """
    result = client.query(query)
                
    if not result.result_rows:
        print('No records found')
        return None

    df = pd.DataFrame(result.result_rows, columns=['Phone_No','Latched_Cell_ID_Count','Imei_Aparty','Imsi_Aparty','Aparty_Name','Aparty_TC_Name','Total_duration_in_sec'])
    df.to_csv('/home/user/Desktop/subscriber_scripts/maximum_subscriber_cellid_count.csv', index=False)
    print("successfully written to csv")

if __name__ == '__main__':
   
    if len(sys.argv) != 3:
        print("Usage: python script.py <start_time> <end_time>")
        sys.exit(1)

    start_time = sys.argv[1]
    end_time = sys.argv[2]

    get_max_sub_day(start_time, end_time)

# query to find max subscriber cellid count for a day

# SELECT phone_no, COUNT(DISTINCT cell_id) AS cell_id_count
# FROM ipdr_details
# WHERE start_date_time >= '1738348200' 
#   AND end_date_time <= '1739212200'
#   AND phone_no REGEXP '^[0-9]+$'  
#   AND LENGTH(phone_no) >= 10      
# GROUP BY phone_no
# ORDER BY cell_id_count DESC
# LIMIT 10;


# TOP 10 subscribers with the most number of cell towers visited

# SELECT phone_no, 
#        COUNT(DISTINCT cell_id) AS cell_id_count
# FROM ipdr_details
# WHERE phone_no REGEXP '^[0-9]+$'  
#   AND LENGTH(phone_no) >= 10      
# GROUP BY phone_no
# ORDER BY cell_id_count DESC
# LIMIT 10;



# query to find max subscriber cellid,b_party count for a day

# SELECT phone_no, 
#        COUNT(DISTINCT cell_id) AS cell_id_count, 
#        COUNT(DISTINCT b_party) AS b_party_count
# FROM act.ipdr_details
# WHERE start_date_time >= '1738348200' 
#   AND end_date_time <= '1739212200'
#   AND phone_no REGEXP '^[0-9]+$'  
#   AND LENGTH(phone_no) >= 10      
# GROUP BY phone_no
# ORDER BY cell_id_count DESC, b_party_count DESC
# LIMIT 10;