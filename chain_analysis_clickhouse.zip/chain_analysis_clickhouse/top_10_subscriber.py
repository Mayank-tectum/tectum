import sys
import clickhouse_connect
import pandas as pd
import json

json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table = 'default.new_dossier'

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception as e:
        print(e)
        return None
    
def top_10_subscriber():
    
    client = create_client()
    query = f"SELECT phone_no, COUNT(DISTINCT cell_id) AS cell_id_count
                FROM ipdr_details
                WHERE phone_no REGEXP '^[0-9]+$' 
                AND length(phone_no) >= 10 
                GROUP BY phone_no
                ORDER BY cell_id_count DESC
                LIMIT 10
            "
    result = client.query(query)
                
    if not result.result_rows:
        print('No records found')
        return None

    df = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id_count'])
    df.to_csv('Top_10_cell_id_allover.csv', index=False)
    print("successfully written to csv")

if __name__ == '__main__':
   
    top_10_subscriber()