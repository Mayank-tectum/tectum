import sys
import clickhouse_connect
import pandas as pd
import json

json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table = 'default.new_dossier'

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception as e:
        print(e)
        return None
    
def get_service_count(start_time,end_time):
    client = create_client()
    query = f"""SELECT phone_no AS service_no, 
                COUNT(cdr_call_type) AS incoming_count 
                FROM ipdr_details 
                WHERE phone_no IN ('1000', '1004', '1010', '1012', '102', '1076', '1090', 
                   '111', '112', '1135', '121', '122', '123', '1234', '1270', '128', '132',
                   '135', '139', '144', '152', '1539', '155', '190', '1900', '1901', '1909', 
                   '1912', '1920', '1925', '1926', '1930', '1944', '1945', '1958', '1962', 
                   '199', '1990', '1991', '1999', '200', '2184', '222', '2223', '2295', 
                   '2300', '250', '2512', '2901', '2939', '2942', '300', '321', '3231', 
                   '3350', '3505', '3538', '3768', '3999', '4011', '4121', '414', '464', 
                   '4701', '4724', '4727', '4735', '4758', '4883', '507', '508', '5247', 
                   '526', '57273021','57273170', '57273200', '57273201', '57575002', '57575022',
                   '57575094','57575108', '57575109', '57575118', '57575128', '57575151', 
                   '57575174', '57575252', '57575342', '57575353', '57575475', '57575480', 
                   '57575566', '57575610', '57575625', '57575701', '57575711', '57575728', 
                   '57575748', '57575751', '57575752', '57575753', '57575754', '57575755', 
                   '57575782', '57575785', '57575787', '57575788', '57575793', '57575794', 
                   '57575795', '57575796', '57575888', '57799000', '57799236', '57799238', 
                   '7203', '7275', '7414', '7535', '7626', '8047', '8090', '8111', '8520', 
                   '8536', '8563', '867', '8684', '8758', '8769', '8794', '888', '900', '9012', 
                   '909', '966', '1098', '112', '1211', '1392', '18001213203', '18001801551', 
                   '18001802877', '18001805220', '18001808752', '18008435145', '18008436455', 
                   '1800111555') AND start_time >= '{start_time}' AND end_time <= '{end_time}'
                    AND cdr_call_type = 'INCOMING' 
                    GROUP BY phone_no """
    result = client.query(query)
                
    if not result.result_rows:
        print('No records found')
        return None

    df = pd.DataFrame(result.result_rows, columns=['service_no','incoming_count'])
    df.to_csv('/home/user/Desktop/subscriber_scripts/service_number_count.csv', index=False)
    print("successfully written to csv")

if __name__ == '__main__':
   
    if len(sys.argv) != 3:
        print("Usage: python script.py <start_time> <end_time>")
        sys.exit(1)

    start_time = sys.argv[1]
    end_time = sys.argv[2]

    get_service_count(start_time, end_time)



    # """SELECT phone_no as service_no, 
    #             COUNT(cdr_call_type) as incoming_count 
    #         from ipdr_details where phone_no IN('112', '101', '102', '108', '1090', '1098', '1076', '1930', '1962', '14567','1920', '1944', '1945', '1912', '1010', '18001805220', '18001808752', '5224004402','18001802877','18001801551','18001213203','18008436455','1926','18008435145','1800111555','1925','1901','57575711','57575174','57575353','57575252','57575151','57575625','57575108','57575022','57575754','57575094','57273170','57575701','5757537X','57575566','5757537X','57575566') AND start_time >= '{start_time}' AND end_time <= '{end_time}'
    #         AND cdr_call_type = 'INCOMING' GROUP BY phone_no """