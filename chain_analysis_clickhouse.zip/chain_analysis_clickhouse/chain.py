import pandas as pd
import pysolr
from datetime import timedelta
import datetime
from collections import defaultdict
import sys


def find_max_connected_chains_per_start(connections):
    adjacency_list = defaultdict(list)
    for a, b in connections:
        adjacency_list[a].append(b)
        adjacency_list[b].append(a)

    def dfs(current, visited, path, start):
        visited.add(current)
        path.append(current)
        
        if len(path) > 1:  # Only consider chains with more than 1 link
            unique_nodes_in_path = set(path)
            num_unique_nodes = len(unique_nodes_in_path)
            if num_unique_nodes > len(set(max_chains[start])):
                max_chains[start] = path[:]
            elif num_unique_nodes == len(set(max_chains[start])) and len(path) > len(max_chains[start]):
                max_chains[start] = path[:]
        
        for neighbor in adjacency_list[current]:
            if neighbor not in visited:
                dfs(neighbor, visited, path, start)
        
        path.pop()
        visited.remove(current)

    # Dictionary to store max chains for each starting node
    max_chains = defaultdict(list)
    unique_nodes = set([item for sublist in connections for item in sublist])
    for node in unique_nodes:
        dfs(node, set(), [], node)
    
    # Convert to list of lists format
    max_chains_list_of_lists = {}
    for start, chain in max_chains.items():
        chain_list_of_lists = [[chain[i], chain[i+1]] for i in range(len(chain)-1)]
        max_chains_list_of_lists[start] = chain_list_of_lists

    return max_chains, max_chains_list_of_lists

def perform_chain_analysis(df, duration):
    df['start_date_time'] = pd.to_datetime(df['start_date_time'])
    connections = {}
    for index, row in df.iterrows():
        a_party = row['a_party']
        b_party = row['b_party']
        start_date_time = row['start_date_time']

        if a_party in connections:
            prev_connections = connections[a_party]
            if isinstance(prev_connections, list):
                for prev_b_party, prev_start_time in prev_connections:
                    # print(f"{b_party} != {prev_b_party} and {start_date_time, prev_start_time} <= {prev_start_time + timedelta(minutes=200)}")
                    if b_party != prev_b_party and start_date_time <= prev_start_time + timedelta(minutes=duration):
                        prev_connections.append((b_party, start_date_time))
                        break
            else:
                connections[a_party] = [(b_party, start_date_time)]
        else:
            connections[a_party] = [(b_party, start_date_time)]

    final_list = []
    for a_party, connected_parties in connections.items():
        for b_party, _ in connected_parties:
            final_list.append([a_party, b_party])

    return final_list

def solr_connection_query(case_id):
    # Solr connection settings
    solr_url = 'http://192.168.1.175:8989/solr'
    solr_core = 'ipdr_details'

    # Create a connection to Solr
    solr = pysolr.Solr(f'{solr_url}/{solr_core}')
    data_query = f'case_id:{case_id}'
    results = solr.search(data_query, rows=1000)
    docs = [dict(doc) for doc in results.docs]
    df = pd.DataFrame(docs)
    df['start_date_time'] = pd.to_datetime(df['start_date_time'], unit='s')
    df['end_date_time'] = pd.to_datetime(df['end_date_time'], unit='s')
    return df

if __name__ == "__main__":
    args = sys.argv
    if len(args) >= 3:
          
        case_id = args[1]
        phone_no = args[2]
        duration_in_min = int(args[3])
        
        df = solr_connection_query(case_id)
        # print('-+-'*20)

        chain_list = perform_chain_analysis(df, duration_in_min)
        list_chains, list_of_list_chain = find_max_connected_chains_per_start(chain_list)
        # Print the final list of connected parties
        # print("[+]Chain List with single node")
        for start, chain in list_chains.items():
            # print(f" start {start}:\t allNumbers{chain}")
            print(f'"start"  : {start} ,  allNumbers : [{", ".join(chain)}]')
            
        
        # print("\n List with both node of Connected Parties:")
        # for start, chain in list_of_list_chain.items():
        #     # print(f"[i] Starting from {start}:\t{chain}")

    else:
        print("[+] Sample command :- 166 30")
        print(f"{args[0]} <case_id> <duration in minutes>") 


        