"""
This script processes IPDR (Internet Protocol Detail Record) details and updates a ClickHouse database with phone number information.
Modules:
    - datetime: Provides classes for manipulating dates and times.
    - json: Provides methods for parsing JSON.
    - time: Provides time-related functions.
    - clickhouse_connect: Provides methods for connecting to ClickHouse.
    - pandas: Provides data structures and data analysis tools.
Functions:
    - create_client(): Creates and returns a ClickHouse client.
    - check_phone_no(df): Checks if phone numbers in the given DataFrame exist in the 'dossier_dis' table.
    - fetch_first_seen(phone_nos): Fetches 'first_seen' values for the given phone numbers from the 'dossier_temp' table.
    - update_last_seen(matched_data): Updates the 'last_seen' field for matched phone numbers in the 'dossier_temp' table.
    - insert_new_data(new_numbers): Inserts new phone number data into the 'dossier_dis' table.
    - phone_no_with_dossier(dossier_chunk, idf_chunk): Matches and separates phone numbers between dossier and IPDR chunks.
    - fetch_numbers_from_ipdr_details(chunk_size): Fetches phone numbers from the 'ipdr_details' table in chunks.
    - fetch_numbers_from_dossier(chunk_size): Fetches phone numbers from the 'dossier_dis' table in chunks.
    - process_ipdr_details(): Processes IPDR details by matching and updating phone numbers in the database.
    - fetch_recent_last_seen(): Fetches the most recent 'last_seen' timestamp from the 'dossier_temp' table.
Usage:
    The script reads database configuration from 'database.config', connects to ClickHouse, and processes IPDR details to update phone number information in the database.
"""
import datetime
import json
import logging.config
import clickhouse_connect
import pandas as pd
import logging
import traceback

logging.basicConfig(filename='dossier.log',level=logging.INFO,format="%(asctime)s - %(levelname)s - %(message)s")

json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table1 = 'dossier_temp'
table2 = 'dossier_dis'

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception as e:
        logging.error("Error creating Clickhouse client: %s",str(e))

def check_phone_no(df):
    try:
        phone_nos = df['phone_no'].tolist()

        if not phone_nos:
            return {}

        client = create_client()
        phone_nos_str = ','.join([f"'{phone_no}'" for phone_no in phone_nos])

        query = f"""
            SELECT phone_no
            FROM dossier_dis
            WHERE phone_no IN ({phone_nos_str})
        """

        result = client.query(query)
        return {row[0] for row in result.result_rows}
    except Exception as e:
        logging.error("Error in check_phone_no: %s",str(e))


def fetch_first_seen(phone_nos):
    """Fetch first_seen values for the given phone numbers from the database."""
    try:
        if not phone_nos:
            return {}

        client = create_client()
        phone_nos_str = ','.join([f"'{phone_no}'" for phone_no in phone_nos])

        query = f"""
            SELECT phone_no, first_seen
            FROM dossier_dis
            WHERE phone_no IN ({phone_nos_str})
        """
        
        result = client.query(query)                                                                                                                                              
        
        return {row[0]: row[1] for row in result.result_rows}
    except Exception as e:
        logging.error("Error in fetch_first_seen: %s",str(e))
    

def update_last_seen(matched_data):
    try:
        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        matched_data['phone_no'] = matched_data['phone_no'].str.replace("’", "") 
        matched_data['name'] = matched_data['name'].fillna('Not Found')
        matched_data['tc_name'] = matched_data['tc_name'].fillna('Not Found')
        matched_data['city'] = matched_data['city'].fillna('Not Found')
        matched_data['state'] = matched_data['state'].fillna('Not Found')
        phone_nos = matched_data['phone_no'].tolist()
        first_seen_dict = fetch_first_seen(phone_nos)
        matched_data['first_seen'] = matched_data['phone_no'].map(first_seen_dict).fillna(current_time)
        matched_data['last_seen'] = current_time
        df_to_insert = matched_data[['phone_no', 'name', 'first_seen','last_seen','tc_name','city','state']]  
        df = df_to_insert[sorted(df_to_insert.columns)].astype(str)
        print(f"{len(df)} records inserted in update_last_seen.")
        client=create_client()
        client.insert(table1, df.to_records(index=False).tolist(),column_names=list(df.columns))
    except Exception as e:
        logging.error("Error in updating last seen data: %s",str(e))

   
def insert_new_data(new_numbers):
    try:
        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        new_numbers['phone_no'] = new_numbers['phone_no'].str.replace("’", "") 
        new_numbers['name'] = new_numbers['name'].fillna('Not Found')
        new_numbers['first_seen'] = current_time 
        new_numbers['last_seen'] = 'Not Found'
        new_numbers['tc_name'] = new_numbers['tc_name'].fillna('Not Found')
        new_numbers['city'] = new_numbers['city'].fillna('Not Found')
        new_numbers['state'] = new_numbers['state'].fillna('Not Found')
        df = new_numbers[sorted(new_numbers.columns)].astype(str)
        existing_phone_nos=check_phone_no(df)
        df_unique = df[~df['phone_no'].isin(existing_phone_nos)]
        if len(df_unique) > 0:
            print(df_unique.columns)
            print(f"new {len(df_unique)} records inserted.")
            client=create_client()
            client.insert(table2, df_unique.to_records(index=False).tolist(),column_names=list(df_unique.columns))
    except Exception as e:
        logging.error("Error in inserting new data: %s",str(e))


def find_match_unmatched_data(dossier_chunk, idf_chunk):
    try:       
        matched_chunk = dossier_chunk.merge(idf_chunk, on='phone_no', how='inner').drop_duplicates(subset=['phone_no'])
        unmatched_chunk = idf_chunk.merge(dossier_chunk, on='phone_no', how='left', indicator=True).query('_merge == "left_only"').drop(columns=['_merge']).drop_duplicates(subset=['phone_no'])
        return matched_chunk, unmatched_chunk
    
    except Exception as e:
        logging.error("Error in find_match_unmatched_data: %s",str(e))


def fetch_numbers_from_ipdr_details(recent_last_seen_epoch,chunk_size=10000000):
    try:
        client = create_client()
        if recent_last_seen_epoch is not None:
            query = f"""
            SELECT phone_no, a_party_name ,a_party_tc_name,a_party_city,a_party_state
            FROM ipdr_details 
            WHERE start_date_time >= '{recent_last_seen_epoch}'
            """
            offset = 0
            while True:

                chunk_query = f"{query} LIMIT {chunk_size} OFFSET {offset}"
                print(chunk_query)
                result = client.query(chunk_query)
                
                if not result.result_rows:
                    break  
                
                df_chunk = pd.DataFrame(result.result_rows, columns=['phone_no', 'name','tc_name','city','state'])
                print(f"ipdr records before drop duplicate:{len(df_chunk)}")
                df_chunk.drop_duplicates(subset=['phone_no'],inplace=True)
                print(f"ipdr records after drop duplicate:{len(df_chunk)}")
                yield df_chunk  
                offset += chunk_size

    except Exception as e:
        logging.error("Error in fetch_numbers_from_ipdr_details: %s",str(e))

def fetch_numbers_from_dossier(chunk_size=500000):
    try:
        client = create_client()
        query = "SELECT phone_no FROM dossier_dis"

        offset = 0
        while True:

            chunk_query = f"{query} LIMIT {chunk_size} OFFSET {offset}"
            print(chunk_query)
            result = client.query(chunk_query)

            if not result.result_rows:
                break  
            
            df_chunk = pd.DataFrame(result.result_rows, columns=['phone_no'])
            print(f"dossier records before drop duplicates:{len(df_chunk)}")
            df_chunk.drop_duplicates(subset=['phone_no'],inplace=True)
            print(f"dossier records after drop duplicates:{len(df_chunk)}")
            yield df_chunk  
            offset += chunk_size

    except Exception as e:
        logging.error("Error in fetch_numbers_from_dossier: %s",str(e))
        
def process_ipdr_details(recent_last_seen_epoch):
    try:
        for dossier_chunk in fetch_numbers_from_dossier():

            for idf_chunk in fetch_numbers_from_ipdr_details(recent_last_seen_epoch):

                matched_data,unmatched_data=find_match_unmatched_data(dossier_chunk, idf_chunk)
                print(f"matched_data:{len(matched_data)} unmatched_data:{len(unmatched_data)}")

                if not matched_data.empty:
                    update_last_seen(matched_data)
            
                if not unmatched_data.empty:
                    insert_new_data(unmatched_data)

    except Exception as e:
        logging.error("Error processing IPDR details: %s",str(e))

def fetch_recent_last_seen():
    try:
        client = create_client()
        query = f""" 
        SELECT
        phone_no,
        parseDateTimeBestEffortOrNull(last_seen) AS recent_last_seen
        FROM dossier_temp
        ORDER BY recent_last_seen DESC
        LIMIT 1
        """
        result = client.query(query)
        
        if result:
            last_seen_str = result.result_rows[0][0] 
            print("last_seen_str:",last_seen_str)
            last_seen_dt = datetime.datetime.strptime(last_seen_str, '%Y-%m-%d %H:%M:%S')
            epoch_time = int(last_seen_dt.timestamp())
            return epoch_time
        logging.info("no last_seen found in dossier_temp")
        return None
    except Exception as e:
        logging.error("Error fetching recent last_seen: %s",str(e))
        logging.error(traceback.format_exc())

recent_last_seen_epoch = fetch_recent_last_seen()
process_ipdr_details(recent_last_seen_epoch)
print("Execution Completed")
# def phone_no_with_dossier(dossier_chunk, ipdr_chunk):
#     dossier_set = set(dossier_chunk['phone_no'])  
    
#     matched_chunk = ipdr_chunk[ipdr_chunk['phone_no'].isin(dossier_set)]
#     unmatched_chunk = ipdr_chunk[~ipdr_chunk['phone_no'].isin(dossier_set)]
    
#     return matched_chunk.drop_duplicates(subset=['phone_no']), unmatched_chunk.drop_duplicates(subset=['phone_no'])









import datetime
import json
import logging.config
import clickhouse_connect
import pandas as pd
import logging
import traceback

logging.basicConfig(filename='dossier.log',level=logging.INFO,format="%(asctime)s - %(levelname)s - %(message)s")

json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table = 'default.new_dossier'

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception as e:
        logging.error("Error creating Clickhouse client: %s",str(e))

def chunk_list(data_list, chunk_size):
    for i in range(0, len(data_list), chunk_size):
        yield data_list[i:i + chunk_size]


def check_phone_no(df):
    try:
        phone_nos = df['phone_no'].tolist()
        data = []

        if not phone_nos:
            return pd.DataFrame(columns=['phone_no', 'cell_id', 'last_seen'])
        client = create_client()

        chunk_size = 10000 
        for chunk in chunk_list(phone_nos, chunk_size):
            phone_nos_str = ','.join([f"'{phone_no}'" for phone_no in chunk])
            query = f"""
                SELECT phone_no, cell_id, last_seen
                FROM default.new_dossier
                WHERE phone_no IN ({phone_nos_str})
            """

            result = client.query(query)
            for row in result.result_rows:
                data.append(row)
        return pd.DataFrame(data, columns=['phone_no', 'cell_id', 'last_seen'])

    except Exception as e:
        logging.error("Error in check_phone_no: %s", str(e))
        return pd.DataFrame(columns=['phone_no', 'cell_id', 'last_seen'])


def insert_filtered_data(new_df, df):
    try:
        new_df = new_df.astype(str)
        df = df.astype(str)
        new_df = new_df.dropna(subset=['phone_no'])
        df = df.dropna(subset=['phone_no'])

        if 'cell_id' in df.columns:
            df = df.rename(columns={'cell_id': 'cell_id_old', 'last_seen': 'last_seen_old'})
        if 'cell_id' in new_df.columns:
            new_df = new_df.rename(columns={'cell_id': 'cell_id_new', 'last_seen': 'last_seen_new'})

        df['last_seen_old'] = pd.to_datetime(df['last_seen_old'], unit='s')
        new_df['last_seen_new'] = pd.to_datetime(new_df['last_seen_new'], unit='s')

        merged_df = df.merge(new_df, on='phone_no', how='inner')
        filtered_df = merged_df[(merged_df['cell_id_old'] != merged_df['cell_id_new']) | ((merged_df['last_seen_new'] - merged_df['last_seen_old']).dt.total_seconds() >= 3600) ]
        phone_nos_to_insert = filtered_df['phone_no'].tolist()
        df_to_insert = df[df['phone_no'].isin(phone_nos_to_insert)]
        print("df_to_insert =>",df_to_insert.columns)
        client = create_client()
        client.insert(table, df_to_insert.to_records(index=False).tolist(),column_names=list(df_to_insert.columns))
        print(f"Total {phone_nos_to_insert} Filtered Data Inserted.")
    except Exception as e:
        logging.error("Error in update_last_seen: %s", str(e))


def insert_new_data(new_numbers):
    try:
        print("insert new data called.")
        new_numbers['phone_no'] = new_numbers['phone_no'].str.replace("’", "") 
        new_numbers = new_numbers.dropna(subset=['phone_no'])
        new_numbers['cell_id'] = new_numbers['cell_id'].fillna('Not Found')
        new_numbers['name'] = new_numbers['name'].fillna('Not Found')
        new_numbers['tc_name'] = new_numbers['tc_name'].fillna('Not Found')
        new_numbers['city'] = new_numbers['city'].fillna('Not Found')
        new_numbers['state'] = new_numbers['state'].fillna('Not Found') 

        new_numbers['first_seen'] = new_numbers['start_date_time']
        new_numbers['last_seen'] = new_numbers['end_date_time']
        new_numbers = new_numbers.drop(columns=['start_date_time', 'end_date_time'])

        df = new_numbers[sorted(new_numbers.columns)].astype(str)

        new_df=check_phone_no(df)
        print("matched records count=>",len(new_df))
        df_unique = pd.DataFrame()

        if not new_df.empty:  
            df_unique = new_numbers[~new_numbers['phone_no'].isin(new_df['phone_no'])]
            insert_filtered_data(new_df,df)
        else:
            print(f'empty table {len(df)} records inserted.')
            client=create_client()
            client.insert(table, df.to_records(index=False).tolist(),column_names=list(df.columns))   
        print("df_unique:",len(df_unique))    
        if len(df_unique) > 0:
            print(f"new {len(df_unique)} records inserted.")
            client=create_client()
            client.insert(table, df_unique.to_records(index=False).tolist(),column_names=list(df_unique.columns))
    except Exception as e:
        logging.error("Error in inserting new data: %s",str(e))
        
def fetch_numbers_from_ipdr_details(recent_last_seen_epoch,chunk_size=10000000):
    try:
        client = create_client()
        if recent_last_seen_epoch is not None:
            query = f"""
            SELECT phone_no,cell_id,a_party_name,a_party_tc_name,a_party_city,a_party_state,start_date_time, end_date_time
            FROM ipdr_details 
            WHERE start_date_time >= '{recent_last_seen_epoch}'
            """

            offset = 0
            while True:

                chunk_query = f"{query} LIMIT {chunk_size} OFFSET {offset}"
                print(chunk_query)
                result = client.query(chunk_query)
                
                if not result.result_rows:
                    break  
                
                df_chunk = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id', 'name','tc_name','city','state','start_date_time','end_date_time'])
                print(f"ipdr records before drop duplicate:{len(df_chunk)}")
                df_chunk.drop_duplicates(subset=['phone_no'],inplace=True)
                print(f"ipdr records after drop duplicate:{len(df_chunk)}")
                yield df_chunk  
                offset += chunk_size

    except Exception as e:
        logging.error("Error in fetch_numbers_from_ipdr_details: %s",str(e))


def fetch_recent_last_seen():
  
    client = create_client()
    query = """
       SELECT
        phone_no,
        parseDateTimeBestEffortOrNull(last_seen) AS recent_last_seen
        FROM default.dossier_temp
        ORDER BY recent_last_seen DESC
        LIMIT 1
    """

    result = client.query(query)
    if result:
        last_seen_str = result.result_rows[0][0]
        last_seen_str = str(last_seen_str).split('+')[0]
        print("last_seen_str:",last_seen_str)
        last_seen_dt = datetime.datetime.strptime(last_seen_str, '%Y-%m-%d %H:%M:%S')
        epoch_time = int(last_seen_dt.timestamp())
        return epoch_time
    logging.info("no last_seen found in new_dossier")

recent_last_seen_epoch = fetch_recent_last_seen()

if recent_last_seen_epoch is not None:
    for df_chunk in fetch_numbers_from_ipdr_details(recent_last_seen_epoch):
        if not df_chunk.empty:
            insert_new_data(df_chunk)
        else:
            logging.info("No new numbers to insert")