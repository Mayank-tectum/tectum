#!/usr/bin/env python3
import json
import clickhouse_connect

json_file = open('database.config', 'r').read()
database = json.loads(json_file)

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}
def run_update_query_on_all_nodes(update_query):

    for node in clickhouse_configs["nodes"]:
        try:
            client = clickhouse_connect.get_client(
                host=node["url"].replace("http://", ""),
                port=node["port"],
                username=node["username"],
                password=node["password"],
                compress=clickhouse_configs["is_use_gzip"],
            )

            # Execute the UPDATE query
            client.command(update_query)
            print(f"Successfully executed Update query on node {node['url']}")

        except Exception as error:
            print(f"Error executing UPDATE query on node {node['url']}: {error}")
            
def create_client():
    # Connect to ClickHouse
    client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
    )
    return client


def chunk_list(data_list, chunk_size):
    """Yield successive n-sized chunks from a list."""
    for i in range(0, len(data_list), chunk_size):
        yield data_list[i:i + chunk_size]

def find_name_difference(phone_list):
    client = create_client()
    if phone_list:

      for batch in chunk_list(phone_list, 5000):
        batch_str = ",".join([f"'{number}'" for number in batch])
        truecaller_query = f"""
            SELECT c_number, c_name 
            FROM truecaller_data_dis 
            WHERE c_number IN ({batch_str})
        """
        truecaller_results = client.query(truecaller_query)
        truecaller_data = {row[0]: row[1] for row in truecaller_results.result_rows}
        # print(truecaller_data)
        sdr_query = f"""
            SELECT phone_no, name 
            FROM u_subscriber_details_dis 
            WHERE phone_no IN ({batch_str})
        """
        sdr_results = client.query(sdr_query)
        sdr_data = {row[0]: row[1] for row in sdr_results.result_rows}
        # print(sdr_data)
    
        for mobile_no in batch:
            truecaller_name = truecaller_data.get(mobile_no)
            sdr_name = sdr_data.get(mobile_no)

            # If only sdr_name is found and not truecaller_name
            if sdr_name:
                update_query_sdr_only = f"""
                    ALTER TABLE dossier
                    UPDATE name = '{sdr_name}'
                    WHERE phone_no = '{mobile_no}'
                """
                run_update_query_on_all_nodes(update_query_sdr_only)

            # If only truecaller_name is found and not sdr_name
            if truecaller_name:
                update_query_tc_only = f"""
                    ALTER TABLE dossier
                    UPDATE tc_name = '{truecaller_name}'
                    WHERE phone_no = '{mobile_no}'
                """
                run_update_query_on_all_nodes(update_query_tc_only)
            # check for alert    
            # if truecaller_name and sdr_name and str(truecaller_name).lower() != str(sdr_name).lower():
    else:        #     print("!!!!!! Alert !!!!!! ")
        print("phone number list is empty.")

def empty_city_and_state():
    client = create_client()
    try:
        missing_query = """
            SELECT phone_no
            FROM dossier_dis
            WHERE city = 'NOT FOUND' AND state = 'NOT FOUND'
        """
        missing_records = client.query(missing_query)
        number_list = [number[0] for number in missing_records.result_rows]
        return number_list
    
    except Exception as e:
        print("Exception occur:",e)
        return

def update_city_and_state(numbers):
    client = create_client()

    if len(numbers) > 0:
        try:
            for batch in chunk_list(numbers, 5000):
                batch_str = ",".join([f"'{number}'" for number in batch])
                sdr_query = f"""
                    SELECT phone_no, city, state 
                    FROM u_subscriber_details_dis 
                    WHERE phone_no IN ({batch_str})
                """
                sdr_results = client.query(sdr_query)
                for row in sdr_results.result_rows:
                    phone_no = row[0]
                    city = row[1]
                    state = row[2]
                    
                    update_query = f"""
                        ALTER TABLE dossier
                        UPDATE city = '{city}', state = '{state}'
                        WHERE phone_no = '{phone_no}'
                    """
                    client.command(update_query)
            print("Batch update operations completed successfully.")

        except Exception as e:
            print("error:",e)  

def empty_name_numbers():
    """ Picking up the Phone_no who's name is not present in Dossier Table."""
    client = create_client()
    try:
        query = """
            SELECT phone_no
            FROM dossier_dis WHERE name ='NOT FOUND'
        """
        names = client.query(query)
        names_list = [name[0] for name in names.result_rows]
        return names_list
    except Exception as e:
        print("Exception occur:",e)
        return
    
phone_list=empty_name_numbers()
find_name_difference(phone_list)
numbers=empty_city_and_state()
update_city_and_state(numbers)

