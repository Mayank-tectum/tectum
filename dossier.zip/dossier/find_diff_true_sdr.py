import json
import clickhouse_connect

def create_client():    

    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    
    client = clickhouse_connect.get_client(
            host=database['click_house_node1'],
            port=database['click_house_port'],
            user=database['click_house_username'],
            password=database['click_house_password'],
            database=database['click_house_database'],
        )
    return client

json_file= open('database.config','r').read()
   

def chunk_list(data_list, chunk_size):
    """Yield successive n-sized chunks from a list."""
    for i in range(0, len(data_list), chunk_size):
        yield data_list[i:i + chunk_size]


def find_name_difference(df):
    client = create_client()
    unique_phone_numbers = df['phone_no'].tolist()
    
    if len(unique_phone_numbers) > 0:

      for batch in chunk_list(unique_phone_numbers, 500):
        formatted_numbers = "', '".join(batch)

        truecaller_query = f"""
            SELECT c_number, c_name 
            FROM truecaller_dis 
            WHERE c_number IN ('{formatted_numbers}')
        """

        truecaller_results = client.query(truecaller_query)
        truecaller_data = {row[0]: row[1] for row in truecaller_results.result_rows}

        sdr_query = f"""
            SELECT phone_no, name 
            FROM u_subscriber_details_dis 
            WHERE phone_no IN ('{formatted_numbers}')
        """
        sdr_results = client.query(sdr_query)
        sdr_data = {row[0]: row[1] for row in sdr_results.result_rows}

        for mobile_no in batch:
            truecaller_name = truecaller_data.get(mobile_no)
            sdr_name = sdr_data.get(mobile_no)

            if truecaller_name and sdr_name and str(truecaller_name).lower() != str(sdr_name).lower():
                print("Found.")
            else:
                print('Not Found.')

