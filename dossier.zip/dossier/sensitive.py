def check_cell_id(unique_cell_id):
    
    cellid_str = ", ".join([f"'{cell_id}'" for cell_id in unique_cell_id])  
    client = create_client()
    results = []
    query = f"""
        SELECT cgi,type
        FROM sensitive_cellid_data 
        WHERE cgi IN ({cellid_str})
    """
    try:
        result = client.query(query)
        if result.result_rows:
            results = {row[0]: row[1] for row in result.result_rows}
    except Exception as e:
        print(f"Error during search for cell_ids: {e}")
    return results

def check_sensitive_cellid(df,unique_cell_id):
    df['sensitive_cell_id'] = None
    sensitive_cell_ids = check_cell_id(unique_cell_id)

    if sensitive_cell_ids:
        df.loc[df['cell_id'].isin(sensitive_cell_ids.keys()), 'sensitive_cell_id'] = df['cell_id'].map(sensitive_cell_ids)
