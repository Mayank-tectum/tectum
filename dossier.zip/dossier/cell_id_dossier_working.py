import json
import logging.config
import clickhouse_connect
import pandas as pd
import logging
import traceback

logging.basicConfig(filename='dossier.log',level=logging.INFO,format="%(asctime)s - %(levelname)s - %(message)s")

json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table = 'default.new_dossier'

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception as e:
        logging.error("Error creating Clickhouse client: %s",str(e))

def chunk_list(data_list, chunk_size):
    for i in range(0, len(data_list), chunk_size):
        yield data_list[i:i + chunk_size]


def check_phone_no(df):
    try:
        print("==================================================")
        print("Checking Phone Numbers")
        print("==================================================")
        
        phone_nos = df['phone_no'].tolist()
        data = []

        if not phone_nos:
            return pd.DataFrame(columns=['phone_no', 'cell_id'])
        client = create_client()

        chunk_size = 10000 
        for chunk in chunk_list(phone_nos, chunk_size):
            phone_nos_str = ','.join([f"'{phone_no}'" for phone_no in chunk])
            query = f"""
                SELECT phone_no, cell_id
                FROM default.new_dossier
                WHERE phone_no IN ({phone_nos_str})
            """

            result = client.query(query)
            for row in result.result_rows:
                data.append(row)
        return pd.DataFrame(data, columns=['phone_no', 'cell_id'])

    except Exception as e:
        logging.error("Error in check_phone_no: %s", str(e))
        return pd.DataFrame(columns=['phone_no', 'cell_id', 'last_seen'])

def insert_filtered_data(new_df, df):
    try:
        print("==================================================")
        print("Filtering Data Before Insertion")
        print("==================================================")
        
        new_df = new_df.astype(str)
        df = df.astype(str)

        # Cleaning data by removing 'Not Found' and NaN values
        new_df = new_df.loc[new_df['cell_id'].notna() & (new_df['cell_id'] != 'Not Found')].dropna(subset=['phone_no'])
        df = df.loc[df['cell_id'].notna() & (df['cell_id'] != 'Not Found')].dropna(subset=['phone_no'])
        
        # **Apply recent logic: filter new_df based on df before renaming columns**
        filtered_new_df = new_df.merge(
            df[['phone_no', 'cell_id']], 
            on=['phone_no', 'cell_id'], 
            how='left', 
            indicator=True
        ).query('_merge == "left_only"').drop(columns=['_merge'])

        
        # **Renaming columns after filtering**
        if 'cell_id' in df.columns:
            df = df.rename(columns={'cell_id': 'cell_id_old'})
        if 'cell_id' in filtered_new_df.columns:
            filtered_new_df = filtered_new_df.rename(columns={'cell_id': 'cell_id_new'})

        merged_df = df.merge(filtered_new_df, on='phone_no', how='inner')
        filtered_df = merged_df[(merged_df['cell_id_old'] != merged_df['cell_id_new'])]

        print("\nFiltered Rows Count:", len(filtered_df))
        df_to_insert = df[df['phone_no'].isin(filtered_df['phone_no'])]

        # Rename back for insertion
        df_to_insert = df_to_insert.rename(columns={'cell_id_old': 'cell_id'})

        print("--------------------------------------------------")
        print("Filtered Data Ready for Insertion")
        print("--------------------------------------------------")

        client = create_client()

        # Prepare data for insertion
        df_to_insert = df_to_insert[sorted(df_to_insert.columns)].astype(str)
        client.insert(table, df_to_insert.to_records(index=False).tolist(), column_names=list(df_to_insert.columns))

        print("--------------------------------------------------")
        print("Filtered Data Inserted Successfully")
        print("--------------------------------------------------")
    except Exception as e:
        logging.error("Error in insert_filtered_data: %s", str(e))


def insert_new_data(new_numbers):
    try:
        print("==================================================")
        print("insert new data called.")
        print("==================================================")

        new_numbers['phone_no'] = new_numbers['phone_no'].str.replace("’", "") 
        new_numbers = new_numbers.dropna(subset=['phone_no'])
        new_numbers['cell_id'] = new_numbers['cell_id'].fillna('Not Found')
        new_numbers['name'] = new_numbers['name'].fillna('Not Found')
        new_numbers['tc_name'] = new_numbers['tc_name'].fillna('Not Found')
        new_numbers['city'] = new_numbers['city'].fillna('Not Found')
        new_numbers['state'] = new_numbers['state'].fillna('Not Found') 
        new_numbers['latitude'] = new_numbers['tower_latitude'].fillna('Not Found')
        new_numbers['longitude'] = new_numbers['tower_longitude'].fillna('Not Found') 
        new_numbers['location'] = new_numbers['tower_location'].fillna('Not Found')

        # Convert before dropping
        new_numbers['first_seen'] = pd.to_numeric(new_numbers['start_date_time'].astype(str).str.strip(), errors='coerce')
        new_numbers['last_seen'] = pd.to_numeric(new_numbers['end_date_time'].astype(str).str.strip(), errors='coerce')

        new_numbers['first_seen'] = pd.to_datetime(new_numbers['start_date_time'], unit='s', utc=True)\
                                .dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)

        new_numbers['last_seen'] = pd.to_datetime(new_numbers['end_date_time'], unit='s', utc=True)\
                               .dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)

        # drop the columns
        new_numbers = new_numbers.drop(columns=['start_date_time', 'end_date_time','tower_latitude','tower_longitude','tower_location'])

        df = new_numbers[sorted(new_numbers.columns)].astype(str)
        new_df = check_phone_no(df)
        print("--------------------------------------------------")
        print("matched records count = ", len(new_df))
        print("--------------------------------------------------")
        df_unique = pd.DataFrame()

        if not new_df.empty:  
            df_unique = new_numbers[~new_numbers['phone_no'].isin(new_df['phone_no'])]
            insert_filtered_data(new_df, df)
        else:
            print("--------------------------------------------------")
            print(f'empty table {len(df)} records inserted.')
            print("--------------------------------------------------")

            client = create_client()
            client.insert(table, df.to_records(index=False).tolist(), column_names=list(df.columns))  

        if len(df_unique) > 0:
            print(df_unique.head(10))
            print()
            df = df_unique[sorted(df_unique.columns)].astype(str)
            print(df.dtypes)
            client = create_client()
            client.insert(table, df.to_records(index=False).tolist(), column_names=list(df.columns))
            print("==================================================")
            print(f"new {len(df_unique)} records inserted.")
            print("==================================================\n")

    except Exception as e:
        logging.error("Error in inserting new data: %s", str(e))
    
def fetch_numbers_from_ipdr_details(recent_last_seen_epoch,end_date,chunk_size=10000000):
    try:
        client = create_client()
        if recent_last_seen_epoch is not None:
            query = f"""
            SELECT 
                phone_no, 
                cell_id, 
                a_party_name, 
                a_party_tc_name, 
                a_party_city, 
                a_party_state, 
                start_date_time, 
                end_date_time,
                tower_latitude,
                tower_longitude,
                tower_location
            FROM ipdr_details 
            WHERE start_date_time >= '{recent_last_seen_epoch}'
            AND end_date_time <= '{end_date}'
            """

            offset = 0
            while True:

                chunk_query = f"{query} LIMIT {chunk_size} OFFSET {offset}"
                print("\n========================================")
                print("Executing SQL Query:")
                print("----------------------------------------")
                print(chunk_query)
                print("========================================\n") 

                result = client.query(chunk_query)
                
                if not result.result_rows:
                    break  
                
                df_chunk = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id', 'name','tc_name','city','state','start_date_time','end_date_time','tower_latitude','tower_longitude','tower_location'])
                print(f"ipdr records before drop duplicate:{len(df_chunk)}")
                df_chunk.drop_duplicates(subset=['phone_no'],inplace=True)
                print(f"ipdr records after drop duplicate:{len(df_chunk)}")
                yield df_chunk  
                offset += chunk_size

    except Exception as e:
        logging.error("Error in fetch_numbers_from_ipdr_details: %s",str(e))

recent_last_seen_epoch= 1739125800
end_date = 1739212200
print("==================================================")
print("Starting Dossier Processing")
print("==================================================")
if recent_last_seen_epoch is not None:
    for df_chunk in fetch_numbers_from_ipdr_details(recent_last_seen_epoch,end_date):
        if not df_chunk.empty:
            print("--------------------------------------------------")
            print("Processing New Data Chunk")
            print("--------------------------------------------------")
            insert_new_data(df_chunk)
        else:
            print("==================================================")
            print("No new numbers to insert.")
            print("==================================================")
            logging.info("No new numbers to insert")





# ---------------------------------------------------------------------------------------



# def check_phone_no(df):
#     try:
#         print("==================================================")
#         print("Checking Phone Numbers")
#         print("==================================================")
        
#         phone_nos = df['phone_no'].tolist()
#         data = []

#         if not phone_nos:
#             return pd.DataFrame(columns=['phone_no', 'cell_id', 'last_seen'])
#         client = create_client()

#         chunk_size = 10000 
#         for chunk in chunk_list(phone_nos, chunk_size):
#             phone_nos_str = ','.join([f"'{phone_no}'" for phone_no in chunk])
#             query = f"""
#                 SELECT phone_no, cell_id, last_seen
#                 FROM default.new_dossier
#                 WHERE phone_no IN ({phone_nos_str})
#             """

#             result = client.query(query)
#             for row in result.result_rows:
#                 data.append(row)
#         return pd.DataFrame(data, columns=['phone_no', 'cell_id', 'last_seen'])

#     except Exception as e:
#         logging.error("Error in check_phone_no: %s", str(e))
#         return pd.DataFrame(columns=['phone_no', 'cell_id', 'last_seen'])

# def insert_filtered_data(new_df, df):
#     try:
#         print("==================================================")
#         print("Filtering Data Before Insertion")
#         print("==================================================")
        
#         new_df = new_df.astype(str)
#         df = df.astype(str)

#         # Cleaning data by removing 'Not Found' and NaN values
#         new_df = new_df.loc[new_df['cell_id'].notna() & (new_df['cell_id'] != 'Not Found')].dropna(subset=['phone_no'])
#         df = df.loc[df['cell_id'].notna() & (df['cell_id'] != 'Not Found')].dropna(subset=['phone_no'])
        
#         # **Apply recent logic: filter new_df based on df before renaming columns**
#         filtered_new_df = new_df.merge(
#             df[['phone_no',  'last_seen', 'cell_id']], 
#             on=['phone_no',  'last_seen', 'cell_id'], 
#             how='left', 
#             indicator=True
#         ).query('_merge == "left_only"').drop(columns=['_merge'])

        
#         # **Renaming columns after filtering**
#         if 'cell_id' in df.columns:
#             df = df.rename(columns={'cell_id': 'cell_id_old', 'last_seen': 'last_seen_old'})
#         if 'cell_id' in filtered_new_df.columns:
#             filtered_new_df = filtered_new_df.rename(columns={'cell_id': 'cell_id_new', 'last_seen': 'last_seen_new'})

#         # Convert to datetime
#         df['last_seen_old'] = pd.to_datetime(df['last_seen_old'], errors='coerce',utc=True)\
#         .dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
#         filtered_new_df['last_seen_new'] = pd.to_datetime(filtered_new_df['last_seen_new'], errors='coerce',utc =True)\
#         .dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)  

#         # **Filter based on recent logic (different cell_id or 1-hour time difference)**
#         merged_df = df.merge(filtered_new_df, on='phone_no', how='inner')
#         filtered_df = merged_df[
#             (merged_df['cell_id_old'] != merged_df['cell_id_new']) |
#             ((merged_df['last_seen_new'] - merged_df['last_seen_old']).dt.total_seconds() >= 3600)
#         ]

#         print("\nFiltered Rows Count:", len(filtered_df))

#         # **Selecting only rows from df that match filtered_df's phone numbers**
#         df_to_insert = df[df['phone_no'].isin(filtered_df['phone_no'])]

#         # Rename back for insertion
#         df_to_insert = df_to_insert.rename(columns={'cell_id_old': 'cell_id', 'last_seen_old': 'last_seen'})

#         print("--------------------------------------------------")
#         print("Filtered Data Ready for Insertion")
#         print("--------------------------------------------------")

#         client = create_client()

#         # Prepare data for insertion
#         df_to_insert = df_to_insert[sorted(df_to_insert.columns)].astype(str)
#         client.insert(table, df_to_insert.to_records(index=False).tolist(), column_names=list(df_to_insert.columns))

#         print("--------------------------------------------------")
#         print("Filtered Data Inserted Successfully")
#         print("--------------------------------------------------")
#     except Exception as e:
#         logging.error("Error in insert_filtered_data: %s", str(e))


# def insert_new_data(new_numbers):
#     try:
#         print("==================================================")
#         print("insert new data called.")
#         print("==================================================")

#         new_numbers['phone_no'] = new_numbers['phone_no'].str.replace("’", "") 
#         new_numbers = new_numbers.dropna(subset=['phone_no'])
#         new_numbers['cell_id'] = new_numbers['cell_id'].fillna('Not Found')
#         new_numbers['name'] = new_numbers['name'].fillna('Not Found')
#         new_numbers['tc_name'] = new_numbers['tc_name'].fillna('Not Found')
#         new_numbers['city'] = new_numbers['city'].fillna('Not Found')
#         new_numbers['state'] = new_numbers['state'].fillna('Not Found') 
#         new_numbers['latitude'] = new_numbers['tower_latitude'].fillna('Not Found')
#         new_numbers['longitude'] = new_numbers['tower_longitude'].fillna('Not Found') 
#         new_numbers['location'] = new_numbers['tower_location'].fillna('Not Found')

#         # Convert before dropping
#         new_numbers['first_seen'] = pd.to_numeric(new_numbers['start_date_time'].astype(str).str.strip(), errors='coerce')
#         new_numbers['last_seen'] = pd.to_numeric(new_numbers['end_date_time'].astype(str).str.strip(), errors='coerce')

#         new_numbers['first_seen'] = pd.to_datetime(new_numbers['start_date_time'], unit='s', utc=True)\
#                                 .dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)

#         new_numbers['last_seen'] = pd.to_datetime(new_numbers['end_date_time'], unit='s', utc=True)\
#                                .dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)

#         # drop the columns
#         new_numbers = new_numbers.drop(columns=['start_date_time', 'end_date_time','tower_latitude','tower_longitude','tower_location'])

#         print(new_numbers[['first_seen', 'last_seen']].head(10))

#         df = new_numbers[sorted(new_numbers.columns)].astype(str)
#         new_df = check_phone_no(df)
#         print("--------------------------------------------------")
#         print("matched records count = ", len(new_df))
#         print("--------------------------------------------------")
#         df_unique = pd.DataFrame()

#         if not new_df.empty:  
#             df_unique = new_numbers[~new_numbers['phone_no'].isin(new_df['phone_no'])]
#             insert_filtered_data(new_df, df)
#         else:
#             print("--------------------------------------------------")
#             print(f'empty table {len(df)} records inserted.')
#             print("--------------------------------------------------")

#             client = create_client()
#             client.insert(table, df.to_records(index=False).tolist(), column_names=list(df.columns))  

#         if len(df_unique) > 0:
#             print(df_unique.head(10))
#             print()
#             df = df_unique[sorted(df_unique.columns)].astype(str)
#             print(df.dtypes)
#             client = create_client()
#             client.insert(table, df.to_records(index=False).tolist(), column_names=list(df.columns))
#             print("==================================================")
#             print(f"new {len(df_unique)} records inserted.")
#             print("==================================================\n")

#     except Exception as e:
#         logging.error("Error in inserting new data: %s", str(e))
    
# def fetch_numbers_from_ipdr_details(recent_last_seen_epoch,end_date,chunk_size=10000000):
#     try:
#         client = create_client()
#         if recent_last_seen_epoch is not None:
#             query = f"""
#             SELECT 
#                 phone_no, 
#                 cell_id, 
#                 a_party_name, 
#                 a_party_tc_name, 
#                 a_party_city, 
#                 a_party_state, 
#                 start_date_time, 
#                 end_date_time,
#                 tower_latitude,
#                 tower_longitude,
#                 tower_location
#             FROM ipdr_details 
#             WHERE start_date_time >= '{recent_last_seen_epoch}'
#             AND end_date_time <= '{end_date}'
#             """

#             offset = 0
#             while True:

#                 chunk_query = f"{query} LIMIT {chunk_size} OFFSET {offset}"
#                 print("\n========================================")
#                 print("Executing SQL Query:")
#                 print("----------------------------------------")
#                 print(chunk_query)
#                 print("========================================\n") 

#                 result = client.query(chunk_query)
                
#                 if not result.result_rows:
#                     break  
                
#                 df_chunk = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id', 'name','tc_name','city','state','start_date_time','end_date_time','tower_latitude','tower_longitude','tower_location'])
#                 print(f"ipdr records before drop duplicate:{len(df_chunk)}")
#                 df_chunk.drop_duplicates(subset=['phone_no'],inplace=True)
#                 print(f"ipdr records after drop duplicate:{len(df_chunk)}")
#                 yield df_chunk  
#                 offset += chunk_size

#     except Exception as e:
#         logging.error("Error in fetch_numbers_from_ipdr_details: %s",str(e))

# # def fetch_recent_last_seen():
  
# #     client = create_client()
# #     query = """
# #         SELECT
# #         parseDateTimeBestEffortOrNull(last_seen) AS recent_last_seen
# #         FROM default.new_dossier
# #         ORDER BY recent_last_seen DESC
# #         LIMIT 1
# #     """

# #     result = client.query(query)
# #     if result:
# #         last_seen_str = result.result_rows[0][0]
# #         last_seen_str = str(last_seen_str).split('+')[0]
# #         print("last_seen_str:",last_seen_str)
# #         last_seen_dt = datetime.datetime.strptime(last_seen_str, '%Y-%m-%d %H:%M:%S')
# #         epoch_time = int(last_seen_dt.timestamp())
# #         return epoch_time
# #     logging.info("no last_seen found in dossier_temp")

# # recent_last_seen_epoch = fetch_recent_last_seen()
# # print(recent_last_seen_epoch)

# # recent_last_seen_epoch=fetch_recent_last_seen()
# recent_last_seen_epoch= 1739125800
# end_date = 1739212200
# print("==================================================")
# print("Starting Dossier Processing")
# print("==================================================")
# if recent_last_seen_epoch is not None:
#     for df_chunk in fetch_numbers_from_ipdr_details(recent_last_seen_epoch,end_date):
#         if not df_chunk.empty:
#             print("--------------------------------------------------")
#             print("Processing New Data Chunk")
#             print("--------------------------------------------------")
#             insert_new_data(df_chunk)
#         else:
#             print("==================================================")
#             print("No new numbers to insert.")
#             print("==================================================")
#             logging.info("No new numbers to insert")
