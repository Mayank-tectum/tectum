import clickhouse_connect
import pandas as pd
import json

# df = pd.read_csv('dossier_data.csv')
# df.drop_duplicates(subset=['phone_no'], inplace=True)
# df['last_seen'] = df['last_seen'].replace(r'\N', 'Not Found')
# df = df[df['phone_no'] != 0]
# print(df.head())
# df['state'] = df['state'].replace(r'\N', 'Not Found')
# df['name'] = df['name'].replace(r'\N', 'Not Found')
# df['name'] = df['name'].str.strip()
# df['name'] = df['name'].replace(' ', 'Not Found')
# df.to_csv('dossier_data_cleaned.csv', index=False)

json_file = open('database.config', 'r').read()
database = json.loads(json_file)

click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
    )
    return client

df = pd.read_csv('dossier_data_cleaned.csv')
def update_dossier(df, batch_size=100000):
    client = create_client()
    for start in range(0, len(df), batch_size):
        end = start + batch_size
        batch = df.iloc[start:end]
        phone_nos = batch['phone_no'].tolist()
        phone_nos_str = ','.join([f"'{phone_no}'" for phone_no in phone_nos])
        query = f"""
        SELECT phone_no, a_party_name AS name, a_party_tc_name AS tc_name, a_party_city AS city, a_party_state AS state 
        FROM ipdr_details 
        WHERE phone_no IN ({phone_nos_str})
        """
        result = client.query(query)
        result_df = pd.DataFrame(result.result_rows, columns=['phone_no', 'name', 'tc_name', 'city', 'state'])
        df.update(result_df.set_index('phone_no'), overwrite=True)
    return df

updated_df = update_dossier(df)
updated_df.to_csv('updated_dossier_data.csv', index=False)