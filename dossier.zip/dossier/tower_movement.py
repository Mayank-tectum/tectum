import sys
import clickhouse_connect
import pandas as pd
import json

json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table = 'default.new_dossier'

# ClickHouse connection details
click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']
click_house_node4 = database['click_house_node4']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node4}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node1,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception as e:
        print(e)
        return None
    
# def single_number(number):
#     print(type(number))
#     client = create_client()
#     query = f"""
#     select phone_no,
#             cell_id,
#             name,
#             tc_name,
#             city,
#             state,
#             first_seen,
#             last_seen,
#             latitude,
#             longitude,
#             location     
#     from default.new_dossier 
#     where phone_no = '{number}'
#     ORDER BY first_seen ASC
#     """
#     print(query)
#     result = client.query(query)
                
#     if not result.result_rows:
#         print('No records found')
#         return None

#     df = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id', 'name','tc_name','city','state','first_seen','last_seen','latitude','longitude','location'])

#     df.to_csv('single_number.csv', index=False)

# # number='9993570122'
# # single_number(number)

# def multiple_numbers(numbers):
#     phone_nos_str = ','.join([f"'{phone_no}'" for phone_no in numbers])
#     client = create_client()
#     query =  f"""
#     select phone_no,
#             cell_id,
#             name,
#             tc_name,
#             city,
#             state,
#             first_seen,
#             last_seen,
#             latitude,
#             longitude,
#             location        
#     from default.new_dossier 
#     where phone_no IN ({phone_nos_str})
#     ORDER BY phone_no, first_seen ASC
#     """
#     result = client.query(query)
                
#     if not result.result_rows:
#         print('No records found')
#         return None

#     df = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id', 'name','tc_name','city','state','first_seen','last_seen','latitude','longitude','location'])
#     df.to_csv('multiple_numbers.csv', index=False)

def tower_movement(phone_no):

    client = create_client()
    if type == 'single':
        query = f"""
            select phone_no,
            cell_id,
            name,
            tc_name,
            city,
            state,
            first_seen,
            last_seen,
            latitude,
            longitude,
            location     
            from default.new_dossier 
            where phone_no = '{phone_no}'
            ORDER BY first_seen ASC """
        
        print(query)
        result = client.query(query)
                    
        if not result.result_rows:
            print('No records found for single number.')
            return None

        df = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id', 'name','tc_name','city','state','first_seen','last_seen','latitude','longitude','location'])
        df.to_csv('single_number.csv', index=False)
        print("successfully written to csv")

    elif type == 'multiple':
        phone_nos_str = ','.join([f"'{phone}'" for phone in phone_no])
        query =  f"""
            select phone_no,
            cell_id,
            name,
            tc_name,
            city,
            state,
            first_seen,
            last_seen,
            latitude,
            longitude,
            location        
            from default.new_dossier 
            where phone_no IN ({phone_nos_str})
            ORDER BY phone_no, first_seen  ASC """
        
        print(query)
        result = client.query(query)
                    
        if not result.result_rows:
            print('No records found for muliple number.')
            return None

        df = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id', 'name','tc_name','city','state','first_seen','last_seen','latitude','longitude','location'])
        df.to_csv('multiple_numbers.csv', index=False)
        print("successfully written to csv")

if __name__ == "__main__":
    args = sys.argv
    if len(args) >= 2:
        type = args[2]
        phone_no = args[3]
        tower_movement(phone_no,type)
