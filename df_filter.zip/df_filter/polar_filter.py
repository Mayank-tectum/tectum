import os
os.environ["POLARS_FORCE_NEW_STREAMING"] = "1" 
import polars as pl
import time 
# print(pl.thread_pool_size())
# pl.set_global_thread_pool_size(16) 
# print(len(filter_with_ploar('phone_numbers_20000.csv','filtered_one_cr_plus_ipdr.csv')))

def filter_with_polar(numbers_csv,large_csv):
    start_time = time.time()
    unique_numbers = set(pl.read_csv(numbers_csv,schema_overrides = {"phone_no":pl.Utf8})["phone_no"].to_numpy())
    large_csv = pl.read_csv(large_csv)
    filter_time = time.time()
    filter_df = (pl.scan_csv(large_csv,schema_overrides = {'Landline/MSISDN/MDN/Leased Circuit ID for Internet Access':pl.Utf8}).filter(pl.col("Landline/MSISDN/MDN/Leased Circuit ID for Internet Access").is_in(unique_numbers)).collect(streaming = True))
    print(f"filter_time is ",time.time()-filter_time)
    print(f"total_time is ",time.time()-start_time)
    large_csv.write_csv("output.csv")

filter_with_polar('phone_numbers_20000.csv','filtered_one_cr_plus_ipdr.csv')