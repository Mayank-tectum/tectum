import os
from pathlib import Path
import shutil
import zipfile

def extract_zip(zip_path,extract_path):
    with zipfile.ZipFile(zip_path, 'r') as zip_file:
        zip_file.extractall(extract_path)

def move_files(source_path,destination_path):

    for file in os.listdir(source_path):
        file_path = os.path.join(source_path,file)
        if os.path.isfile(file_path):
            shutil.move(file_path,os.path.join(destination_path,file_path))

def extract_nested_zip(source_path,destination_path,processed_path,temp_path):

    Path(processed_path).mkdir(parents=True,exist_ok= True)
    Path(temp_path).mkdir(parents=True,exist_ok= True)

    for file in os.listdir(source_path):
        file_path = os.path.join(source_path,file)
        if file_path.endswith('.csv') and os.path.isfile(file_path):
            shutil.move(file_path,os.path.join(destination_path,file_path))

    for file in os.listdir(source_path):
        file_path = os.path.join(source_path,file)
        if file_path.endswith('.zip') and os.path.isfile(file_path):
            extract_zip(file_path,temp_path)
            move_files(temp_path,destination_path)
            shutil.move(file_path,os.path.join(processed_path,file))
            shutil.rmtree(temp_path)
            Path(temp_path).mkdir(parents=True,exist_ok= True)

processed_path = r"/home/tectum18/Desktop/Mayank/zip_folder/processed_zip_files"
destination_path = r"/home/tectum18/Desktop/Mayank/output_folder"  
source_path = r"/home/tectum18/Desktop/Mayank/zip_folder"
temp_path = r"/home/tectum18/Desktop/Mayank/zip_folder/temp_dir"
extract_nested_zip(source_path,destination_path,processed_path,temp_path)