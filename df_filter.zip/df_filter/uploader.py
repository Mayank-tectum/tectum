import hashlib
import json
import logging
import mmap
from pathlib import Path
import re
import subprocess
import sys
import shutil
import os
import MySQLdb
import magic

def ipdr_conn():
    json_file= open('database.config','r').read()
    database = json.loads(json_file)
    return MySQLdb.connect(
        host=database['database_url'],
        port=database['database_port'], 
        user=database['database_user'],
        passwd=database['database_password'],
        db=database['database_name']
    )

def extract_zip(zip_path,extract_path):
    print('zip_path:',zip_path)
    subprocess.call(['7z', 'x', f'-o{extract_path}', '-aoa', zip_path, '-y', '-bso0', '-bsp0'])


def move_files(source_path, destination_path):
    for file in os.listdir(source_path):
        file_path = os.path.join(source_path, file)

        if os.path.isfile(file_path) and file_path.endswith('.csv'):
            shutil.move(file_path, destination_path)  
        elif os.path.isdir(file_path):  
            for subfile in os.listdir(file_path):  
                subfile_path = os.path.join(file_path, subfile)
                if os.path.isfile(subfile_path) and subfile_path.endswith('.csv'):
                    shutil.move(subfile_path, destination_path)  
            
            os.rmdir(file_path)


def process_zip(source_path,destination_path,processed_path):
    Path(processed_path).mkdir(parents=True,exist_ok= True)
    temp_path = Path(processed_path) / "temp"
    temp_path.mkdir(parents=True, exist_ok=True)

    for file in os.listdir(source_path):
        file_path = os.path.join(source_path, file)
        if file.endswith('.csv') and os.path.isfile(file_path): 
            shutil.move(file_path, os.path.join(destination_path, file)) 

    for file in os.listdir(source_path):
        file_path = os.path.join(source_path, file)
        if file_path.endswith('.zip') and os.path.isfile(file_path):
            extract_zip(file_path, temp_path)

            for root, _, files in os.walk(temp_path):
                for filename in files:
                    print("filename:",filename)
                    if re.search(r'\.zip$', filename):
                        fileSpec = os.path.join(root, filename)
                        extract_zip(fileSpec, root)
                        print(f"Contents of temp_path before moving files: {os.listdir(temp_path)}")

            move_files(temp_path, destination_path)
            shutil.move(file_path, os.path.join(processed_path, file))

            shutil.rmtree(temp_path)
            Path(temp_path).mkdir(parents=True, exist_ok=True)


def mime_to_type(file_path,file_ext):
    res = ''
    mimetype =  magic.from_file(file_path, mime=True)
    # print(mimetype, file_ext)
    d = {
        
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
        'application/vnd.ms-excel': 'xls',            
        'application/vnd.ms-excel.sheet.binary.macroEnabled.12':'xlsb',
        'text/html': 'html',
        'text/plain': 'csv',
        'text/csv': 'csv',
        'application/csv': 'csv',
        'application/x-zip-compressed': 'zip',
        'application/zip': 'zip',
        'application/gzip': 'gz',
        'application/x-tar': 'tar',
        'application/x-bzip2': 'bz2',
        'application/x-7z-compressed': '7z',
        'application/x-rar-compressed': 'rar'
    }
    if file_ext == 'csv' and mimetype == 'application/octet-stream':
        res = 'csv'
        return res

    elif mimetype in d:
        res = d[mimetype]
        return res

def get_all_file_path(path):
    result = []
    for root,_, files in os.walk(path):
        for filename in files:
            file_path = os.path.join(root, filename)
            result.append(file_path)
    return result

# get file size in mb
def get_file_size_mb(file_path):
    file_size_bytes = os.path.getsize(file_path)
    file_size_mb = file_size_bytes / (1024 * 1024)
    return file_size_mb

def get_sha256_hash(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as file:
        try:
            with mmap.mmap(file.fileno(), 0, access=mmap.ACCESS_READ) as mmapped_file:
                sha256.update(mmapped_file)
        except:
            sha256.update(file.read())
    return sha256.hexdigest()

# get sha256 hash of a file by mb
def get_sha256_hash_by_mb(file_path, mb_to_read):
    chunk_size_bytes = 1024 * 1024
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as file:
        bytes_read = 0
        while bytes_read < mb_to_read * chunk_size_bytes:
            data = file.read(chunk_size_bytes)
            if not data:
                break
            sha256.update(data)
            bytes_read += len(data)
    return sha256.hexdigest()

def generate_hash(file_paths):
    mb_to_read = 10
    datas = {}
    dup_datas = []
    if not isinstance(file_paths, list):
        file_paths = [file_paths]
    for file_path in file_paths:
        ext = os.path.splitext(file_path)[1].replace('.', '')
        if ext not in ['ini']:
            s_mb = get_file_size_mb(file_path)
            if s_mb <= 10:
                hash = get_sha256_hash(file_path)
            else:
                hash = get_sha256_hash_by_mb(file_path, mb_to_read)
            #print(mime_to_type(file_path,model_type,os.path.splitext(file_path)[1].replace('.', '')),'===========================',file_path)
            if hash not in datas:
                datas[hash] = {'file_path': file_path, 'file_hash': hash, 'file_format': mime_to_type(file_path,os.path.splitext(file_path)[1].replace('.', '')), 'file_extension': os.path.splitext(file_path)[1].replace('.', '')}
            else:
                dup_datas.append({'file_path': file_path, 'file_hash': hash, 'file_format': mime_to_type(file_path,os.path.splitext(file_path)[1].replace('.', '')), 'file_extension': os.path.splitext(file_path)[1].replace('.', '')})
    return datas, dup_datas

def check_exists_new(datas, case_id):
    exists, new = {}, {}
    hash_list = list(datas.keys())
    sql_query = "SELECT file_hash FROM ipdr_data.files_meta_details WHERE file_hash IN (%s)" # dummy query
    conn = ipdr_conn()
    cur = conn.cursor()
    enquiry_string =', '.join(map(lambda x: '%s', hash_list))
    sql_enquiry = sql_query % (enquiry_string)
    cur.execute(sql_enquiry, hash_list)
    exists_hash = [item[0] for item in cur.fetchall()]
    cur.close()
    conn.close()
    new_hash = list(set(hash_list) - set(exists_hash))
    exists = {h1:datas[h1] for h1 in exists_hash}
    new = {h2:datas[h2] for h2 in new_hash}
    return exists, new

def generic_injest(data_dict,file_format):
    rows = []
    mapper_dict_with_raw = {}

    if isinstance(data_dict, dict):
        data_dict = data_dict.values()
    for item in data_dict:
        name = os.path.basename(item['file_path'])            
        file_hash = item['file_hash']
        path = os.path.dirname(item['file_path'])            
        file_format =item['file_format']
        telecom_name = ''            
        if injest_type =='failed':                
            uploadStatus, mapper_name, telecom_name, file_type, header_position, header_length = 12, None, model_type, None, None, None
            row = (file_id, name, request_id, input_type, Input_value, start_date, end_date, total_records, case_id, file_hash, telecom_name, path, uploadStatus, pcap_phone_no, pcap_public_ip_address, file_type, file_format, mapper_name, header_position, header_length, date_format, mapper_country_name, mapper_dict_with_raw,top_not_found_mapper)
            rows.append(row)
                   
    if rows:
        meta_bulk_injest(rows)


def main_function(source_path,destination_path,processed_path):
    print("main called.")
    process_zip(source_path,destination_path,processed_path)
    file_path=get_all_file_path(destination_path)
    # print("All file_path",file_path,end='\n')
    hashes, duplicate_hashes=generate_hash(file_path)
    # print(hashes)
    # print("----------------------------------------\n")
    # print(duplicate_hashes)

    if hashes:                
        hash_already_exists, new_hashes = check_exists_new(hashes)                
        if new_hashes:
            generic_injest(model_type,'insert', new_hashes, case_id, '', '',ft,MAPPER_DF,telecom_name_cdr=telecom_name_cdr)
        if hash_already_exists:
            generic_injest(model_type,'duplicate', hash_already_exists, case_id, '', '','',telecom_name_cdr=telecom_name_cdr)
    if duplicate_hashes:
        generic_injest(model_type,'duplicate', duplicate_hashes, case_id, '', '','',telecom_name_cdr=telecom_name_cdr)


if __name__ == '__main__':
    if len(sys.argv) >= 3:
        source_path = sys.argv[1]
        destination_path = sys.argv[2]
        processed_path = sys.argv[3]

        main_function(source_path,destination_path,processed_path)  

    else:
        print('use command - ')
        print(f'{os.path.basename(sys.argv[0])} <zip_folder_path>')
        print('sample command - ')
        print(f'{os.path.basename(sys.argv[0])} /dir/zip_folder')
