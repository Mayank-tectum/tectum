from threading import Thread
import threading

# it will print the current thread which is main thread with PID
print(threading.current_thread())

# print current thread name and name is the attribute of Thread class
print(threading.current_thread().name)

# print the ident number which is same as the PID of current thread
print(threading.current_thread().ident)

# print the current status of thread
print(threading.current_thread().is_alive())

# execute using t1 thread
def func1():
    print("function 1 Called.")

# execute using t2 thread

def func2():
    print("function 2 Called.")


t1 = Thread(target=func1)
t2 = Thread(target=func2)

t1.start()
t2.start()