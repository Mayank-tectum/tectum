from threading import Thread,current_thread

class Myclass:
    # instance method executed by t1 Thread
    def fun1(self,n1):
        print(f"Thread 1 details: {current_thread()}")
        for i in range(n1):
            print("T1")

    # class method executed by t2 Thread        
    @classmethod
    def fun2(self,n2):
        print(f"Thread 2 details: {current_thread()}")   
        for i in range(n2):
            print("T2")  

    # static method executed by t3 Thread        
    @staticmethod
    def fun3(n3):
        print(f"Thread 3 details: {current_thread()}")   
        for i in range(n3):
            print("T3") 
            
# creating instance of class
m1 = Myclass()

t1 = Thread(target=m1.fun1,args=(5,))
t1.start()

t2 = Thread(target=Myclass.fun2, args=(5,))
t2.start()

t3 = Thread(target=Myclass.fun3,args=(5,))
t3.start()

# executed by Main Thread which is also called as Parent Thread
print(f"main thread details: {current_thread()}")    
for i in range(5):
    print("hello")
