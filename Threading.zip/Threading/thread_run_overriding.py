from threading import Thread
from time import sleep

to_upload = ['video1','video2','video3','video4','video5']

class MyThread(Thread):

    def __init__(self):
        print("constructor called.")
        Thread.__init__(self)

    def compression(self):
        print("video compressed Successfully")

    def run(self):
        for vid in to_upload:
            print(f"{vid} is uploading.")
            self.compression()
            sleep(3)
            print(f"{vid} uploaded successfully.")
  
t1 = MyThread()
t1.start()
for i in range(5):
    print("Check for copyright")
    sleep(3)