from threading import Thread,current_thread

# executed by t1 Thread
def fun1(n,msg):
    print(f"Thread 1 details: {current_thread()}")
    for i in range(n):
        print(msg)

# executed by t2 Thread
def fun2(n):
    print(f"Thread 2 details: {current_thread()}")
    for i in range(n):
        print("kushwah")

# Thread 1
t1 = Thread(target=fun1, kwargs={'n':5,'msg':'Mayank'})
t1.start()

# Thread2
t2 = Thread(target=fun2, args=(5,))
t2.start()

# executed by Main Thread which is also called as Parent Thread
for i in range(5):
    print("hello")
print(f"main thread details: {current_thread()}")    