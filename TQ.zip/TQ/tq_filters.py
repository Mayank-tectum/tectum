import traceback
import MySQLdb
import clickhouse_connect
import pandas as pd
import logging
import json
import time

logging.basicConfig(filename='tq_filter.log', level=logging.ERROR,format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
json_file = open('database.config', 'r').read()
database = json.loads(json_file)
table = "tq_filters"
chunk_size = 100000

# ClickHouse connection details
click_house_node = database['click_house_node2']
CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
        
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}        

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE

        )
        return client
    except Exception :
        logging.error("Error creating Clickhouse client: %s",traceback.format_exc())

def ipdr_conn():
    json_file = open('database.config','r').read()
    database = json.loads(json_file)
    return MySQLdb.connect(
        host=database['database_url'],
        port=database['database_port'],  
        user=database['database_user'],
        passwd=database['database_password'],
        db=database['database_name']
    )

# return latest date from database
def fetch_latest_date():
    try:
        client = create_client()
        query = f"SELECT MAX((start_date_time)) FROM isquare_staging_db.ipdr_details"
        result = client.query(query).result_rows[0][0]
        return result
    except Exception :
        logging.error("Error in fetch_latest_date query: %s",traceback.format_exc())     

def fetch_predominent_data(df):
    try:
        chunks = 10000
        client = create_client()
        df['cell_id'] = ''
        df['latitude'] = ''
        df['longitude'] = ''
        all_results = [] # for storing query result
        phone_no = df['phone_no'].tolist()

        # process data in chunks
        for i in range(0, len(phone_no), chunks):
            chunk = phone_no[i:i + chunks]
            numbers = ','.join([f"'{p}'" for p in chunk])
            query = f"SELECT phone_no,cell_id,latitude,longitude FROM isquare_staging_db.pre_dominent_cell_id WHERE phone_no IN ({numbers})"

            result = client.query(query)
            result = pd.DataFrame(result.result_rows, columns=['phone_no','cell_id','latitude','longitude'])

            # merging two columns into one single column (lat,long)
            # if not result.empty:
            #     result['lat_long'] = result['lat'].astype(str) + ',' + result['long'].astype(str) 
            #     result = result[['phone_no', 'cell_id', 'lat_long']]
            #     all_results.append(result)

            if not result.empty:
                all_results.append(result)    

        # update cell_id, lat_long column in original df
        if all_results:
            final_df = pd.concat(all_results, ignore_index=True)
            df = df.merge(final_df,on ='phone_no',how ='left',suffixes = ('','_pred'))

            for col in ['cell_id','latitude','longitude']:
                df[col] = df[f'{col}_pred'].combine_first(df[col])
                df.drop(columns = [f'{col}_pred'],inplace = True)

            return df
        else:
            return pd.DataFrame() 
    
    except Exception :
         logging.error("Error in fetch_predominent_data %s:",traceback.format_exc())

# filter (A) 
def pak_voip_calls():
    pak_time = time.time()
    try:
        print("+" * 30)
        print("pak_voip_calls is in process.")
        print("+" * 30)

        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        client = create_client()
        query = f"""
            SELECT DISTINCT phone_no
            FROM (
                SELECT 
                    phone_no,
                    COUNT() OVER (PARTITION BY phone_no) AS session_count
                FROM isquare_staging_db.ipdr_details 
                WHERE 
                    service_provider_detail NOT IN ('UNKNOWN', 'unknown')
                    AND t_detection = 'no'
                    AND voip_call_platform_name IS NOT NULL
                    AND voip_call_status = '1'
                    AND voip_call_index = '0'
                    AND ip_country = 'PAKISTAN'
                    AND toDateTime(start_date_time) 
                        BETWEEN toDateTime('{recent_date}') - INTERVAL 1 MONTH 
                        AND toDateTime('{recent_date}')
            ) AS filtered_data
            WHERE session_count > 9
        """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Error while executing query: %s", traceback.format_exc())
            return
        
        # prepare df
        pak_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if pak_df.empty:
            logging.error("pak_df is empty.")
            return

        pak_df['tq_filter_id'] = 'a'
        pak_df['tq_marks'] = '50'

        # add cell_id, latitude and longitude columns in df
        pak_df=fetch_predominent_data(pak_df)
        for i in range(0,len(pak_df),chunk_size):
            chunk_df = pak_df[i:i+chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for pak_voip_calls.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())
        print("\n" + "+" * 30)
        print("pak_voip_calls time:",time.time()-pak_time)
        print("+" * 30 + "\n")

    except Exception :
        logging.error("Unexpected error in pak_voip_calls: %s", traceback.format_exc())
    
# filter (B)
def cdr_calls():
    cdrtime = time.time()

    try:
        print("+" * 30)
        print("cdr_calls is in process.")
        print("+" * 30)

        client = create_client()
        recent_date = fetch_latest_date()

        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        query = f"""
            SELECT 
                phone_no,
                toStartOfWeek(toDateTime(start_date_time,'Asia/Kolkata')) AS week_start,
                COUNTIf(cdr_service_type = 'CALL') AS total_calls
            FROM 
                isquare_staging_db.ipdr_details
            WHERE 
                toDateTime(start_date_time) 
                BETWEEN toDateTime('{recent_date}') - INTERVAL 1 MONTH AND toDateTime('{recent_date}')
                AND (destination_ip_address IS NOT NULL OR public_ip_address IS NOT NULL) 
                AND cdr_service_type != 'UNKNOWN'
            GROUP BY 
                phone_no, week_start
            HAVING 
                total_calls < 10
        """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Error while executing query: %s", traceback.format_exc())
            return
        
        cdr_calls_df = pd.DataFrame(result.result_rows, columns=['phone_no', 'week_start', 'total_calls'])
        if cdr_calls_df.empty:
            logging.error("cdr_calls_df is empty.")
            return

        cdr_calls_df.drop(columns=['week_start', 'total_calls'], inplace=True)
        cdr_calls_df['tq_filter_id'] = 'b'
        cdr_calls_df['tq_marks'] = '50'

        # add cell_id, latitude and longitude columns in df
        cdr_calls_df=fetch_predominent_data(cdr_calls_df)

        for i in range(0,len(cdr_calls_df),chunk_size):
            chunk_df = cdr_calls_df[i:i+chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for cdr_calls.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" * 30)
        print("cdr_calls time:",time.time()-cdrtime)
        print("+" * 30 + "\n")
    
    except Exception :
        logging.error("Unexpected error in cdr_calls: %s", traceback.format_exc())

# filter (C)
def low_ipdr_activity_users():
    ipdr_time = time.time()

    try:
        print("+" * 30)
        print("low_ipdr_activity_users is in process.")
        print("+" * 30)

        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        client = create_client()
        query = f"""
            SELECT 
                phone_no, 
                COUNT(DISTINCT toDate(toUInt32(start_date_time))) AS distinct_days
            FROM 
                isquare_staging_db.ipdr_details
            WHERE 
                toDateTime(start_date_time)
                BETWEEN toDateTime('{recent_date}') - INTERVAL 1 MONTH AND toDateTime('{recent_date}')
                AND (destination_ip_address IS NOT NULL OR public_ip_address IS NOT NULL)
            GROUP BY 
                phone_no 
            HAVING 
                distinct_days = 5
        """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Error while executing query: %s", traceback.format_exc())
            return
        
        low_ipdr_df = pd.DataFrame(result.result_rows, columns=['phone_no', 'distinct_days'])
        if low_ipdr_df.empty:
            logging.error("low_ipdr_df is empty.")
            return

        low_ipdr_df.drop(columns=['distinct_days'], inplace=True)
        low_ipdr_df['tq_filter_id'] = 'c'
        low_ipdr_df['tq_marks'] = '50'

        # add cell_id, latitude and longitude columns in df
        low_ipdr_df=fetch_predominent_data(low_ipdr_df)
        for i in range(0,len(low_ipdr_df),chunk_size):
            chunk_df = low_ipdr_df[i:i+chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for low_ipdr_activity_users.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" * 30)
        print("low_ipdr_activity_users time:",time.time()-ipdr_time)
        print("+" * 30 + "\n")

    except Exception :
        logging.error("Unexpected error in low_ipdr_activity_users: %s", traceback.format_exc())

# filter (E)
def identify_frequent_otp_calls():
    otptime = time.time()

    try:
        print("+" * 30)
        print("identify_frequent_otp_calls is in process.")
        print("+" * 30)

        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        client = create_client()
        query = f"""
                
                """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Error while executing query: %s", traceback.format_exc())
            return
        
        otp_calls_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if otp_calls_df.empty:
            logging.error("otp_calls_df is empty.")
            return

        otp_calls_df['tq_filter_id'] = 'e'
        otp_calls_df['tq_marks'] = '50'

        # add cell_id, latitude and longitude columns in df
        otp_calls_df=fetch_predominent_data(otp_calls_df)

        for i in range(0,len(otp_calls_df),otp_calls_df):
            chunk_df = otp_calls_df[i:i +chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for identify_frequent_otp_calls.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" * 30)
        print("identify_frequent_otp_calls time:",time.time()-otptime)         
        print("+" * 30 + "\n")

    except Exception :
        logging.error("Unexpected error in identify_frequent_otp_calls: %s", traceback.format_exc())

# filter (F)
def identify_frequent_otp_sms():
    sms_time = time.time()
  
    try:
        print("+"*30)
        print("identify_frequent_otp_sms is in process.")
        print("+"*30)

        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        client = create_client()
        query = f"""
                """
        try:
            result = client.query(query)
        except Exception :
            logging.error("Error while executing query: %s", traceback.format_exc())
            return
        
        otp_sms_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if otp_sms_df.empty:
            logging.error("otp_sms_df is empty.")
            return

        otp_sms_df['tq_filter_id'] = 'f'
        otp_sms_df['tq_marks'] = '30'

        # add cell_id, latitude and longitude columns in df
        otp_sms_df=fetch_predominent_data(otp_sms_df)
        for i in range(0,len(otp_sms_df),chunk_size):
            chunk_df = otp_sms_df[i:i+chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for identify_frequent_otp_sms.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" * 30)
        print("identify_frequent_otp_sms time:",time.time()-sms_time)        
        print("+" * 30 + "\n")

    except Exception :
        logging.error("Unexpected error in identify_frequent_otp_sms: %s", traceback.format_exc())

# filter (G)
def b_party_vpn():
    bparty_time = time.time()
   
    try:
        print("+"*30)
        print("b_party_vpn is in process.")
        print("+"*30)

        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        client = create_client()
        query = f"""    
                    SELECT distinct phone_no
                    FROM (
                    SELECT distinct phone_no, b_party, destination_ip_address, start_date_time, ip_country, vpn_name,        
                    COUNT() OVER (PARTITION BY phone_no) AS session_count
                                    FROM isquare_staging_db.ipdr_details 
                                    WHERE toDateTime(start_date_time) BETWEEN toDateTime('{recent_date}') - INTERVAL 1 MONTH AND toDateTime('{recent_date}')
                                    AND public_ip_address != destination_ip_address
                                    AND (is_vpn = 'True' OR vpn_tor = 'True' OR vpn_is_relay = 'True' OR vpn_proxy = 'True')
                                    AND toInt32(destination_port) >= 10000
                                    AND ip_country != 'INDIA'
                                    AND (vpn_name IS NOT NULL AND vpn_name != '')
                                    AND phone_no IN (SELECT phone_no FROM file('phone_no_suspects.csv', 'CSV', 'phone_no String'))
                    ) AS filtered_data
                    WHERE session_count >= 100
                """
        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        b_party_vpn_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if b_party_vpn_df.empty:
            logging.error("b_party_vpn_df is empty.")
            return

        b_party_vpn_df['tq_filter_id'] = 'g'
        b_party_vpn_df['tq_marks'] = '20'

        # add cell_id, latitude and longitude columns in df
        b_party_vpn_df=fetch_predominent_data(b_party_vpn_df)

        for i in range(0,len(b_party_vpn_df),chunk_size):
            chunk_df = b_party_vpn_df[i:i+chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for b_party_vpn.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+"  * 30)
        print("b_party_vpn time:",time.time()-bparty_time)
        print("+" * 30 + "\n")
       
    except Exception :
        logging.error("Error in b_party_vpn query: %s", traceback.format_exc())


# filter (H)
def predominant_location():
    predominant_time = time.time()
   
    try:
        print("+"*30)
        print("predominant_location is in process.")
        print("+"*30)

        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        client = create_client()
        query = f"""    
                   
                """
        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        dominant_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if dominant_df.empty:
            logging.error("dominant_df is empty.")
            return

        dominant_df['tq_filter_id'] = 'h'
        dominant_df['tq_marks'] = '20'

        # add cell_id, latitude and longitude columns in df
        dominant_df=fetch_predominent_data(dominant_df)

        for i in range(0,len(dominant_df),chunk_size):
            chunk_df = dominant_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for predominant_location.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())
    
        print("\n" + "+" * 30)
        print("predominant_location time:",time.time()-predominant_time)
        print("+" * 30 + "\n")
        
    except Exception :
        logging.error("Error in predominant_location query: %s", traceback.format_exc())

# filter (I)
def suspicious_apps_in_remote_location():
    suspicious_time = time.time()
  
    try:
        print("+" * 30)
        print("suspicious_apps_in_remote_location is in process.")
        print("+" * 30)

        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return  

        query = """
                SELECT DISTINCT phone_no, cell_id
                FROM isquare_staging_db.ipdr_details ip
                WHERE app_name IN (
                    SELECT app_name FROM file('suspicious_apps.csv', 'CSV', 'app_name String')
                )
                AND EXISTS (
                    SELECT phone_no
                    FROM isquare_staging_db.pre_dominent_cell_id rt 
                    WHERE rt.phone_no = ip.phone_no 
                    AND ip.cell_id IN splitByChar('|', rt.remote_location) 
                )
                """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        in_remote_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if in_remote_df.empty:
            logging.error("in_remote_df is empty.")
            return

        in_remote_df['tq_filter_id'] = 'i'
        in_remote_df['tq_marks'] = '20'  

        # add cell_id, latitude and longitude columns in df
        in_remote_df=fetch_predominent_data(in_remote_df)

        for i in range(0,len(in_remote_df),chunk_size):
            chunk_df = in_remote_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} records inserted for suspicious_apps_in_remote_location.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" * 40)
        print("suspicious_apps_in_remote_location time:",time.time()-suspicious_time)
        print("+" * 40 + "\n")

    except Exception :
        logging.error("Unexpected error in suspicious_apps_in_remote_location: %s", traceback.format_exc())

# filter (J)
def vpn_usage():
    vpn_usage_time =time.time()

    try:
        print("+" * 30)
        print("vpn_usage is in process.")
        print("+" * 30)

        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return  

        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return  

        query = f"""
                SELECT DISTINCT phone_no
                FROM (
                    SELECT phone_no, destination_ip_address, start_date_time, ip_country, vpn_name,
                           COUNT() OVER (PARTITION BY phone_no) AS session_count
                    FROM isquare_staging_db.ipdr_details 
                    WHERE toDateTime(start_date_time) BETWEEN toDateTime('{recent_date}') - INTERVAL 1 MONTH 
                        AND toDateTime('{recent_date}') 
                        AND public_ip_address != destination_ip_address
                        AND (is_vpn = 'True' OR vpn_tor = 'True' OR vpn_is_relay = 'True' OR vpn_proxy = 'True')
                        AND toInt32(destination_port) >= 10000
                        AND ip_country != 'INDIA'
                        AND vpn_name IS NOT NULL AND vpn_name != ''
                        AND (
                            (
                                (is_vpn = 'True' OR vpn_tor = 'True')
                                AND destination_port NOT IN (
                                    '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '443', 
                                    '500', '4500', '6881', '6882', '6883', '600', '4600', '1390', '3390', 
                                    '1723', '1194', '1701', '51820', '53133'
                                )
                            ) 
                            OR (
                                destination_port NOT IN (
                                    '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '443', 
                                    '500', '4500', '6881', '6882', '6883', '600', '4600', '1390', '3390', 
                                    '1723', '1194', '1701', '51820', '53133'
                                )
                                AND ip_country = 'INDIA'
                            )
                        )
                        AND phone_no IN (  
                            SELECT phone_no FROM file('phone_no_suspects.csv', 'CSV', 'phone_no String')
                        )
                ) AS filtered_data
                WHERE session_count < 300
                """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        vpn_usage_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if vpn_usage_df.empty:
            logging.error("vpn_usage_df is empty.")
            return

        vpn_usage_df['tq_filter_id'] = 'j'
        vpn_usage_df['tq_marks'] = '20'  

        # add cell_id, latitude and longitude columns in df
        vpn_usage_df=fetch_predominent_data(vpn_usage_df)

        for i in range(0,len(vpn_usage_df),chunk_size):
            chunk_df = vpn_usage_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} records inserted for vpn_usage.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" * 20)
        print("vpn_usage time:",time.time()-vpn_usage_time)
        print("+" * 20 + "\n")
        
    except Exception :
        logging.error("Unexpected error in vpn_usage: %s", traceback.format_exc())

# filter (K)
def change_imei():
    imei_time = time.time()

    try:
        print("+" * 30)
        print("change_imei is in process.")
        print("+" * 30)

        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return      

        query = """
                SELECT phone_no
                FROM isquare_staging_db.ipdr_details
                WHERE phone_no IS NOT NULL
                GROUP BY phone_no
                HAVING COUNT(DISTINCT imei_no) > 3
                """
        
        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        change_imei_df = pd.DataFrame(result.result_rows, columns=['phone_no'])  
        if change_imei_df.empty:
            logging.error("change_imei_df is empty.")
            return

        change_imei_df['tq_filter_id'] = 'k'
        change_imei_df['tq_marks'] = '10'  

        # add cell_id, latitude and longitude columns in df
        change_imei_df=fetch_predominent_data(change_imei_df)
        for i in range(0,len(change_imei_df),chunk_size):
            chunk_df = change_imei_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} records inserted for change_imei.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())
 
        print("\n" + "+" * 30)
        print("change_imei time:",time.time()-imei_time)
        print("+" * 30 + "\n")
       
    except Exception :
        logging.error("Unexpected error in change_imei: %s", traceback.format_exc())

# filter (L)
def asymmetric_calls():
    asymmetric_time = time.time()
    try:
        print("+" * 30)
        print("asymmetric_calls is in process.")
        print("+" * 30)

        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return      

        query = f"""
                SELECT DISTINCT phone_no
                FROM isquare_staging_db.ipdr_details 
                WHERE 
                    service_provider_detail NOT IN ('UNKNOWN', 'unknown')
                    AND t_detection = 'no'
                    AND voip_call_platform_name IS NOT NULL
                    AND toDateTime(start_date_time) BETWEEN toDateTime('{recent_date}') - INTERVAL 1 MONTH AND toDateTime('{recent_date}')
                    AND voip_call_platform_name LIKE '%WHATSAPP%'
                    AND b_party_table_status = 'yes'
                    AND destination_ip_address IS NULL
                """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        asymmetric_df = pd.DataFrame(result.result_rows, columns=['phone_no'])  
        if asymmetric_df.empty:
            logging.error("asymmetric_df is empty.")
            return

        asymmetric_df['tq_filter_id'] = 'l'
        asymmetric_df['tq_marks'] = '10' 

        # add cell_id, latitude and longitude columns in df
        asymmetric_df=fetch_predominent_data(asymmetric_df)
        for i in range(0,len(asymmetric_df),chunk_size):
            chunk_df = asymmetric_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} records inserted for asymmetric_calls.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" * 30)
        print("asymmetric_calls time:",time.time()-asymmetric_time)
        print("+" * 30 + "\n")
        
    except Exception :
        logging.error("Unexpected error in asymmetric_calls: %s", traceback.format_exc())


# filter (M)
def get_telegram_users():
    telegram_time = time.time()

    try:
        print("+" * 30)
        print("get_telegram_users is in process.")
        print("=" * 30)

        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return      

        query = """
                SELECT DISTINCT phone_no, cell_id
                FROM isquare_staging_db.ipdr_details ip
                WHERE voip_call_platform_name = 'TELEGRAM' 
                AND EXISTS (
                    SELECT phone_no
                    FROM isquare_staging_db.pre_dominent_cell_id rt 
                    WHERE rt.phone_no = ip.phone_no 
                    AND ip.cell_id IN splitByChar('|', rt.remote_location) 
                )
                """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        telegram_users_df = pd.DataFrame(result.result_rows, columns=['phone_no', 'cell_id'])  
        if telegram_users_df.empty:
            logging.error("telegram_users_df is empty.")
            return
        
        telegram_users_df = telegram_users_df.drop(columns=['cell_id'])
        telegram_users_df['tq_filter_id'] = 'm'
        telegram_users_df['tq_marks'] = '5' 

        # add cell_id, latitude and longitude columns in df
        telegram_users_df=fetch_predominent_data(telegram_users_df)
        for i in range(0,len(telegram_users_df),chunk_size):
            chunk_df = telegram_users_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for get_telegram_users.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" *30)
        print("get_telegram_users time:",time.time()-telegram_time)
        print("+" * 30 + "\n")
      
    except Exception :
        logging.error("Unexpected error in get_telegram_users: %s", traceback.format_exc())        

# filter (N)
def get_signal_users():
    signal_time = time.time()

    try:
        print("+" * 30)
        print("get_signal_users is in process.")
        print("+" * 30)

        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return      

        query = """
                SELECT DISTINCT phone_no, cell_id
                FROM isquare_staging_db.ipdr_details ip
                WHERE voip_call_platform_name LIKE '%SIGNAL%' 
                AND EXISTS (
                    SELECT phone_no
                    FROM isquare_staging_db.pre_dominent_cell_id rt 
                    WHERE rt.phone_no = ip.phone_no 
                    AND ip.cell_id IN splitByChar('|', rt.remote_location) 
                )
                """
        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        signal_users_df = pd.DataFrame(result.result_rows, columns=['phone_no', 'cell_id']) 
        if signal_users_df.empty:
            logging.error("signal_users_df is empty.")
            return
        
        signal_users_df = signal_users_df.drop(columns=['cell_id'])
        signal_users_df['tq_filter_id'] = 'n'
        signal_users_df['tq_marks'] = '-10'  

        # add cell_id, latitude and longitude columns in df
        signal_users_df=fetch_predominent_data(signal_users_df)
        for i in range(0,len(signal_users_df),chunk_size):
            chunk_df = signal_users_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for get_signal_users.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())

        print("\n" + "+" * 30)
        print("get_signal_users time:",time.time()-signal_time)
        print("+" * 30 + "\n")
       
    except Exception :
        logging.error("Unexpected error in get_signal_users: %s", traceback.format_exc())       

# filter (O)
def suspicious_apps_not_in_remote_location():
    suspicious_time = time.time()

    try:
        print("+"*45)
        print("suspicious_apps_not_in_remote_location is in process.")
        print("+"*45)
        
        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return       
        
        query = f"""
                SELECT distinct phone_no, cell_id
                FROM isquare_staging_db.ipdr_details ip
                WHERE app_name IN (
                    SELECT app_name FROM file('suspicious_apps.csv', 'CSV', 'app_name String')
                )
                AND EXISTS (
                    SELECT phone_no
                    FROM isquare_staging_db.pre_dominent_cell_id rt 
                    WHERE rt.phone_no = ip.phone_no 
                    AND ip.cell_id NOT IN splitByChar('|', rt.remote_location) 
                )
            """
        
        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        notin_remote_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if notin_remote_df.empty:
            logging.error("notin_remote_df is empty.")
            return
        
        notin_remote_df['tq_filter_id'] = 'o'
        notin_remote_df['tq_marks'] = '-15'   

        # add cell_id, latitude and longitude columns in df
        notin_remote_df=fetch_predominent_data(notin_remote_df)
        for i in range(0,len(notin_remote_df),chunk_size):
            chunk_df = notin_remote_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for suspicious_apps_not_in_remote_location.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())
    
        print("\n" + "+" * 45)
        print("suspicious_apps_not_in_remote_location time:",time.time()-suspicious_time)
        print("+" * 45 + "\n")
    

    except Exception :
        logging.error("Unexpected error in suspicious_apps_not_in_remote_location: %s", traceback.format_exc())  

# filter (P)
def stationary_target():
    stationary_time = time.time()

    try:
        print("+" * 30)
        print("stationary_target is in process.")
        print("+" * 30)
        
        recent_date = fetch_latest_date()
        if not recent_date:
            logging.error("Failed to fetch recent datetime.")
            return

        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return
        
        query = f"""
            SELECT phone_no
            FROM isquare_staging_db.ipdr_details
            WHERE cell_id IS NOT NULL
            AND toDateTime(start_date_time) BETWEEN toDateTime('{recent_date}') - INTERVAL 30 DAY AND toDateTime('{recent_date}')
            GROUP BY phone_no
            HAVING uniq(cell_id) < 50
        """
        
        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        stationary_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if stationary_df.empty:
            logging.error("stationary_df is empty.")
            return
        
        stationary_df['tq_filter_id'] = 'p'
        stationary_df['tq_marks'] = '-15' 

        # add cell_id, latitude and longitude columns in df
        stationary_df=fetch_predominent_data(stationary_df)

        for i in range(0,len(stationary_df),chunk_size):
            chunk_df = stationary_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for stationary_target.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())
       
        print("\n" + "+" * 30)
        print("stationary_target time:",time.time()-stationary_time)
        print("+" * 30 + "\n")

    except Exception :
        logging.error("Unexpected error in stationary_target: %s", traceback.format_exc())

# filter (R)
def bittorrent_users():
    torrent_time = time.time()
  
    try:
        print("+" * 30)
        print("bittorrent_users is in process.")
        print("+" * 30)
        
        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return
        
        query = """
                SELECT DISTINCT phone_no 
                FROM isquare_staging_db.ipdr_details 
                WHERE app_name = 'BITTORRENT CLIENT' 
                AND phone_no IS NOT NULL
                """

        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        torrent_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if torrent_df.empty:
            logging.error("torrent_df is empty.")
            return

        torrent_df['tq_filter_id'] = 'r'
        torrent_df['tq_marks'] = '-5'

        # add cell_id, latitude and longitude columns in df
        torrent_df=fetch_predominent_data(torrent_df)

        for i in range(0,len(torrent_df),chunk_size):
            chunk_df = torrent_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for bittorrent_users.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())
       
        print("\n" + "+" * 30)
        print("bittorrent_users time:",time.time()-torrent_time)
        print("+" * 30 + "\n")

    except Exception :
        logging.error("Unexpected error in bittorrent_users: %s", traceback.format_exc())     

# filter (S)
def gf_bf_calls():
    gf_bf_time = time.time()

    try:
        print("+" * 30)
        print("gf_bf_calls is in process.")
        print("+" * 30)
        
        client = create_client()
        if not client:
            logging.error("Failed to create database client.")
            return
        
        query = """
                SELECT phone_no
                FROM isquare_staging_db.ipdr_details
                WHERE 
                    service_provider_detail NOT IN ('UNKNOWN', 'unknown')
                    AND t_detection = 'no'
                    AND voip_call_platform_name IS NOT NULL
                    AND voip_call_status = '1'
                    AND voip_call_index = '0'  
                GROUP BY phone_no
                HAVING 
                    COUNTIf(toHour(toDateTime(start_date_time)) BETWEEN 0 AND 3) > 
                    COUNTIf(toHour(toDateTime(start_date_time)) BETWEEN 4 AND 22)
                """
        
        try:
            result = client.query(query)
        except Exception :
            logging.error("Query execution failed: %s", traceback.format_exc())
            return
        
        gf_bf_calls_df = pd.DataFrame(result.result_rows, columns=['phone_no'])
        if gf_bf_calls_df.empty:
            logging.error("gf_bf_calls_df is empty.")
            return

        gf_bf_calls_df['tq_filter_id'] = 's'
        gf_bf_calls_df['tq_marks'] = '-20'

        # add cell_id and lat_long columns in df
        gf_bf_calls_df=fetch_predominent_data(gf_bf_calls_df)
        for i in range(0,len(gf_bf_calls_df),chunk_size):
            chunk_df = gf_bf_calls_df[i:i+ chunk_size]
            try:
                client.insert(table, chunk_df.to_records(index=False).tolist(), column_names=list(chunk_df.columns))
                print(f"{len(chunk_df)} data inserted for gf_bf_calls.")
            except Exception :
                logging.error("Error while inserting data: %s", traceback.format_exc())
       
        print("\n" + "+" *30)
        print("gf_bf_calls time:",time.time()-gf_bf_time)
        print("+" * 30 + "\n")

    except Exception:
        logging.error("Unexpected error in gf_bf_calls: %s", traceback.format_exc())     


TQ_FILTERS = [pak_voip_calls,cdr_calls,low_ipdr_activity_users,identify_frequent_otp_calls,identify_frequent_otp_sms,b_party_vpn,predominant_location,suspicious_apps_in_remote_location,vpn_usage,change_imei,asymmetric_calls,get_telegram_users,get_signal_users,suspicious_apps_not_in_remote_location,stationary_target,bittorrent_users, gf_bf_calls]  

# execute single TQ Filter Function at a time
def main():
    total_time = time.time()
    for func in TQ_FILTERS:
        try:
            func()  
        except Exception:
            logging.error(f"Error in {func.__name__}: {traceback.format_exc()}")
            break

    print(f"Total TQ Time: {time.time() - total_time}")

if __name__ == "__main__":
    main()
