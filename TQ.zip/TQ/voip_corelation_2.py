import hashlib
import logging
import time
import traceback
import clickhouse_connect
import pandas as pd
import json

logging.basicConfig(filename='voip_corelation.log',  level=logging.ERROR,format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

json_file= open('database.config','r').read()
database = json.loads(json_file)

click_house_node1 = database['click_house_node1']
click_house_node2 = database['click_house_node2']
click_house_node3 = database['click_house_node3']

CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

# Prepare clickhouse configuration
clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node1}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node2}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        {
            "url": f"http://{click_house_node3}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        },
        # Add more nodes as necessary
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}

def create_client_node(node):
    try:
        client = clickhouse_connect.get_client(
            host=node["url"].replace("http://", ""),
            port=node["port"],
            username=node["username"],
            password=node["password"],
            compress=clickhouse_configs["is_use_gzip"],
        )
        return client
    except Exception as error:
        print(f"Failed to connect to ClickHouse node {node['url']}: {error}")
        return None

def data_insertion(df,table):
    if df.empty:
        print("DataFrame is empty. No data to insert.")
        return
    try:
        df = df[sorted(df.columns)].astype(str)
        client = create_client_node(clickhouse_configs["nodes"][2])  
        if client:
            client.insert(table, df.to_records(index=False).tolist(), column_names=list(df.columns))
            print(f"Data inserted successfully into table {table}.")
    except Exception as error:
        print(f"Error during data insertion: {error}")
     
def select_data(query):
    try:
        print()
        print(query)
        client = create_client_node(clickhouse_configs["nodes"][1]) 
        if client:
            result = client.query(query)
            print("Query executed successfully.")
            return result.result_rows, result.column_names
    except Exception as error:

        print(f"Error during SELECT query execution: {error}")
        return None

def process_bidirectional_correlations_bulk(ipdr_data_df):
    print("Bulk correlation processing started...")

    ipdr_data_df['start_date_time_from'] = ipdr_data_df['start_date_time'].astype(int) - 120
    ipdr_data_df['start_date_time_to'] = ipdr_data_df['end_date_time'].astype(int) + 120

    ipdr_data_df['destination_ip_address_main'] = ipdr_data_df['destination_ip_address'].astype(str).str.strip()
    ipdr_data_df['public_ip_address_main'] = ipdr_data_df['public_ip_address'].astype(str).str.strip()
    ipdr_data_df['source_ip_address_main'] = ipdr_data_df['source_ip_address'].astype(str).str.strip()

    batch_tuples = list(zip(
        ipdr_data_df['phone_no'],
        ipdr_data_df['public_ip_address_main'],
        ipdr_data_df['destination_ip_address_main'],
        ipdr_data_df['start_date_time_from'],
        ipdr_data_df['start_date_time_to'],
        ipdr_data_df['destination_port'],
        ipdr_data_df['public_ip_port']
    ))

    # [1] PUBLIC IP ADDRESS: Bidirectional correlation count check for Public IP address
    bulk_count_query = f"""
    SELECT count(*) 
    FROM mact.ipdr_details b
    JOIN (
        SELECT 
            tupleElement(1) as a_party,
            tupleElement(2) as a_public_ip,
            tupleElement(3) as a_dest_ip,
            tupleElement(4) as min_time,
            tupleElement(5) as max_time
        FROM VALUES {','.join([str(t) for t in batch_tuples])}
    ) a ON 
        b.public_ip_address = a.a_dest_ip
        AND b.destination_ip_address = a.a_public_ip
        AND b.start_date_time BETWEEN a.min_time AND a.max_time
        AND b.phone_no != a.a_party
    WHERE NOT (b.mapper_name LIKE '%CDR%')
      AND b.b_party_table_status = 'yes'
    """
    row_data, column_data = select_data(bulk_count_query)
    total_rows = row_data[0][0]
    print(total_rows)
  
def correlation_data_insertion_for_bidirectional(ipdr_data_df_row):
    print("correlation_data_insertion_for_bidirectional called.")
    a_party = ipdr_data_df_row['phone_no']
    start_date_time_from = int(ipdr_data_df_row['start_date_time'])-1800
    start_date_time_to = int(ipdr_data_df_row['end_date_time'])+1800
    destination_ip_address_main = str(ipdr_data_df_row['destination_ip_address']).strip()
    destination_port_main = ipdr_data_df_row['destination_port']
    public_ip_address_main = str(ipdr_data_df_row['public_ip_address']).strip()
    public_ip_port_main = ipdr_data_df_row['public_ip_port']
    source_ip_address_main = str(ipdr_data_df_row['source_ip_address']).strip()
    source_port_main = ipdr_data_df_row['source_port']

    count_check_query = f"""SELECT count(*) FROM mact.ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND public_ip_address = '{destination_ip_address_main}' AND destination_ip_address = '{public_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes';"""
    row_data, column_data = select_data(count_check_query)
    total_rows = row_data[0][0]
    print("pheli query bi ki ka total_rows:",total_rows)
    if total_rows > 0:
        total_corelation_rows = total_rows
        start_corelation_counter = 0
        row_corelation_counter = 100000
        while True:
            # fetch data in chunk
            main_query = f"""SELECT b_party, public_ip_address, public_ip_port, source_ip_address, source_port, destination_ip_address, destination_port, start_date_time, end_date_time, imei_no, imsi_no, cell_id, tower_location, service_provider_detail, session_duration, ip_country FROM mact.ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND public_ip_address = '{public_ip_address_main}' AND destination_ip_address = '{destination_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes' LIMIT {row_corelation_counter} OFFSET {start_corelation_counter};"""
            row_data, column_data = select_data(main_query)
            if row_data:
                b_party_ipdr_data_df = pd.DataFrame(row_data, columns=column_data)
                b_party_ipdr_data_df['is_public_ip_match'] = "yes"
                b_party_ipdr_data_df['is_public_ip_port_match'] = b_party_ipdr_data_df['public_ip_port'].apply(lambda x: "yes" if x == destination_port_main  else "no")
                b_party_ipdr_data_df['a_party'] = a_party
                try:
                    b_party_ipdr_data_df['imei_no'] = ipdr_data_df_row['imei_no']
                except:
                    b_party_ipdr_data_df['imei_no'] = ''
                try:
                    b_party_ipdr_data_df['imsi_no'] = ipdr_data_df_row['imsi_no']
                except:
                    b_party_ipdr_data_df['imsi_no'] = ''
                            
                b_party_ipdr_data_df['public_ip_address'] = ipdr_data_df_row['public_ip_address'].strip()
                b_party_ipdr_data_df['public_ip_port'] = ipdr_data_df_row['public_ip_port']
                b_party_ipdr_data_df['source_ip_address'] = ipdr_data_df_row['source_ip_address'].strip()
                b_party_ipdr_data_df['source_port'] = ipdr_data_df_row['source_port']
                b_party_ipdr_data_df['destination_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                b_party_ipdr_data_df['destination_port'] = ipdr_data_df_row['destination_port']
                b_party_ipdr_data_df['start_date_time'] = ipdr_data_df_row['start_date_time']
                b_party_ipdr_data_df['end_date_time'] = ipdr_data_df_row['end_date_time']
                b_party_ipdr_data_df['session_duration'] = ipdr_data_df_row['session_duration']
                try:
                    b_party_ipdr_data_df['cell_id'] = b_party_ipdr_data_df['cell_id']
                except:
                        b_party_ipdr_data_df['cell_id'] = ''
                try:
                    b_party_ipdr_data_df['tower_location'] = ipdr_data_df_row['tower_location']
                except:b_party_ipdr_data_df['tower_location'] = ''
                b_party_ipdr_data_df['service_provider_detail'] = ipdr_data_df_row['service_provider_detail']
                b_party_ipdr_data_df['is_source_ip_match'] = "no"
                b_party_ipdr_data_df['is_source_port_match'] = "no"
                b_party_ipdr_data_df['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                b_party_ipdr_data_df['ip_country'] = ipdr_data_df_row['ip_country']
                b_party_ipdr_data_df['direction'] = 2
                            
                b_party_ipdr_data_df['correlation_hash'] = b_party_ipdr_data_df.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}'.format(str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask = b_party_ipdr_data_df.duplicated(subset='correlation_hash', keep='first')
                b_party_ipdr_data_df = b_party_ipdr_data_df[~b_party_remove_duplicate_mask]

                # Insert data to the p2p_connections_solr table
                # data_insertion(b_party_ipdr_data_df,'p2p_connections')
                print("length of b_party_ipdr_data_df:",len(b_party_ipdr_data_df))

                b_party_ipdr_data_df2 = pd.DataFrame(row_data, columns=column_data)
                b_party_ipdr_data_df2['is_public_ip_match'] = b_party_ipdr_data_df2['destination_ip_address'].apply(lambda x: "yes" if x == public_ip_address_main  else "no")
                b_party_ipdr_data_df2['is_public_ip_port_match'] = b_party_ipdr_data_df2['destination_port'].apply(lambda x: "yes" if x == public_ip_port_main  else "no")
                b_party_ipdr_data_df2['a_party'] = b_party_ipdr_data_df2['b_party']
                b_party_ipdr_data_df2['b_party'] = a_party
                b_party_ipdr_data_df2['start_date_time'] = ipdr_data_df_row['start_date_time']
                b_party_ipdr_data_df2['end_date_time'] = ipdr_data_df_row['end_date_time']
                b_party_ipdr_data_df2['session_duration'] = ipdr_data_df_row['session_duration']
                b_party_ipdr_data_df2['is_source_ip_match'] = "no"
                b_party_ipdr_data_df2['is_source_port_match'] = "no"
                b_party_ipdr_data_df2['destination_ip_address'] = ipdr_data_df_row['public_ip_address'].strip()
                b_party_ipdr_data_df2['destination_port'] = ipdr_data_df_row['public_ip_port']
                b_party_ipdr_data_df2['public_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                b_party_ipdr_data_df2['public_ip_port'] = ipdr_data_df_row['destination_port']
                try:
                    b_party_ipdr_data_df2['cell_id'] = ipdr_data_df_row['cell_id']
                except:
                    b_party_ipdr_data_df2['cell_id'] = ''
                b_party_ipdr_data_df2['direction'] = 2
                b_party_ipdr_data_df2['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                b_party_ipdr_data_df2['correlation_hash'] = b_party_ipdr_data_df2.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}'.format(str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask2 = b_party_ipdr_data_df2.duplicated(subset='correlation_hash', keep='first')
                b_party_ipdr_data_df2 = b_party_ipdr_data_df2[~b_party_remove_duplicate_mask2]
                # Insert data to the p2p_connections_solr table
                # data_insertion(b_party_ipdr_data_df2,'p2p_connections')
                print("length of b_party_ipdr_data_df2:",len(b_party_ipdr_data_df2))

            # Increamnet and exit the loop once all rows are processed
            start_corelation_counter += row_corelation_counter
            if start_corelation_counter>=total_corelation_rows:
                break

    # [2] SOURCE IP ADDRESS: Bidirectional correlation count check for Source IP address
    count_check_query = f"""SELECT count(*) FROM mact.ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND source_ip_address = '{destination_ip_address_main}' AND destination_ip_address = '{source_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes';"""
    row_data, column_data = select_data(count_check_query)
    total_rows = row_data[0][0]
    print("dusri query bi ki ka total_rows:",total_rows)

    if total_rows > 0:
        total_corelation_rows = total_rows
        start_corelation_counter = 0
        row_corelation_counter =100000
        while True:
            # fetch data in chunk
            main_query = f"""SELECT b_party, public_ip_address, public_ip_port, source_ip_address, source_port, destination_ip_address, destination_port, start_date_time, end_date_time, imei_no, imsi_no, cell_id, tower_location, service_provider_detail, session_duration, ip_country FROM mact.ipdr_details WHERE start_date_time >= '{start_date_time_from}' AND start_date_time <= '{start_date_time_to}' AND NOT (mapper_name LIKE '%CDR%') AND source_ip_address = '{destination_ip_address_main}' AND destination_ip_address = '{source_ip_address_main}' AND phone_no != '{a_party}' AND b_party_table_status = 'yes' LIMIT {row_corelation_counter} OFFSET {start_corelation_counter};"""
            row_data, column_data = select_data(main_query)
            if row_data:
                source_b_party_ipdr_data_df = pd.DataFrame(row_data, columns=column_data)
                source_b_party_ipdr_data_df['is_source_ip_match'] = "yes"
                source_b_party_ipdr_data_df['is_source_port_match'] = source_b_party_ipdr_data_df['source_port'].apply(lambda x: "yes" if x == destination_port_main  else "no")
                source_b_party_ipdr_data_df['is_public_ip_match'] = "no"
                source_b_party_ipdr_data_df['is_public_ip_port_match'] = "no"
                source_b_party_ipdr_data_df['a_party'] = a_party
                try:
                    source_b_party_ipdr_data_df['imei_no'] = ipdr_data_df_row['imei_no']
                except:
                    source_b_party_ipdr_data_df['imei_no'] = ''
                try:
                    source_b_party_ipdr_data_df['imsi_no'] = ipdr_data_df_row['imsi_no']
                except:
                    source_b_party_ipdr_data_df['imsi_no'] = ''

                source_b_party_ipdr_data_df['public_ip_address'] = ipdr_data_df_row['public_ip_address'].strip()
                source_b_party_ipdr_data_df['public_ip_port'] = ipdr_data_df_row['public_ip_port']
                source_b_party_ipdr_data_df['source_ip_address'] = ipdr_data_df_row['source_ip_address'].strip()
                source_b_party_ipdr_data_df['source_port'] = ipdr_data_df_row['source_port']
                source_b_party_ipdr_data_df['destination_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                source_b_party_ipdr_data_df['destination_port'] = ipdr_data_df_row['destination_port']
                source_b_party_ipdr_data_df['start_date_time'] = ipdr_data_df_row['start_date_time']
                source_b_party_ipdr_data_df['end_date_time'] = ipdr_data_df_row['end_date_time']
                source_b_party_ipdr_data_df['session_duration'] = ipdr_data_df_row['session_duration']
                try:
                    source_b_party_ipdr_data_df['cell_id'] = source_b_party_ipdr_data_df['cell_id']
                except:
                    source_b_party_ipdr_data_df['cell_id'] = ''
                source_b_party_ipdr_data_df['tower_location'] = ipdr_data_df_row['tower_location']
                source_b_party_ipdr_data_df['service_provider_detail'] = ipdr_data_df_row['service_provider_detail']
                source_b_party_ipdr_data_df['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                source_b_party_ipdr_data_df['ip_country'] = ipdr_data_df_row['ip_country']
                source_b_party_ipdr_data_df['direction'] = 2
                            
                source_b_party_ipdr_data_df['correlation_hash'] = source_b_party_ipdr_data_df.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}'.format(str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask = source_b_party_ipdr_data_df.duplicated(subset='correlation_hash', keep='first')
                source_b_party_ipdr_data_df = source_b_party_ipdr_data_df[~b_party_remove_duplicate_mask]

                # Insertion of data in p2p_connections_solr table
                # data_insertion(source_b_party_ipdr_data_df,'p2p_connections')
                print("length of source_b_party_ipdr_data_df:",len(source_b_party_ipdr_data_df))

                source_b_party_ipdr_data_df2 = pd.DataFrame(row_data, columns=column_data)
                source_b_party_ipdr_data_df2['is_source_ip_match'] = source_b_party_ipdr_data_df2['destination_ip_address'].apply(lambda x: "yes" if x == source_ip_address_main  else "no")
                source_b_party_ipdr_data_df2['is_source_port_match'] = source_b_party_ipdr_data_df2['destination_port'].apply(lambda x: "yes" if x == source_port_main  else "no")
                source_b_party_ipdr_data_df2['is_public_ip_match'] = "no"
                source_b_party_ipdr_data_df2['is_public_ip_port_match'] = "no"
                source_b_party_ipdr_data_df2['start_date_time'] = ipdr_data_df_row['start_date_time']
                source_b_party_ipdr_data_df2['end_date_time'] = ipdr_data_df_row['end_date_time']
                source_b_party_ipdr_data_df2['session_duration'] = ipdr_data_df_row['session_duration']

                            
                source_b_party_ipdr_data_df2['destination_ip_address'] = ipdr_data_df_row['source_ip_address'].strip()
                source_b_party_ipdr_data_df2['destination_port'] = ipdr_data_df_row['source_port']
                source_b_party_ipdr_data_df2['source_ip_address'] = ipdr_data_df_row['destination_ip_address'].strip()
                source_b_party_ipdr_data_df2['source_port'] = ipdr_data_df_row['destination_port']
                try:
                    source_b_party_ipdr_data_df2['cell_id'] = ipdr_data_df_row['cell_id']
                except:
                    source_b_party_ipdr_data_df2['cell_id'] = ''
                            
                source_b_party_ipdr_data_df2['a_party'] = source_b_party_ipdr_data_df2['b_party']
                source_b_party_ipdr_data_df2['b_party'] = a_party
                source_b_party_ipdr_data_df2['is_source_ip_match'] = "no"
                source_b_party_ipdr_data_df2['is_source_port_match'] = "no"
                source_b_party_ipdr_data_df2['b_party_table_status'] = ipdr_data_df_row['b_party_table_status']
                source_b_party_ipdr_data_df2['direction'] = 2

                source_b_party_ipdr_data_df2['correlation_hash'] = source_b_party_ipdr_data_df2.apply(lambda x: hashlib.sha256('{}{}{}{}{}{}{}{}{}'.format(str(x.b_party),str(x.a_party),str(x.start_date_time),str(x.end_date_time),str(x.is_public_ip_match),str(x.is_public_ip_port_match),str(x.is_source_ip_match),str(x.is_source_port_match),str(x.direction)).encode()).hexdigest(), axis=1)
                b_party_remove_duplicate_mask2 = source_b_party_ipdr_data_df2.duplicated(subset='correlation_hash', keep='first')
                source_b_party_ipdr_data_df2 = source_b_party_ipdr_data_df2[~b_party_remove_duplicate_mask2]
                # Insertion of data in p2p_connections table
                # data_insertion(source_b_party_ipdr_data_df2,'p2p_connections')
                print("length of source_b_party_ipdr_data_df2:",len(source_b_party_ipdr_data_df2))

            else:
                break

            # Increment the corelation counter and check if it exceeds the total corelation rows
            start_corelation_counter += row_corelation_counter
            if start_corelation_counter>=total_corelation_rows:
                break

def known_voip_corelation_integerator():    
    print("into the known voip call")

    query = f"""SELECT COUNT(*) AS num_found FROM mact.ipdr_details WHERE NOT (mapper_name LIKE '%CDR%') AND public_ip_address != destination_ip_address AND destination_port >= '1000' AND b_party_table_status = 'yes';"""
    response_row, response_column = select_data(query)
    num_found = response_row[0][0]
    if int(num_found) > 0:
        total_rows = num_found
        start_counter = 0
        row_counter = 100000
        
        while True:
            # Query with remove unwanted destination ports 
            query = f"""
                    SELECT phone_no, imei_no, imsi_no, public_ip_address, public_ip_port,
                        source_ip_address, source_port, destination_ip_address, destination_port,
                        start_date_time, end_date_time, session_duration, cell_id, tower_location,
                        service_provider_detail, b_party_table_status, ip_country
                    FROM mact.ipdr_details
                    WHERE NOT (mapper_name LIKE '%CDR%')
                    AND public_ip_address != destination_ip_address
                    AND destination_port >= '1000'
                    AND destination_port NOT IN (
                        '80', '53', '443', '123', '5222', '5223', '5228', '8443', '8130', '853',
                        '500', '4500', '8080', '6881', '6882', '6883', '600', '1600', '4600', '1390',
                        '3390', '1723', '1194', '1701', '5242', '3478', '3479', '3480', '3481', '3482',
                        '3483', '3484', '3485', '3486', '3487', '3488', '3489', '3490', '3491', '3492',
                        '3493', '3494', '3495', '3496', '3497', '5349', '1400', '599', '19302', '19305'
                    )
                    AND b_party_table_status = 'yes'
                    LIMIT {row_counter} OFFSET {start_counter}
                    """            
            ipdr_data, response_ipdr_column = select_data(query)               

            if ipdr_data:
                ipdr_data_df = pd.DataFrame(ipdr_data, columns=[
                    'phone_no', 'imei_no', 'imsi_no', 'public_ip_address', 'public_ip_port',
                    'source_ip_address', 'source_port', 'destination_ip_address', 'destination_port',
                    'start_date_time', 'end_date_time', 'session_duration', 'cell_id', 'tower_location',
                    'service_provider_detail', 'b_party_table_status', 'ip_country'
                ])
                # Call correlation function
                process_bidirectional_correlations_bulk(ipdr_data_df)

            else:
                break
            
            start_counter += row_counter
            if start_counter >= total_rows:
                break

if __name__ == '__main__':
    try:
        total_time = time.time()
        known_voip_corelation_integerator()
        print("total_time:",time.time()-total_time)
    except Exception:
        logging.error('known_voip_corelation_integerator Failed: '+str(traceback.format_exc()))


   