
# def calculate_tq_profile():
#     try:
#         tq_time = time.time()
#         print("-"*30)
#         print("CALCULATING TQ PROFILE.")
#         print("-"*30)
        
#         client = create_client()
#         query = f"""
                    
#                 SELECT 
#                 phone_no,
#                 SUM(tq_marks) AS tq_score_total,
#                 SUM(CASE WHEN tq_marks >= 0 THEN tq_marks ELSE 0 END) AS tq_score_positive,
#                 SUM(CASE WHEN tq_marks < 0 THEN tq_marks ELSE 0 END) AS tq_score_negative
#             FROM isquare_staging_db.tq_filters
#             GROUP BY phone_no
#                 """
#         result = client.query(query)
#         profile_df = pd.DataFrame(result.result_rows, columns=['phone_no','tq_score_total','tq_score_positive','tq_score_negative'])
        

#         if not profile_df.empty:
#             client.insert(table2, profile_df.to_records(index=False).tolist(),column_names=list(profile_df.columns))
#             print(f"{len(profile_df)} data inserted for calculate_tq_profile is completed.")
#             print(f"tq time: {time.time()-tq_time}")
#             print("+"*30+"\n")
#         else:
#             logging.error("profile_df is Empty.")
#     except Exception as e:
#         logging.error("error in calculate_tq_profile: %s",str(e))



# def fetch_data_tq_master(df):
#     try:
#         id = df['tq_filter_id'].iloc[0]
#         client = create_client()
#         query = f"""
#                     SELECT tq_marks FROM isquare_staging_db.tq_master WHERE tq_filter_id = '{id}'
#                 """
#         return client.query(query).result_rows[0][0]
        
#     except Exception as e:
#         logging.error("Error in fetch_data_tq_master query: %s",str(e))   