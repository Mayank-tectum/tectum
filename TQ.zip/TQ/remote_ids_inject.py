import hashlib
import traceback
import clickhouse_connect
import pandas as pd
import json

json_file = open('database.config', 'r').read()
database = json.loads(json_file)

# ClickHouse connection details
click_house_node = database['click_house_node1']
CLICKHOUSE_PORT = database['click_house_port']
CLICKHOUSE_USER = database['click_house_username']
CLICKHOUSE_PASSWORD = database['click_house_password']
DATABASE = database['click_house_database']

def create_client():
    try:
        client = clickhouse_connect.get_client(
        host=click_house_node,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=DATABASE
        )
        return client
    except Exception:
        print(traceback.format_exc())

clickhouse_configs = {
    "nodes": [
        {
            "url": f"http://{click_house_node}",
            "port": CLICKHOUSE_PORT,
            "username": CLICKHOUSE_USER,
            "password": CLICKHOUSE_PASSWORD,
        }
        
    ],
    "is_use_gzip": True,
    "format": "json",
    "raw": False,
}        

def remote_location():
    try:
        print("remote id processing....")
        df = pd.read_csv('unique.csv')
        client = create_client()
        records = []
        count = 0
        for num in df['phone_no'].tolist():
            query = f"""
                        SELECT 
                        t1.phone_no,
                        t1.cell_id,
                        t1.tower_location,
                        t1.tower_district,
                        t1.tower_pincode,
                        t1.tower_latitude,
                        t1.tower_longitude,
                        groupUniqArray(t2.tower_cgi) AS tower_cgi_list
                    FROM isquare_staging_db.tower_test AS t2
                    GLOBAL JOIN (
                        SELECT 
                            phone_no,
                            cell_id,
                            tower_latitude,
                            tower_longitude,
                            tower_location,
                            tower_district,
                            tower_pincode
                        FROM isquare_staging_db.ipdr_details
                        WHERE phone_no = '{num}'
                        AND day_night = 'N'
                        AND cell_id IS NOT NULL 
                        AND tower_latitude IS NOT NULL 
                        AND tower_longitude IS NOT NULL
                        GROUP BY phone_no, cell_id, tower_latitude, tower_longitude, tower_location, tower_district, tower_pincode
                        ORDER BY COUNT(*) DESC
                        LIMIT 1 BY phone_no
                    ) AS t1 ON 1 = 1
                    WHERE greatCircleDistance(
                        toFloat64OrZero(t2.tower_latitude), 
                        toFloat64OrZero(t2.tower_longitude), 
                        toFloat64OrZero(t1.tower_latitude),  
                        toFloat64OrZero(t1.tower_longitude)
                    ) BETWEEN 3000 AND 15000
                    GROUP BY 
                        t1.phone_no, 
                        t1.cell_id,
                        t1.tower_location,
                        t1.tower_district,
                        t1.tower_pincode,
                        t1.tower_latitude,
                        t1.tower_longitude
                    """
            result = client.query(query) 
            
            if result.result_rows:  
                for row in result.result_rows:  
                    phone_no, cell_id, tower_location, tower_district, tower_pincode, latitude, longitude, tower_cgi_list = row
                    
                    # Generate hash
                    hash_input = f"{phone_no}{cell_id}{latitude}{longitude}"
                    phone_cell_id_hash = hashlib.md5(hash_input.encode()).hexdigest()
                    records.append((phone_no, cell_id, phone_cell_id_hash, latitude,longitude, tower_district, tower_pincode,tower_cgi_list))
                    print(f"{count} number processed out of 20000.")
                    count += 1

        # insert records
        if records:
            try:
                df_to_insert = pd.DataFrame(records, columns=['phone_no', 'cell_id', 'phone_cell_id_hash', 'latitude','longitude', 'tower_district', 'tower_pincode', 'remote_ids'])
                client.insert('isquare_staging_db.pre_dominent_cell_id', df_to_insert.to_records(index=False).tolist(), column_names=list(df_to_insert.columns))
                print(f"Inserted {len(records)} records successfully!")
            except Exception:
                print(traceback.format_exc())

    except Exception:
        print(traceback.format_exc())


if __name__ == "__main__":
    remote_location()