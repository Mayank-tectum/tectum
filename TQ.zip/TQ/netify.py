import requests
import gzip
import json
from io import BytesIO

api_key = "sk_tt_live_YWZmMWFmMDBjZDcxZDdlYWQ" 

url = "https://feeds.netify.ai/datasets/v2/vpns/vpns.json.gz"
headers = {"Authorization": f"Bearer {api_key}"}

response = requests.get(url, headers=headers)

if response.status_code == 200:
    with gzip.GzipFile(fileobj=BytesIO(response.content)) as f:
        data = json.load(f)
        print("JSON data fetched.")
        print(json.dumps(data[:2], indent=2))  
else:
    print("❌ Failed to fetch JSON:", response.status_code, response.text)
