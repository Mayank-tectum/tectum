# import json
# import pandas as pd
# import MySQLdb

# def ipdr_conn():
#     try:
#         json_file = open('database.config','r').read()
#         database = json.loads(json_file)
#         return MySQLdb.connect(
#             host=database['database_url'],
#             port=database['database_port'],  
#             user=database['database_user'],
#             passwd=database['database_password'],
#             db=database['database_name']
#         )
#     except Exception as e:
#         print("[ERROR]:",str(e))

# def test_function(df):
    
#     id = df['tq_filter_id'].iloc[0]
#     conn=ipdr_conn()
#     cur=conn.cursor()
#     cur.execute( f"SELECT tq_marks FROM ipdr_data.tq_master WHERE tq_filter_id = '{id}'")
#     marks = cur.fetchall()    
#     conn.commit()
#     conn.close()
#     return marks[0][0]
    
   
        
# data = {
#     'tq_filter_id': ['a', 'a', 'a', 'a', 'a'],
#     'column_2': [1, 2, 3, 4, 5],
#     'column_3': [6, 7, 8, 9, 10]
# }

# df = pd.DataFrame(data)
# marks=test_function(df)
# print("marks:",marks)

# update check for predominant script 

# import pandas as pd
# df = pd.DataFrame({
#     'phone_no': ['123', '456', '789'],
#     'cell_id': ['', '', ''],
#     'lat_long': ['', '', '']
# })
# print("Original DataFrame:\n", df)

# final_df = pd.DataFrame({
#     'phone_no': ['123', '456'],
#     'cell_id': ['cellA', 'cellB'],
#     'lat_long': ['12.34,56.78', '98.76,54.32']
# })
# final_df = final_df.set_index('phone_no')  
# print("\nFinal DataFrame to update with:\n", final_df)

# df.set_index('phone_no', inplace=True)
# df.update(final_df, overwrite=True)
# df.reset_index(inplace=True)

# print("\nUpdated DataFrame:\n", df)


# import pandas as pd

# # Sample DataFrame simulating tower_lat_long
# df = pd.DataFrame({
#     'phone_no': ['9876543210', '9123456780'],
#     'tower_lat_long': ['18.5204,73.8567', '19.0760,72.8777']
# })

# # Split tower_lat_long into latitude and longitude
# df[['latitude', 'longitude']] = df['tower_lat_long'].str.split(',', expand=True)

# # Display result
# print(df)




# import time
# import pandas as pd
# import numpy as np

# # Creating a sample DataFrame with None, '', 0, and NaN values
# data = {
#     'public_ip_address': [None, '', '192.168.1.1', 0, '10.0.0.1'],
#     'destination_ip_address': ['192.168.1.2', '', None, 0, ''],
#     'source_ip_address': [np.nan, '10.0.0.2', '', '172.16.0.1', None]
# }

# # Sample DataFrame
# df = pd.DataFrame(data)
# else_time = time.time()

# df['public_ip_address'] = df['public_ip_address'].apply(lambda x: x if x else '')
# df['destination_ip_address'] = df['destination_ip_address'].apply(lambda x: x if x else '')
# df['source_ip_address'] = df['source_ip_address'].apply(lambda x: x if x else '') 

# # cols = ['public_ip_address','destination_ip_address','source_ip_address']
# # df[cols] = df[cols].replace([None, '', 0], '')
# print(f"else_time:{time.time()-else_time}")

# print(df)



